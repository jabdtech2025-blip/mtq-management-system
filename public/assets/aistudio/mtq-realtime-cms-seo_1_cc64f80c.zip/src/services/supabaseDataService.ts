import {
  supabase,
  isSupabaseConfigured,
  getSupabaseConnectionInfo,
  setRuntimeSupabaseConnectionState,
  createEphemeralSupabaseAuthClient,
  SupabaseConnectionInfo
} from '../lib/supabaseClient';
import {
  Tenant,
  User,
  Kafilah,
  Participant,
  StageParticipation,
  Question,
  ErrorCategory,
  JudgeAssessment,
  CompetitionStage,
  JudgeAssignment,
  AuditLogItem,
  GenericMasterItem,
  CompetitionRuleConfig,
  StageResultSnapshot,
  RubricVersion,
  RubricField,
  RubricCriterion,
  DeductionRule,
  LotteryDrawLogItem,
  LotteryDrawResultItem,
  SiteSettings,
  DEFAULT_SITE_SETTINGS,
  PlatformHealthCheckItem
} from '../types/mtq';
import { generateUuid, isValidUuid, toDeterministicUuid, validateDatabaseUuids } from '../utils/uuid';
import { formatDateTimeWIB } from '../utils/dateTime';

export interface RpcServiceResult<T = Record<string, any>> {
  success: boolean;
  message: string;
  mode: 'supabase_live' | 'local_offline_fallback';
  data?: T;
  validationErrors?: string[];
}

export interface AuthenticatedSupabaseProfile {
  authUserId: string;
  email: string;
  name: string;
  username: string;
  globalRole: 'superadmin' | 'admin' | 'judge';
  hasProfileRow: boolean;
  inactiveMembershipsCount: number;
  verificationError?: string;
  memberships: Array<{
    tenantId: string;
    role: 'superadmin' | 'admin' | 'judge';
    judgeCategory?: string;
    judgeField?: string;
    status: string;
  }>;
}

export interface HydratedWorkspacePayload {
  tenants: Tenant[];
  users: User[];
  cabangList: GenericMasterItem[];
  jenjangList: GenericMasterItem[];
  kafilahs: Kafilah[];
  participants: Participant[];
  stages: CompetitionStage[];
  stageParticipations: StageParticipation[];
  questions: Question[];
  errorCategories: ErrorCategory[];
  rubricVersions: RubricVersion[];
  competitionRules: CompetitionRuleConfig[];
  judgeAssignments: JudgeAssignment[];
  assessments: JudgeAssessment[];
  stageSnapshots: StageResultSnapshot[];
  auditLogs: AuditLogItem[];
  lotteryDrawLogs?: LotteryDrawLogItem[];
}

export interface WorkspaceHydrationResult {
  success: boolean;
  tenantId: string;
  mode: 'supabase_live' | 'demo_local';
  error?: string;
  failedQueries?: string[];
  payload: HydratedWorkspacePayload | null;
}

export interface DatabaseReferenceCheckInput {
  tenantId?: string | null;
  branchId?: string | null;
  levelId?: string | null;
  stageId?: string | null;
  kafilahId?: string | null;
  participantId?: string | null;
  stageParticipationId?: string | null;
  assignedMaqraId?: string | null;
  judgeProfileId?: string | null;
  rubricVersionId?: string | null;
  questionId?: string | null;
}

// Memungkinkan injeksi client database lokal (PGlite adapter) pada pengujian otomatis
// tanpa menyentuh proyek Supabase remote milik pengguna.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let injectedDatabaseClient: any = null;

function getActiveClient() {
  return injectedDatabaseClient || supabase;
}

const SYSTEM_TENANT_UUID = '00000000-0000-0000-0000-000000000000';

/**
 * Service Data Terpusat untuk Operasi Database Supabase, Validasi UUID & Keberadaan FK, Autentikasi, & RPC.
 * - Tidak pernah menggunakan service_role key di frontend.
 * - Memastikan seluruh foreign key benar-benar ada di database sebelum upsert/RPC.
 * - Menggunakan ID baris nyata dari database untuk assigned_maqras dan stage_participations.
 * - Memeriksa error setiap query pada hidrasi workspace dan tidak mencampur data demo saat mode database aktif.
 */
/** Data pendukung untuk mengubah baris tabel judge_assessments menjadi JudgeAssessment. */
export interface AssessmentRowLookups {
  spById: Map<string, StageParticipation>;
  questionIdByAssignedMaqraId: Map<string, string>;
  judgeInfoById: Map<string, { name: string; field: string }>;
}

/**
 * Ubah satu baris judge_assessments (dari query atau dari event realtime) menjadi JudgeAssessment.
 * Dipakai bersama oleh pemuatan workspace penuh dan pembaruan realtime per baris.
 */
export function mapJudgeAssessmentRow(a: Record<string, unknown>, lookups: AssessmentRowLookups): JudgeAssessment {
  const spId = String(a.stage_participation_id);
  const spObj = lookups.spById.get(spId);
  const amId = String(a.assigned_maqra_id);
  const resolvedQuestionId = lookups.questionIdByAssignedMaqraId.get(amId) || amId;
  const jId = String(a.judge_profile_id);
  const jInfo = lookups.judgeInfoById.get(jId);
  return {
    id: String(a.id),
    tenantId: String(a.tenant_id),
    stageParticipationId: spId,
    assignedMaqraId: amId,
    stageId: spObj?.stageId || '',
    stageName: spObj?.stageName || 'Penyisihan',
    participantId: spObj?.participantId || '',
    judgeId: jId,
    judgeName: jInfo?.name || 'Dewan Hakim',
    judgeField: jInfo?.field || 'Dewan Hakim',
    questionId: resolvedQuestionId,
    status: (a.status as JudgeAssessment['status']) || 'in_progress',
    errorCounts: (a.error_counts as Record<string, number>) || {},
    deductions: {},
    fieldScores: (a.field_scores as Record<string, number>) || {},
    totalDeductions: Number(a.total_deductions || 0),
    finalScore: Number(a.final_score || 100),
    annotations: (a.annotations as JudgeAssessment['annotations']) || [],
    rubricVersionId: String(a.rubric_version_id),
    isLocked: Boolean(a.is_locked),
    reopenedAt: a.reopened_at ? String(a.reopened_at) : undefined,
    reopenedBy: a.reopened_by ? String(a.reopened_by) : undefined,
    reopenReason: a.reopen_reason ? String(a.reopen_reason) : undefined,
    finalizedAt: a.finalized_at ? String(a.finalized_at) : undefined,
    lastUpdated: String(a.updated_at || a.created_at || '')
  };
}

/** Event realtime yang diteruskan ke aplikasi. */
export interface TenantRealtimeEvent {
  table: 'judge_assessments' | 'stage_participations' | 'stages' | 'connection';
  eventType: string;
  newRow?: Record<string, unknown>;
  oldRow?: Record<string, unknown>;
}

export const supabaseDataService = {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  setTestDatabaseClient(client: any | null): void {
    injectedDatabaseClient = client;
    setRuntimeSupabaseConnectionState({
      isTestClientActive: Boolean(client),
      state: client ? 'checking' : isSupabaseConfigured() ? 'checking' : 'unconfigured',
      isDatabaseReady: false,
      lastError: null
    });
  },

  getConnectionStatus(): SupabaseConnectionInfo {
    return getSupabaseConnectionInfo();
  },

  isLive(): boolean {
    if (injectedDatabaseClient) return true;
    return isSupabaseConfigured() && supabase !== null;
  },

  /**
   * Memastikan bahwa seluruh referensi ID merupakan sintaks UUID PostgreSQL yang valid.
   */
  validateReferences(refs: Record<string, string | undefined | null>): {
    valid: boolean;
    message?: string;
    invalidFields: string[];
  } {
    const check = validateDatabaseUuids(refs);
    if (!check.valid) {
      return {
        valid: false,
        invalidFields: check.invalidFields,
        message: `Operasi database dibatalkan: ID referensi belum berupa UUID database yang sah (${check.invalidFields.join(', ')}).`
      };
    }
    return { valid: true, invalidFields: [] };
  },

  /**
   * Memverifikasi secara nyata ke database bahwa baris referensi foreign key
   * (tenant, branch, stage, participant, stage_participation, assigned_maqra, judge, rubric_version, question)
   * benar-benar ada di database sebelum melakukan upsert atau RPC.
   */
  async verifyDatabaseReferencesExist(refs: DatabaseReferenceCheckInput): Promise<{
    valid: boolean;
    message?: string;
    missingReferences: string[];
  }> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        valid: false,
        missingReferences: ['database_client'],
        message: 'Koneksi database aktif tidak tersedia.'
      };
    }

    const nonEmptyRefs: Record<string, string> = {};
    for (const [k, v] of Object.entries(refs)) {
      if (v !== undefined && v !== null && String(v).trim() !== '') {
        nonEmptyRefs[k] = String(v).trim();
      }
    }

    const syntaxCheck = this.validateReferences(nonEmptyRefs);
    if (!syntaxCheck.valid) {
      return {
        valid: false,
        missingReferences: syntaxCheck.invalidFields,
        message: syntaxCheck.message
      };
    }

    const missingReferences: string[] = [];

    const checkTableRow = async (table: string, idValue: string, label: string) => {
      const { data, error } = await client
        .from(table)
        .select('id')
        .eq('id', idValue)
        .maybeSingle();
      if (error || !data || !data.id) {
        missingReferences.push(`${label} (${table}.id = ${idValue})`);
      }
    };

    const checks: Promise<void>[] = [];
    if (nonEmptyRefs.tenantId) {
      checks.push(checkTableRow('tenants', nonEmptyRefs.tenantId, 'Tenant'));
    }
    if (nonEmptyRefs.branchId) {
      checks.push(checkTableRow('branches', nonEmptyRefs.branchId, 'Cabang Lomba'));
    }
    if (nonEmptyRefs.stageId) {
      checks.push(checkTableRow('stages', nonEmptyRefs.stageId, 'Babak Kompetisi'));
    }
    if (nonEmptyRefs.kafilahId) {
      checks.push(checkTableRow('kafilahs', nonEmptyRefs.kafilahId, 'Kafilah'));
    }
    if (nonEmptyRefs.participantId) {
      checks.push(checkTableRow('participants', nonEmptyRefs.participantId, 'Peserta'));
    }
    if (nonEmptyRefs.stageParticipationId) {
      checks.push(checkTableRow('stage_participations', nonEmptyRefs.stageParticipationId, 'Partisipasi Babak'));
    }
    if (nonEmptyRefs.assignedMaqraId) {
      checks.push(checkTableRow('assigned_maqras', nonEmptyRefs.assignedMaqraId, 'Penetapan Maqra'));
    }
    if (nonEmptyRefs.judgeProfileId) {
      checks.push(checkTableRow('profiles', nonEmptyRefs.judgeProfileId, 'Profil Hakim'));
    }
    if (nonEmptyRefs.rubricVersionId) {
      checks.push(checkTableRow('rubric_versions', nonEmptyRefs.rubricVersionId, 'Versi Rubrik'));
    }
    if (nonEmptyRefs.questionId) {
      checks.push(checkTableRow('questions', nonEmptyRefs.questionId, 'Soal Maqra'));
    }

    await Promise.all(checks);

    if (missingReferences.length > 0) {
      return {
        valid: false,
        missingReferences,
        message: `Integritas Foreign Key Ditolak: Referensi belum terdaftar di database (${missingReferences.join('; ')}).`
      };
    }

    return { valid: true, missingReferences: [] };
  },

  /**
   * Melakukan pemeriksaan nyata terhadap koneksi database Supabase, keberadaan skema tabel,
   * dan status sesi autentikasi pengguna saat ini.
   */
  async verifyDatabaseConnection(): Promise<SupabaseConnectionInfo> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      setRuntimeSupabaseConnectionState({
        state: 'unconfigured',
        isDatabaseReady: false,
        isAuthenticated: false,
        lastError: null
      });
      return getSupabaseConnectionInfo();
    }

    try {
      const { data: sessionData } = await client.auth.getSession();
      const hasSession = Boolean(sessionData?.session?.user?.id);

      const { error } = await client.from('tenants').select('id').limit(1);

      if (error) {
        const msg = (error.message || '').toLowerCase();
        const code = (error.code || '').toUpperCase();
        const isSchemaMissing =
          code === '42P01' ||
          code === 'PGRST205' ||
          msg.includes('does not exist') ||
          msg.includes('could not find the table') ||
          msg.includes('schema cache');

        // Server menjawab tetapi menolak karena izin (mis. pengunjung belum login dan RLS memanggil
        // fungsi yang hanya untuk pengguna terautentikasi). Artinya database TERJANGKAU, bukan putus.
        const isPermissionOnly = code === '42501' || msg.includes('permission denied');
        if (isPermissionOnly) {
          setRuntimeSupabaseConnectionState({
            state: hasSession ? 'connected_authenticated' : 'connected_unauthenticated',
            isDatabaseReady: true,
            isAuthenticated: hasSession,
            lastError: null
          });
          return getSupabaseConnectionInfo();
        }

        if (isSchemaMissing) {
          setRuntimeSupabaseConnectionState({
            state: 'schema_missing',
            isDatabaseReady: false,
            isAuthenticated: hasSession,
            lastError: 'Tabel database belum ditemukan. Jalankan supabase/schema.sql pada SQL Editor Supabase Anda.'
          });
          return getSupabaseConnectionInfo();
        }

        setRuntimeSupabaseConnectionState({
          state: 'connection_error',
          isDatabaseReady: false,
          isAuthenticated: hasSession,
          lastError: error.message
        });
        return getSupabaseConnectionInfo();
      }

      setRuntimeSupabaseConnectionState({
        state: hasSession ? 'connected_authenticated' : 'connected_unauthenticated',
        isDatabaseReady: true,
        isAuthenticated: hasSession,
        lastError: null
      });
      return getSupabaseConnectionInfo();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Kegagalan jaringan saat menghubungi Supabase.';
      setRuntimeSupabaseConnectionState({
        state: 'connection_error',
        isDatabaseReady: false,
        isAuthenticated: false,
        lastError: message
      });
      return getSupabaseConnectionInfo();
    }
  },

  /**
   * Mengambil profil pengguna yang sedang terautentikasi di Supabase Auth beserta keanggotaan tenant-nya.
   */
  async fetchAuthenticatedUserProfile(): Promise<AuthenticatedSupabaseProfile | null> {
    const client = getActiveClient();
    if (!this.isLive() || !client) return null;

    const { data: sessionData, error: sessionErr } = await client.auth.getSession();
    const authUser = sessionData?.session?.user;
    if (sessionErr || !authUser || !isValidUuid(authUser.id)) {
      return null;
    }

    const { data: profileRow, error: profileErr } = await client
      .from('profiles')
      .select('id, username, name, email, role')
      .eq('id', authUser.id)
      .maybeSingle();

    const { data: allMembershipRows, error: membershipErr } = await client
      .from('tenant_memberships')
      .select('tenant_id, role, judge_category, judge_field, status')
      .eq('profile_id', authUser.id);

    const activeRows = (allMembershipRows || []).filter(
      (m: Record<string, unknown>) => String(m.status || 'Aktif') === 'Aktif'
    );
    const inactiveCount = (allMembershipRows || []).filter(
      (m: Record<string, unknown>) => String(m.status || '') === 'Nonaktif'
    ).length;

    const memberships = activeRows.map((m: Record<string, unknown>) => ({
      tenantId: String(m.tenant_id || ''),
      role: (m.role as 'superadmin' | 'admin' | 'judge') || 'judge',
      judgeCategory: m.judge_category ? String(m.judge_category) : undefined,
      judgeField: m.judge_field ? String(m.judge_field) : undefined,
      status: String(m.status || 'Aktif')
    }));

    const verificationErrors: string[] = [];
    if (profileErr) verificationErrors.push(`profiles: ${profileErr.message}`);
    if (membershipErr) verificationErrors.push(`tenant_memberships: ${membershipErr.message}`);

    return {
      authUserId: authUser.id,
      email: String(profileRow?.email || authUser.email || ''),
      name: String(
        profileRow?.name ||
          authUser.user_metadata?.name ||
          authUser.email?.split('@')[0] ||
          'Pengguna Terautentikasi'
      ),
      username: String(
        profileRow?.username ||
          authUser.user_metadata?.username ||
          authUser.email?.split('@')[0] ||
          'user'
      ),
      globalRole: ((profileRow?.role as string) || 'judge') as 'superadmin' | 'admin' | 'judge',
      hasProfileRow: Boolean(profileRow && profileRow.id),
      inactiveMembershipsCount: inactiveCount,
      verificationError: verificationErrors.length > 0 ? verificationErrors.join('; ') : undefined,
      memberships
    };
  },

  async signInWithPassword(email: string, password: string): Promise<{
    success: boolean;
    message: string;
    profile?: AuthenticatedSupabaseProfile | null;
  }> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        message: 'Kredensial Supabase (VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY) belum dikonfigurasi.'
      };
    }

    const { error } = await client.auth.signInWithPassword({
      email: email.trim(),
      password
    });

    if (error) {
      return {
        success: false,
        message: `Autentikasi gagal: ${error.message}`
      };
    }

    await this.verifyDatabaseConnection();
    const profile = await this.fetchAuthenticatedUserProfile();
    return {
      success: true,
      message: `Berhasil login sebagai ${profile?.name || email}.`,
      profile
    };
  },

  async signOut(): Promise<{ success: boolean; message?: string }> {
    const client = getActiveClient();
    if (!this.isLive() || !client) return { success: true };
    const { error } = await client.auth.signOut();
    await this.verifyDatabaseConnection();
    if (error) {
      return { success: false, message: error.message };
    }
    return { success: true };
  },

  /**
   * Mendaftarkan pengguna baru (Sign Up) ke Supabase Auth (`auth.users`).
   * Trigger database `on_auth_user_created` akan otomatis membuat baris di `public.profiles`.
   */
  async signUpNewUser(params: {
    name: string;
    username: string;
    email: string;
    password: string;
  }): Promise<{
    success: boolean;
    userId?: string;
    requiresEmailConfirmation?: boolean;
    message: string;
    profile?: AuthenticatedSupabaseProfile | null;
  }> {
    const cleanName = (params.name || '').trim();
    const cleanUsername = (params.username || '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9_.-]/g, '_');
    const cleanEmail = (params.email || '').trim().toLowerCase();
    const rawPassword = params.password || '';

    if (!cleanName || cleanName.length < 2) {
      return { success: false, message: 'Nama lengkap wajib diisi minimal 2 karakter.' };
    }
    if (!cleanUsername || cleanUsername.length < 3) {
      return { success: false, message: 'Username wajib diisi minimal 3 karakter.' };
    }
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return { success: false, message: 'Format alamat email tidak valid.' };
    }
    if (!rawPassword || rawPassword.length < 8) {
      return { success: false, message: 'Kata sandi wajib minimal 8 karakter.' };
    }

    const client = getActiveClient();
    if (!this.isLive() || !client || typeof client.auth?.signUp !== 'function') {
      return {
        success: false,
        message: 'Layanan Supabase Auth belum dikonfigurasi atau tidak tersedia.'
      };
    }

    const redirectValidation = this.validateRedirectUrl();
    const { data, error } = await client.auth.signUp({
      email: cleanEmail,
      password: rawPassword,
      options: {
        data: {
          name: cleanName,
          username: cleanUsername
        },
        ...(redirectValidation.valid ? { emailRedirectTo: redirectValidation.url } : {})
      }
    });

    if (error) {
      return {
        success: false,
        message: `Pendaftaran akun gagal: ${error.message}`
      };
    }

    const createdUserId = data?.user?.id ? String(data.user.id) : undefined;
    await this.verifyDatabaseConnection();
    const hasActiveSession = Boolean(data?.session?.user?.id);
    if (hasActiveSession) {
      const profile = await this.fetchAuthenticatedUserProfile();
      return {
        success: true,
        userId: createdUserId,
        requiresEmailConfirmation: false,
        message: `Pendaftaran berhasil! Akun ${cleanName} (${cleanEmail}) telah dibuat di Supabase Auth & tabel public.profiles.`,
        profile
      };
    }

    return {
      success: true,
      userId: createdUserId,
      requiresEmailConfirmation: true,
      message: `Pendaftaran akun ${cleanName} (${cleanEmail}) berhasil! Akun telah tercatat di tabel public.profiles. Silakan buka kotak masuk email Anda untuk klik tautan verifikasi sebelum login.`
    };
  },

  /**
   * Memvalidasi bahwa URL redirect (untuk reset password / undangan) aman, berada pada origin yang sama,
   * atau menggunakan HTTPS yang valid (mencegah open-redirect).
   */
  validateRedirectUrl(candidateUrl?: string): { valid: boolean; url: string; reason?: string } {
    const fallbackOrigin =
      typeof window !== 'undefined' && window.location?.origin
        ? window.location.origin
        : 'http://localhost:3000';
    // Tautan undangan & reset kata sandi diarahkan ke aplikasi (/app), bukan landing page (/)
    const raw = (candidateUrl || `${fallbackOrigin}/app`).trim();

    try {
      const parsed = new URL(raw);
      if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
        return {
          valid: false,
          url: fallbackOrigin,
          reason: 'Protokol URL redirect harus http: atau https:.'
        };
      }
      const isLocalhost =
        parsed.hostname === 'localhost' ||
        parsed.hostname === '127.0.0.1' ||
        parsed.hostname.endsWith('.local');
      if (parsed.protocol === 'http:' && !isLocalhost) {
        return {
          valid: false,
          url: fallbackOrigin,
          reason: 'URL redirect produksi non-localhost wajib menggunakan HTTPS.'
        };
      }
      if (
        typeof window !== 'undefined' &&
        window.location?.origin &&
        parsed.origin !== window.location.origin
      ) {
        return {
          valid: false,
          url: window.location.origin,
          reason: 'Redirect lintas domain (cross-origin) ditolak demi keamanan.'
        };
      }
      return { valid: true, url: parsed.toString() };
    } catch {
      return {
        valid: false,
        url: fallbackOrigin,
        reason: 'Format URL redirect tidak valid.'
      };
    }
  },

  /**
   * Mengirimkan email instruksi pemulihan / reset kata sandi melalui Supabase Auth.
   */
  async requestPasswordReset(
    email: string,
    customRedirectUrl?: string
  ): Promise<{ success: boolean; message: string }> {
    const cleanEmail = (email || '').trim().toLowerCase();
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return {
        success: false,
        message: 'Masukkan alamat email yang valid untuk menerima tautan pemulihan kata sandi.'
      };
    }

    const redirectValidation = this.validateRedirectUrl(customRedirectUrl);
    if (!redirectValidation.valid) {
      return {
        success: false,
        message: `Permintaan reset kata sandi ditolak: ${redirectValidation.reason}`
      };
    }

    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        message: 'Layanan Supabase Auth belum terhubung.'
      };
    }

    const { error } = await client.auth.resetPasswordForEmail(cleanEmail, {
      redirectTo: redirectValidation.url
    });

    if (error) {
      return {
        success: false,
        message: `Gagal mengirim email pemulihan kata sandi: ${error.message}`
      };
    }

    return {
      success: true,
      message: `Tautan pemulihan kata sandi telah dikirim ke ${cleanEmail}. Periksa kotak masuk atau folder spam Anda.`
    };
  },

  /**
   * Memperbarui kata sandi pengguna menggunakan sesi recovery resmi dari Supabase Auth.
   */
  async updatePasswordWithRecoverySession(
    newPassword: string
  ): Promise<{ success: boolean; message: string }> {
    if (!newPassword || newPassword.length < 8) {
      return {
        success: false,
        message: 'Kata sandi baru minimal harus terdiri dari 8 karakter.'
      };
    }

    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        message: 'Layanan Supabase Auth belum terhubung.'
      };
    }

    const { data: sessionData } = await client.auth.getSession();
    if (!sessionData?.session?.user?.id) {
      return {
        success: false,
        message:
          'Sesi pemulihan kata sandi tidak ditemukan atau telah kedaluwarsa. Silakan minta ulang tautan reset kata sandi.'
      };
    }

    const { error } = await client.auth.updateUser({
      password: newPassword
    });

    if (error) {
      return {
        success: false,
        message: `Gagal memperbarui kata sandi: ${error.message}`
      };
    }

    return {
      success: true,
      message: 'Kata sandi Anda berhasil diperbarui. Anda kini dapat mengakses workspace MTQ.'
    };
  },

  /**
   * Menjalankan prosedur bootstrap superadmin pertama satu kali (`bootstrap_first_superadmin`).
   * Hanya berhasil jika belum ada satu pun baris `profiles` dengan `role = 'superadmin'`.
   */
  async bootstrapFirstSuperadmin(params?: {
    targetEmail?: string;
    initialTenantId?: string;
  }): Promise<RpcServiceResult<{ profileId: string; email: string; initialTenantId: string }>> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        mode: 'local_offline_fallback',
        message: 'Layanan Supabase belum dikonfigurasi.'
      };
    }

    const cleanTenantId =
      params?.initialTenantId && isValidUuid(params.initialTenantId) ? params.initialTenantId : null;

    const { data, error } = await client.rpc('bootstrap_first_superadmin', {
      p_target_email: params?.targetEmail ? params.targetEmail.trim().toLowerCase() : null,
      p_initial_tenant_id: cleanTenantId
    });

    if (error) {
      return {
        success: false,
        mode: 'supabase_live',
        message: error.message
      };
    }

    await this.verifyDatabaseConnection();
    return {
      success: true,
      mode: 'supabase_live',
      message:
        'Bootstrap Superadmin Pertama berhasil dijalankan. Akun Anda kini terdaftar sebagai Superadmin Platform dan tercatat di audit_logs.',
      data: data as { profileId: string; email: string; initialTenantId: string }
    };
  },

  /**
   * Mengambil seluruh data operasional, rubrik, dan master untuk tenant aktif dari Supabase
   * dengan pemeriksaan error eksplisit untuk setiap tabel.
   */
  async fetchTenantWorkspaceResult(rawTenantId: string): Promise<WorkspaceHydrationResult> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        tenantId: rawTenantId,
        mode: 'demo_local',
        error: 'Supabase belum dikonfigurasi.',
        payload: null
      };
    }

    const conn = await this.verifyDatabaseConnection();
    if (!conn.isDatabaseReady) {
      return {
        success: false,
        tenantId: rawTenantId,
        mode: 'supabase_live',
        error: conn.lastError || 'Database Supabase belum siap.',
        payload: null
      };
    }

    let tenantUuid = isValidUuid(rawTenantId) ? rawTenantId : '';
    if (!tenantUuid) {
      // Jika rawTenantId adalah kode lokal seperti 'tenant-jabar' atau 'platform', ambil UUID tenant pertama yang valid di database
      const { data: firstTenants } = await client
        .from('tenants')
        .select('id')
        .neq('id', SYSTEM_TENANT_UUID)
        .limit(1);
      if (firstTenants && firstTenants.length > 0 && firstTenants[0]?.id) {
        tenantUuid = String(firstTenants[0].id);
      } else {
        tenantUuid = toDeterministicUuid(rawTenantId);
      }
    }

    if (!isValidUuid(tenantUuid)) {
      return {
        success: false,
        tenantId: rawTenantId,
        mode: 'supabase_live',
        error: `Tenant ID "${rawTenantId}" bukan UUID yang valid.`,
        payload: null
      };
    }

    const [
      tenantsRes,
      profilesRes,
      membershipsRes,
      branchesRes,
      levelsRes,
      kafilahsRes,
      stagesRes,
      questionsRes,
      participantsRes,
      spRes,
      assignedMaqrasRes,
      errorCatsRes,
      rubricVersionsRes,
      rubricFieldsRes,
      rubricCriteriaRes,
      deductionRulesRes,
      rulesRes,
      judgeAsgRes,
      assessmentsRes,
      snapshotsRes,
      auditRes
    ] = await Promise.all([
      client.from('tenants').select('*').neq('id', SYSTEM_TENANT_UUID),
      client.from('profiles').select('id, username, name, email, role'),
      client.from('tenant_memberships').select('*, profiles(id, username, name, email, role)'),
      client.from('branches').select('*').eq('tenant_id', tenantUuid),
      client.from('levels').select('*').eq('tenant_id', tenantUuid),
      client.from('kafilahs').select('*').eq('tenant_id', tenantUuid),
      client.from('stages').select('*').eq('tenant_id', tenantUuid).order('stage_order', { ascending: true }),
      client.from('questions').select('*').eq('tenant_id', tenantUuid),
      client.from('participants').select('*').eq('tenant_id', tenantUuid),
      client.from('stage_participations').select('*').eq('tenant_id', tenantUuid),
      client.from('assigned_maqras').select('*').eq('tenant_id', tenantUuid),
      client.from('error_categories').select('*').eq('tenant_id', tenantUuid).order('sort_order', { ascending: true }),
      client.from('rubric_versions').select('*').eq('tenant_id', tenantUuid),
      client.from('rubric_fields').select('*').order('field_order', { ascending: true }),
      client.from('rubric_criteria').select('*').order('sort_order', { ascending: true }),
      client.from('deduction_rules').select('*'),
      client.from('competition_rule_configs').select('*').eq('tenant_id', tenantUuid),
      client.from('judge_assignments').select('*, profiles(name)').eq('tenant_id', tenantUuid),
      client.from('judge_assessments').select('*').eq('tenant_id', tenantUuid),
      client.from('stage_result_snapshots').select('*').eq('tenant_id', tenantUuid),
      client.from('audit_logs').select('*').eq('tenant_id', tenantUuid).order('created_at', { ascending: false }).limit(50)
    ]);

    const queryChecks: Array<{ name: string; error: { message?: string } | null }> = [
      { name: 'tenants', error: tenantsRes.error },
      { name: 'profiles', error: profilesRes.error },
      { name: 'tenant_memberships', error: membershipsRes.error },
      { name: 'branches', error: branchesRes.error },
      { name: 'levels', error: levelsRes.error },
      { name: 'kafilahs', error: kafilahsRes.error },
      { name: 'stages', error: stagesRes.error },
      { name: 'questions', error: questionsRes.error },
      { name: 'participants', error: participantsRes.error },
      { name: 'stage_participations', error: spRes.error },
      { name: 'assigned_maqras', error: assignedMaqrasRes.error },
      { name: 'error_categories', error: errorCatsRes.error },
      { name: 'rubric_versions', error: rubricVersionsRes.error },
      { name: 'rubric_fields', error: rubricFieldsRes.error },
      { name: 'rubric_criteria', error: rubricCriteriaRes.error },
      { name: 'deduction_rules', error: deductionRulesRes.error },
      { name: 'competition_rule_configs', error: rulesRes.error },
      { name: 'judge_assignments', error: judgeAsgRes.error },
      { name: 'judge_assessments', error: assessmentsRes.error },
      { name: 'stage_result_snapshots', error: snapshotsRes.error },
      { name: 'audit_logs', error: auditRes.error }
    ];

    const failedQueries = queryChecks
      .filter((q) => q.error !== null && q.error !== undefined)
      .map((q) => `${q.name}: ${q.error?.message || 'Query error'}`);

    if (failedQueries.length > 0) {
      return {
        success: false,
        tenantId: tenantUuid,
        mode: 'supabase_live',
        error: `Gagal memuat sebagian data workspace dari Supabase (${failedQueries.join('; ')}).`,
        failedQueries,
        payload: null
      };
    }

    const allMemberships = (membershipsRes.data || []) as Array<Record<string, unknown>>;
    const allProfiles = (profilesRes.data || []) as Array<Record<string, unknown>>;
    const profileById = new Map<string, Record<string, unknown>>();
    allProfiles.forEach((p) => {
      if (p.id) profileById.set(String(p.id), p);
    });

    const userCountByTenant = new Map<string, number>();
    allMemberships.forEach((m) => {
      const tId = String(m.tenant_id || '');
      if (tId) {
        userCountByTenant.set(tId, (userCountByTenant.get(tId) || 0) + 1);
      }
    });

    const tenants: Tenant[] = (tenantsRes.data || []).map((t: Record<string, unknown>) => {
      const tId = String(t.id);
      return {
        id: tId,
        code: String(t.code || ''),
        name: String(t.name || ''),
        eventName: String(t.event_name || ''),
        region: String(t.region || ''),
        edition: String(t.edition || '2025'),
        period: String(t.period || '2025 - 2026'),
        primaryAdminId: '',
        groupLabel: t.group_label ? String(t.group_label) : 'Kafilah / Utusan',
        status: (t.status as 'Aktif' | 'Nonaktif') || 'Aktif',
        userCount: userCountByTenant.get(tId) || 0
      };
    });

    const profileIdsWithMembership = new Set<string>();
    const usersFromMemberships: User[] = allMemberships.map((m: Record<string, unknown>) => {
      const rawProf = m.profiles;
      const joinedProf = (Array.isArray(rawProf) ? rawProf[0] : rawProf) as Record<string, unknown> | undefined;
      const profileId = String(m.profile_id || joinedProf?.id || '');
      const fallbackProf = profileById.get(profileId) || {};
      const prof = { ...fallbackProf, ...(joinedProf || {}) };

      if (profileId) {
        profileIdsWithMembership.add(profileId);
      }

      const statusVal = ((m.status as string) || 'Aktif') as 'Aktif' | 'Nonaktif';
      const globalRole = String(prof.role || '');
      const memberRole = String(m.role || globalRole || 'judge');
      const effectiveRole = (
        globalRole === 'superadmin' ? 'superadmin' : memberRole
      ) as 'superadmin' | 'admin' | 'judge';
      const rawMemberTenantId = String(m.tenant_id || tenantUuid);

      return {
        id: profileId,
        tenantId:
          effectiveRole === 'superadmin' && rawMemberTenantId === SYSTEM_TENANT_UUID
            ? 'platform'
            : rawMemberTenantId,
        username: String(prof.username || prof.email || profileId),
        name: String(prof.name || 'Pengguna MTQ'),
        email: prof.email ? String(prof.email) : undefined,
        role: effectiveRole,
        judgeCategory: m.judge_category ? String(m.judge_category) : undefined,
        judgeField: m.judge_field ? String(m.judge_field) : undefined,
        status: statusVal,
        provisioningStatus: statusVal === 'Aktif' ? 'Aktif' : 'Nonaktif'
      };
    });

    // Sertakan juga baris di tabel public.profiles yang belum memiliki baris di tenant_memberships
    // (mis. akun baru hasil Sign Up atau Superadmin platform) agar 100% sinkron dengan tabel profiles Supabase
    const usersWithoutMembership: User[] = allProfiles
      .filter((p) => p.id && !profileIdsWithMembership.has(String(p.id)))
      .map((p) => {
        const profileId = String(p.id);
        const roleVal = ((p.role as string) || 'judge') as 'superadmin' | 'admin' | 'judge';
        const isSuper = roleVal === 'superadmin';
        return {
          id: profileId,
          tenantId: isSuper ? 'platform' : 'unassigned',
          username: String(p.username || p.email || profileId),
          name: String(p.name || 'Pengguna Terdaftar'),
          email: p.email ? String(p.email) : undefined,
          role: roleVal,
          status: 'Aktif' as const,
          provisioningStatus: isSuper ? 'Aktif' : 'Menunggu Verifikasi',
          provisioningMessage: isSuper
            ? undefined
            : 'Terdaftar di tabel profiles — belum ditugaskan ke tenant MTQ.'
        };
      });

    const seenUserIds = new Set<string>();
    const users: User[] = [];
    [...usersFromMemberships, ...usersWithoutMembership].forEach((u) => {
      if (!u.id || seenUserIds.has(u.id)) return;
      seenUserIds.add(u.id);
      users.push(u);
    });

    const branchMap = new Map<string, string>();
    const cabangList: GenericMasterItem[] = (branchesRes.data || []).map((b: Record<string, unknown>) => {
      const id = String(b.id);
      const name = String(b.name || '');
      branchMap.set(id, name);
      return {
        id,
        tenantId: String(b.tenant_id),
        code: String(b.code || ''),
        name,
        description: String(b.description || ''),
        status: (b.status as 'Aktif' | 'Nonaktif') || 'Aktif'
      };
    });

    const levelMap = new Map<string, string>();
    const jenjangList: GenericMasterItem[] = (levelsRes.data || []).map((l: Record<string, unknown>) => {
      const id = String(l.id);
      const name = String(l.name || '');
      levelMap.set(id, name);
      return {
        id,
        tenantId: String(l.tenant_id),
        code: String(l.code || ''),
        name,
        description: String(l.description || ''),
        status: (l.status as 'Aktif' | 'Nonaktif') || 'Aktif'
      };
    });

    const kafilahMap = new Map<string, string>();
    const kafilahs: Kafilah[] = (kafilahsRes.data || []).map((k: Record<string, unknown>) => {
      const id = String(k.id);
      const name = String(k.name || '');
      kafilahMap.set(id, name);
      return {
        id,
        tenantId: String(k.tenant_id),
        code: String(k.code || ''),
        name,
        region: String(k.region || ''),
        contactPerson: String(k.contact_person || k.leader_name || '-'),
        contactPhone: String(k.contact_phone || '-'),
        participantCount: 0,
        status: (k.status as 'Aktif' | 'Nonaktif') || 'Aktif'
      };
    });

    const stageMap = new Map<string, { name: string; branchId?: string; branchName: string }>();
    const stages: CompetitionStage[] = (stagesRes.data || []).map((s: Record<string, unknown>) => {
      const id = String(s.id);
      const name = String(s.name || '');
      const bId = s.branch_id ? String(s.branch_id) : undefined;
      const bName = (bId && branchMap.get(bId)) || 'Semua Cabang';
      stageMap.set(id, { name, branchId: bId, branchName: bName });
      return {
        id,
        tenantId: String(s.tenant_id),
        name,
        order: Number(s.stage_order || 1),
        branchId: bId,
        branchName: bName,
        status: (s.status as 'Menunggu' | 'Aktif' | 'Selesai') || 'Menunggu',
        qualificationQuota: Number(s.qualification_quota || 3),
        championCount: Number(s.champion_count || 3),
        qualificationMethod: (s.qualification_method as 'top_n' | 'manual') || 'top_n',
        isFinalized: Boolean(s.is_finalized),
        finalizedAt: s.finalized_at ? String(s.finalized_at) : undefined,
        finalizedBy: s.finalized_by ? String(s.finalized_by) : undefined
      };
    });

    const questionMap = new Map<string, Question>();
    const questions: Question[] = (questionsRes.data || []).map((q: Record<string, unknown>) => {
      const id = String(q.id);
      const bId = q.branch_id ? String(q.branch_id) : undefined;
      const lId = q.level_id ? String(q.level_id) : undefined;
      const sId = q.stage_id ? String(q.stage_id) : undefined;
      const resolvedBranchName = (bId && branchMap.get(bId)) || String(q.branch_name || 'Tilawah Dewasa Putra');
      const resolvedLevelName = (lId && levelMap.get(lId)) || (jenjangList[0]?.name || 'Umum');
      const resolvedStageName = (sId && stageMap.get(sId)?.name) || 'Penyisihan';
      const item: Question = {
        id,
        tenantId: String(q.tenant_id),
        code: String(q.code || ''),
        title: String(q.title || ''),
        surahName: String(q.surah_name || ''),
        surahNumber: Number(q.surah_number || 1),
        startAyah: Number(q.start_ayah || 1),
        endAyah: Number(q.end_ayah || 1),
        pageNumber: Number(q.page_number || 1),
        pageStart: Number(q.page_start || q.page_number || 1),
        pageEnd: Number(q.page_end || q.page_number || 1),
        branchId: bId,
        branchName: resolvedBranchName,
        levelId: lId,
        levelName: resolvedLevelName,
        stageId: sId,
        branchAndLevel: lId ? `${resolvedBranchName} - ${resolvedLevelName}` : resolvedBranchName,
        stage: resolvedStageName,
        stageName: resolvedStageName,
        status: (q.status as 'Aktif' | 'Nonaktif') || 'Aktif',
        description: q.description ? String(q.description) : undefined
      };
      questionMap.set(id, item);
      return item;
    });

    const assignedMaqraBySp = new Map<string, Array<{ id: string; questionId: string; assignedAt: string }>>();
    const assignedMaqraIdToQuestionId = new Map<string, string>();
    (assignedMaqrasRes.data || []).forEach((am: Record<string, unknown>) => {
      const amId = String(am.id);
      const spId = String(am.stage_participation_id);
      const qId = String(am.question_id);
      assignedMaqraIdToQuestionId.set(amId, qId);
      const list = assignedMaqraBySp.get(spId) || [];
      list.push({ id: amId, questionId: qId, assignedAt: String(am.assigned_at || '') });
      assignedMaqraBySp.set(spId, list);
    });

    const participantBranchMap = new Map<string, string>();
    (participantsRes.data || []).forEach((p: Record<string, unknown>) => {
      if (p.id && p.branch_id) {
        participantBranchMap.set(String(p.id), String(p.branch_id));
      }
    });

    const assessedSpIds = new Set<string>();
    (assessmentsRes.data || []).forEach((a: Record<string, unknown>) => {
      if (a.stage_participation_id) {
        assessedSpIds.add(String(a.stage_participation_id));
      }
    });

    const rawStageParticipations: StageParticipation[] = (spRes.data || []).map((sp: Record<string, unknown>) => {
      const spId = String(sp.id);
      const partId = String(sp.participant_id);
      const stgId = String(sp.stage_id);
      const stgInfo = stageMap.get(stgId);
      const partBranchId = participantBranchMap.get(partId);
      const resolvedBranchId = partBranchId || stgInfo?.branchId;
      const resolvedBranchName =
        (partBranchId ? branchMap.get(partBranchId) : undefined) ||
        (stgInfo?.branchName && stgInfo.branchName !== 'Semua Cabang' ? stgInfo.branchName : undefined) ||
        'Tilawah Dewasa Putra';
      const maqras = assignedMaqraBySp.get(spId) || [];
      const assignedQuestions = maqras.map((m) => {
        const qObj = questionMap.get(m.questionId);
        return {
          id: m.id, // Real database row ID from assigned_maqras.id
          questionId: m.questionId,
          code: qObj?.code,
          title: qObj?.title || 'Maqra',
          surahName: qObj?.surahName,
          surahNumber: qObj?.surahNumber,
          startAyah: qObj?.startAyah,
          endAyah: qObj?.endAyah,
          pageNumber: qObj?.pageNumber || 1,
          pageStart: qObj?.pageStart || 1,
          pageEnd: qObj?.pageEnd || 1,
          assignedAt: m.assignedAt,
          stageName: stgInfo?.name || 'Penyisihan'
        };
      });
      const firstQ = assignedQuestions[0];
      return {
        id: spId,
        tenantId: String(sp.tenant_id),
        participantId: partId,
        stageId: stgId,
        stageName: stgInfo?.name || 'Penyisihan',
        branchId: resolvedBranchId,
        branchName: resolvedBranchName,
        lotteryNumber: String(sp.lottery_number || ''),
        questionId: firstQ ? firstQ.questionId : '',
        assignedMaqra:
          assignedQuestions.length === 0
            ? 'Belum Ditetapkan'
            : assignedQuestions.length === 1
            ? firstQ.title
            : `${assignedQuestions.length} Maqra Ditetapkan`,
        pageNumber: firstQ ? firstQ.pageNumber : 1,
        assignedQuestions,
        status: (sp.status as StageParticipation['status']) || 'Maqra Belum Ditetapkan',
        provisionalScore: sp.provisional_score !== null && sp.provisional_score !== undefined ? Number(sp.provisional_score) : undefined,
        finalScore: sp.final_score !== null && sp.final_score !== undefined ? Number(sp.final_score) : undefined,
        rank: sp.rank !== null && sp.rank !== undefined ? Number(sp.rank) : undefined,
        championRank: sp.champion_rank !== null && sp.champion_rank !== undefined ? Number(sp.champion_rank) : undefined,
        championTitle: sp.champion_title ? String(sp.champion_title) : undefined,
        isQualified: Boolean(sp.is_qualified),
        qualificationReason: sp.qualification_reason ? String(sp.qualification_reason) : undefined,
        finalizedAt: sp.finalized_at ? String(sp.finalized_at) : undefined
      };
    });

    // Consolidate assignedQuestions across duplicate stage_participations rows on the same (participantId, stageName)
    const mergedQuestionsByPartStage = new Map<string, StageParticipation['assignedQuestions']>();
    rawStageParticipations.forEach((sp) => {
      const key = `${sp.participantId}::${sp.stageName}`;
      const existing = mergedQuestionsByPartStage.get(key) || [];
      const combined = [...existing];
      (sp.assignedQuestions || []).forEach((aq) => {
        if (!combined.some((item) => item.questionId === aq.questionId)) {
          combined.push(aq);
        }
      });
      mergedQuestionsByPartStage.set(key, combined);
    });

    const stageParticipations: StageParticipation[] = rawStageParticipations.map((sp) => {
      const key = `${sp.participantId}::${sp.stageName}`;
      const consolidatedQuestions = mergedQuestionsByPartStage.get(key) || sp.assignedQuestions || [];
      const firstQ = consolidatedQuestions[0];
      return {
        ...sp,
        questionId: firstQ ? firstQ.questionId : sp.questionId,
        assignedMaqra:
          consolidatedQuestions.length === 0
            ? sp.assignedMaqra
            : consolidatedQuestions.length === 1
            ? firstQ.title
            : `${consolidatedQuestions.length} Maqra Ditetapkan`,
        pageNumber: firstQ ? firstQ.pageNumber : sp.pageNumber,
        assignedQuestions: consolidatedQuestions
      };
    });

    const stageOrderById = new Map<string, number>();
    stages.forEach((s) => stageOrderById.set(s.id, s.order || 1));

    const participants: Participant[] = (participantsRes.data || []).map((p: Record<string, unknown>) => {
      const id = String(p.id);
      const bId = String(p.branch_id || '');
      const kId = String(p.kafilah_id || '');
      const lId = p.level_id ? String(p.level_id) : '';
      const sId = p.stage_id ? String(p.stage_id) : '';
      const matchingSps = stageParticipations
        .filter((sp) => sp.participantId === id)
        .sort((a, b) => {
          const orderA = stageOrderById.get(a.stageId) || 1;
          const orderB = stageOrderById.get(b.stageId) || 1;
          if (orderA !== orderB) return orderA - orderB;
          const aHasAsm = assessedSpIds.has(a.id) ? 1 : 0;
          const bHasAsm = assessedSpIds.has(b.id) ? 1 : 0;
          if (aHasAsm !== bHasAsm) return aHasAsm - bHasAsm;
          return (a.assignedQuestions?.length || 0) - (b.assignedQuestions?.length || 0);
        });
      const latestSp = matchingSps[matchingSps.length - 1];
      const kafilahRegion = (kafilahs.find((k) => k.id === kId)?.region) || '';
      const rawStatus = String(p.status || 'Menunggu');
      const normalizedStatus: Participant['status'] =
        rawStatus === 'Berlangsung'
          ? 'Berlangsung'
          : rawStatus === 'Lolos'
          ? 'Lolos'
          : rawStatus === 'Gugur'
          ? 'Gugur'
          : rawStatus === 'Final'
          ? 'Final'
          : 'Menunggu';
      return {
        id,
        tenantId: String(p.tenant_id),
        adminSequenceNumber: p.admin_sequence_number ? String(p.admin_sequence_number) : undefined,
        participantId: String(p.participant_code || ''),
        lotteryNumber: String(p.lottery_number || ''),
        name: String(p.name || ''),
        fatherName: p.father_name ? String(p.father_name) : undefined,
        gender: (p.gender as 'Putra' | 'Putri') || 'Putra',
        originCity: p.origin_city ? String(p.origin_city) : kafilahRegion || undefined,
        originRegion: p.origin_region ? String(p.origin_region) : kafilahRegion || undefined,
        originInstitution: p.origin_institution ? String(p.origin_institution) : undefined,
        kafilahId: kId,
        kafilahName: kafilahMap.get(kId) || 'Kafilah',
        branchId: bId,
        branchName: branchMap.get(bId) || 'Tilawah Dewasa Putra',
        levelId: lId || undefined,
        levelName: (lId && levelMap.get(lId)) || jenjangList[0]?.name || 'Ulya',
        stageId: latestSp?.stageId || sId || undefined,
        stageName: latestSp?.stageName || (sId && stageMap.get(sId)?.name) || 'Penyisihan',
        questionId: latestSp?.questionId || '',
        assignedMaqra: latestSp?.assignedMaqra || 'Belum Ditetapkan',
        pageNumber: latestSp?.pageNumber || 1,
        assignedQuestions: latestSp?.assignedQuestions || [],
        questionIds: (latestSp?.assignedQuestions || []).map((q) => q.questionId),
        status: normalizedStatus,
        verificationStatus:
          (p.verification_status as 'Diajukan' | 'Diverifikasi' | 'Ditolak') || 'Diverifikasi',
        verificationNote: p.verification_note ? String(p.verification_note) : undefined,
        verifiedBy: p.verified_by ? String(p.verified_by) : undefined,
        verifiedAt: p.verified_at ? String(p.verified_at) : undefined
      };
    });

    const uniqueParticipants = Array.from(new Map(participants.map((p) => [p.id, p])).values());

    // Update participantCount on kafilahs
    kafilahs.forEach((k) => {
      k.participantCount = uniqueParticipants.filter((p) => p.kafilahId === k.id).length;
    });

    const errorCategories: ErrorCategory[] = (errorCatsRes.data || []).map((c: Record<string, unknown>) => ({
      id: String(c.id),
      tenantId: String(c.tenant_id),
      fieldId: c.rubric_field_id ? String(c.rubric_field_id) : undefined,
      criterionId: c.criterion_id ? String(c.criterion_id) : undefined,
      deductionRuleId: c.deduction_rule_id ? String(c.deduction_rule_id) : undefined,
      code: String(c.code || ''),
      name: String(c.name || ''),
      scope: (c.scope as ErrorCategory['scope']) || 'Tajwid & Makhraj',
      defaultDeduction: Number(c.default_deduction || 0.5),
      maxDeduction: c.max_deduction !== null && c.max_deduction !== undefined ? Number(c.max_deduction) : undefined,
      methodType: (c.method_type as ErrorCategory['methodType']) || 'Pengurangan tetap',
      status: (c.status as 'Aktif' | 'Nonaktif') || 'Aktif',
      order: Number(c.sort_order || 1)
    }));

    // Map deduction_rules -> rubric_criteria -> rubric_fields -> rubric_versions
    const deductionRulesByCriterionId = new Map<string, DeductionRule[]>();
    (deductionRulesRes.data || []).forEach((dr: Record<string, unknown>) => {
      const criterionId = String(dr.criterion_id || '');
      const perErr = Number(dr.deduction_points ?? dr.deduction_per_error ?? 0.5);
      const ruleName = String(dr.name || dr.label || '');
      const item: DeductionRule = {
        id: String(dr.id),
        criterionId,
        name: ruleName,
        label: ruleName,
        errorGrade: dr.error_grade ? (String(dr.error_grade) as DeductionRule['errorGrade']) : undefined,
        deductionPoints: perErr,
        deductionPerError: perErr,
        maxDeduction: dr.max_deduction !== null && dr.max_deduction !== undefined ? Number(dr.max_deduction) : undefined,
        methodType: (dr.method_type as DeductionRule['methodType']) || 'Pengurangan tetap'
      };
      const list = deductionRulesByCriterionId.get(criterionId) || [];
      list.push(item);
      deductionRulesByCriterionId.set(criterionId, list);
    });

    const criteriaByFieldId = new Map<string, RubricCriterion[]>();
    (rubricCriteriaRes.data || []).forEach((rc: Record<string, unknown>) => {
      const critId = String(rc.id);
      const fieldId = String(rc.rubric_field_id || '');
      const item: RubricCriterion = {
        id: critId,
        fieldId,
        code: rc.code ? String(rc.code) : undefined,
        name: String(rc.name || ''),
        description: rc.description ? String(rc.description) : undefined,
        maxDeduction: rc.max_deduction !== null && rc.max_deduction !== undefined ? Number(rc.max_deduction) : undefined,
        deductionRules: deductionRulesByCriterionId.get(critId) || []
      };
      const list = criteriaByFieldId.get(fieldId) || [];
      list.push(item);
      criteriaByFieldId.set(fieldId, list);
    });

    const fieldsByRubricVersionId = new Map<string, RubricField[]>();
    (rubricFieldsRes.data || []).forEach((rf: Record<string, unknown>) => {
      const fieldId = String(rf.id);
      const rvId = String(rf.rubric_version_id || '');
      const item: RubricField = {
        id: fieldId,
        code: String(rf.code || ''),
        name: String(rf.name || ''),
        maxScore: Number(rf.max_score ?? 0),
        minScore: Number(rf.min_score ?? 0),
        maxDeduction: rf.max_deduction !== null && rf.max_deduction !== undefined ? Number(rf.max_deduction) : undefined,
        maxAllowedErrors:
          rf.max_allowed_errors !== null && rf.max_allowed_errors !== undefined ? Number(rf.max_allowed_errors) : undefined,
        weight: rf.weight !== null && rf.weight !== undefined ? Number(rf.weight) : undefined,
        order: Number(rf.field_order || 1),
        description: rf.description ? String(rf.description) : undefined,
        status: (rf.status as RubricField['status']) || 'Aktif',
        criteria: criteriaByFieldId.get(fieldId) || []
      };
      const list = fieldsByRubricVersionId.get(rvId) || [];
      list.push(item);
      fieldsByRubricVersionId.set(rvId, list);
    });

    // Clear errorCategories.fieldId only if it points to a non-existent/deleted field ID; never re-attach NULL field_id by guessing scope
    const allHydratedFields: RubricField[] = Array.from(fieldsByRubricVersionId.values()).flat();
    const validFieldIds = new Set(allHydratedFields.map((f) => f.id));
    errorCategories.forEach((cat) => {
      if (cat.fieldId && !validFieldIds.has(cat.fieldId)) {
        cat.fieldId = undefined;
      }
    });

    const rubricVersions: RubricVersion[] = (rubricVersionsRes.data || []).map((rv: Record<string, unknown>) => {
      const rvId = String(rv.id);
      const rawTenant = String(rv.tenant_id || SYSTEM_TENANT_UUID);
      const codeStr = String(rv.code || '');
      const sourceStr = rv.official_source ? String(rv.official_source) : undefined;
      const isOfficialVerified =
        codeStr === 'RUBRIC-SENI-BACA-2025' ||
        Boolean(sourceStr && sourceStr.includes('Buku Pedoman Musabaqah'));
      return {
        id: rvId,
        tenantId: rawTenant === SYSTEM_TENANT_UUID ? 'system' : rawTenant,
        code: codeStr,
        name: String(rv.name || ''),
        branchId: rv.branch_id ? String(rv.branch_id) : undefined,
        branchCode: String(rv.branch_code || ''),
        branchName: String(rv.branch_name || ''),
        levelId: rv.level_id ? String(rv.level_id) : undefined,
        version: String(rv.version || '2025.1'),
        description: String(rv.description || ''),
        officialSource: sourceStr,
        isOfficialVerified,
        status: (rv.status as RubricVersion['status']) || 'Aktif',
        startingScore: Number(rv.starting_score ?? 100),
        fields: fieldsByRubricVersionId.get(rvId) || [],
        createdAt: String(rv.created_at || new Date().toISOString())
      };
    });

    const competitionRules: CompetitionRuleConfig[] = (rulesRes.data || []).map((r: Record<string, unknown>) => {
      const bId = r.branch_id ? String(r.branch_id) : undefined;
      const lId = r.level_id ? String(r.level_id) : undefined;
      return {
        id: String(r.id),
        tenantId: String(r.tenant_id),
        branchId: bId,
        levelId: lId,
        branchName: String(r.branch_name || (bId && branchMap.get(bId)) || 'Tilawah Dewasa Putra'),
        rubricVersionId: String(r.rubric_version_id),
        tieBreakOrder: Array.isArray(r.tie_break_order)
          ? (r.tie_break_order as string[])
          : ['total', 'Tajwid', 'Lagu', 'Fashahah'],
        quotaPerStage: (r.quota_per_stage as Record<string, number>) || { Penyisihan: 3, Final: 3 },
        officialSource: r.official_source ? String(r.official_source) : undefined,
        isVerifiedOfficial: Boolean(r.is_verified_official),
        status: (r.status as CompetitionRuleConfig['status']) || 'Aktif',
        updatedAt: r.updated_at ? String(r.updated_at) : undefined
      };
    });

    const judgeNameByProfileId = new Map<string, { name: string; field: string }>();
    const judgeAssignments: JudgeAssignment[] = (judgeAsgRes.data || []).map((ja: Record<string, unknown>) => {
      const stgId = String(ja.stage_id);
      const stgInfo = stageMap.get(stgId);
      const bId = ja.branch_id ? String(ja.branch_id) : undefined;
      const prof = ja.profiles as { name?: string } | null;
      const judgeId = String(ja.judge_profile_id);
      const jName = prof?.name || 'Dewan Hakim';
      const jField = String(ja.judge_field || 'Bidang Penilaian');
      judgeNameByProfileId.set(judgeId, { name: jName, field: jField });
      return {
        id: String(ja.id),
        tenantId: String(ja.tenant_id),
        judgeId,
        judgeName: jName,
        stageId: stgId,
        stageName: stgInfo?.name || 'Penyisihan',
        branchId: bId,
        branchName:
          (bId && branchMap.get(bId)) ||
          (stgInfo?.branchId && stgInfo.branchName && stgInfo.branchName !== 'Semua Cabang'
            ? stgInfo.branchName
            : 'Semua Cabang'),
        judgeField: jField,
        rubricFieldId: ja.rubric_field_id ? String(ja.rubric_field_id) : undefined,
        levelId: ja.level_id ? String(ja.level_id) : undefined,
        levelName: ja.level_name ? String(ja.level_name) : undefined,
        status: (ja.status as 'Aktif' | 'Nonaktif') || 'Aktif'
      };
    });

    const spLookup = new Map<string, StageParticipation>();
    stageParticipations.forEach((s) => spLookup.set(s.id, s));

    const assessments: JudgeAssessment[] = (assessmentsRes.data || []).map((a: Record<string, unknown>) =>
      mapJudgeAssessmentRow(a, {
        spById: spLookup,
        questionIdByAssignedMaqraId: assignedMaqraIdToQuestionId,
        judgeInfoById: judgeNameByProfileId
      })
    );

    const stageSnapshots: StageResultSnapshot[] = (snapshotsRes.data || []).map((s: Record<string, unknown>) => {
      const stgId = String(s.stage_id);
      const bId = String(s.branch_id);
      return {
        id: String(s.id),
        tenantId: String(s.tenant_id),
        stageId: stgId,
        stageName: stageMap.get(stgId)?.name || 'Penyisihan',
        branchId: bId,
        branchName: branchMap.get(bId) || 'Tilawah Dewasa Putra',
        quota: Number(s.quota || 3),
        finalizedAt: String(s.created_at || ''),
        finalizedBy: String(s.finalized_by || ''),
        rubricVersionId: String(s.rubric_version_id || ''),
        tieBreakRuleUsed: String(s.tie_break_rule_used || ''),
        rankings: Array.isArray(s.rankings_snapshot)
          ? (s.rankings_snapshot as StageResultSnapshot['rankings'])
          : []
      };
    });

    const activeTenantObj = tenants.find((t) => t.id === tenantUuid);
    const auditLogs: AuditLogItem[] = (auditRes.data || []).map((al: Record<string, unknown>) => ({
      id: String(al.id),
      timestamp: String(al.created_at || ''),
      actor: String(al.actor_name || ''),
      action: String(al.action || ''),
      target: String(al.target || ''),
      tenantName: activeTenantObj?.name || 'Tenant Aktif',
      summary: String(al.summary || ''),
      reason: al.reason ? String(al.reason) : undefined,
      outcome: ((al.outcome as string) || 'Success') as 'Success' | 'Failed' | 'Warning'
    }));

    let lotteryDrawLogs: LotteryDrawLogItem[] = [];
    try {
      const { data: drawLogRows, error: drawLogErr } = await client
        .from('lottery_draw_logs')
        .select('*')
        .eq('tenant_id', tenantUuid)
        .order('created_at', { ascending: false })
        .limit(50);
      if (!drawLogErr && Array.isArray(drawLogRows)) {
        lotteryDrawLogs = drawLogRows.map((row: Record<string, unknown>) => ({
          id: String(row.id),
          tenantId: String(row.tenant_id),
          stageId: row.stage_id ? String(row.stage_id) : undefined,
          stageName: String(row.stage_name || 'Penyisihan'),
          branchId: row.branch_id ? String(row.branch_id) : undefined,
          branchName: String(row.branch_name || ''),
          levelId: row.level_id ? String(row.level_id) : undefined,
          levelName: row.level_name ? String(row.level_name) : undefined,
          actorId: row.actor_id ? String(row.actor_id) : undefined,
          actorName: String(row.actor_name || 'Administrator'),
          questionsPerParticipant: Number(row.questions_per_participant || 1),
          participantIds: Array.isArray(row.participant_ids) ? (row.participant_ids as string[]) : [],
          questionPoolIds: Array.isArray(row.question_pool_ids) ? (row.question_pool_ids as string[]) : [],
          drawResults: Array.isArray(row.draw_results) ? (row.draw_results as LotteryDrawResultItem[]) : [],
          drawVersion: Number(row.draw_version || 1),
          seedHex: row.seed_hex ? String(row.seed_hex) : undefined,
          seedSha256: row.seed_sha256 ? String(row.seed_sha256) : undefined,
          drawMode: (row.draw_mode as 'lottery_number' | 'maqra' | 'both') || 'both',
          notes: row.notes ? String(row.notes) : undefined,
          createdAt: String(row.created_at || new Date().toISOString())
        }));
      }
    } catch {
      // Tabel lottery_draw_logs bersifat opsional pada database yang belum menjalankan migrasi terbaru
    }

    return {
      success: true,
      tenantId: tenantUuid,
      mode: 'supabase_live',
      payload: {
        tenants,
        users,
        cabangList,
        jenjangList,
        kafilahs,
        participants: uniqueParticipants,
        stages,
        stageParticipations,
        questions,
        errorCategories,
        rubricVersions,
        competitionRules,
        judgeAssignments,
        assessments,
        stageSnapshots,
        auditLogs,
        lotteryDrawLogs
      }
    };
  },

  /**
   * Wrapper kompatibel yang mengembalikan payload apabila seluruh query workspace berhasil,
   * atau null jika terjadi kegagalan koneksi/query.
   */
  async fetchTenantWorkspaceData(rawTenantId: string): Promise<HydratedWorkspacePayload | null> {
    const res = await this.fetchTenantWorkspaceResult(rawTenantId);
    if (!res.success || !res.payload) return null;
    return res.payload;
  },

  /**
   * Memastikan baris stage_participations benar-benar tersimpan di database,
   * dan mengembalikan ID baris nyata dari database.
   */
  async ensureStageParticipationPersisted(params: {
    stageParticipation: StageParticipation;
    participant?: Participant;
    levelId?: string | null;
  }): Promise<{ success: boolean; stageParticipationId?: string; message?: string }> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, message: 'Koneksi database tidak tersedia.' };
    }

    const { stageParticipation, participant, levelId } = params;
    const spId = isValidUuid(stageParticipation.id)
      ? stageParticipation.id
      : toDeterministicUuid(stageParticipation.id);
    const tenantId = isValidUuid(stageParticipation.tenantId)
      ? stageParticipation.tenantId
      : toDeterministicUuid(stageParticipation.tenantId);
    const participantId = isValidUuid(stageParticipation.participantId)
      ? stageParticipation.participantId
      : toDeterministicUuid(stageParticipation.participantId);
    const stageId = isValidUuid(stageParticipation.stageId)
      ? stageParticipation.stageId
      : toDeterministicUuid(stageParticipation.stageId);

    // 1. Cek apakah sudah ada baris di stage_participations
    const { data: existingById } = await client
      .from('stage_participations')
      .select('id')
      .eq('id', spId)
      .maybeSingle();

    if (existingById?.id) {
      return { success: true, stageParticipationId: String(existingById.id) };
    }

    const { data: existingByComposite } = await client
      .from('stage_participations')
      .select('id')
      .eq('tenant_id', tenantId)
      .eq('stage_id', stageId)
      .eq('participant_id', participantId)
      .maybeSingle();

    if (existingByComposite?.id) {
      return { success: true, stageParticipationId: String(existingByComposite.id) };
    }

    // 2. Pastikan participant sudah ada di database; jika belum dan objek participant diberikan, simpan dulu
    const { data: existingParticipant } = await client
      .from('participants')
      .select('id')
      .eq('id', participantId)
      .maybeSingle();

    if (!existingParticipant?.id && participant) {
      const partRes = await this.upsertParticipantWithStage({
        participant: { ...participant, id: participantId, tenantId },
        stageParticipation: { ...stageParticipation, id: spId, tenantId, participantId, stageId },
        levelId
      });
      if (!partRes.success) {
        return { success: false, message: partRes.message };
      }
      const persistedId =
        (partRes.data as { stageParticipationId?: string })?.stageParticipationId || spId;
      return { success: true, stageParticipationId: persistedId };
    }

    // 3. Verifikasi FK tenant, stage, dan participant sebelum insert stage_participations
    const fkCheck = await this.verifyDatabaseReferencesExist({
      tenantId,
      stageId,
      participantId
    });
    if (!fkCheck.valid) {
      return { success: false, message: fkCheck.message };
    }

    const { data: insertedSp, error: spErr } = await client
      .from('stage_participations')
      .upsert(
        {
          id: spId,
          tenant_id: tenantId,
          participant_id: participantId,
          stage_id: stageId,
          lottery_number: stageParticipation.lotteryNumber,
          status: stageParticipation.status
        },
        { onConflict: 'tenant_id,stage_id,participant_id' }
      )
      .select('id')
      .maybeSingle();

    if (spErr) {
      return { success: false, message: spErr.message };
    }

    if (insertedSp?.id) {
      return { success: true, stageParticipationId: String(insertedSp.id) };
    }

    const { data: recheckSp } = await client
      .from('stage_participations')
      .select('id')
      .eq('tenant_id', tenantId)
      .eq('stage_id', stageId)
      .eq('participant_id', participantId)
      .maybeSingle();

    return {
      success: Boolean(recheckSp?.id),
      stageParticipationId: recheckSp?.id ? String(recheckSp.id) : spId
    };
  },

  /**
   * RPC 1: Finalisasi & Penguncian Lembar Penilaian oleh Hakim Bertugas (Server-Side Atomic Lock).
   */
  async finalizeJudgeAssessmentRpc(assessmentId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ p_assessment_id: assessmentId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }

    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        mode: 'local_offline_fallback',
        message: 'Supabase belum dikonfigurasi. Finalisasi lembar nilai dieksekusi pada penyimpanan lokal.'
      };
    }

    const { data, error } = await client.rpc('finalize_judge_assessment', {
      p_assessment_id: assessmentId
    });

    if (error) {
      return {
        success: false,
        mode: 'supabase_live',
        message: error.message || 'Gagal mengeksekusi RPC finalize_judge_assessment.'
      };
    }

    return {
      success: true,
      mode: 'supabase_live',
      message: (data as { message?: string })?.message || 'Lembar penilaian berhasil dikunci melalui RPC.',
      data
    };
  },

  /**
   * RPC 2: Pembukaan Kembali Lembar Penilaian Final oleh Administrator dengan Alasan Audit.
   */
  async reopenJudgeAssessmentRpc(assessmentId: string, reason: string): Promise<RpcServiceResult> {
    if (!reason || reason.trim().length < 5) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: 'Alasan pembukaan kembali lembar nilai wajib diisi minimal 5 karakter untuk rekaman audit trail.'
      };
    }

    const uuidCheck = this.validateReferences({ p_assessment_id: assessmentId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }

    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        mode: 'local_offline_fallback',
        message: 'Supabase belum dikonfigurasi. Pembukaan kembali lembar nilai dieksekusi pada penyimpanan lokal.'
      };
    }

    const { data, error } = await client.rpc('reopen_judge_assessment', {
      p_assessment_id: assessmentId,
      p_reason: reason.trim()
    });

    if (error) {
      return {
        success: false,
        mode: 'supabase_live',
        message: error.message || 'Gagal mengeksekusi RPC reopen_judge_assessment.'
      };
    }

    return {
      success: true,
      mode: 'supabase_live',
      message: (data as { message?: string })?.message || 'Lembar penilaian berhasil dibuka kembali melalui RPC.',
      data
    };
  },

  /**
   * RPC 2b: Perhitungan Peringkat & Deteksi Seri Resmi di Server (compute_stage_rankings).
   */
  async computeStageRankingsRpc(stageId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ p_stage_id: stageId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }

    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        mode: 'local_offline_fallback',
        message: 'Supabase belum dikonfigurasi. Perhitungan peringkat dieksekusi pada penyimpanan lokal.'
      };
    }

    const { data, error } = await client.rpc('compute_stage_rankings', {
      p_stage_id: stageId
    });

    if (error) {
      return {
        success: false,
        mode: 'supabase_live',
        message: error.message || 'Gagal mengeksekusi RPC compute_stage_rankings.'
      };
    }

    return {
      success: true,
      mode: 'supabase_live',
      message: 'Peringkat babak berhasil dihitung di server.',
      data
    };
  },

  /**
   * RPC 3: Pengesahan Babak & Pelolosan Kualifikasi Atomik di Server (Termasuk Babak Final dengan nextStageId = null).
   */
  async advanceStageQualifiersRpc(params: {
    stageId: string;
    nextStageId: string | null;
    qualifiedParticipantIds: string[];
    overrideReasons: Record<string, string>;
    rankingsSnapshot?: unknown;
    tieResolution?: Record<string, number>;
  }): Promise<RpcServiceResult> {
    const refMap: Record<string, string | undefined | null> = {
      p_stage_id: params.stageId
    };
    if (params.nextStageId) {
      refMap.p_next_stage_id = params.nextStageId;
    }
    params.qualifiedParticipantIds.forEach((pid, idx) => {
      refMap[`qualified_participant_ids[${idx}]`] = pid;
    });

    const uuidCheck = this.validateReferences(refMap);
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }

    for (const [pid, r] of Object.entries(params.overrideReasons || {})) {
      if (!r || r.trim().length < 5) {
        return {
          success: false,
          mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
          message: `Alasan override manual untuk peserta ${pid} wajib minimal 5 karakter.`
        };
      }
    }

    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        mode: 'local_offline_fallback',
        message: 'Supabase belum dikonfigurasi. Pengesahan babak dieksekusi pada penyimpanan lokal.'
      };
    }

    // Verifikasi bahwa babak asal (dan babak tujuan jika ada) benar-benar ada di database
    const fkCheck = await this.verifyDatabaseReferencesExist({
      stageId: params.stageId
    });
    if (!fkCheck.valid) {
      return {
        success: false,
        mode: 'supabase_live',
        message: fkCheck.message!
      };
    }
    if (params.nextStageId) {
      const nextStageCheck = await this.verifyDatabaseReferencesExist({
        stageId: params.nextStageId
      });
      if (!nextStageCheck.valid) {
        return {
          success: false,
          mode: 'supabase_live',
          message: nextStageCheck.message!
        };
      }
    }

    const { data, error } = await client.rpc('advance_stage_qualifiers', {
      p_stage_id: params.stageId,
      p_next_stage_id: params.nextStageId,
      p_qualified_participant_ids: params.qualifiedParticipantIds,
      p_override_reasons: params.overrideReasons,
      p_rankings_snapshot: params.rankingsSnapshot ?? [],
      p_tie_resolution: params.tieResolution ?? {}
    });

    if (error) {
      return {
        success: false,
        mode: 'supabase_live',
        message: error.message || 'Gagal mengeksekusi RPC advance_stage_qualifiers.'
      };
    }

    return {
      success: true,
      mode: 'supabase_live',
      message: (data as { message?: string })?.message || 'Babak berhasil disahkan melalui RPC.',
      data
    };
  },

  /**
   * P0-04: Transaksi Atomik Undian & Penetapan Maqra via commit_lottery_draw RPC.
   * Memvalidasi relasi 3D (babak, cabang, jenjang) dan mencatat assigned_maqras,
   * stage_participations, lottery_draw_logs, dan audit_logs dalam 1 transaksi atomik.
   */
  async commitLotteryDrawRpc(params: {
    tenantId: string;
    stageId: string;
    stageName: string;
    branchId?: string | null;
    branchName?: string | null;
    levelId?: string | null;
    levelName?: string | null;
    actorId?: string | null;
    actorName?: string | null;
    results: Array<{
      participantId: string;
      questionIds: string[];
    }>;
    questionsPerParticipant?: number;
    notes?: string | null;
  }): Promise<{ success: boolean; message: string; data?: any }> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, message: 'Koneksi database tidak tersedia.' };
    }

    // 1.5 Keamanan Audit Undian: Server mengabaikan p_actor_id & p_actor_name dari klien
    // dan selalu menggunakan auth.uid() serta profiles.name yang terverifikasi di PostgreSQL.
    const { data, error } = await client.rpc('commit_lottery_draw', {
      p_tenant_id: params.tenantId,
      p_stage_id: params.stageId,
      p_stage_name: params.stageName,
      p_branch_id: params.branchId || null,
      p_branch_name: params.branchName || null,
      p_level_id: params.levelId || null,
      p_level_name: params.levelName || null,
      p_actor_id: null,
      p_actor_name: null,
      p_results: params.results,
      p_questions_per_participant: params.questionsPerParticipant || 1,
      p_notes: params.notes || null
    });

    if (error) {
      return {
        success: false,
        message: error.message || 'Gagal mengeksekusi RPC commit_lottery_draw.'
      };
    }

    return {
      success: true,
      message: (data as { message?: string })?.message || 'Hasil undian maqra berhasil ditetapkan secara atomik.',
      data
    };
  },

  /**
   * 3.1 Verifikasi Berkas Peserta via verify_participant RPC.
   */
  async verifyParticipantRpc(params: {
    tenantId: string;
    participantId: string;
    status: 'Diajukan' | 'Diverifikasi' | 'Ditolak';
    note?: string | null;
  }): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({
      p_tenant_id: params.tenantId,
      p_participant_id: params.participantId
    });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }

    if (params.status === 'Ditolak' && (!params.note || params.note.trim().length < 5)) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: 'Alasan penolakan berkas wajib diisi minimal 5 karakter.'
      };
    }

    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        mode: 'local_offline_fallback',
        message: 'Mode lokal aktif.'
      };
    }

    const { data, error } = await client.rpc('verify_participant', {
      p_tenant_id: params.tenantId,
      p_participant_id: params.participantId,
      p_status: params.status,
      p_note: params.note || null
    });

    if (error) {
      return {
        success: false,
        mode: 'supabase_live',
        message: error.message || 'Gagal memverifikasi berkas peserta.'
      };
    }

    return {
      success: true,
      mode: 'supabase_live',
      message: (data as { message?: string })?.message || `Status verifikasi peserta diperbarui menjadi ${params.status}.`,
      data
    };
  },

  /**
   * 3.2 & 3.3 Undian Nomor Tampil & Maqra di Server via draw_lottery_server RPC.
   */
  async drawLotteryServerRpc(params: {
    tenantId: string;
    stageId: string;
    branchId?: string | null;
    levelId?: string | null;
    questionsPerParticipant?: number;
    drawMode?: 'lottery_number' | 'maqra' | 'both';
    notes?: string | null;
    participantIds?: string[];
    questionPoolIds?: string[];
  }): Promise<{ success: boolean; message: string; data?: any }> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, message: 'Koneksi database tidak tersedia.' };
    }

    const { data, error } = await client.rpc('draw_lottery_server', {
      p_tenant_id: params.tenantId,
      p_stage_id: params.stageId,
      p_branch_id: params.branchId && isValidUuid(params.branchId) ? params.branchId : null,
      p_level_id: params.levelId && isValidUuid(params.levelId) ? params.levelId : null,
      p_questions_per_participant: params.questionsPerParticipant || 1,
      p_draw_mode: params.drawMode || 'both',
      p_notes: params.notes || null,
      p_participant_ids: params.participantIds && params.participantIds.length > 0 ? params.participantIds : null,
      p_question_pool_ids: params.questionPoolIds && params.questionPoolIds.length > 0 ? params.questionPoolIds : null
    });

    if (error) {
      return {
        success: false,
        message: error.message || 'Gagal mengeksekusi RPC draw_lottery_server.'
      };
    }

    return {
      success: true,
      message: (data as { message?: string })?.message || 'Undian server berhasil dieksekusi secara atomik.',
      data
    };
  },

  /**
   * Mencari atau menyimpan baris assigned_maqras yang nyata di database
   * dan mengembalikan ID primary key sebenarnya dari tabel assigned_maqras.
   */
  async resolveOrPersistAssignedMaqraId(params: {
    tenantId: string;
    stageParticipationId: string;
    questionId?: string;
    assignedMaqraRecordId?: string;
  }): Promise<{ success: boolean; assignedMaqraId?: string; message?: string }> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, message: 'Koneksi database tidak tersedia.' };
    }

    const { tenantId, stageParticipationId, questionId, assignedMaqraRecordId } = params;

    // 1. Jika ada assignedMaqraRecordId, cek apakah baris tersebut benar-benar merupakan assigned_maqras.id di DB
    if (assignedMaqraRecordId && isValidUuid(assignedMaqraRecordId)) {
      const { data: byId } = await client
        .from('assigned_maqras')
        .select('id, question_id')
        .eq('id', assignedMaqraRecordId)
        .eq('stage_participation_id', stageParticipationId)
        .maybeSingle();

      if (byId?.id) {
        return { success: true, assignedMaqraId: String(byId.id) };
      }
    }

    // 2. Cari berdasarkan kombinasi unik (stage_participation_id, question_id)
    const candidateQuestionId = questionId || assignedMaqraRecordId;
    if (candidateQuestionId && isValidUuid(candidateQuestionId)) {
      const { data: byPair } = await client
        .from('assigned_maqras')
        .select('id')
        .eq('stage_participation_id', stageParticipationId)
        .eq('question_id', candidateQuestionId)
        .maybeSingle();

      if (byPair?.id) {
        return { success: true, assignedMaqraId: String(byPair.id) };
      }

      // 3. Jika belum ada di assigned_maqras, pastikan question_id ada di tabel questions lalu buat melalui assignMaqraRecord
      const amRes = await this.assignMaqraRecord({
        id:
          assignedMaqraRecordId &&
          isValidUuid(assignedMaqraRecordId) &&
          assignedMaqraRecordId !== candidateQuestionId
            ? assignedMaqraRecordId
            : toDeterministicUuid(`am-${stageParticipationId}-${candidateQuestionId}`),
        tenantId,
        stageParticipationId,
        questionId: candidateQuestionId,
        method: 'undian'
      });

      if (amRes.success) {
        const persistedAmId = (amRes.data as { assignedMaqraId?: string })?.assignedMaqraId;
        if (persistedAmId) {
          return { success: true, assignedMaqraId: persistedAmId };
        }
      } else {
        return { success: false, message: amRes.message };
      }
    }

    // 4. Fallback: cek apakah ada minimal 1 baris assigned_maqras untuk stage_participation_id ini
    const { data: firstAm } = await client
      .from('assigned_maqras')
      .select('id')
      .eq('stage_participation_id', stageParticipationId)
      .limit(1)
      .maybeSingle();

    if (firstAm?.id) {
      return { success: true, assignedMaqraId: String(firstAm.id) };
    }

    return {
      success: false,
      message:
        'Penetapan maqra (assigned_maqras) belum ditemukan di database untuk peserta pada babak ini. Tetapkan maqra terlebih dahulu.'
    };
  },

  /**
   * Menyimpan draf lembar penilaian yang belum terkunci ke tabel judge_assessments
   * hanya apabila seluruh baris referensi foreign key terbukti ada di database,
   * serta menggunakan assigned_maqra_id nyata dari database.
   */
  async syncAssessmentToRemote(
    assessment: JudgeAssessment,
    assignedMaqraRecordId?: string,
    contextRecords?: {
      stageParticipation?: StageParticipation;
      participant?: Participant;
      levelId?: string | null;
    }
  ): Promise<RpcServiceResult> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        mode: 'local_offline_fallback',
        message: 'Mode lokal aktif: perubahan lembar penilaian disimpan di penyimpanan lokal.'
      };
    }

    let effectiveSpId = assessment.stageParticipationId;
    if (contextRecords?.stageParticipation) {
      const spEnsure = await this.ensureStageParticipationPersisted({
        stageParticipation: contextRecords.stageParticipation,
        participant: contextRecords.participant,
        levelId: contextRecords.levelId
      });
      if (!spEnsure.success || !spEnsure.stageParticipationId) {
        return {
          success: false,
          mode: 'supabase_live',
          message: spEnsure.message || 'Gagal memastikan data partisipasi babak di database.'
        };
      }
      effectiveSpId = spEnsure.stageParticipationId;
    }

    // Resolusi ID baris assigned_maqras yang benar-benar ada di database
    const amResolution = await this.resolveOrPersistAssignedMaqraId({
      tenantId: assessment.tenantId,
      stageParticipationId: effectiveSpId,
      questionId: assessment.questionId,
      assignedMaqraRecordId: assignedMaqraRecordId || assessment.assignedMaqraId
    });

    if (!amResolution.success || !amResolution.assignedMaqraId) {
      return {
        success: false,
        mode: 'supabase_live',
        message:
          amResolution.message ||
          'Gagal memverifikasi atau menyimpan baris assigned_maqras di database.'
      };
    }

    const realAssignedMaqraId = amResolution.assignedMaqraId;

    const uuidCheck = this.validateReferences({
      id: assessment.id,
      tenant_id: assessment.tenantId,
      stage_participation_id: effectiveSpId,
      assigned_maqra_id: realAssignedMaqraId,
      judge_profile_id: assessment.judgeId,
      rubric_version_id: assessment.rubricVersionId
    });

    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: 'supabase_live',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }

    // Verifikasi eksistensi nyata dari seluruh foreign key di database
    const fkExistCheck = await this.verifyDatabaseReferencesExist({
      tenantId: assessment.tenantId,
      stageParticipationId: effectiveSpId,
      assignedMaqraId: realAssignedMaqraId,
      judgeProfileId: assessment.judgeId,
      rubricVersionId: assessment.rubricVersionId
    });

    if (!fkExistCheck.valid) {
      return {
        success: false,
        mode: 'supabase_live',
        message: fkExistCheck.message!,
        validationErrors: fkExistCheck.missingReferences
      };
    }

    // Pastikan tidak pernah mengirim status 'finalized' atau is_locked = true lewat Data API
    const { data: upsertedRow, error } = await client
      .from('judge_assessments')
      .upsert(
        {
          id: assessment.id,
          tenant_id: assessment.tenantId,
          stage_participation_id: effectiveSpId,
          assigned_maqra_id: realAssignedMaqraId,
          judge_profile_id: assessment.judgeId,
          rubric_version_id: assessment.rubricVersionId,
          status: assessment.status === 'finalized' ? 'in_progress' : assessment.status,
          total_deductions: assessment.totalDeductions,
          final_score: assessment.finalScore,
          field_scores: assessment.fieldScores || {},
          error_counts: assessment.errorCounts || {},
          annotations: assessment.annotations || [],
          is_locked: false,
          updated_at: new Date().toISOString()
        },
        { onConflict: 'stage_participation_id,assigned_maqra_id,judge_profile_id' }
      )
      .select('id, stage_participation_id, assigned_maqra_id, status, is_locked')
      .maybeSingle();

    if (error) {
      return {
        success: false,
        mode: 'supabase_live',
        message: error.message
      };
    }

    const persistedAssessmentId = upsertedRow?.id ? String(upsertedRow.id) : assessment.id;

    return {
      success: true,
      mode: 'supabase_live',
      message: 'Lembar penilaian draf tersinkronisasi ke tabel judge_assessments.',
      data: {
        assessmentId: persistedAssessmentId,
        stageParticipationId: effectiveSpId,
        assignedMaqraId: realAssignedMaqraId
      }
    };
  },

  /**
   * Menyimpan pendaftaran peserta beserta baris partisipasi babak awal ke Supabase
   * dengan verifikasi keberadaan nyata tenant, kafilah, branch, dan stage di database.
   */
  async upsertParticipantWithStage(params: {
    participant: Participant;
    stageParticipation: StageParticipation;
    levelId?: string | null;
    autoCreateMissingMaster?: boolean;
  }): Promise<RpcServiceResult> {
    const { participant, stageParticipation, levelId, autoCreateMissingMaster } = params;
    const uuidCheck = this.validateReferences({
      participant_id: participant.id,
      tenant_id: participant.tenantId,
      kafilah_id: participant.kafilahId,
      branch_id: participant.branchId,
      stage_participation_id: stageParticipation.id,
      stage_id: stageParticipation.stageId
    });

    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }

    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        mode: 'local_offline_fallback',
        message: 'Mode lokal: peserta disimpan pada localStorage.'
      };
    }

    if (autoCreateMissingMaster) {
      try {
        const { data: existingBranch } = await client
          .from('branches')
          .select('id')
          .eq('id', participant.branchId)
          .maybeSingle();
        if (!existingBranch?.id && participant.branchName && participant.branchId) {
          const autoCode = participant.branchName
            .toUpperCase()
            .replace(/[^A-Z0-9]/g, '-')
            .slice(0, 20);
          await client.from('branches').upsert({
            id: participant.branchId,
            tenant_id: participant.tenantId,
            code: `${autoCode}-${participant.branchId.slice(0, 4).toUpperCase()}`,
            name: participant.branchName,
            status: 'Aktif'
          });
        }

        const { data: existingStage } = await client
          .from('stages')
          .select('id')
          .eq('id', stageParticipation.stageId)
          .maybeSingle();
        if (!existingStage?.id && stageParticipation.stageName) {
          await client.from('stages').upsert({
            id: stageParticipation.stageId,
            tenant_id: participant.tenantId,
            branch_id: participant.branchId,
            name: stageParticipation.stageName,
            stage_order: stageParticipation.stageName === 'Final' ? 2 : 1,
            qualification_quota: 3,
            qualification_method: 'top_n',
            status: 'Aktif',
            is_finalized: false
          });
        }
      } catch {
        // Proceed to standard FK verification
      }
    }

    const fkCheck = await this.verifyDatabaseReferencesExist({
      tenantId: participant.tenantId,
      kafilahId: participant.kafilahId,
      branchId: participant.branchId,
      stageId: stageParticipation.stageId
    });
    if (!fkCheck.valid) {
      return {
        success: false,
        mode: 'supabase_live',
        message: fkCheck.message!,
        validationErrors: fkCheck.missingReferences
      };
    }

    const resolvedLevelId =
      (levelId && isValidUuid(levelId) ? levelId : null) ||
      (participant.levelId && isValidUuid(participant.levelId) ? participant.levelId : null);

    const baseParticipantPayload = {
      id: participant.id,
      tenant_id: participant.tenantId,
      participant_code: participant.participantId,
      lottery_number: participant.lotteryNumber,
      name: participant.name,
      gender: participant.gender,
      kafilah_id: participant.kafilahId,
      branch_id: participant.branchId,
      level_id: resolvedLevelId,
      status: participant.status
    };

    const extendedParticipantPayload = {
      ...baseParticipantPayload,
      admin_sequence_number: participant.adminSequenceNumber || null,
      father_name: participant.fatherName || null,
      origin_city: participant.originCity || null,
      origin_region: participant.originRegion || null,
      origin_institution: participant.originInstitution || null,
      stage_id: stageParticipation.stageId && isValidUuid(stageParticipation.stageId) ? stageParticipation.stageId : null,
      verification_status: participant.verificationStatus || 'Diajukan',
      verification_note: participant.verificationNote || null
    };

    let { error: partErr } = await client.from('participants').upsert(extendedParticipantPayload);
    if (partErr && (partErr.message?.includes('column') || partErr.code === 'PGRST204')) {
      const retryRes = await client.from('participants').upsert(baseParticipantPayload);
      partErr = retryRes.error;
    }

    if (partErr) {
      return { success: false, mode: 'supabase_live', message: partErr.message };
    }

    const { data: spRow, error: spErr } = await client
      .from('stage_participations')
      .upsert(
        {
          id: stageParticipation.id,
          tenant_id: stageParticipation.tenantId,
          participant_id: participant.id,
          stage_id: stageParticipation.stageId,
          lottery_number: stageParticipation.lotteryNumber,
          status: stageParticipation.status
        },
        { onConflict: 'tenant_id,stage_id,participant_id' }
      )
      .select('id')
      .maybeSingle();

    if (spErr) {
      return { success: false, mode: 'supabase_live', message: spErr.message };
    }

    const realSpId = spRow?.id ? String(spRow.id) : stageParticipation.id;

    return {
      success: true,
      mode: 'supabase_live',
      message: 'Peserta dan partisipasi babak awal tersimpan di Supabase.',
      data: {
        participantId: participant.id,
        stageParticipationId: realSpId
      }
    };
  },

  /**
   * Mencatat penetapan maqra (assigned_maqras) pada Supabase, memverifikasi keberadaan
   * stage_participations dan questions di database, memperbarui status stage_participations,
   * serta mengembalikan ID baris nyata (assigned_maqras.id) dari database.
   */
  async assignMaqraRecord(params: {
    id: string;
    tenantId: string;
    stageParticipationId: string;
    questionId: string;
    method?: 'undian' | 'manual' | 'jadwal';
    stageParticipation?: StageParticipation;
    participant?: Participant;
  }): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({
      id: params.id,
      tenant_id: params.tenantId,
      stage_participation_id: params.stageParticipationId,
      question_id: params.questionId
    });

    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }

    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        mode: 'local_offline_fallback',
        message: 'Mode lokal: penetapan maqra disimpan di penyimpanan lokal.'
      };
    }

    let effectiveSpId = params.stageParticipationId;
    if (params.stageParticipation) {
      const spEnsure = await this.ensureStageParticipationPersisted({
        stageParticipation: params.stageParticipation,
        participant: params.participant
      });
      if (!spEnsure.success || !spEnsure.stageParticipationId) {
        return {
          success: false,
          mode: 'supabase_live',
          message: spEnsure.message || 'Gagal memastikan stage_participations di database sebelum penetapan maqra.'
        };
      }
      effectiveSpId = spEnsure.stageParticipationId;
    }

    const fkCheck = await this.verifyDatabaseReferencesExist({
      tenantId: params.tenantId,
      stageParticipationId: effectiveSpId,
      questionId: params.questionId
    });
    if (!fkCheck.valid) {
      return {
        success: false,
        mode: 'supabase_live',
        message: fkCheck.message!,
        validationErrors: fkCheck.missingReferences
      };
    }

    const normalizedMethod = String(params.method || 'undian').toLowerCase();
    const validMethod =
      normalizedMethod === 'manual' || normalizedMethod === 'jadwal' ? normalizedMethod : 'undian';

    const { data: upsertedRow, error } = await client
      .from('assigned_maqras')
      .upsert(
        {
          id: params.id || generateUuid(),
          tenant_id: params.tenantId,
          stage_participation_id: effectiveSpId,
          question_id: params.questionId,
          method: validMethod
        },
        { onConflict: 'stage_participation_id,question_id' }
      )
      .select('id, stage_participation_id, question_id, assigned_at, method')
      .maybeSingle();

    if (error) {
      return { success: false, mode: 'supabase_live', message: error.message };
    }

    let realAssignedMaqraId = upsertedRow?.id ? String(upsertedRow.id) : '';
    if (!realAssignedMaqraId) {
      const { data: fetchedRow, error: fetchErr } = await client
        .from('assigned_maqras')
        .select('id, stage_participation_id, question_id, assigned_at')
        .eq('stage_participation_id', effectiveSpId)
        .eq('question_id', params.questionId)
        .maybeSingle();

      if (fetchErr || !fetchedRow?.id) {
        return {
          success: false,
          mode: 'supabase_live',
          message: fetchErr?.message || 'Gagal membaca kembali ID baris assigned_maqras dari database.'
        };
      }
      realAssignedMaqraId = String(fetchedRow.id);
    }

    await client
      .from('stage_participations')
      .update({ status: 'Belum Dimulai', updated_at: new Date().toISOString() })
      .eq('id', effectiveSpId)
      .eq('status', 'Maqra Belum Ditetapkan');

    return {
      success: true,
      mode: 'supabase_live',
      message: 'Penetapan maqra berhasil disimpan ke tabel assigned_maqras.',
      data: {
        assignedMaqraId: realAssignedMaqraId,
        stageParticipationId: effectiveSpId,
        questionId: params.questionId
      }
    };
  },

  async upsertKafilah(kafilah: Kafilah): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: kafilah.id, tenant_id: kafilah.tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const fkCheck = await this.verifyDatabaseReferencesExist({ tenantId: kafilah.tenantId });
    if (!fkCheck.valid) {
      return { success: false, mode: 'supabase_live', message: fkCheck.message! };
    }
    const { error } = await client.from('kafilahs').upsert({
      id: kafilah.id,
      tenant_id: kafilah.tenantId,
      code: kafilah.code,
      name: kafilah.name,
      region: kafilah.region,
      leader_name: kafilah.contactPerson,
      contact_person: kafilah.contactPerson,
      contact_phone: kafilah.contactPhone,
      status: kafilah.status
    });
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Kafilah tersimpan di Supabase.' };
  },

  async upsertQuestion(
    question: Question,
    branchId?: string,
    stageId?: string,
    levelId?: string
  ): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: question.id, tenant_id: question.tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const effectiveBranchId = branchId || question.branchId;
    const effectiveStageId = stageId || question.stageId;
    const effectiveLevelId = levelId || question.levelId;
    const fkCheck = await this.verifyDatabaseReferencesExist({
      tenantId: question.tenantId,
      branchId: effectiveBranchId && isValidUuid(effectiveBranchId) ? effectiveBranchId : undefined,
      stageId: effectiveStageId && isValidUuid(effectiveStageId) ? effectiveStageId : undefined
    });
    if (!fkCheck.valid) {
      return { success: false, mode: 'supabase_live', message: fkCheck.message! };
    }
    const baseQuestionPayload = {
      id: question.id,
      tenant_id: question.tenantId,
      code: question.code,
      title: question.title,
      surah_name: question.surahName,
      surah_number: question.surahNumber,
      start_ayah: question.startAyah,
      end_ayah: question.endAyah,
      page_number: question.pageNumber,
      page_start: question.pageStart || question.pageNumber,
      page_end: question.pageEnd || question.pageNumber,
      branch_id: effectiveBranchId && isValidUuid(effectiveBranchId) ? effectiveBranchId : null,
      stage_id: effectiveStageId && isValidUuid(effectiveStageId) ? effectiveStageId : null,
      status: question.status,
      description: question.description || null
    };
    const extendedQuestionPayload = {
      ...baseQuestionPayload,
      level_id: effectiveLevelId && isValidUuid(effectiveLevelId) ? effectiveLevelId : null
    };
    let { error } = await client.from('questions').upsert(extendedQuestionPayload);
    if (error && (error.message?.includes('column') || error.code === 'PGRST204')) {
      const retryRes = await client.from('questions').upsert(baseQuestionPayload);
      error = retryRes.error;
    }
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Soal maqra tersimpan di Supabase.' };
  },

  async insertLotteryDrawLog(log: LotteryDrawLogItem): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: log.id, tenant_id: log.tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const { error } = await client.from('lottery_draw_logs').upsert({
      id: log.id,
      tenant_id: log.tenantId,
      stage_id: log.stageId && isValidUuid(log.stageId) ? log.stageId : null,
      stage_name: log.stageName,
      branch_id: log.branchId && isValidUuid(log.branchId) ? log.branchId : null,
      branch_name: log.branchName,
      level_id: log.levelId && isValidUuid(log.levelId) ? log.levelId : null,
      level_name: log.levelName || null,
      actor_id: log.actorId && isValidUuid(log.actorId) ? log.actorId : null,
      actor_name: log.actorName,
      questions_per_participant: log.questionsPerParticipant,
      participant_ids: log.participantIds,
      question_pool_ids: log.questionPoolIds,
      draw_results: log.drawResults,
      draw_version: log.drawVersion,
      seed_hex: log.seedHex || null,
      seed_sha256: log.seedSha256 || null,
      draw_mode: log.drawMode || 'both',
      notes: log.notes || null,
      created_at: log.createdAt
    }, { onConflict: 'id', ignoreDuplicates: true });
    if (error) {
      return { success: false, mode: 'supabase_live', message: error.message };
    }
    return { success: true, mode: 'supabase_live', message: 'Riwayat undian maqra tercatat di database.' };
  },

  async upsertJudgeAssignment(assignment: JudgeAssignment): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({
      id: assignment.id,
      tenant_id: assignment.tenantId,
      stage_id: assignment.stageId,
      judge_profile_id: assignment.judgeId
    });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const fkCheck = await this.verifyDatabaseReferencesExist({
      tenantId: assignment.tenantId,
      stageId: assignment.stageId,
      judgeProfileId: assignment.judgeId,
      branchId: assignment.branchId && isValidUuid(assignment.branchId) ? assignment.branchId : undefined
    });
    if (!fkCheck.valid) {
      return { success: false, mode: 'supabase_live', message: fkCheck.message! };
    }
    const { error } = await client.from('judge_assignments').upsert({
      id: assignment.id,
      tenant_id: assignment.tenantId,
      stage_id: assignment.stageId,
      branch_id: assignment.branchId && isValidUuid(assignment.branchId) ? assignment.branchId : null,
      level_id: assignment.levelId && isValidUuid(assignment.levelId) ? assignment.levelId : null,
      level_name: assignment.levelName || null,
      rubric_field_id: assignment.rubricFieldId && isValidUuid(assignment.rubricFieldId) ? assignment.rubricFieldId : null,
      judge_field: assignment.judgeField,
      judge_profile_id: assignment.judgeId,
      status: 'Aktif'
    });
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Penugasan hakim tersimpan di Supabase.' };
  },

  async fetchCompetitionRules(tenantId: string): Promise<CompetitionRuleConfig[] | null> {
    const client = getActiveClient();
    if (!this.isLive() || !client || !isValidUuid(tenantId)) return null;
    const { data, error } = await client
      .from('competition_rule_configs')
      .select('*')
      .eq('tenant_id', tenantId);
    if (error || !data) return null;
    return data as unknown as CompetitionRuleConfig[];
  },

  async fetchStageResultSnapshots(tenantId: string): Promise<StageResultSnapshot[] | null> {
    const client = getActiveClient();
    if (!this.isLive() || !client || !isValidUuid(tenantId)) return null;
    const { data, error } = await client
      .from('stage_result_snapshots')
      .select('*')
      .eq('tenant_id', tenantId);
    if (error || !data) return null;
    return data as unknown as StageResultSnapshot[];
  },

  /**
   * Mencatat log audit administrasi melalui RPC tepercaya `append_admin_audit_log`
   * (bukan INSERT langsung ke tabel audit_logs yang telah dikunci).
   */
  async appendAuditLog(entry: AuditLogItem & { tenantId?: string; actorId?: string }): Promise<boolean> {
    const client = getActiveClient();
    if (!this.isLive() || !client) return false;
    if (!entry.tenantId || !isValidUuid(entry.tenantId)) return false;

    const reservedActions = new Set([
      'ASSESSMENT_FINALIZED',
      'ASSESSMENT_REOPENED',
      'STAGE_FINALIZED',
      'CHAMPIONSHIP_FINALIZED'
    ]);
    if (reservedActions.has((entry.action || '').trim().toUpperCase())) {
      // Sudah dicatat secara atomik oleh RPC transaksi utamanya
      return true;
    }

    const { error } = await client.rpc('append_admin_audit_log', {
      p_tenant_id: entry.tenantId,
      p_action: entry.action,
      p_target: entry.target,
      p_summary: entry.summary,
      p_reason: entry.reason ?? null,
      p_outcome: entry.outcome || 'Success'
    });

    return !error;
  },

  async deleteKafilah(tenantId: string, kafilahId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ tenant_id: tenantId, kafilah_id: kafilahId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const { error } = await client
      .from('kafilahs')
      .delete()
      .eq('id', kafilahId)
      .eq('tenant_id', tenantId);
    if (error) {
      if (error.message?.includes('violates foreign key') || error.message?.includes('participants')) {
        return {
          success: false,
          mode: 'supabase_live',
          message: 'Grup/Kafilah tidak dapat dihapus karena masih memiliki peserta terdaftar.'
        };
      }
      return { success: false, mode: 'supabase_live', message: error.message };
    }
    return { success: true, mode: 'supabase_live', message: 'Kafilah berhasil dihapus dari database.' };
  },

  async deleteParticipant(tenantId: string, participantId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ tenant_id: tenantId, participant_id: participantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }

    // S6: penghapusan transaksional di server (peserta + babak + maqra), ditolak bila sudah ada lembar nilai
    const { data, error } = await client.rpc('delete_participant_safe', {
      p_tenant_id: tenantId,
      p_participant_id: participantId
    });
    if (error) {
      return { success: false, mode: 'supabase_live', message: error.message };
    }
    return {
      success: true,
      mode: 'supabase_live',
      message: 'Peserta berhasil dihapus.',
      data
    };
  },

  async updateParticipantRecord(
    participant: Participant,
    branchId?: string,
    levelId?: string
  ): Promise<RpcServiceResult> {
    const effectiveBranchId = branchId || participant.branchId;
    const uuidCheck = this.validateReferences({
      id: participant.id,
      tenant_id: participant.tenantId,
      kafilah_id: participant.kafilahId,
      branch_id: effectiveBranchId
    });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!,
        validationErrors: uuidCheck.invalidFields
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const fkCheck = await this.verifyDatabaseReferencesExist({
      tenantId: participant.tenantId,
      kafilahId: participant.kafilahId,
      branchId: effectiveBranchId
    });
    if (!fkCheck.valid) {
      return { success: false, mode: 'supabase_live', message: fkCheck.message! };
    }

    const effectiveLevelId = levelId || participant.levelId;
    const baseUpdatePayload = {
      kafilah_id: participant.kafilahId,
      branch_id: effectiveBranchId,
      level_id: effectiveLevelId && isValidUuid(effectiveLevelId) ? effectiveLevelId : null,
      participant_code: participant.participantId,
      name: participant.name,
      gender: participant.gender,
      lottery_number: participant.lotteryNumber,
      status: participant.status,
      updated_at: new Date().toISOString()
    };

    const extendedUpdatePayload = {
      ...baseUpdatePayload,
      admin_sequence_number: participant.adminSequenceNumber || null,
      father_name: participant.fatherName || null,
      origin_city: participant.originCity || null,
      origin_region: participant.originRegion || null,
      origin_institution: participant.originInstitution || null,
      stage_id: participant.stageId && isValidUuid(participant.stageId) ? participant.stageId : null,
      ...(participant.verificationStatus ? { verification_status: participant.verificationStatus } : {}),
      ...(participant.verificationNote !== undefined ? { verification_note: participant.verificationNote || null } : {})
    };

    let { error } = await client
      .from('participants')
      .update(extendedUpdatePayload)
      .eq('id', participant.id)
      .eq('tenant_id', participant.tenantId);

    if (error && (error.message?.includes('column') || error.code === 'PGRST204')) {
      const retryRes = await client
        .from('participants')
        .update(baseUpdatePayload)
        .eq('id', participant.id)
        .eq('tenant_id', participant.tenantId);
      error = retryRes.error;
    }

    if (error) return { success: false, mode: 'supabase_live', message: error.message };

    await client
      .from('stage_participations')
      .update({
        lottery_number: participant.lotteryNumber,
        updated_at: new Date().toISOString()
      })
      .eq('participant_id', participant.id)
      .eq('tenant_id', participant.tenantId);

    return { success: true, mode: 'supabase_live', message: 'Data peserta berhasil diperbarui di database.' };
  },

  async deleteQuestion(tenantId: string, questionId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ tenant_id: tenantId, question_id: questionId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    try {
      await client
        .from('assigned_maqras')
        .delete()
        .eq('question_id', questionId)
        .eq('tenant_id', tenantId);
    } catch {}
    const { error } = await client
      .from('questions')
      .delete()
      .eq('id', questionId)
      .eq('tenant_id', tenantId);
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Paket soal dihapus dari database.' };
  },

  async unassignMaqraRecord(params: {
    tenantId: string;
    stageParticipationId: string;
    questionId?: string;
  }): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({
      tenant_id: params.tenantId,
      stage_participation_id: params.stageParticipationId,
      ...(params.questionId ? { question_id: params.questionId } : {})
    });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }

    let deleteQuery = client
      .from('assigned_maqras')
      .delete()
      .eq('tenant_id', params.tenantId)
      .eq('stage_participation_id', params.stageParticipationId);

    if (params.questionId && isValidUuid(params.questionId)) {
      deleteQuery = deleteQuery.eq('question_id', params.questionId);
    }

    const { error } = await deleteQuery;
    if (error) {
      return { success: false, mode: 'supabase_live', message: error.message };
    }

    const { data: remainingRows } = await client
      .from('assigned_maqras')
      .select('id')
      .eq('tenant_id', params.tenantId)
      .eq('stage_participation_id', params.stageParticipationId);

    if (!remainingRows || remainingRows.length === 0) {
      await client
        .from('stage_participations')
        .update({
          status: 'Maqra Belum Ditetapkan',
          updated_at: new Date().toISOString()
        })
        .eq('id', params.stageParticipationId)
        .eq('tenant_id', params.tenantId);
    }

    return {
      success: true,
      mode: 'supabase_live',
      message: 'Penetapan maqra berhasil dilepaskan dari database.'
    };
  },

  async deleteJudgeAssignment(tenantId: string, assignmentId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ tenant_id: tenantId, assignment_id: assignmentId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const { error } = await client
      .from('judge_assignments')
      .delete()
      .eq('id', assignmentId)
      .eq('tenant_id', tenantId);
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Penugasan hakim berhasil dihapus dari database.' };
  },

  async upsertTenant(tenant: Tenant): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: tenant.id });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }

    const tenantPayload = {
      id: tenant.id,
      code: tenant.code.trim().toUpperCase(),
      name: tenant.name.trim(),
      event_name: tenant.eventName.trim(),
      region: tenant.region.trim(),
      edition: tenant.edition?.trim() || null,
      period: tenant.period?.trim() || null,
      group_label: (tenant.groupLabel || 'Kafilah / Utusan').trim(),
      status: tenant.status,
      updated_at: new Date().toISOString()
    };

    try {
      const { data: existingById } = await client
        .from('tenants')
        .select('id, code')
        .eq('id', tenant.id)
        .maybeSingle();

      let saveError: any = null;

      if (existingById?.id) {
        const { error } = await client
          .from('tenants')
          .update(tenantPayload)
          .eq('id', tenant.id);
        saveError = error;
      } else {
        // Cek apakah kode tenant sudah digunakan oleh tenant lain
        const { data: existingByCode } = await client
          .from('tenants')
          .select('id, name')
          .eq('code', tenantPayload.code)
          .maybeSingle();

        if (existingByCode?.id && existingByCode.id !== tenant.id) {
          return {
            success: false,
            mode: 'supabase_live',
            message: `Kode singkat "${tenantPayload.code}" sudah digunakan oleh penyelenggara "${existingByCode.name}". Gunakan kode unik.`
          };
        }

        const { error } = await client
          .from('tenants')
          .insert(tenantPayload);
        saveError = error;
      }

      if (saveError) {
        return { success: false, mode: 'supabase_live', message: saveError.message };
      }

      // Pastikan sesi superadmin aktif ditautkan ke tenant_memberships agar memiliki hak akses langsung
      try {
        const { data: sessionData } = await client.auth.getSession();
        const currentUserId = sessionData?.session?.user?.id;
        if (currentUserId && isValidUuid(currentUserId)) {
          await client.from('tenant_memberships').upsert(
            {
              id: toDeterministicUuid(`tm-${tenant.id}-${currentUserId}`),
              tenant_id: tenant.id,
              profile_id: currentUserId,
              role: 'superadmin',
              status: 'Aktif',
              updated_at: new Date().toISOString()
            },
            { onConflict: 'tenant_id,profile_id' }
          );
        }
      } catch (linkErr) {
        console.warn('Membership auto-link non-fatal:', linkErr);
      }

      return { success: true, mode: 'supabase_live', message: 'Tenant tersimpan di Supabase.' };
    } catch (err: any) {
      return { success: false, mode: 'supabase_live', message: err?.message || 'Gagal menyimpan tenant ke database.' };
    }
  },

  async deleteTenant(tenantId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }

    // S6: penghapusan transaksional di server; ditolak bila tenant sudah punya riwayat penilaian/undian/audit
    const { data, error } = await client.rpc('delete_tenant_safe', { p_tenant_id: tenantId });
    if (error) {
      return { success: false, mode: 'supabase_live', message: error.message };
    }
    return { success: true, mode: 'supabase_live', message: 'Penyelenggara berhasil dihapus.', data };
  },

  async deleteUser(userId: string): Promise<RpcServiceResult> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }

    if (isValidUuid(userId)) {
      try {
        await client.from('judge_assignments').delete().eq('judge_profile_id', userId);
        await client.from('tenant_memberships').delete().eq('profile_id', userId);
      } catch {}

      const { error } = await client.from('profiles').delete().eq('id', userId);
      if (error) {
        return { success: false, mode: 'supabase_live', message: error.message };
      }
    }

    return { success: true, mode: 'supabase_live', message: 'Akun pengguna berhasil dihapus dari database.' };
  },

  async upsertStage(stage: CompetitionStage): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({
      id: stage.id,
      tenant_id: stage.tenantId,
      ...(stage.branchId ? { branch_id: stage.branchId } : {})
    });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const fkCheck = await this.verifyDatabaseReferencesExist({
      tenantId: stage.tenantId,
      branchId: stage.branchId && isValidUuid(stage.branchId) ? stage.branchId : undefined
    });
    if (!fkCheck.valid) {
      return { success: false, mode: 'supabase_live', message: fkCheck.message! };
    }

    const { error } = await client.from('stages').upsert({
      id: stage.id,
      tenant_id: stage.tenantId,
      branch_id: stage.branchId && isValidUuid(stage.branchId) ? stage.branchId : null,
      name: stage.name,
      stage_order: stage.order,
      qualification_quota: stage.qualificationQuota,
      champion_count: stage.championCount ?? 3,
      qualification_method: stage.qualificationMethod || 'top_n',
      status: stage.status === 'Selesai' ? 'Aktif' : stage.status,
      is_finalized: false
    });
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Konfigurasi babak tersimpan di Supabase.' };
  },

  async upsertBranch(tenantId: string, branch: GenericMasterItem): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: branch.id, tenant_id: tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const { error } = await client.from('branches').upsert({
      id: branch.id,
      tenant_id: tenantId,
      code: branch.code,
      name: branch.name,
      description: branch.description || null,
      status: branch.status
    });
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Cabang lomba tersimpan di Supabase.' };
  },

  async deleteBranch(tenantId: string, branchId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: branchId, tenant_id: tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const { error } = await client
      .from('branches')
      .delete()
      .eq('id', branchId)
      .eq('tenant_id', tenantId);
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Cabang lomba berhasil dihapus dari database.' };
  },

  async upsertLevel(tenantId: string, level: GenericMasterItem): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: level.id, tenant_id: tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const { error } = await client.from('levels').upsert({
      id: level.id,
      tenant_id: tenantId,
      code: level.code,
      name: level.name,
      description: level.description || null,
      status: level.status
    });
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Jenjang berhasil disimpan di Supabase.' };
  },

  async deleteLevel(tenantId: string, levelId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: levelId, tenant_id: tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const { error } = await client
      .from('levels')
      .delete()
      .eq('id', levelId)
      .eq('tenant_id', tenantId);
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Jenjang berhasil dihapus dari database.' };
  },

  async upsertErrorCategory(cat: ErrorCategory): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: cat.id, tenant_id: cat.tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const { error } = await client.from('error_categories').upsert({
      id: cat.id,
      tenant_id: cat.tenantId,
      rubric_field_id: cat.fieldId && isValidUuid(cat.fieldId) ? cat.fieldId : null,
      criterion_id: cat.criterionId && isValidUuid(cat.criterionId) ? cat.criterionId : null,
      deduction_rule_id: cat.deductionRuleId && isValidUuid(cat.deductionRuleId) ? cat.deductionRuleId : null,
      code: cat.code,
      name: cat.name,
      scope: cat.scope || null,
      default_deduction: cat.defaultDeduction,
      max_deduction: cat.maxDeduction ?? null,
      method_type: cat.methodType || 'Pengurangan tetap',
      status: cat.status || 'Aktif',
      sort_order: cat.order ?? 1
    });
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Kategori kesalahan tersimpan di Supabase.' };
  },

  async deleteErrorCategory(tenantId: string, categoryId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: categoryId, tenant_id: tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const { error } = await client
      .from('error_categories')
      .delete()
      .eq('id', categoryId)
      .eq('tenant_id', tenantId);
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Kategori kesalahan berhasil dihapus dari database.' };
  },

  async upsertRubricVersionWithFields(tenantId: string, rubric: RubricVersion): Promise<RpcServiceResult> {
    const effectiveTenantId = rubric.tenantId && isValidUuid(rubric.tenantId) ? rubric.tenantId : tenantId;
    const uuidCheck = this.validateReferences({ id: rubric.id, tenant_id: effectiveTenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }

    const { error: rvError } = await client.from('rubric_versions').upsert({
      id: rubric.id,
      tenant_id: effectiveTenantId,
      code: rubric.code,
      name: rubric.name,
      branch_id: rubric.branchId && isValidUuid(rubric.branchId) ? rubric.branchId : null,
      branch_code: rubric.branchCode || null,
      branch_name: rubric.branchName || null,
      level_id: rubric.levelId && isValidUuid(rubric.levelId) ? rubric.levelId : null,
      version: rubric.version,
      description: rubric.description || null,
      official_source: rubric.officialSource || null,
      starting_score: rubric.startingScore ?? 100,
      status: rubric.status
    });
    if (rvError) return { success: false, mode: 'supabase_live', message: rvError.message };

    const activeFieldIds: string[] = [];
    for (let idx = 0; idx < (rubric.fields || []).length; idx++) {
      const f = rubric.fields[idx];
      const fieldId = isValidUuid(f.id) ? f.id : toDeterministicUuid(`${rubric.id}:field:${f.code}`);
      activeFieldIds.push(fieldId);
      const { error: rfError } = await client.from('rubric_fields').upsert({
        id: fieldId,
        rubric_version_id: rubric.id,
        code: f.code,
        name: f.name,
        max_score: f.maxScore,
        min_score: f.minScore ?? 0,
        max_deduction: f.maxDeduction ?? null,
        weight: f.weight ?? 1,
        field_order: f.order ?? idx + 1,
        status: f.status || 'Aktif',
        description: f.description || null
      });
      if (rfError) return { success: false, mode: 'supabase_live', message: rfError.message };
    }

    // Hapus bidang yang telah dihapus dari daftar rubric.fields secara kaskade aman, namun migrasikan relasi jika kode/nama bidang masih ada
    try {
      const { data: existingFields } = await client
        .from('rubric_fields')
        .select('id, code, name')
        .eq('rubric_version_id', rubric.id);
      const activeSet = new Set(activeFieldIds);
      const removedFieldObjs = (existingFields || []).filter((f: { id: string }) => !activeSet.has(f.id));
      const removeIds = removedFieldObjs.map((f: { id: string }) => f.id);
      if (removeIds.length > 0) {
        // Coba migrasikan error_categories dan judge_assignments ke fieldId baru jika kode/namanya cocok
        for (const oldFld of removedFieldObjs as { id: string; code?: string; name?: string }[]) {
          const matchedNewIdx = rubric.fields.findIndex(
            (nf) =>
              (oldFld.code && nf.code.toLowerCase() === oldFld.code.toLowerCase()) ||
              (oldFld.name && nf.name.toLowerCase() === oldFld.name.toLowerCase())
          );
          if (matchedNewIdx >= 0 && activeFieldIds[matchedNewIdx]) {
            const newTargetFieldId = activeFieldIds[matchedNewIdx];
            await client
              .from('error_categories')
              .update({ rubric_field_id: newTargetFieldId })
              .eq('rubric_field_id', oldFld.id);
            await client
              .from('judge_assignments')
              .update({ rubric_field_id: newTargetFieldId })
              .eq('rubric_field_id', oldFld.id);
          }
        }
        await client.from('error_categories').update({ rubric_field_id: null }).in('rubric_field_id', removeIds);
        await client.from('judge_assignments').update({ rubric_field_id: null }).in('rubric_field_id', removeIds);
        const { data: critRows } = await client.from('rubric_criteria').select('id').in('rubric_field_id', removeIds);
        if (critRows && critRows.length > 0) {
          const critIds = critRows.map((c: { id: string }) => c.id);
          await client.from('deduction_rules').delete().in('criterion_id', critIds);
          await client.from('rubric_criteria').delete().in('rubric_field_id', removeIds);
        }
        await client.from('rubric_fields').delete().in('id', removeIds);
      }
    } catch (cleanErr) {
      console.warn('[upsertRubricVersionWithFields] Cleanup warning:', cleanErr);
    }

    return { success: true, mode: 'supabase_live', message: 'Versi rubrik & struktur bidang tersimpan di Supabase.' };
  },

  async deleteRubricField(rubricVersionId: string, fieldId: string): Promise<RpcServiceResult> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    try {
      const { data: rpcData, error: rpcError } = await client.rpc('delete_rubric_field_cascade', {
        p_rubric_version_id: rubricVersionId,
        p_field_id: fieldId
      });
      if (!rpcError && rpcData) {
        const res = rpcData as { success: boolean; message: string };
        return { success: res.success, mode: 'supabase_live', message: res.message };
      }
      // Direct cascade cleanup if RPC not yet deployed
      await client.from('error_categories').update({ rubric_field_id: null }).eq('rubric_field_id', fieldId);
      await client.from('judge_assignments').update({ rubric_field_id: null }).eq('rubric_field_id', fieldId);
      const { data: criteria } = await client.from('rubric_criteria').select('id').eq('rubric_field_id', fieldId);
      if (criteria && criteria.length > 0) {
        const critIds = criteria.map((c: { id: string }) => c.id);
        await client.from('deduction_rules').delete().in('criterion_id', critIds);
        await client.from('rubric_criteria').delete().eq('rubric_field_id', fieldId);
      }
      const { error: delError } = await client.from('rubric_fields').delete().eq('id', fieldId);
      if (delError) return { success: false, mode: 'supabase_live', message: delError.message };
      return { success: true, mode: 'supabase_live', message: 'Bidang berhasil dihapus dari database.' };
    } catch (err) {
      return { success: false, mode: 'supabase_live', message: err instanceof Error ? err.message : 'Gagal menghapus bidang' };
    }
  },

  async deleteRubricVersion(tenantId: string, rubricId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: rubricId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }

    try {
      // 1. Dapatkan seluruh ID bidang dari versi rubrik ini
      const { data: fieldRows } = await client
        .from('rubric_fields')
        .select('id')
        .eq('rubric_version_id', rubricId);
      const fieldIds = (fieldRows || []).map((f: { id: string }) => String(f.id)).filter(Boolean);

      if (fieldIds.length > 0) {
        // Lepaskan referensi foreign key di error_categories dan judge_assignments
        await client.from('error_categories').update({ rubric_field_id: null }).in('rubric_field_id', fieldIds);
        await client.from('judge_assignments').update({ rubric_field_id: null }).in('rubric_field_id', fieldIds);
        // Hapus kriteria dan aturan potongan terkait bidang-bidang ini
        const { data: critRows } = await client.from('rubric_criteria').select('id').in('rubric_field_id', fieldIds);
        const critIds = (critRows || []).map((c: { id: string }) => String(c.id)).filter(Boolean);
        if (critIds.length > 0) {
          await client.from('deduction_rules').delete().in('criterion_id', critIds);
          await client.from('rubric_criteria').delete().in('rubric_field_id', fieldIds);
        }
        await client.from('rubric_fields').delete().in('id', fieldIds);
      } else {
        await client.from('rubric_fields').delete().eq('rubric_version_id', rubricId);
      }

      // 2. Lepaskan/hapus aturan kompetisi yang merujuk pada versi rubrik ini
      await client.from('competition_rule_configs').delete().eq('rubric_version_id', rubricId);

      // 3. Hapus versi rubrik
      const { error } = await client
        .from('rubric_versions')
        .delete()
        .eq('id', rubricId);

      if (error) {
        return { success: false, mode: 'supabase_live', message: error.message };
      }

      return { success: true, mode: 'supabase_live', message: 'Versi rubrik berhasil dihapus permanen dari database.' };
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Gagal menghapus rubrik';
      return { success: false, mode: 'supabase_live', message: msg };
    }
  },

  async updateRubricVersionStatus(
    tenantId: string,
    rubricId: string,
    status: 'Draft' | 'Aktif' | 'Arsip'
  ): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: rubricId, tenant_id: tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const { error } = await client
      .from('rubric_versions')
      .update({ status })
      .eq('id', rubricId)
      .eq('tenant_id', tenantId);
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: `Status rubrik diperbarui menjadi ${status}.` };
  },

  async upsertCompetitionRuleConfig(rule: CompetitionRuleConfig): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({
      id: rule.id,
      tenant_id: rule.tenantId,
      ...(rule.branchId ? { branch_id: rule.branchId } : {}),
      ...(rule.levelId ? { level_id: rule.levelId } : {}),
      rubric_version_id: rule.rubricVersionId
    });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const fkCheck = await this.verifyDatabaseReferencesExist({
      tenantId: rule.tenantId,
      branchId: rule.branchId && isValidUuid(rule.branchId) ? rule.branchId : undefined,
      levelId: rule.levelId && isValidUuid(rule.levelId) ? rule.levelId : undefined,
      rubricVersionId: rule.rubricVersionId
    });
    if (!fkCheck.valid) {
      return { success: false, mode: 'supabase_live', message: fkCheck.message! };
    }
    const { error } = await client.from('competition_rule_configs').upsert({
      id: rule.id,
      tenant_id: rule.tenantId,
      branch_id: rule.branchId && isValidUuid(rule.branchId) ? rule.branchId : null,
      level_id: rule.levelId && isValidUuid(rule.levelId) ? rule.levelId : null,
      branch_name: rule.branchName || null,
      rubric_version_id: rule.rubricVersionId,
      tie_break_order: rule.tieBreakOrder || ['total', 'Tajwid', 'Lagu', 'Fashahah'],
      quota_per_stage: rule.quotaPerStage || { Penyisihan: 3, Final: 3 },
      official_source: rule.officialSource || null,
      is_verified_official: Boolean(rule.isVerifiedOfficial),
      status: rule.status || 'Aktif',
      updated_at: new Date().toISOString()
    });
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Konfigurasi aturan kompetisi tersimpan di Supabase.' };
  },

  async deleteCompetitionRuleConfig(tenantId: string, ruleId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: ruleId, tenant_id: tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }
    const { error } = await client
      .from('competition_rule_configs')
      .delete()
      .eq('id', ruleId)
      .eq('tenant_id', tenantId);
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Konfigurasi aturan kompetisi berhasil dihapus dari database.' };
  },

  async deleteStage(tenantId: string, stageId: string): Promise<RpcServiceResult> {
    const uuidCheck = this.validateReferences({ id: stageId, tenant_id: tenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode lokal aktif.' };
    }

    try {
      // Hapus penugasan dewan hakim yang terkait dengan babak ini terlebih dahulu jika ada
      await client
        .from('judge_assignments')
        .delete()
        .eq('stage_id', stageId)
        .eq('tenant_id', tenantId);

      // Hapus draft soal yang hanya terikat ke babak ini
      await client
        .from('questions')
        .delete()
        .eq('stage_id', stageId)
        .eq('tenant_id', tenantId);

      const { error } = await client
        .from('stages')
        .delete()
        .eq('id', stageId)
        .eq('tenant_id', tenantId);

      if (error) {
        if (error.message?.includes('violates foreign key') || error.message?.includes('stage_participations')) {
          return {
            success: false,
            mode: 'supabase_live',
            message: 'Babak tidak dapat dihapus karena masih memiliki riwayat partisipasi peserta atau lembar penilaian.'
          };
        }
        return { success: false, mode: 'supabase_live', message: error.message };
      }
      return { success: true, mode: 'supabase_live', message: 'Babak musabaqah berhasil dihapus dari database.' };
    } catch (err: any) {
      return { success: false, mode: 'supabase_live', message: err?.message || 'Gagal menghapus babak.' };
    }
  },

  async upsertUserAndMembership(params: {
    tenantId: string;
    user: User;
    initialPassword?: string;
    preferEdgeInvite?: boolean;
  }): Promise<
    RpcServiceResult<{
      profileId: string;
      provisioningStatus: 'Mengundang...' | 'Menunggu Verifikasi' | 'Aktif' | 'Nonaktif' | 'Gagal / Perlu Tindakan Admin';
    }>
  > {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        mode: 'local_offline_fallback',
        message: 'Mode lokal aktif.'
      };
    }

    let effectiveTenantId = params.tenantId;
    if (
      !isValidUuid(effectiveTenantId) ||
      effectiveTenantId === 'platform' ||
      effectiveTenantId === 'unassigned'
    ) {
      if (params.user.role === 'superadmin') {
        effectiveTenantId = SYSTEM_TENANT_UUID;
      } else {
        const { data: firstTenants } = await client
          .from('tenants')
          .select('id')
          .neq('id', SYSTEM_TENANT_UUID)
          .limit(1);
        if (firstTenants && firstTenants.length > 0 && firstTenants[0]?.id) {
          effectiveTenantId = String(firstTenants[0].id);
        }
      }
    }

    const uuidCheck = this.validateReferences({ tenant_id: effectiveTenantId });
    if (!uuidCheck.valid) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: uuidCheck.message!
      };
    }

    const cleanEmail = (params.user.email || '').trim().toLowerCase();
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: 'Alamat email pengguna wajib diisi dengan format yang valid untuk penautan akun Supabase Auth.'
      };
    }

    let resolvedProfileId: string | null = isValidUuid(params.user.id) ? params.user.id : null;
    const cleanStatus = params.user.status === 'Nonaktif' ? 'Nonaktif' : 'Aktif';
    let createdViaPasswordSignUp = false;
    let requiresEmailVerification = false;

    // 0A. Jika Admin/Superadmin mengisi Kata Sandi Awal (initialPassword >= 8 karakter),
    // daftarkan akun baru di Supabase Auth menggunakan client ephemeral (persistSession: false)
    // sehingga sesi Admin/Superadmin yang sedang login TIDAK terputus.
    if (params.initialPassword && params.initialPassword.trim().length > 0) {
      const rawPassword = params.initialPassword.trim();
      if (rawPassword.length < 8) {
        return {
          success: false,
          mode: 'supabase_live',
          message: 'Kata sandi awal untuk akun baru wajib minimal 8 karakter.',
          data: {
            profileId: params.user.id,
            provisioningStatus: 'Gagal / Perlu Tindakan Admin'
          }
        };
      }

      const ephemeralClient = injectedDatabaseClient ? client : createEphemeralSupabaseAuthClient();
      if (ephemeralClient && typeof ephemeralClient.auth?.signUp === 'function') {
        const redirectValidation = this.validateRedirectUrl();
        const { data: signUpData, error: signUpErr } = await ephemeralClient.auth.signUp({
          email: cleanEmail,
          password: rawPassword,
          options: {
            data: {
              name: params.user.name,
              username: params.user.username
            },
            ...(redirectValidation.valid ? { emailRedirectTo: redirectValidation.url } : {})
          }
        });

        if (signUpErr) {
          const errLower = (signUpErr.message || '').toLowerCase();
          const isAlreadyRegistered =
            errLower.includes('already registered') ||
            errLower.includes('already exists') ||
            errLower.includes('user_already_exists');
          if (!isAlreadyRegistered) {
            return {
              success: false,
              mode: 'supabase_live',
              message: `Gagal mendaftarkan akun baru di Supabase Auth: ${signUpErr.message}`,
              data: {
                profileId: params.user.id,
                provisioningStatus: 'Gagal / Perlu Tindakan Admin'
              }
            };
          }
        } else if (signUpData?.user?.id && isValidUuid(signUpData.user.id)) {
          resolvedProfileId = signUpData.user.id;
          createdViaPasswordSignUp = true;
          requiresEmailVerification = !signUpData.session;
        }
      }
    }

    // 0B. Resolusi UUID profil berdasarkan email dari tabel public.profiles jika sudah ada
    // (memastikan kompatibilitas penuh meskipun menggunakan versi fungsi RPC sebelumnya)
    try {
      const { data: existingProf } = await client
        .from('profiles')
        .select('id')
        .eq('email', cleanEmail)
        .maybeSingle();
      if (existingProf?.id && isValidUuid(String(existingProf.id))) {
        resolvedProfileId = String(existingProf.id);
      }
    } catch {
      // Lanjutkan ke RPC jika pembacaan prasyarat gagal
    }

    // 1. Tautkan/perbarui melalui RPC upsert_tenant_member_profile (mendukung resolusi email di auth.users & retry-safe)
    if (!params.preferEdgeInvite) {
      const { data, error } = await client.rpc('upsert_tenant_member_profile', {
        p_tenant_id: effectiveTenantId,
        p_profile_id: resolvedProfileId,
        p_username: params.user.username,
        p_name: params.user.name,
        p_email: cleanEmail,
        p_role: params.user.role,
        p_judge_category: params.user.judgeCategory || null,
        p_judge_field: params.user.judgeField || null,
        p_status: cleanStatus
      });

      if (!error) {
        const realProfileId =
          (data && typeof data === 'object' && 'profile_id' in data && String(data.profile_id)) ||
          resolvedProfileId ||
          params.user.id;

        const finalProvStatus =
          createdViaPasswordSignUp && requiresEmailVerification
            ? 'Menunggu Verifikasi'
            : cleanStatus;

        const successMsg = createdViaPasswordSignUp
          ? requiresEmailVerification
            ? `Akun ${params.user.name} (${cleanEmail}) berhasil dibuat beserta kata sandinya dan ditautkan ke tenant. Email verifikasi telah dikirim ke pengguna.`
            : `Akun ${params.user.name} (${cleanEmail}) berhasil dibuat beserta kata sandinya dan langsung aktif di database.`
          : `Profil dan keanggotaan ${params.user.name} (${cleanEmail}) berhasil ditautkan di database.`;

        return {
          success: true,
          mode: 'supabase_live',
          message: successMsg,
          data: {
            profileId: realProfileId,
            provisioningStatus: finalProvStatus
          }
        };
      }

      const isMissingAuthUser =
        error.message.includes('AUTH_USER_NOT_FOUND') ||
        error.message.toLowerCase().includes('belum terdaftar di supabase auth');

      if (!isMissingAuthUser) {
        return {
          success: false,
          mode: 'supabase_live',
          message: error.message,
          data: {
            profileId: resolvedProfileId || params.user.id,
            provisioningStatus: 'Gagal / Perlu Tindakan Admin'
          }
        };
      }
    }

    // 2. Jika akun belum ada di auth.users dan tidak diberikan kata sandi awal, panggil Edge Function `admin-provision-user`
    if (client.functions && typeof client.functions.invoke === 'function') {
      try {
        const redirectCheck = this.validateRedirectUrl();
        const { data: fnData, error: fnError } = await client.functions.invoke('admin-provision-user', {
          body: {
            tenantId: effectiveTenantId,
            profileId: resolvedProfileId,
            username: params.user.username,
            name: params.user.name,
            email: cleanEmail,
            role: params.user.role,
            judgeCategory: params.user.judgeCategory || null,
            judgeField: params.user.judgeField || null,
            status: cleanStatus,
            redirectTo: redirectCheck.valid ? redirectCheck.url : undefined
          }
        });

        const responseObj = (fnData || {}) as Record<string, unknown>;
        if (!fnError && responseObj.success === true) {
          const resolvedId = String(responseObj.profileId || resolvedProfileId || params.user.id);
          const isInvited = responseObj.provisioningState === 'invited';
          return {
            success: true,
            mode: 'supabase_live',
            message: String(
              responseObj.message ||
                `Undangan akun email ${cleanEmail} berhasil dikirim dan keanggotaan tenant telah diikat.`
            ),
            data: {
              profileId: resolvedId,
              provisioningStatus: isInvited ? 'Menunggu Verifikasi' : cleanStatus
            }
          };
        }

        return {
          success: false,
          mode: 'supabase_live',
          message: `Akun ${cleanEmail} belum terdaftar di Supabase Auth. Isi kolom "Kata Sandi Awal" (minimal 8 karakter) pada formulir Tambah Akun agar sistem langsung membuatkan akun login Supabase Auth, atau minta pengguna mendaftar melalui tab "Daftar Akun Baru (Sign Up)" di halaman login.`,
          data: {
            profileId: String(responseObj.authUserId || params.user.id),
            provisioningStatus: 'Gagal / Perlu Tindakan Admin'
          }
        };
      } catch {
        return {
          success: false,
          mode: 'supabase_live',
          message: `Akun ${cleanEmail} belum terdaftar di Supabase Auth. Isi kolom "Kata Sandi Awal" (minimal 8 karakter) pada formulir Tambah Akun untuk membuat akun secara langsung, atau daftarkan melalui tab "Daftar Akun Baru" di halaman login.`,
          data: {
            profileId: params.user.id,
            provisioningStatus: 'Gagal / Perlu Tindakan Admin'
          }
        };
      }
    }

    return {
      success: false,
      mode: 'supabase_live',
      message: `Pengguna (${cleanEmail}) belum terdaftar di Supabase Auth. Isi "Kata Sandi Awal" (min. 8 karakter) saat menambah akun agar sistem langsung membuatkan akun di Supabase Auth, atau gunakan menu "Daftar Akun Baru (Sign Up)" di halaman login.`,
      data: {
        profileId: params.user.id,
        provisioningStatus: 'Gagal / Perlu Tindakan Admin'
      }
    };
  },

  /**
   * Berlangganan perubahan realtime milik satu penyelenggara.
   * - judge_assessments & stage_participations & stages difilter tenant_id di server (hemat kuota).
   * - Event 'connection' dikirim saat koneksi realtime pulih setelah terputus, agar aplikasi
   *   memuat ulang sekali untuk menutup celah perubahan yang terlewat.
   * Catatan: tabel harus terdaftar di publikasi supabase_realtime (lihat migrasi 20261119).
   */
  subscribeToTenantRealtime(tenantId: string, onChange: (event: TenantRealtimeEvent) => void): () => void {
    const client = getActiveClient();
    if (!this.isLive() || !client || !isValidUuid(tenantId) || typeof client.channel !== 'function') {
      return () => {};
    }

    type Payload = { eventType?: string; new?: Record<string, unknown>; old?: Record<string, unknown> };
    const forward = (table: TenantRealtimeEvent['table']) => (payload: Payload) => {
      const rowTenantId = String(payload?.new?.tenant_id || payload?.old?.tenant_id || '');
      // Event DELETE tidak bisa difilter di server dan baris lamanya hanya berisi id: saring di sini bila ada tenant_id
      if (rowTenantId && rowTenantId !== tenantId) return;
      onChange({
        table,
        eventType: payload?.eventType || 'UPDATE',
        newRow: payload?.new && Object.keys(payload.new).length > 0 ? payload.new : undefined,
        oldRow: payload?.old && Object.keys(payload.old).length > 0 ? payload.old : undefined
      });
    };

    const filter = `tenant_id=eq.${tenantId}`;
    let wasDisconnected = false;
    const channel = client
      .channel(`mtq-live-tenant-${tenantId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'judge_assessments', filter }, forward('judge_assessments'))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'stage_participations', filter }, forward('stage_participations'))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'stages', filter }, forward('stages'))
      .subscribe((status: string) => {
        if (status === 'SUBSCRIBED') {
          if (wasDisconnected) {
            wasDisconnected = false;
            onChange({ table: 'connection', eventType: 'RECONNECTED' });
          }
        } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
          wasDisconnected = true;
        }
      });

    return () => {
      try {
        if (typeof client.removeChannel === 'function') {
          client.removeChannel(channel);
        } else if (channel && typeof channel.unsubscribe === 'function') {
          channel.unsubscribe();
        }
      } catch {
        // Ignore cleanup errors on unmount
      }
    };
  },

  /* ---------------------------- CMS ringan (Superadmin) ---------------------------- */

  async fetchSiteContentAdmin(key: 'landing'): Promise<RpcServiceResult<{ content: Record<string, unknown>; updatedAt?: string }>> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Konten situs hanya tersedia saat terhubung ke database.' };
    }
    const { data, error } = await client.from('site_content').select('content, updated_at').eq('key', key).maybeSingle();
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return {
      success: true,
      mode: 'supabase_live',
      message: 'Konten situs dimuat.',
      data: { content: (data?.content as Record<string, unknown>) || {}, updatedAt: data?.updated_at ? String(data.updated_at) : undefined }
    };
  },

  async saveSiteContent(key: 'landing', content: Record<string, unknown>): Promise<RpcServiceResult> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode Demo: konten tidak disimpan ke database.' };
    }
    const { error } = await client.from('site_content').upsert({ key, content }, { onConflict: 'key' });
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Konten landing page tersimpan.' };
  },

  async fetchSitePagesAdmin(): Promise<RpcServiceResult<Record<string, unknown>[]>> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Halaman hanya tersedia saat terhubung ke database.' };
    }
    const { data, error } = await client.from('site_pages').select('*').order('sort_order', { ascending: true });
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Halaman dimuat.', data: (data || []) as Record<string, unknown>[] };
  },

  async saveSitePage(page: {
    id?: string;
    slug: string;
    title: string;
    summary: string;
    category: string;
    bodyMd: string;
    status: string;
    effectiveDate?: string;
    sortOrder: number;
    showInFooter: boolean;
  }): Promise<RpcServiceResult<{ id: string }>> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode Demo: halaman tidak disimpan ke database.' };
    }
    const row = {
      slug: page.slug,
      title: page.title,
      summary: page.summary,
      category: page.category,
      body_md: page.bodyMd,
      status: page.status,
      effective_date: page.effectiveDate || null,
      sort_order: page.sortOrder,
      show_in_footer: page.showInFooter
    };
    const query = page.id
      ? client.from('site_pages').update(row).eq('id', page.id).select('id').maybeSingle()
      : client.from('site_pages').insert(row).select('id').maybeSingle();
    const { data, error } = await query;
    if (error) {
      const msg = /duplicate key|unique/i.test(error.message) ? `Alamat (slug) "${page.slug}" sudah dipakai halaman lain.` : error.message;
      return { success: false, mode: 'supabase_live', message: msg };
    }
    return { success: true, mode: 'supabase_live', message: 'Halaman tersimpan.', data: { id: String(data?.id || page.id || '') } };
  },

  async deleteSitePage(id: string): Promise<RpcServiceResult> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Mode Demo: halaman tidak dihapus dari database.' };
    }
    const { error } = await client.from('site_pages').delete().eq('id', id);
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Halaman dihapus.' };
  },

  async fetchSitePageVersions(pageId: string): Promise<RpcServiceResult<Record<string, unknown>[]>> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return { success: false, mode: 'local_offline_fallback', message: 'Riwayat hanya tersedia saat terhubung ke database.' };
    }
    const { data, error } = await client
      .from('site_page_versions')
      .select('id, title, body_md, status, effective_date, created_at')
      .eq('page_id', pageId)
      .order('created_at', { ascending: false })
      .limit(30);
    if (error) return { success: false, mode: 'supabase_live', message: error.message };
    return { success: true, mode: 'supabase_live', message: 'Riwayat dimuat.', data: (data || []) as Record<string, unknown>[] };
  },

  async fetchSiteSettings(): Promise<RpcServiceResult<SiteSettings>> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: true,
        mode: 'local_offline_fallback',
        message: 'Menggunakan pengaturan SEO & Meta bawaan (Mode Lokal).',
        data: { ...DEFAULT_SITE_SETTINGS }
      };
    }

    const { data, error } = await client
      .from('site_settings')
      .select('*')
      .eq('id', 'global')
      .maybeSingle();

    if (error || !data) {
      return {
        success: false,
        mode: 'supabase_live',
        message: error?.message || 'Baris site_settings global belum ditemukan.',
        data: { ...DEFAULT_SITE_SETTINGS }
      };
    }

    const mapped: SiteSettings = {
      id: 'global',
      siteName: String(data.site_name ?? DEFAULT_SITE_SETTINGS.siteName),
      titleTemplate: String(data.title_template ?? DEFAULT_SITE_SETTINGS.titleTemplate),
      defaultTitle: String(data.default_title ?? DEFAULT_SITE_SETTINGS.defaultTitle),
      metaDescription: String(data.meta_description ?? DEFAULT_SITE_SETTINGS.metaDescription),
      metaKeywords: String(data.meta_keywords ?? DEFAULT_SITE_SETTINGS.metaKeywords),
      canonicalUrl: String(data.canonical_url ?? DEFAULT_SITE_SETTINGS.canonicalUrl),
      robots: data.robots === 'noindex,nofollow' ? 'noindex,nofollow' : 'index,follow',
      faviconUrl: String(data.favicon_url ?? DEFAULT_SITE_SETTINGS.faviconUrl),
      ogTitle: String(data.og_title ?? DEFAULT_SITE_SETTINGS.ogTitle),
      ogDescription: String(data.og_description ?? DEFAULT_SITE_SETTINGS.ogDescription),
      ogImageUrl: String(data.og_image_url ?? DEFAULT_SITE_SETTINGS.ogImageUrl),
      ogImageAlt: String(data.og_image_alt ?? DEFAULT_SITE_SETTINGS.ogImageAlt),
      ogType: String(data.og_type ?? DEFAULT_SITE_SETTINGS.ogType),
      ogLocale: String(data.og_locale ?? DEFAULT_SITE_SETTINGS.ogLocale),
      twitterCard: data.twitter_card === 'summary' ? 'summary' : 'summary_large_image',
      twitterSite: String(data.twitter_site ?? DEFAULT_SITE_SETTINGS.twitterSite),
      themeColor: String(data.theme_color ?? DEFAULT_SITE_SETTINGS.themeColor),
      googleSiteVerification: String(data.google_site_verification ?? ''),
      manualChecks:
        data.manual_checks && typeof data.manual_checks === 'object'
          ? (data.manual_checks as Record<string, boolean>)
          : {},
      updatedBy: data.updated_by ? String(data.updated_by) : null,
      updatedAt: data.updated_at ? formatDateTimeWIB(String(data.updated_at)) : DEFAULT_SITE_SETTINGS.updatedAt
    };

    return {
      success: true,
      mode: 'supabase_live',
      message: 'Pengaturan situs berhasil dimuat.',
      data: mapped
    };
  },

  async updateSiteSettings(updates: Partial<SiteSettings>): Promise<RpcServiceResult<SiteSettings>> {
    if (updates.defaultTitle !== undefined && updates.defaultTitle.trim().length > 70) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: 'Judul Bawaan (Default Title) maksimal 70 karakter.'
      };
    }
    if (updates.metaDescription !== undefined && updates.metaDescription.trim().length > 200) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: 'Deskripsi Meta maksimal 200 karakter.'
      };
    }
    if (updates.canonicalUrl !== undefined && !/^https:\/\//.test(updates.canonicalUrl.trim())) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: 'Canonical URL wajib diawali dengan https://'
      };
    }
    if (updates.ogImageUrl !== undefined && !/^https:\/\//.test(updates.ogImageUrl.trim())) {
      return {
        success: false,
        mode: this.isLive() ? 'supabase_live' : 'local_offline_fallback',
        message: 'URL Gambar Open Graph wajib diawali dengan https://'
      };
    }

    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: true,
        mode: 'local_offline_fallback',
        message: 'Pengaturan SEO & Meta berhasil disimpan pada sesi lokal.',
        data: {
          ...DEFAULT_SITE_SETTINGS,
          ...updates,
          id: 'global',
          updatedAt: formatDateTimeWIB(new Date().toISOString())
        }
      };
    }

    const payload: Record<string, unknown> = {};
    if (updates.siteName !== undefined) payload.site_name = updates.siteName.trim();
    if (updates.titleTemplate !== undefined) payload.title_template = updates.titleTemplate.trim();
    if (updates.defaultTitle !== undefined) payload.default_title = updates.defaultTitle.trim();
    if (updates.metaDescription !== undefined) payload.meta_description = updates.metaDescription.trim();
    if (updates.metaKeywords !== undefined) payload.meta_keywords = updates.metaKeywords.trim();
    if (updates.canonicalUrl !== undefined) payload.canonical_url = updates.canonicalUrl.trim();
    if (updates.robots !== undefined) payload.robots = updates.robots;
    if (updates.faviconUrl !== undefined) payload.favicon_url = updates.faviconUrl.trim();
    if (updates.ogTitle !== undefined) payload.og_title = updates.ogTitle.trim();
    if (updates.ogDescription !== undefined) payload.og_description = updates.ogDescription.trim();
    if (updates.ogImageUrl !== undefined) payload.og_image_url = updates.ogImageUrl.trim();
    if (updates.ogImageAlt !== undefined) payload.og_image_alt = updates.ogImageAlt.trim();
    if (updates.ogType !== undefined) payload.og_type = updates.ogType.trim();
    if (updates.ogLocale !== undefined) payload.og_locale = updates.ogLocale.trim();
    if (updates.twitterCard !== undefined) payload.twitter_card = updates.twitterCard;
    if (updates.twitterSite !== undefined) payload.twitter_site = updates.twitterSite.trim();
    if (updates.themeColor !== undefined) payload.theme_color = updates.themeColor.trim();
    if (updates.googleSiteVerification !== undefined)
      payload.google_site_verification = updates.googleSiteVerification.trim();
    if (updates.manualChecks !== undefined) payload.manual_checks = updates.manualChecks;

    const { data, error } = await client
      .from('site_settings')
      .update(payload)
      .eq('id', 'global')
      .select('*')
      .maybeSingle();

    if (error || !data) {
      return {
        success: false,
        mode: 'supabase_live',
        message: error?.message || 'Gagal memperbarui pengaturan SEO & Meta (pastikan Anda masuk sebagai Superadmin).'
      };
    }

    return this.fetchSiteSettings();
  },

  async getPlatformHealth(): Promise<RpcServiceResult<PlatformHealthCheckItem[]>> {
    const client = getActiveClient();
    if (!this.isLive() || !client) {
      return {
        success: false,
        mode: 'local_offline_fallback',
        message: 'Evaluasi kesehatan dijalankan dari state lokal Mode Demo.'
      };
    }

    const { data, error } = await client.rpc('get_platform_health');
    if (error || !Array.isArray(data)) {
      return {
        success: false,
        mode: 'supabase_live',
        message: error?.message || 'Gagal menjalankan pemeriksaan kesehatan platform.'
      };
    }

    return {
      success: true,
      mode: 'supabase_live',
      message: 'Pemeriksaan kesehatan platform selesai.',
      data: data as PlatformHealthCheckItem[]
    };
  }
};

