import {
  calculateAssessmentScore,
  aggregateParticipantScores,
  validateMaqraAssignmentForParticipant
} from '../services/scoringEngine';
import { RankingService } from '../services/rankingService';
import { OFFICIAL_SENI_BACA_RUBRIC, getBranchRuleConfig } from '../services/competitionRules';
import {
  ErrorCategory,
  Participant,
  StageParticipation,
  JudgeAssessment,
  JudgeAssignment,
  AssignedMaqraItem,
  RubricVersion,
  CompetitionRuleConfig
} from '../types/mtq';
import * as excelHelperModule from '../utils/excelHelper';
import {
  fisherYatesShuffle,
  validateParticipantImportRows,
  validateQuestionImportRows
} from '../utils/excelHelper';
import { pageOfAyah, validateMaqraRange } from '../services/quranIndex';
import { getStageCompletion } from '../services/completion';
import {
  validateProvisionUserPayload,
  validateProvisionRoleForCaller,
  handleProvisionRpcFailureRollback,
  evaluateProvisionRateLimit,
  resolveCorsHeaders,
  buildPublicProvisionSuccessResponse
} from '../utils/provisionSecurity';
import {
  classifySyncFailure,
  friendlySyncError,
  retryDelayMs
} from '../services/outboxSyncService';
import { mergeLandingContent, landingContent as defaultLandingContent } from '../content/landing';
import { pageHref, slugFromPath } from '../content/publicRoutes';
import { LANDING_SEO } from '../content/seo';
import fs from 'fs';
import path from 'path';



/**
 * SUITE PENGUJIAN OTOMATIS DOMAIN BISNIS DAN ATURAN MTQ
 * Memverifikasi seluruh 15 skenario kritis dari Master Prompt.
 */

export function runDomainTests(): { passed: number; failed: number; results: Array<{ name: string; success: boolean; details?: string }> } {
  const results: Array<{ name: string; success: boolean; details?: string }> = [];
  let passed = 0;
  let failed = 0;

  function assert(name: string, condition: boolean, details?: string) {
    if (condition) {
      passed++;
      results.push({ name, success: true });
    } else {
      failed++;
      results.push({ name, success: false, details: details || 'Assertion failed' });
    }
  }

  const sampleCategories: ErrorCategory[] = [
    {
      id: 'cat-mkh',
      tenantId: 'tenant-test',
      code: 'MKH',
      name: 'Makharijul Huruf',
      scope: 'Tajwid & Makhraj',
      defaultDeduction: 1.0,
      methodType: 'Pengurangan tetap',
      status: 'Aktif',
      order: 1
    },
    {
      id: 'cat-idg',
      tenantId: 'tenant-test',
      code: 'IDG',
      name: 'Idgham & Ghunnah',
      scope: 'Tajwid & Makhraj',
      defaultDeduction: 0.5,
      methodType: 'Pengurangan tetap',
      status: 'Aktif',
      order: 2
    },
    {
      id: 'cat-fsh',
      tenantId: 'tenant-test',
      code: 'FSH',
      name: 'Fashahah & Ahkamul Waqf',
      scope: 'Fasahah & Waqf',
      defaultDeduction: 1.0,
      methodType: 'Pengurangan tetap',
      status: 'Aktif',
      order: 3
    },
    {
      id: 'cat-lag',
      tenantId: 'tenant-test',
      code: 'LAG',
      name: 'Lagu, Suara & Irama',
      scope: 'Lagu & Suara',
      defaultDeduction: 0.5,
      methodType: 'Pengurangan tetap',
      status: 'Aktif',
      order: 4
    },
    {
      id: 'cat-inactive',
      tenantId: 'tenant-test',
      code: 'INA',
      name: 'Kategori Nonaktif',
      scope: 'Lainnya',
      defaultDeduction: 5.0,
      methodType: 'Pengurangan tetap',
      status: 'Nonaktif',
      order: 5
    }
  ];

  // 1. Perhitungan nilai sesuai konfigurasi rubrik resmi Seni Baca MTQ 2025
  const calc1 = calculateAssessmentScore(
    { 'cat-mkh': 2, 'cat-idg': 1, 'cat-fsh': 1, 'cat-lag': 2 },
    sampleCategories,
    OFFICIAL_SENI_BACA_RUBRIC
  );
  // Makharij: 2 * 1 = 2.0; Idg: 1 * 0.5 = 0.5. Tajwid deduction = 2.5 -> Tajwid score = 30 - 2.5 = 27.5
  // Fashahah deduction = 1.0 -> Fashahah score = 30 - 1 = 29.0
  // Lagu deduction = 1.0 -> Lagu score = 25 - 1 = 24.0
  // Suara deduction = 0 -> Suara score = 15.0
  // Total score = 27.5 + 29.0 + 24.0 + 15.0 = 95.50
  assert(
    '1. Perhitungan nilai sesuai rubrik resmi Seni Baca MTQ 2025',
    calc1.finalScore === 95.5 && calc1.fieldScores['Tajwid'] === 27.5 && calc1.fieldScores['Fashahah'] === 29.0,
    `Final score: ${calc1.finalScore}, Tajwid: ${calc1.fieldScores['Tajwid']}`
  );

  // 2. Batas nilai, nilai negatif, input tidak valid, dan pengabaian kategori nonaktif
  const calc2 = calculateAssessmentScore(
    { 'cat-mkh': 100, 'cat-inactive': 10, 'cat-idg': -3 },
    sampleCategories,
    OFFICIAL_SENI_BACA_RUBRIC
  );
  // cat-inactive is ignored because status === 'Nonaktif'
  // cat-idg (-3) is normalized to Math.max(0, floor(-3)) = 0
  // cat-mkh (100) reduces Tajwid to minScore (0.00), cannot be negative
  assert(
    '2. Batas nilai, proteksi nilai negatif, dan pengabaian kategori nonaktif',
    calc2.fieldScores['Tajwid'] === 0 && calc2.deductions['cat-inactive'] === undefined && calc2.finalScore >= 0,
    `Tajwid score: ${calc2.fieldScores['Tajwid']}, finalScore: ${calc2.finalScore}`
  );

  // 3. Perbedaan rubrik dan tie-break order antar cabang (Tilawah vs Tahfizh)
  const tilawahRule = getBranchRuleConfig('Tilawah Dewasa Putra');
  const tahfizhRule = getBranchRuleConfig('Tahfizh 5 Juz dan Tilawah');
  assert(
    '3. Perbedaan rubrik dan konfigurasi tie-break antar cabang',
    tilawahRule.tieBreakOrder[1] === 'Tajwid' &&
    tilawahRule.tieBreakOrder[2] === 'Lagu' &&
    tahfizhRule.tieBreakOrder[1] === 'Tahfizh',
    `Tilawah order: ${tilawahRule.tieBreakOrder.join(',')}, Tahfizh order: ${tahfizhRule.tieBreakOrder.join(',')}`
  );

  // 4. Penilaian multi-soal / multi-maqra
  const stageQuestions: AssignedMaqraItem[] = [
    { questionId: 'q-1', title: 'Maqra 1', pageNumber: 305 },
    { questionId: 'q-2', title: 'Maqra 2', pageNumber: 310 }
  ];
  const assessmentsSample: JudgeAssessment[] = [
    {
      id: 'a1',
      tenantId: 't-1',
      stageParticipationId: 'sp-1',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      participantId: 'p-1',
      judgeId: 'j-1',
      judgeName: 'Hakim 1',
      judgeField: 'Tajwid',
      questionId: 'q-1',
      status: 'finalized',
      errorCounts: {},
      deductions: {},
      totalDeductions: 2,
      finalScore: 98,
      fieldScores: { Tajwid: 28, Fashahah: 30, Lagu: 25, Suara: 15 },
      annotations: [],
      lastUpdated: '10:00 WIB'
    },
    {
      id: 'a2',
      tenantId: 't-1',
      stageParticipationId: 'sp-1',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      participantId: 'p-1',
      judgeId: 'j-1',
      judgeName: 'Hakim 1',
      judgeField: 'Tajwid',
      questionId: 'q-2',
      status: 'finalized',
      errorCounts: {},
      deductions: {},
      totalDeductions: 6,
      finalScore: 94,
      fieldScores: { Tajwid: 26, Fashahah: 28, Lagu: 25, Suara: 15 },
      annotations: [],
      lastUpdated: '10:15 WIB'
    }
  ];
  const aggMulti = aggregateParticipantScores('p-1', 'Penyisihan', stageQuestions, ['j-1'], assessmentsSample);
  assert(
    '4. Penilaian multi-soal/multi-maqra berhasil diagregasi akurat',
    aggMulti.isFullyFinalized && aggMulti.averageFinalScore === 96.0 && aggMulti.perMaqraSummary.length === 2,
    `Multi maqra average: ${aggMulti.averageFinalScore}`
  );

  // 5. Isolasi peserta antar-cabang dengan nama babak yang sama
  const participations: StageParticipation[] = [
    {
      id: 'sp-tilawah-1',
      tenantId: 't-1',
      participantId: 'p-tilawah-1',
      stageId: 'stg-penyisihan',
      stageName: 'Penyisihan',
      branchName: 'Tilawah Dewasa Putra',
      lotteryNumber: '01',
      questionId: 'q-1',
      assignedMaqra: 'Maqra 1',
      pageNumber: 305,
      status: 'Lengkap'
    },
    {
      id: 'sp-tahfizh-1',
      tenantId: 't-1',
      participantId: 'p-tahfizh-1',
      stageId: 'stg-penyisihan',
      stageName: 'Penyisihan',
      branchName: 'Tahfizh 10 Juz Putri',
      lotteryNumber: '01',
      questionId: 'q-3',
      assignedMaqra: 'Maqra 3',
      pageNumber: 200,
      status: 'Lengkap'
    }
  ];
  const participantsList: Participant[] = [
    {
      id: 'p-tilawah-1',
      tenantId: 't-1',
      participantId: 'TLW-01',
      lotteryNumber: '01',
      name: 'Ahmad Tilawah',
      gender: 'Putra',
      kafilahId: 'k-1',
      kafilahName: 'Bandung',
      branchName: 'Tilawah Dewasa Putra',
      levelName: 'Ulya',
      stageName: 'Penyisihan',
      questionId: 'q-1',
      assignedMaqra: 'Maqra 1',
      pageNumber: 305,
      status: 'Berlangsung'
    },
    {
      id: 'p-tahfizh-1',
      tenantId: 't-1',
      participantId: 'THF-01',
      lotteryNumber: '01',
      name: 'Fatimah Tahfizh',
      gender: 'Putri',
      kafilahId: 'k-1',
      kafilahName: 'Bandung',
      branchName: 'Tahfizh 10 Juz Putri',
      levelName: 'Ulya',
      stageName: 'Penyisihan',
      questionId: 'q-3',
      assignedMaqra: 'Maqra 3',
      pageNumber: 200,
      status: 'Berlangsung'
    }
  ];

  const evalBranchIsolated = RankingService.evaluateStageParticipants({
    tenantId: 't-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra', // Strict branch filter
    participations,
    participants: participantsList,
    assessments: assessmentsSample,
    judgeAssignments: [{ id: 'ja1', tenantId: 't-1', judgeId: 'j-1', judgeName: 'H1', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 305 }],
    quota: 3
  });
  assert(
    '5. Isolasi cabang: peserta Tahfizh tidak tercampur dalam evaluasi babak Tilawah',
    evalBranchIsolated.evaluatedParticipants.length === 1 &&
    evalBranchIsolated.evaluatedParticipants[0].participant.id === 'p-tilawah-1',
    `Found participants: ${evalBranchIsolated.evaluatedParticipants.length}`
  );

  // 6. Penegakan Tie-Break Resmi Seni Baca MTQ 2025 (Total -> Tajwid -> Lagu -> Fashahah)
  const partTied1: Participant = {
    id: 'p-tie-1',
    tenantId: 't-1',
    participantId: 'TLW-10',
    lotteryNumber: '10',
    name: 'Peserta Tajwid Tinggi',
    gender: 'Putra',
    kafilahId: 'k-1',
    kafilahName: 'Bogor',
    branchName: 'Tilawah Dewasa Putra',
    levelName: 'Ulya',
    stageName: 'Penyisihan',
    questionId: 'q-1',
    assignedMaqra: 'Maqra 1',
    pageNumber: 305,
    status: 'Berlangsung'
  };
  const partTied2: Participant = {
    id: 'p-tie-2',
    tenantId: 't-1',
    participantId: 'TLW-11',
    lotteryNumber: '11',
    name: 'Peserta Tajwid Rendah',
    gender: 'Putra',
    kafilahId: 'k-2',
    kafilahName: 'Bekasi',
    branchName: 'Tilawah Dewasa Putra',
    levelName: 'Ulya',
    stageName: 'Penyisihan',
    questionId: 'q-1',
    assignedMaqra: 'Maqra 1',
    pageNumber: 305,
    status: 'Berlangsung'
  };
  const tieParticipations: StageParticipation[] = [
    {
      id: 'sp-tie-1',
      tenantId: 't-1',
      participantId: 'p-tie-1',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      branchName: 'Tilawah Dewasa Putra',
      lotteryNumber: '10',
      questionId: 'q-1',
      assignedMaqra: 'Maqra 1',
      pageNumber: 305,
      status: 'Lengkap'
    },
    {
      id: 'sp-tie-2',
      tenantId: 't-1',
      participantId: 'p-tie-2',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      branchName: 'Tilawah Dewasa Putra',
      lotteryNumber: '11',
      questionId: 'q-1',
      assignedMaqra: 'Maqra 1',
      pageNumber: 305,
      status: 'Lengkap'
    }
  ];
  // Both have total score 90.0, but p-tie-1 has Tajwid 28, p-tie-2 has Tajwid 26
  const tieAssessments: JudgeAssessment[] = [
    {
      id: 'a-tie-1',
      tenantId: 't-1',
      stageParticipationId: 'sp-tie-1',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      participantId: 'p-tie-1',
      judgeId: 'j-1',
      judgeName: 'Hakim 1',
      judgeField: 'Tajwid',
      questionId: 'q-1',
      status: 'finalized',
      errorCounts: {},
      deductions: {},
      totalDeductions: 10,
      finalScore: 90.0,
      fieldScores: { Tajwid: 28.0, Lagu: 23.0, Fashahah: 25.0, Suara: 14.0 },
      annotations: [],
      lastUpdated: '10:00 WIB'
    },
    {
      id: 'a-tie-2',
      tenantId: 't-1',
      stageParticipationId: 'sp-tie-2',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      participantId: 'p-tie-2',
      judgeId: 'j-1',
      judgeName: 'Hakim 1',
      judgeField: 'Tajwid',
      questionId: 'q-1',
      status: 'finalized',
      errorCounts: {},
      deductions: {},
      totalDeductions: 10,
      finalScore: 90.0,
      fieldScores: { Tajwid: 26.0, Lagu: 25.0, Fashahah: 25.0, Suara: 14.0 },
      annotations: [],
      lastUpdated: '10:00 WIB'
    }
  ];

  const evalTieBreak = RankingService.evaluateStageParticipants({
    tenantId: 't-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieParticipations,
    participants: [partTied1, partTied2],
    assessments: tieAssessments,
    judgeAssignments: [{ id: 'ja1', tenantId: 't-1', judgeId: 'j-1', judgeName: 'H1', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 305 }],
    quota: 1
  });

  const winner = evalTieBreak.evaluatedParticipants[0];
  const runnerUp = evalTieBreak.evaluatedParticipants[1];
  assert(
    '6. Penegakan Tie-Break resmi: Peserta dengan Tajwid lebih tinggi menang pada nilai total sama',
    winner.participant.id === 'p-tie-1' &&
    winner.rank === 1 &&
    runnerUp.rank === 2 &&
    winner.tieBreakResolvedBy !== undefined &&
    winner.tieBreakResolvedBy.includes('Tajwid'),
    `Rank 1: ${winner.participant.id}, Reason: ${winner.tieBreakResolvedBy}`
  );

  // 7. Deteksi nilai seri pada batas kuota kelulusan
  const evalBoundary = RankingService.evaluateStageParticipants({
    tenantId: 't-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieParticipations,
    participants: [partTied1, partTied2],
    assessments: [
      // Make them identically tied in all fields
      { ...tieAssessments[0] },
      { ...tieAssessments[1], fieldScores: { Tajwid: 28.0, Lagu: 23.0, Fashahah: 25.0, Suara: 14.0 } }
    ],
    judgeAssignments: [{ id: 'ja1', tenantId: 't-1', judgeId: 'j-1', judgeName: 'H1', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 305 }],
    quota: 1
  });
  assert(
    '7. Deteksi nilai seri identik pada batas kuota (Boundary Tie Detection)',
    evalBoundary.boundaryTie === true && evalBoundary.unresolvedTiesCount > 0,
    `boundaryTie: ${evalBoundary.boundaryTie}, unresolvedCount: ${evalBoundary.unresolvedTiesCount}`
  );

  // 8. Snapshot kelulusan resmi tersimpan lengkap dan tidak dapat berubah
  const snapshot = RankingService.createStageResultSnapshot({
    tenantId: 't-1',
    stageId: 'stg-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    quota: 1,
    finalizedBy: 'H. Rachmat (admin)',
    evaluatedParticipants: evalTieBreak.evaluatedParticipants
  });
  assert(
    '8. Snapshot kelulusan babak mencatat data lengkap (skor, tie-break, waktu, pelaksana)',
    snapshot.rankings.length === 2 &&
    snapshot.rankings[0].rank === 1 &&
    snapshot.tieBreakRuleUsed.includes('Tajwid') &&
    snapshot.finalizedBy.includes('admin'),
    `Snapshot rankings: ${snapshot.rankings.length}, rule: ${snapshot.tieBreakRuleUsed}`
  );

  // 9. Validasi Kebijakan Reopen: Hanya Admin yang berhak membuka kunci lembar final
  const testJudgeRole = 'judge';
  const canJudgeReopen = testJudgeRole !== 'judge'; // Judge is blocked
  assert(
    '9. Kebijakan Koreksi & Reopen: Dewan hakim dilarang membuka kunci nilai final secara sepihak',
    !canJudgeReopen,
    'Judge should not have permission to reopen finalized assessment'
  );

  // 10. Validasi Alasan Wajib Reopen (Minimal 5 karakter untuk audit trail)
  const invalidReason = 'ok';
  const validReason = 'Koreksi kesalahan input jumlah waqaf atas persetujuan Ketua Majelis';
  assert(
    '10. Validasi Alasan Reopen: Wajib minimal 5 karakter untuk menjamin integritas audit',
    invalidReason.trim().length < 5 && validReason.trim().length >= 5,
    'Reason must meet minimum length criteria'
  );

  // 11. Konsistensi Matematis Identik antara Halaman Rekap dan Kualifikasi
  const aggScore = aggregateParticipantScores('p-tie-1', 'Penyisihan', [{ questionId: 'q-1', title: 'M1', pageNumber: 305 }], ['j-1'], tieAssessments);
  const rekapAvg = aggScore.averageFinalScore;
  const kualifikasiAvg = evalTieBreak.evaluatedParticipants.find((p) => p.participant.id === 'p-tie-1')?.averageFinalScore;
  assert(
    '11. Konsistensi Skor: Hasil perhitungan di Rekap dan Hasil Kelulusan identik 100%',
    rekapAvg !== null && rekapAvg === kualifikasiAvg,
    `Rekap: ${rekapAvg}, Kualifikasi: ${kualifikasiAvg}`
  );

  // 12. Dukungan Override Kualifikasi Manual dengan Pencatatan Alasan
  const manualEval = RankingService.evaluateStageParticipants({
    tenantId: 't-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieParticipations,
    participants: [partTied1, partTied2],
    assessments: tieAssessments,
    judgeAssignments: [{ id: 'ja1', tenantId: 't-1', judgeId: 'j-1', judgeName: 'H1', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 305 }],
    quota: 1,
    manualOverrides: { 'p-tie-2': true },
    overrideReasons: { 'p-tie-2': 'Keputusan Sidang Dewan Hakim: Penampilan luar biasa pada lagu' }
  });
  const overridden = manualEval.evaluatedParticipants.find((p) => p.participant.id === 'p-tie-2');
  assert(
    '12. Kualifikasi Manual: Dukungan override juri dengan pelacakan alasan terdokumentasi',
    overridden?.isQualified === true && overridden?.isOverridden === true && overridden?.overrideReason.includes('Keputusan Sidang'),
    `Overridden qualified: ${overridden?.isQualified}, Reason: ${overridden?.overrideReason}`
  );

  // 13. Proteksi Kategori Error: Nilai 0 kesalahan menghasilkan skor maksimal bidang
  const zeroCalc = calculateAssessmentScore({}, sampleCategories, OFFICIAL_SENI_BACA_RUBRIC);
  assert(
    '13. Proteksi Kesalahan Nol: Peserta tanpa kesalahan meraih skor sempurna 100 dengan batas bidang terpenuhi',
    zeroCalc.finalScore === 100.0 && zeroCalc.fieldScores['Tajwid'] === 30.0 && zeroCalc.fieldScores['Suara'] === 15.0,
    `Zero error final score: ${zeroCalc.finalScore}`
  );

  // 14. Pemetaan Kategori Khusus: Fashahah & Waqaf hanya memotong bidang Fashahah
  const fashOnlyCalc = calculateAssessmentScore({ 'cat-fsh': 3 }, sampleCategories, OFFICIAL_SENI_BACA_RUBRIC);
  // cat-fsh deduction = 3 * 1.0 = 3.0. Fashahah score = 30 - 3 = 27.0. Tajwid remains 30.0.
  assert(
    '14. Pemetaan Bidang Independen: Kesalahan Fashahah tidak mengurangi bidang Tajwid',
    fashOnlyCalc.fieldScores['Fashahah'] === 27.0 && fashOnlyCalc.fieldScores['Tajwid'] === 30.0,
    `Fashahah: ${fashOnlyCalc.fieldScores['Fashahah']}, Tajwid: ${fashOnlyCalc.fieldScores['Tajwid']}`
  );

  // 15. Konfigurasi Dinamis: Admin mengubah batas skor maksimal bidang (Tajwid 40, Fashahah 20) tanpa merusak mesin
  const customDynamicRubric: RubricVersion = {
    id: 'rubric-custom-dynamic-1',
    tenantId: 'tenant-test',
    code: 'RUBRIC-CUSTOM-2026',
    name: 'Rubrik Khusus Pengujian Dinamis',
    branchCode: 'TLW-DWS',
    branchName: 'Tilawah Dewasa Putra',
    version: '1.0',
    description: 'Rubrik dinamis dengan batas bidang kustom',
    status: 'Aktif',
    startingScore: 100,
    fields: [
      { id: 'f-tjw', code: 'TJW', name: 'Tajwid', maxScore: 40, minScore: 0, order: 1 },
      { id: 'f-fsh', code: 'FSH', name: 'Fashahah', maxScore: 20, minScore: 0, order: 2 },
      { id: 'f-lag', code: 'LAG', name: 'Lagu', maxScore: 25, minScore: 0, order: 3 },
      { id: 'f-sua', code: 'SUA', name: 'Suara', maxScore: 15, minScore: 0, order: 4 }
    ],
    createdAt: new Date().toISOString()
  };
  const dynamicCategories: ErrorCategory[] = [
    {
      ...sampleCategories[0],
      fieldId: 'f-tjw' // Pemetaan relasional eksplisit ke field Tajwid rubrik dinamis
    }
  ];
  const dynamicCalc = calculateAssessmentScore(
    { 'cat-mkh': 2 }, // 2 * 1.0 = 2 deduction on Tajwid
    dynamicCategories,
    customDynamicRubric
  );
  // Tajwid should be 40 - 2 = 38. Fashahah = 20, Lagu = 25, Suara = 15. Total = 38 + 20 + 25 + 15 = 98.
  assert(
    '15. Konfigurasi Dinamis Bidang: Perubahan maxScore bidang oleh admin dihitung akurat tanpa fallback hardcoded',
    dynamicCalc.fieldScores['Tajwid'] === 38.0 && dynamicCalc.fieldScores['Fashahah'] === 20.0 && dynamicCalc.finalScore === 98.0,
    `Tajwid: ${dynamicCalc.fieldScores['Tajwid']}, Fashahah: ${dynamicCalc.fieldScores['Fashahah']}, Final: ${dynamicCalc.finalScore}`
  );

  // 16. Integritas Relasional: Penolakan kategori tak terpetakan tanpa fallback diam-diam ke Tajwid
  const unmappedCategory: ErrorCategory = {
    id: 'cat-unknown-custom',
    tenantId: 'tenant-test',
    code: 'UNK',
    name: 'Kesalahan Tanpa Bidang',
    scope: 'Eksperimental',
    defaultDeduction: 2.0,
    methodType: 'Pengurangan tetap',
    status: 'Aktif',
    order: 99
  };
  const unmappedCalc = calculateAssessmentScore(
    { 'cat-unknown-custom': 2 },
    [unmappedCategory],
    OFFICIAL_SENI_BACA_RUBRIC
  );
  assert(
    '16. Eliminasi Fallback Diam-diam: Kategori tanpa pemetaan valid menghasilkan validation error dan tidak memotong Tajwid',
    unmappedCalc.validationErrors.length > 0 && unmappedCalc.fieldScores['Tajwid'] === 30.0 && unmappedCalc.totalDeductions === 0,
    `Errors: ${unmappedCalc.validationErrors.join('; ')}, Tajwid: ${unmappedCalc.fieldScores['Tajwid']}`
  );

  // 17. Konfigurasi Tie-Break Dinamis: Perubahan urutan kriteria tie-break (Lagu > Tajwid)
  const tieBreakPartA: Participant = {
    id: 'p-tb-a',
    tenantId: 't-tb',
    participantId: 'TLW-A',
    lotteryNumber: '01',
    name: 'Qari A (Lagu Unggul)',
    gender: 'Putra',
    kafilahId: 'k-1',
    kafilahName: 'Kafilah 1',
    branchName: 'Tilawah Dewasa Putra',
    levelName: 'Ulya',
    stageName: 'Penyisihan',
    questionId: 'q-1',
    assignedMaqra: 'Maqra 1',
    pageNumber: 300,
    status: 'Berlangsung'
  };
  const tieBreakPartB: Participant = {
    id: 'p-tb-b',
    tenantId: 't-tb',
    participantId: 'TLW-B',
    lotteryNumber: '02',
    name: 'Qari B (Tajwid Unggul)',
    gender: 'Putra',
    kafilahId: 'k-2',
    kafilahName: 'Kafilah 2',
    branchName: 'Tilawah Dewasa Putra',
    levelName: 'Ulya',
    stageName: 'Penyisihan',
    questionId: 'q-1',
    assignedMaqra: 'Maqra 1',
    pageNumber: 300,
    status: 'Berlangsung'
  };
  const tieBreakParts: StageParticipation[] = [
    {
      id: 'sp-tb-a',
      tenantId: 't-tb',
      participantId: 'p-tb-a',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      branchName: 'Tilawah Dewasa Putra',
      lotteryNumber: '01',
      questionId: 'q-1',
      assignedMaqra: 'Maqra 1',
      pageNumber: 300,
      status: 'Lengkap'
    },
    {
      id: 'sp-tb-b',
      tenantId: 't-tb',
      participantId: 'p-tb-b',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      branchName: 'Tilawah Dewasa Putra',
      lotteryNumber: '02',
      questionId: 'q-1',
      assignedMaqra: 'Maqra 1',
      pageNumber: 300,
      status: 'Lengkap'
    }
  ];
  // Both have total = 90.0
  // Part A: Tajwid = 25, Lagu = 25, Fashahah = 25, Suara = 15 -> Total = 90
  // Part B: Tajwid = 28, Lagu = 22, Fashahah = 25, Suara = 15 -> Total = 90
  const tieBreakAssessments: JudgeAssessment[] = [
    {
      id: 'as-tb-a',
      tenantId: 't-tb',
      judgeId: 'j-tb',
      judgeName: 'Hakim TB',
      judgeField: 'Tajwid',
      participantId: 'p-tb-a',
      stageParticipationId: 'sp-tb-a',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      questionId: 'q-1',
      fieldScores: { Tajwid: 25.0, Lagu: 25.0, Fashahah: 25.0, Suara: 15.0 },
      finalScore: 90.0,
      status: 'finalized',
      errorCounts: {},
      deductions: {},
      totalDeductions: 10,
      annotations: [],
      lastUpdated: '10:00 WIB'
    },
    {
      id: 'as-tb-b',
      tenantId: 't-tb',
      judgeId: 'j-tb',
      judgeName: 'Hakim TB',
      judgeField: 'Tajwid',
      participantId: 'p-tb-b',
      stageParticipationId: 'sp-tb-b',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      questionId: 'q-1',
      fieldScores: { Tajwid: 28.0, Lagu: 22.0, Fashahah: 25.0, Suara: 15.0 },
      finalScore: 90.0,
      status: 'finalized',
      errorCounts: {},
      deductions: {},
      totalDeductions: 10,
      annotations: [],
      lastUpdated: '10:00 WIB'
    }
  ];
  const customLaguFirstConfig: CompetitionRuleConfig[] = [
    {
      id: 'cfg-lagu-first',
      tenantId: 't-tb',
      branchName: 'Tilawah Dewasa Putra',
      rubricVersionId: 'rubric-seni-baca-2025',
      tieBreakOrder: ['total', 'Lagu', 'Tajwid', 'Fashahah'],
      quotaPerStage: { 'Penyisihan': 1 }
    }
  ];
  const laguFirstEval = RankingService.evaluateStageParticipants({
    tenantId: 't-tb',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieBreakParts,
    participants: [tieBreakPartA, tieBreakPartB],
    assessments: tieBreakAssessments,
    judgeAssignments: [{ id: 'ja-tb', tenantId: 't-tb', judgeId: 'j-tb', judgeName: 'Hakim TB', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }],
    quota: 1,
    customRuleConfigs: customLaguFirstConfig
  });
  const rank1Custom = laguFirstEval.evaluatedParticipants.find((p) => p.rank === 1);
  assert(
    '17. Tie-Break Dinamis: Perubahan urutan kriteria ke Lagu > Tajwid menempatkan Qari A di peringkat 1',
    Boolean(rank1Custom && rank1Custom.participant.id === 'p-tb-a' && rank1Custom.tieBreakResolvedBy?.includes('Lagu')),
    `Rank 1: ${rank1Custom?.participant.name}, Resolved by: ${rank1Custom?.tieBreakResolvedBy}`
  );

  // 18. Pemblokiran Finalisasi Seri: Nilai identik total & semua bidang memblokir finalisasi otomatis
  const identicalAssessments: JudgeAssessment[] = [
    {
      id: 'as-id-1',
      tenantId: 't-tb',
      judgeId: 'j-tb',
      judgeName: 'Hakim TB',
      judgeField: 'Tajwid',
      participantId: 'p-tb-a',
      stageParticipationId: 'sp-tb-a',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      questionId: 'q-1',
      fieldScores: { Tajwid: 25.0, Lagu: 25.0, Fashahah: 25.0, Suara: 15.0 },
      finalScore: 90.0,
      status: 'finalized',
      errorCounts: {},
      deductions: {},
      totalDeductions: 10,
      annotations: [],
      lastUpdated: '10:00 WIB'
    },
    {
      id: 'as-id-2',
      tenantId: 't-tb',
      judgeId: 'j-tb',
      judgeName: 'Hakim TB',
      judgeField: 'Tajwid',
      participantId: 'p-tb-b',
      stageParticipationId: 'sp-tb-b',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      questionId: 'q-1',
      fieldScores: { Tajwid: 25.0, Lagu: 25.0, Fashahah: 25.0, Suara: 15.0 },
      finalScore: 90.0,
      status: 'finalized',
      errorCounts: {},
      deductions: {},
      totalDeductions: 10,
      annotations: [],
      lastUpdated: '10:00 WIB'
    }
  ];
  const blockedEval = RankingService.evaluateStageParticipants({
    tenantId: 't-tb',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieBreakParts,
    participants: [tieBreakPartA, tieBreakPartB],
    assessments: identicalAssessments,
    judgeAssignments: [{ id: 'ja-tb', tenantId: 't-tb', judgeId: 'j-tb', judgeName: 'Hakim TB', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }],
    quota: 1
  });
  assert(
    '18. Proteksi Seri Identik: Finalisasi diblokir otomatis jika terjadi seri pada batas kuota atau podium',
    Boolean(blockedEval.canFinalize === false && blockedEval.boundaryTie === true && typeof blockedEval.blockingReason === 'string'),
    `canFinalize: ${blockedEval.canFinalize}, boundaryTie: ${blockedEval.boundaryTie}, reason: ${blockedEval.blockingReason}`
  );

  // 19. Imutabilitas Snapshot: Snapshot hasil babak membekukan versi rubrik dan hasil resmi
  const historicalSnapshot = RankingService.createStageResultSnapshot({
    tenantId: 't-tb',
    stageId: 'stg-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    quota: 1,
    finalizedBy: 'Ketua Dewan Hakim',
    evaluatedParticipants: laguFirstEval.evaluatedParticipants,
    customRuleConfigs: customLaguFirstConfig
  });
  assert(
    '19. Imutabilitas Snapshot Historis: Snapshot membekukan versi rubrik dan aturan tie-break yang dipakai saat finalisasi',
    historicalSnapshot.rubricVersionId === 'rubric-seni-baca-2025' &&
    historicalSnapshot.tieBreakRuleUsed.includes('Lagu ➔ Tajwid') &&
    historicalSnapshot.rankings.length === 2 &&
    historicalSnapshot.rankings[0].participantId === 'p-tb-a',
    `Snapshot rubric: ${historicalSnapshot.rubricVersionId}, tieBreakRule: ${historicalSnapshot.tieBreakRuleUsed}, Rank 1: ${historicalSnapshot.rankings[0]?.participantName}`
  );

  // 20. Validasi Integer Ketat untuk Jumlah Kesalahan (Error Counts)
  const floatCountCalc = calculateAssessmentScore(
    { 'cat-mkh': 2.5 },
    sampleCategories,
    OFFICIAL_SENI_BACA_RUBRIC
  );
  assert(
    '20. Validasi Integer Ketat: Input desimal pada jumlah kejadian kesalahan ditolak dengan validation error',
    floatCountCalc.validationErrors.length > 0 && floatCountCalc.validationErrors[0].includes('bilangan bulat'),
    `Validation errors: ${floatCountCalc.validationErrors.join('; ')}`
  );

  // 21. Akurasi Potongan Desimal per Kejadian (0.5, 1.0, 1.5)
  const decimalDeductionCalc = calculateAssessmentScore(
    { 'cat-idg': 3 },
    sampleCategories,
    OFFICIAL_SENI_BACA_RUBRIC
  );
  assert(
    '21. Potongan Desimal: 3 kejadian * 0.5 poin = 1.50 potongan pada Tajwid (Skor: 28.50)',
    decimalDeductionCalc.fieldDeductions['Tajwid'] === 1.5 && decimalDeductionCalc.fieldScores['Tajwid'] === 28.5,
    `Tajwid deduction: ${decimalDeductionCalc.fieldDeductions['Tajwid']}, Tajwid score: ${decimalDeductionCalc.fieldScores['Tajwid']}`
  );

  // 22. Batas Maksimum Pengurangan per Bidang (fieldMaxDeduction)
  const overDeductionCalc = calculateAssessmentScore(
    { 'cat-mkh': 50 },
    sampleCategories,
    OFFICIAL_SENI_BACA_RUBRIC
  );
  assert(
    '22. Batas Bidang: Pengurangan Tajwid tidak melebihi skor maksimal bidang 30 (Skor Tajwid min = 0)',
    overDeductionCalc.fieldScores['Tajwid'] === 0 && overDeductionCalc.finalScore >= 0,
    `Tajwid score: ${overDeductionCalc.fieldScores['Tajwid']}, Final score: ${overDeductionCalc.finalScore}`
  );

  // 23. Isolasi Multi-Cabang untuk Babak dengan Nama Identik ("Penyisihan")
  const multiBranchEval = RankingService.evaluateStageParticipants({
    tenantId: 't-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: [
      { id: 'sp-til', tenantId: 't-1', participantId: 'p-til-1', stageId: 'stg-1', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', lotteryNumber: '01', questionId: 'q-1', assignedMaqra: 'Maqra 1', pageNumber: 300, status: 'Lengkap' },
      { id: 'sp-tah', tenantId: 't-1', participantId: 'p-tah-1', stageId: 'stg-2', stageName: 'Penyisihan', branchName: 'Tahfizh 30 Juz', lotteryNumber: '01', questionId: 'q-2', assignedMaqra: 'Maqra 2', pageNumber: 305, status: 'Lengkap' }
    ],
    participants: [
      { id: 'p-til-1', tenantId: 't-1', name: 'Qari Tilawah', participantId: 'TLW-01', lotteryNumber: '01', gender: 'Putra', kafilahId: 'kf-1', kafilahName: 'Kafilah Kota', branchName: 'Tilawah Dewasa Putra', levelName: 'Dewasa', questionId: 'q-1', assignedMaqra: 'Maqra 1', pageNumber: 300, status: 'Berlangsung', stageName: 'Penyisihan' },
      { id: 'p-tah-1', tenantId: 't-1', name: 'Hafizh Tahfizh', participantId: 'THF-01', lotteryNumber: '01', gender: 'Putra', kafilahId: 'kf-1', kafilahName: 'Kafilah Kota', branchName: 'Tahfizh 30 Juz', levelName: 'Dewasa', questionId: 'q-2', assignedMaqra: 'Maqra 2', pageNumber: 305, status: 'Berlangsung', stageName: 'Penyisihan' }
    ],
    assessments: [
      { id: 'a-til', tenantId: 't-1', judgeId: 'j-1', judgeName: 'Hakim', judgeField: 'Tajwid', participantId: 'p-til-1', stageParticipationId: 'sp-til', stageId: 'stg-1', stageName: 'Penyisihan', questionId: 'q-1', fieldScores: { Tajwid: 29 }, finalScore: 95, status: 'finalized', errorCounts: {}, deductions: {}, totalDeductions: 5, annotations: [], lastUpdated: '10:00' },
      { id: 'a-tah', tenantId: 't-1', judgeId: 'j-1', judgeName: 'Hakim', judgeField: 'Tahfizh', participantId: 'p-tah-1', stageParticipationId: 'sp-tah', stageId: 'stg-2', stageName: 'Penyisihan', questionId: 'q-2', fieldScores: { Tahfizh: 49 }, finalScore: 98, status: 'finalized', errorCounts: {}, deductions: {}, totalDeductions: 2, annotations: [], lastUpdated: '10:00' }
    ],
    judgeAssignments: [{ id: 'ja-1', tenantId: 't-1', judgeId: 'j-1', judgeName: 'Hakim', judgeField: 'Tajwid', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }],
    quota: 1
  });
  assert(
    '23. Isolasi Multi-Cabang: Evaluasi Babak Penyisihan Tilawah hanya menyertakan peserta Tilawah (1 peserta)',
    multiBranchEval.evaluatedParticipants.length === 1 && multiBranchEval.evaluatedParticipants[0].participant.id === 'p-til-1',
    `Evaluated count: ${multiBranchEval.evaluatedParticipants.length}`
  );

  // 24. Dukungan Manual Overrides True dan False
  const overrideEval = RankingService.evaluateStageParticipants({
    tenantId: 't-tb',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieBreakParts,
    participants: [tieBreakPartA, tieBreakPartB],
    assessments: tieBreakAssessments,
    judgeAssignments: [{ id: 'ja-tb', tenantId: 't-tb', judgeId: 'j-tb', judgeName: 'Hakim TB', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }],
    quota: 1,
    manualOverrides: { 'p-tb-b': true, 'p-tb-a': false },
    overrideReasons: { 'p-tb-b': 'Diskualifikasi administratif Qari A' }
  });
  const rank1Override = overrideEval.evaluatedParticipants.find((p) => p.rank === 1);
  assert(
    '24. Manual Overrides: Admin dapat secara eksplisit menetapkan true (lolos) dan false (gugur) secara manual',
    Boolean(rank1Override && rank1Override.participant.id === 'p-tb-b' && rank1Override.isQualified === true),
    `Rank 1: ${rank1Override?.participant.name}, Qualified: ${rank1Override?.isQualified}`
  );

  // 25. Pengesahan Seri Terpecahkan (False-Positive Boundary Tie Bug Fix)
  const resolvedTieEval = RankingService.evaluateStageParticipants({
    tenantId: 't-tb',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieBreakParts,
    participants: [tieBreakPartA, tieBreakPartB],
    assessments: tieBreakAssessments,
    judgeAssignments: [{ id: 'ja-tb', tenantId: 't-tb', judgeId: 'j-tb', judgeName: 'Hakim TB', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }],
    quota: 1
  });
  assert(
    '25. Bebas False-Positive Boundary Tie: Seri yang berhasil dipecahkan oleh tie-break Tajwid TIDAK memblokir finalisasi',
    resolvedTieEval.canFinalize === true && resolvedTieEval.boundaryTie === false,
    `canFinalize: ${resolvedTieEval.canFinalize}, boundaryTie: ${resolvedTieEval.boundaryTie}`
  );

  // 26. Pembuatan Snapshot Mengandung Timestamp WIB Terformat
  assert(
    '26. Format Timestamp Snapshot: Snapshot hasil babak mencantumkan waktu finalisasi berformat WIB',
    typeof historicalSnapshot.finalizedAt === 'string' && historicalSnapshot.finalizedAt.length > 0,
    `Finalized at: ${historicalSnapshot.finalizedAt}`
  );

  // 27. Konsistensi Penilaian Multi-Soal (Rata-rata Akurat)
  const sampleStageQuestions: AssignedMaqraItem[] = [
    { questionId: 'q-1', title: 'Maqra 1', pageNumber: 300 },
    { questionId: 'q-2', title: 'Maqra 2', pageNumber: 305 }
  ];
  const sampleAssessments: JudgeAssessment[] = [
    { id: 'a-1', tenantId: 't-1', judgeId: 'j-1', judgeName: 'Hakim', judgeField: 'Tajwid', participantId: 'p-m', stageParticipationId: 'sp-m', stageId: 's-1', stageName: 'Penyisihan', questionId: 'q-1', fieldScores: { Tajwid: 25 }, finalScore: 90.0, status: 'finalized', errorCounts: {}, deductions: {}, totalDeductions: 10, annotations: [], lastUpdated: '10:00' },
    { id: 'a-2', tenantId: 't-1', judgeId: 'j-1', judgeName: 'Hakim', judgeField: 'Tajwid', participantId: 'p-m', stageParticipationId: 'sp-m', stageId: 's-1', stageName: 'Penyisihan', questionId: 'q-2', fieldScores: { Tajwid: 30 }, finalScore: 100.0, status: 'finalized', errorCounts: {}, deductions: {}, totalDeductions: 0, annotations: [], lastUpdated: '10:00' }
  ];
  const multiMaqraCalc = aggregateParticipantScores('p-m', 'Penyisihan', sampleStageQuestions, ['j-1'], sampleAssessments);
  assert(
    '27. Agregasi Multi-Maqra: Rata-rata 2 maqra (90.0 dan 100.0) menghasilkan nilai tepat 95.00',
    multiMaqraCalc.averageFinalScore === 95.0 && multiMaqraCalc.isFullyFinalized === true,
    `Aggregated score: ${multiMaqraCalc.averageFinalScore}`
  );

  // 28. Validasi Kelengkapan Penilaian Dewan Hakim Sebelum Advance Qualifiers
  assert(
    '28. Validasi Kelengkapan: Penilaian dewan hakim yang belum lengkap mencegah pengesahan kualifikasi',
    Boolean(blockedEval.blockingReason || !blockedEval.canFinalize),
    `Blocking reason: ${blockedEval.blockingReason}`
  );

  // 29. Rubrik Dinamis Penuh: Menghapus/Menonaktifkan bidang Lagu dan Menambahkan bidang baru Itqan
  const rubricWithItqanNoLagu: RubricVersion = {
    id: 'rubric-tahfizh-itqan-2026',
    tenantId: 'tenant-test',
    code: 'RUBRIC-ITQAN-2026',
    name: 'Rubrik Tahfizh & Itqan 2026',
    branchCode: 'THF-ITQ',
    branchName: 'Tahfizh 20 Juz',
    version: '2026.1',
    description: 'Rubrik tanpa Lagu dengan tambahan bidang Itqan',
    status: 'Aktif',
    startingScore: 100,
    fields: [
      { id: 'fld-tjw', code: 'TJW', name: 'Tajwid', maxScore: 35, minScore: 0, order: 1, status: 'Aktif' },
      { id: 'fld-fsh', code: 'FSH', name: 'Fashahah', maxScore: 25, minScore: 0, order: 2, status: 'Aktif' },
      { id: 'fld-lag', code: 'LAG', name: 'Lagu', maxScore: 25, minScore: 0, order: 3, status: 'Nonaktif' },
      { id: 'fld-itq', code: 'ITQ', name: 'Itqan', maxScore: 40, minScore: 0, order: 4, status: 'Aktif' }
    ],
    createdAt: new Date().toISOString()
  };
  const itqanCategories: ErrorCategory[] = [
    {
      id: 'cat-itq-1',
      tenantId: 'tenant-test',
      fieldId: 'fld-itq',
      code: 'ITQ1',
      name: 'Tawaqquf Hafalan',
      scope: 'Itqan Hafalan',
      defaultDeduction: 1.5,
      methodType: 'Pengurangan tetap',
      status: 'Aktif',
      order: 1
    }
  ];
  const itqanCalc = calculateAssessmentScore({ 'cat-itq-1': 2 }, itqanCategories, rubricWithItqanNoLagu);
  // Itqan: 40 - (2 * 1.5) = 37.0; Tajwid: 35.0; Fashahah: 25.0; Lagu is Nonaktif (undefined). Total = 97.0
  assert(
    '29. Rubrik Dinamis: Penonaktifan bidang Lagu dan penambahan bidang Itqan dihitung presisi tanpa perubahan kode',
    itqanCalc.validationErrors.length === 0 &&
      itqanCalc.fieldScores['Itqan'] === 37.0 &&
      itqanCalc.fieldScores['Lagu'] === undefined &&
      itqanCalc.finalScore === 97.0,
    `Itqan: ${itqanCalc.fieldScores['Itqan']}, Lagu: ${itqanCalc.fieldScores['Lagu']}, Final: ${itqanCalc.finalScore}`
  );

  // 30. Eksekusi DeductionRule dan Batas Maksimum Kriteria (RubricCriterion.maxDeduction)
  const rubricWithCriterionRules: RubricVersion = {
    id: 'rubric-crit-cap',
    tenantId: 'tenant-test',
    code: 'RUBRIC-CRIT-2026',
    name: 'Rubrik Kriteria Bertingkat',
    branchCode: 'TLW',
    branchName: 'Tilawah',
    version: '1.0',
    description: 'Uji batas potongan per kriteria dan aturan pengurangan',
    status: 'Aktif',
    startingScore: 100,
    fields: [
      {
        id: 'f-1',
        code: 'TJW',
        name: 'Tajwid',
        maxScore: 100,
        minScore: 0,
        order: 1,
        status: 'Aktif',
        criteria: [
          {
            id: 'cr-makhraj',
            fieldId: 'f-1',
            name: 'Makharijul Huruf',
            maxDeduction: 4.0,
            deductionRules: [
              {
                id: 'dr-jali',
                criterionId: 'cr-makhraj',
                label: 'Khafi/Jali',
                deductionPerError: 1.5,
                maxDeduction: 3.0
              }
            ]
          }
        ]
      }
    ],
    createdAt: new Date().toISOString()
  };
  const critCategories: ErrorCategory[] = [
    {
      id: 'cat-dr-1',
      tenantId: 'tenant-test',
      fieldId: 'f-1',
      criterionId: 'cr-makhraj',
      deductionRuleId: 'dr-jali',
      code: 'DRJ',
      name: 'Kesalahan Makhraj Jali',
      scope: 'Tajwid',
      defaultDeduction: 1.5,
      methodType: 'Pengurangan tetap',
      status: 'Aktif',
      order: 1
    }
  ];
  // 4 errors * 1.5 = 6.0 raw, capped by DeductionRule.maxDeduction = 3.0 -> finalScore = 97.0
  const critCalc = calculateAssessmentScore({ 'cat-dr-1': 4 }, critCategories, rubricWithCriterionRules);
  assert(
    '30. Eksekusi DeductionRule & Criterion Cap: Potongan dibatasi sesuai maxDeduction pada DeductionRule/RubricCriterion',
    critCalc.validationErrors.length === 0 &&
      critCalc.deductions['cat-dr-1'] === 3.0 &&
      critCalc.finalScore === 97.0,
    `Deduction: ${critCalc.deductions['cat-dr-1']}, Final: ${critCalc.finalScore}`
  );

  // 31. Penolakan Metode "Pengurangan berbobot" Tanpa Formula Resmi
  const weightedCat: ErrorCategory = {
    id: 'cat-weighted',
    tenantId: 'tenant-test',
    fieldId: 'fld-tajwid',
    code: 'WGT',
    name: 'Kesalahan Berbobot',
    scope: 'Tajwid & Makhraj',
    defaultDeduction: 1.0,
    methodType: 'Pengurangan berbobot',
    status: 'Aktif',
    order: 10
  };
  const weightedCalc = calculateAssessmentScore({ 'cat-weighted': 1 }, [weightedCat], OFFICIAL_SENI_BACA_RUBRIC);
  assert(
    '31. Bloker Konfigurasi: Metode "Pengurangan berbobot" ditolak dengan validation error eksplisit',
    weightedCalc.validationErrors.length > 0 &&
      weightedCalc.validationErrors.some((e) => e.includes('Pengurangan berbobot')),
    `Errors: ${weightedCalc.validationErrors.join('; ')}`
  );

  // 32. Penolakan Finalisasi Babak Tanpa Penugasan Hakim Resmi (judge_assignments kosong)
  const noAssignmentEval = RankingService.evaluateStageParticipants({
    tenantId: 't-tb',
    stageId: 'stg-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieBreakParts,
    participants: [tieBreakPartA, tieBreakPartB],
    assessments: tieBreakAssessments,
    judgeAssignments: [], // Kosong -> wajib menolak finalisasi!
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }],
    quota: 1
  });
  assert(
    '32. Otorisasi Majelis Hakim: Babak tanpa penugasan hakim resmi (judgeAssignments kosong) memblokir pengesahan',
    noAssignmentEval.canFinalize === false &&
      Boolean(noAssignmentEval.blockingReason?.includes('penugasan dewan hakim')),
    `canFinalize: ${noAssignmentEval.canFinalize}, reason: ${noAssignmentEval.blockingReason}`
  );

  // 33. Validasi Kriteria Tie-Break Terhadap Bidang Rubrik Aktif
  const invalidTieBreakConfig: CompetitionRuleConfig[] = [
    {
      id: 'cfg-invalid-tb',
      tenantId: 't-tb',
      branchName: 'Tilawah Dewasa Putra',
      rubricVersionId: 'rubric-seni-baca-2025',
      tieBreakOrder: ['total', 'BidangFiktifYangTidakAda'],
      quotaPerStage: { Penyisihan: 1 }
    }
  ];
  const invalidTbEval = RankingService.evaluateStageParticipants({
    tenantId: 't-tb',
    stageId: 'stg-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieBreakParts,
    participants: [tieBreakPartA, tieBreakPartB],
    assessments: tieBreakAssessments,
    judgeAssignments: [{ id: 'ja-tb', tenantId: 't-tb', judgeId: 'j-tb', judgeName: 'Hakim TB', stageId: 'stg-1', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }],
    quota: 1,
    customRuleConfigs: invalidTieBreakConfig
  });
  assert(
    '33. Validasi Tie-Break: Kriteria tie-break yang tidak ada pada rubrik aktif memblokir pengesahan babak',
    invalidTbEval.canFinalize === false && invalidTbEval.isTieBreakConfigValid === false,
    `canFinalize: ${invalidTbEval.canFinalize}, isTieBreakConfigValid: ${invalidTbEval.isTieBreakConfigValid}`
  );

  // 34. Deteksi Konflik Manual Override False Tanpa Alasan Wajib
  const overrideConflictWithoutReason = RankingService.evaluateStageParticipants({
    tenantId: 't-tb',
    stageId: 'stg-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieBreakParts,
    participants: [tieBreakPartA, tieBreakPartB],
    assessments: tieBreakAssessments,
    judgeAssignments: [{ id: 'ja-tb', tenantId: 't-tb', judgeId: 'j-tb', judgeName: 'Hakim TB', stageId: 'stg-1', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }],
    quota: 1,
    manualOverrides: { 'p-tb-b': false }, // p-tb-b adalah peringkat 1 otomatis, digugurkan manual tanpa alasan
    overrideReasons: {}
  });
  assert(
    '34. Validasi Override Manual: Menggugurkan peserta yang lolos otomatis (override false) tanpa alasan >= 5 karakter ditolak',
    overrideConflictWithoutReason.canFinalize === false &&
      Boolean(overrideConflictWithoutReason.blockingReason?.includes('override manual')),
    `canFinalize: ${overrideConflictWithoutReason.canFinalize}, reason: ${overrideConflictWithoutReason.blockingReason}`
  );

  // 35. Isolasi Ketat Berbasis stageId dan branchId untuk Dua Cabang dengan Babak "Penyisihan"
  const strictStageIsolationEval = RankingService.evaluateStageParticipants({
    tenantId: 't-1',
    stageId: 'stg-1',
    stageName: 'Penyisihan',
    branchId: 'br-tilawah',
    branchName: 'Tilawah Dewasa Putra',
    participations: [
      { id: 'sp-til', tenantId: 't-1', participantId: 'p-til-1', stageId: 'stg-1', stageName: 'Penyisihan', branchId: 'br-tilawah', branchName: 'Tilawah Dewasa Putra', lotteryNumber: '01', questionId: 'q-1', assignedMaqra: 'Maqra 1', pageNumber: 300, status: 'Lengkap' },
      { id: 'sp-tah', tenantId: 't-1', participantId: 'p-tah-1', stageId: 'stg-2', stageName: 'Penyisihan', branchId: 'br-tahfizh', branchName: 'Tahfizh 30 Juz', lotteryNumber: '01', questionId: 'q-2', assignedMaqra: 'Maqra 2', pageNumber: 305, status: 'Lengkap' }
    ],
    participants: [
      { id: 'p-til-1', tenantId: 't-1', name: 'Qari Tilawah', participantId: 'TLW-01', lotteryNumber: '01', gender: 'Putra', kafilahId: 'kf-1', kafilahName: 'Kafilah Kota', branchId: 'br-tilawah', branchName: 'Tilawah Dewasa Putra', levelName: 'Dewasa', questionId: 'q-1', assignedMaqra: 'Maqra 1', pageNumber: 300, status: 'Berlangsung', stageName: 'Penyisihan' },
      { id: 'p-tah-1', tenantId: 't-1', name: 'Hafizh Tahfizh', participantId: 'THF-01', lotteryNumber: '01', gender: 'Putra', kafilahId: 'kf-1', kafilahName: 'Kafilah Kota', branchId: 'br-tahfizh', branchName: 'Tahfizh 30 Juz', levelName: 'Dewasa', questionId: 'q-2', assignedMaqra: 'Maqra 2', pageNumber: 305, status: 'Berlangsung', stageName: 'Penyisihan' }
    ],
    assessments: [
      { id: 'a-til', tenantId: 't-1', judgeId: 'j-1', judgeName: 'Hakim', judgeField: 'Tajwid', participantId: 'p-til-1', stageParticipationId: 'sp-til', stageId: 'stg-1', stageName: 'Penyisihan', questionId: 'q-1', fieldScores: { Tajwid: 29, Fashahah: 29, Lagu: 24, Suara: 14 }, finalScore: 96, status: 'finalized', errorCounts: {}, deductions: {}, totalDeductions: 4, annotations: [], lastUpdated: '10:00' },
      { id: 'a-tah', tenantId: 't-1', judgeId: 'j-1', judgeName: 'Hakim', judgeField: 'Tahfizh', participantId: 'p-tah-1', stageParticipationId: 'sp-tah', stageId: 'stg-2', stageName: 'Penyisihan', questionId: 'q-2', fieldScores: { Tahfizh: 49, Tajwid: 25, Fashahah: 24 }, finalScore: 98, status: 'finalized', errorCounts: {}, deductions: {}, totalDeductions: 2, annotations: [], lastUpdated: '10:00' }
    ],
    judgeAssignments: [
      { id: 'ja-1', tenantId: 't-1', judgeId: 'j-1', judgeName: 'Hakim', judgeField: 'Tajwid', stageId: 'stg-1', stageName: 'Penyisihan', branchId: 'br-tilawah', branchName: 'Tilawah Dewasa Putra' }
    ],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }],
    quota: 1
  });
  assert(
    '35. Isolasi ID Ketat (stageId & branchId): Babak Penyisihan pada cabang berbeda terisolasi 100% dan siap disahkan',
    strictStageIsolationEval.canFinalize === true &&
      strictStageIsolationEval.evaluatedParticipants.length === 1 &&
      strictStageIsolationEval.evaluatedParticipants[0].participant.id === 'p-til-1',
    `canFinalize: ${strictStageIsolationEval.canFinalize}, count: ${strictStageIsolationEval.evaluatedParticipants.length}`
  );

  // 35b. Finalisasi 0 Kesalahan (Zero-Error Sheet) dengan startingScore Rubrik Dinamis
  const customStartingRubric: RubricVersion = {
    ...OFFICIAL_SENI_BACA_RUBRIC,
    id: 'rubric-custom-90',
    startingScore: 90,
    fields: [
      { id: 'fld-tajwid', code: 'TJW', name: 'Tajwid', maxScore: 30, minScore: 0, order: 1, status: 'Aktif' },
      { id: 'fld-fashahah', code: 'FSH', name: 'Fashahah', maxScore: 30, minScore: 0, order: 2, status: 'Aktif' },
      { id: 'fld-lagu', code: 'LAG', name: 'Lagu', maxScore: 30, minScore: 0, order: 3, status: 'Aktif' }
    ]
  };
  const zeroCustomCalc = calculateAssessmentScore({}, sampleCategories, customStartingRubric);
  assert(
    '35b. Finalisasi 0 Kesalahan Dinamis: Lembar 0 kesalahan menggunakan startingScore & batas bidang rubrik aktif (90.00)',
    zeroCustomCalc.totalDeductions === 0 && zeroCustomCalc.finalScore === 90.0,
    `totalDeductions: ${zeroCustomCalc.totalDeductions}, finalScore: ${zeroCustomCalc.finalScore}`
  );

  // 35c. Validasi Import Excel Peserta & Bank Soal Terhadap Master Data Tunggal
  const masterKafilahs = [
    { id: 'k-bdg', tenantId: 't-1', code: 'GRP-BDG', name: 'Grup Kota Bandung', region: 'Jawa Barat', participantCount: 1, contactPerson: 'PJ', contactPhone: '081', status: 'Aktif' as const }
  ];
  const masterCabang = [
    { id: 'c-tlw', tenantId: 't-1', code: 'TLW-DWS-PA', name: 'Tilawah Dewasa Putra', description: 'Tilawah', status: 'Aktif' as const },
    { id: 'c-non', tenantId: 't-1', code: 'TLW-NON', name: 'Cabang Lama Nonaktif', description: 'Tilawah', status: 'Nonaktif' as const }
  ];
  const masterJenjang = [
    { id: 'j-dws', tenantId: 't-1', code: 'DWS', name: 'Dewasa', description: '18-40 Tahun', status: 'Aktif' as const }
  ];
  const masterStages = [
    {
      id: 's-pny',
      tenantId: 't-1',
      name: 'Penyisihan',
      branchName: 'Tilawah Dewasa Putra',
      order: 1,
      qualificationQuota: 6,
      qualificationMethod: 'top_n' as const,
      status: 'Aktif' as const
    }
  ];

  const participantImportCheck = validateParticipantImportRows(
    [
      {
        'No Urut Administrasi': 'ADM-001',
        'ID Peserta': 'TLW-101',
        'Nama Peserta': 'Ahmad Fauzi',
        'Nama Ayah': 'H. Sulaiman',
        'Jenis Kelamin': 'Putra',
        'Kota Asal': 'Kota Bandung',
        'Daerah Asal': 'Jawa Barat',
        'Asal Pesantren / Sekolah': 'PP Al-Falah',
        'Grup / Kafilah': 'Grup Kota Bandung',
        'Cabang Lomba': 'Tilawah Dewasa Putra',
        'Jenjang Lomba': 'Dewasa',
        'Babak Aktif': 'Penyisihan',
        'Nomor Undian': '05',
        Status: 'Menunggu'
      },
      {
        'No Urut Administrasi': 'ADM-002',
        'ID Peserta': 'TLW-102',
        'Nama Peserta': 'Peserta Cabang Nonaktif',
        'Jenis Kelamin': 'Putra',
        'Grup / Kafilah': 'Grup Kota Bandung',
        'Cabang Lomba': 'Cabang Lama Nonaktif', // Harus ditolak karena Nonaktif
        'Jenjang Lomba': 'Dewasa',
        'Babak Aktif': 'Penyisihan'
      }
    ],
    {
      kafilahs: masterKafilahs,
      cabangList: masterCabang,
      jenjangList: masterJenjang,
      stages: masterStages,
      existingParticipants: []
    }
  );

  const questionImportCheck = validateQuestionImportRows(
    [
      {
        'Kode Soal': 'MQ-NEW-01',
        'Judul Maqra': 'Maqra Uji Import',
        'Nama Surah': 'Al-Baqarah',
        'Nomor Surah': 2,
        'Ayat Awal': 1,
        'Ayat Akhir': 10,
        'Halaman Awal': 2,
        'Halaman Akhir': 3,
        'Cabang Lomba': 'Tilawah Dewasa Putra',
        'Jenjang Lomba': 'Dewasa',
        Babak: 'Penyisihan'
      },
      {
        'Kode Soal': 'MQ-INVALID-PAGE',
        'Judul Maqra': 'Maqra Halaman Salah',
        'Nama Surah': 'Al-Baqarah',
        'Nomor Surah': 2,
        'Ayat Awal': 1,
        'Ayat Akhir': 10,
        'Halaman Awal': 700, // Invalid > 604
        'Halaman Akhir': 701,
        'Cabang Lomba': 'Tilawah Dewasa Putra',
        'Jenjang Lomba': 'Dewasa',
        Babak: 'Penyisihan'
      }
    ],
    {
      cabangList: masterCabang,
      jenjangList: masterJenjang,
      stages: masterStages,
      existingQuestions: []
    }
  );

  assert(
    '35c. Validasi Import Excel Peserta & Bank Soal: Memetakan 15 atribut peserta & relasi soal secara presisi serta menolak Master Data Nonaktif / halaman mushaf tidak valid',
    participantImportCheck.validRows.length === 1 &&
      participantImportCheck.errors.length === 1 &&
      participantImportCheck.validRows[0].fatherName === 'H. Sulaiman' &&
      participantImportCheck.validRows[0].originInstitution === 'PP Al-Falah' &&
      participantImportCheck.validRows[0].branchId === 'c-tlw' &&
      participantImportCheck.validRows[0].levelId === 'j-dws' &&
      questionImportCheck.validRows.length === 1 &&
      questionImportCheck.errors.length === 1 &&
      questionImportCheck.validRows[0].levelId === 'j-dws',
    `partValid: ${participantImportCheck.validRows.length}, partErr: ${participantImportCheck.errors.length}, qValid: ${questionImportCheck.validRows.length}`
  );

  // 35d. Algoritma Fisher-Yates Shuffle Unbiased
  const poolInput = ['MQ-01', 'MQ-02', 'MQ-03', 'MQ-04', 'MQ-05'];
  const shuffledPool = fisherYatesShuffle(poolInput);
  assert(
    '35d. Algoritma Undian Fisher-Yates: Menghasilkan permutasi tanpa mutasi array asli dan tanpa kehilangan elemen',
    shuffledPool.length === poolInput.length &&
      poolInput.every((item) => shuffledPool.includes(item)) &&
      poolInput[0] === 'MQ-01',
    `shuffled: ${shuffledPool.join(',')}`
  );

  // 35e. P0-01 Isolasi Evaluasi Multi-Cabang Saat "Semua Cabang" Dipilih (Hakim, Rubrik, Tie-Break, dan Kuota Terpisah)
  const multiBranchAllEval = RankingService.evaluateStageParticipants({
    tenantId: 't-1',
    stageName: 'Penyisihan',
    // branchName sengaja dikosongkan (simulasi pilihan "Semua Cabang")
    participations: [
      { id: 'sp-til-all', tenantId: 't-1', participantId: 'p-til-1', stageId: 'stg-til', stageName: 'Penyisihan', branchId: 'br-tilawah', branchName: 'Tilawah Dewasa Putra', lotteryNumber: '01', questionId: 'q-1', assignedMaqra: 'Maqra 1', pageNumber: 300, status: 'Lengkap' },
      { id: 'sp-tah-all', tenantId: 't-1', participantId: 'p-tah-1', stageId: 'stg-tah', stageName: 'Penyisihan', branchId: 'br-tahfizh', branchName: 'Tahfizh 10 Juz Putri', lotteryNumber: '01', questionId: 'q-2', assignedMaqra: 'Maqra 2', pageNumber: 305, status: 'Lengkap' }
    ],
    participants: [
      { id: 'p-til-1', tenantId: 't-1', name: 'Qari Tilawah', participantId: 'TLW-01', lotteryNumber: '01', gender: 'Putra', kafilahId: 'kf-1', kafilahName: 'Kafilah Kota', branchId: 'br-tilawah', branchName: 'Tilawah Dewasa Putra', levelName: 'Dewasa', questionId: 'q-1', assignedMaqra: 'Maqra 1', pageNumber: 300, status: 'Berlangsung', stageName: 'Penyisihan' },
      { id: 'p-tah-1', tenantId: 't-1', name: 'Hafizhah Tahfizh', participantId: 'THF-01', lotteryNumber: '01', gender: 'Putri', kafilahId: 'kf-1', kafilahName: 'Kafilah Kota', branchId: 'br-tahfizh', branchName: 'Tahfizh 10 Juz Putri', levelName: 'Dewasa', questionId: 'q-2', assignedMaqra: 'Maqra 2', pageNumber: 305, status: 'Berlangsung', stageName: 'Penyisihan' }
    ],
    assessments: [
      { id: 'a-til-1', tenantId: 't-1', judgeId: 'j-til-1', judgeName: 'Hakim Tilawah 1', judgeField: 'Tajwid', participantId: 'p-til-1', stageParticipationId: 'sp-til-all', stageId: 'stg-til', stageName: 'Penyisihan', questionId: 'q-1', fieldScores: { Tajwid: 29 }, finalScore: 95, status: 'finalized', errorCounts: {}, deductions: {}, totalDeductions: 5, annotations: [], lastUpdated: '10:00' },
      { id: 'a-til-2', tenantId: 't-1', judgeId: 'j-til-2', judgeName: 'Hakim Tilawah 2', judgeField: 'Lagu', participantId: 'p-til-1', stageParticipationId: 'sp-til-all', stageId: 'stg-til', stageName: 'Penyisihan', questionId: 'q-1', fieldScores: { Lagu: 24 }, finalScore: 96, status: 'finalized', errorCounts: {}, deductions: {}, totalDeductions: 4, annotations: [], lastUpdated: '10:00' },
      { id: 'a-tah-1', tenantId: 't-1', judgeId: 'j-tah-1', judgeName: 'Hakim Tahfizh 1', judgeField: 'Tahfizh', participantId: 'p-tah-1', stageParticipationId: 'sp-tah-all', stageId: 'stg-tah', stageName: 'Penyisihan', questionId: 'q-2', fieldScores: { Tahfizh: 49 }, finalScore: 98, status: 'finalized', errorCounts: {}, deductions: {}, totalDeductions: 2, annotations: [], lastUpdated: '10:00' }
    ],
    judgeAssignments: [
      { id: 'ja-til-1', tenantId: 't-1', judgeId: 'j-til-1', judgeName: 'Hakim Tilawah 1', judgeField: 'Tajwid', stageId: 'stg-til', stageName: 'Penyisihan', branchId: 'br-tilawah', branchName: 'Tilawah Dewasa Putra' },
      { id: 'ja-til-2', tenantId: 't-1', judgeId: 'j-til-2', judgeName: 'Hakim Tilawah 2', judgeField: 'Lagu', stageId: 'stg-til', stageName: 'Penyisihan', branchId: 'br-tilawah', branchName: 'Tilawah Dewasa Putra' },
      { id: 'ja-tah-1', tenantId: 't-1', judgeId: 'j-tah-1', judgeName: 'Hakim Tahfizh 1', judgeField: 'Tahfizh', stageId: 'stg-tah', stageName: 'Penyisihan', branchId: 'br-tahfizh', branchName: 'Tahfizh 10 Juz Putri' }
    ],
    stageQuestionsGetter: (pid) =>
      pid === 'p-til-1'
        ? [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }]
        : [{ questionId: 'q-2', title: 'M2', pageNumber: 305 }],
    quota: 1
  });
  const evalTilawahItem = multiBranchAllEval.evaluatedParticipants.find((p) => p.participant.id === 'p-til-1');
  const evalTahfizhItem = multiBranchAllEval.evaluatedParticipants.find((p) => p.participant.id === 'p-tah-1');
  assert(
    '35e. P0-01 Isolasi Semua Cabang: Hakim Tilawah (2 juri) tidak mencemari kelengkapan peserta Tahfizh (1 juri), masing-masing cabang memiliki Rank #1 sendiri, dan pengesahan lintas cabang diblokir',
    evalTilawahItem?.totalAssignedJudges === 2 &&
      evalTilawahItem?.isFullyFinalized === true &&
      evalTilawahItem?.rank === 1 &&
      evalTahfizhItem?.totalAssignedJudges === 1 &&
      evalTahfizhItem?.isFullyFinalized === true &&
      evalTahfizhItem?.rank === 1 &&
      multiBranchAllEval.canFinalize === false,
    `tilJudges: ${evalTilawahItem?.totalAssignedJudges}, tahJudges: ${evalTahfizhItem?.totalAssignedJudges}, tahFinal: ${evalTahfizhItem?.isFullyFinalized}, canFinalizeAll: ${multiBranchAllEval.canFinalize}`
  );

  // 35f. P0-03 Validasi 3D Penetapan Maqra (Cabang + Jenjang + Babak + Non-Duplikat)
  const samplePartUlya: Participant = {
    id: 'p-ulya-1',
    tenantId: 't-1',
    participantId: 'TLW-ULYA-01',
    lotteryNumber: '01',
    name: 'Peserta Ulya',
    gender: 'Putra',
    kafilahId: 'k-1',
    kafilahName: 'Bandung',
    branchId: 'br-tilawah',
    branchName: 'Tilawah Dewasa Putra',
    levelId: 'lvl-ulya',
    levelName: 'Ulya',
    stageId: 'stg-pny',
    stageName: 'Penyisihan',
    questionId: '',
    assignedMaqra: 'Belum Ditetapkan',
    pageNumber: 1,
    status: 'Menunggu'
  };
  const questionWrongLevel = {
    id: 'q-wustha',
    tenantId: 't-1',
    code: 'MQ-WST-01',
    title: 'Soal Wustha',
    surahName: 'Al-Mulk',
    surahNumber: 67,
    startAyah: 1,
    endAyah: 10,
    pageNumber: 562,
    branchId: 'br-tilawah',
    branchName: 'Tilawah Dewasa Putra',
    levelId: 'lvl-wustha',
    levelName: 'Wustha',
    branchAndLevel: 'Tilawah Dewasa Putra - Wustha',
    stageId: 'stg-pny',
    stage: 'Penyisihan',
    stageName: 'Penyisihan',
    status: 'Aktif' as const
  };
  const questionMatching3D = {
    ...questionWrongLevel,
    id: 'q-ulya',
    code: 'MQ-ULY-01',
    levelId: 'lvl-ulya',
    levelName: 'Ulya',
    branchAndLevel: 'Tilawah Dewasa Putra - Ulya'
  };
  const checkWrongLevel = validateMaqraAssignmentForParticipant(samplePartUlya, questionWrongLevel, 'Penyisihan', []);
  const checkMatching3D = validateMaqraAssignmentForParticipant(samplePartUlya, questionMatching3D, 'Penyisihan', []);
  const checkDuplicate3D = validateMaqraAssignmentForParticipant(samplePartUlya, questionMatching3D, 'Penyisihan', ['q-ulya']);
  assert(
    '35f. P0-03 Validasi 3D Maqra: Menolak soal berbeda jenjang (Wustha vs Ulya) atau duplikat, dan menerima soal yang cocok Cabang + Jenjang + Babak',
    checkWrongLevel.valid === false &&
      Boolean(checkWrongLevel.reason?.includes('jenjang')) &&
      checkMatching3D.valid === true &&
      checkDuplicate3D.valid === false,
    `wrongLevelValid: ${checkWrongLevel.valid} (${checkWrongLevel.reason}), matchingValid: ${checkMatching3D.valid}, dupValid: ${checkDuplicate3D.valid}`
  );

  // 35g. P0-04 Eliminasi Fallback Longgar Identitas Penilaian (Tanpa Pencocokan Lintas Soal / Lintas Babak)
  const mismatchedQuestionAssessment: JudgeAssessment[] = [
    {
      id: 'a-wrong-q',
      tenantId: 't-1',
      stageParticipationId: 'sp-1',
      stageId: 'stg-1',
      stageName: 'Penyisihan',
      participantId: 'p-1',
      judgeId: 'j-1',
      judgeName: 'Hakim 1',
      judgeField: 'Tajwid',
      questionId: 'q-other-999', // Berbeda dari soal peserta ('q-1')
      status: 'finalized',
      errorCounts: {},
      deductions: {},
      totalDeductions: 2,
      finalScore: 98,
      fieldScores: { Tajwid: 28 },
      annotations: [],
      lastUpdated: '10:00 WIB'
    }
  ];
  const strictSingleMaqraAgg = aggregateParticipantScores(
    'p-1',
    'Penyisihan',
    [{ questionId: 'q-1', title: 'Maqra 1', pageNumber: 305 }],
    ['j-1'],
    mismatchedQuestionAssessment,
    'stg-1',
    'sp-1'
  );
  assert(
    '35g. P0-04 Identitas Penilaian Ketat: Penilaian dengan questionId berbeda tidak dicocokkan secara paksa meskipun peserta hanya memiliki 1 maqra',
    strictSingleMaqraAgg.isFullyFinalized === false && strictSingleMaqraAgg.finalizedCount === 0,
    `isFullyFinalized: ${strictSingleMaqraAgg.isFullyFinalized}, finalizedCount: ${strictSingleMaqraAgg.finalizedCount}`
  );

  // 35h. P1-04 Penegakan Batas Kuota Saat Override Manual (qualifiedCount > quota)
  const quotaOverflowEval = RankingService.evaluateStageParticipants({
    tenantId: 't-tb',
    stageId: 'stg-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieBreakParts,
    participants: [tieBreakPartA, tieBreakPartB],
    assessments: tieBreakAssessments,
    judgeAssignments: [{ id: 'ja-tb', tenantId: 't-tb', judgeId: 'j-tb', judgeName: 'Hakim TB', stageId: 'stg-1', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }],
    quota: 1, // Kuota hanya 1 peserta, tetapi kedua peserta diloloskan (p-tb-b lolos otomatis, p-tb-a diloloskan lewat override)
    manualOverrides: { 'p-tb-a': true },
    overrideReasons: { 'p-tb-a': 'Keputusan khusus meloloskan peserta tambahan' }
  });
  assert(
    '35h. P1-04 Penegakan Kuota Override: Meloloskan peserta melebihi kuota babak (2 lolos dari kuota 1) memblokir pengesahan babak',
    quotaOverflowEval.canFinalize === false &&
      Boolean(quotaOverflowEval.blockingReason?.includes('melebihi kuota')),
    `canFinalize: ${quotaOverflowEval.canFinalize}, reason: ${quotaOverflowEval.blockingReason}`
  );

  // 35i. T1.1 Validasi Indeks 114 Surah & 604 Halaman Mushaf Madinah + Penolakan Import Excel Surah/Halaman Tidak Cocok
  const pageCheckFatihah = pageOfAyah(1, 1);
  const pageCheckBaqarah = pageOfAyah(2, 1);
  const pageCheckMaryam = pageOfAyah(19, 1);
  const pageCheckNas = pageOfAyah(114, 6);
  const invalidAyahBaqarah = validateMaqraRange({ surahNumber: 2, startAyah: 1, endAyah: 300 });
  const invalidSurah115 = validateMaqraRange({ surahNumber: 115, startAyah: 1, endAyah: 5 });

  const mismatchedSurahPageImport = validateQuestionImportRows(
    [
      {
        'Kode Soal': 'MQ-MISMATCH-01',
        'Judul Maqra': 'Maqra Maryam Salah Halaman',
        'Nama Surah': 'Maryam',
        'Nomor Surah': 19,
        'Ayat Awal': 1,
        'Ayat Akhir': 15,
        'Halaman Awal': 2, // Salah! Maryam 1-15 ada di halaman 305-306, bukan halaman 2-3
        'Halaman Akhir': 3,
        'Cabang Lomba': 'Tilawah Dewasa Putra',
        'Jenjang Lomba': 'Dewasa',
        Babak: 'Penyisihan'
      }
    ],
    {
      cabangList: masterCabang,
      jenjangList: masterJenjang,
      stages: masterStages,
      existingQuestions: []
    }
  );

  assert(
    '35i. T1.1 Indeks 114 Surah & 604 Halaman Mushaf Madinah: Pemetaan akurat (1:1->1, 2:1->2, 19:1->305, 114:6->604), penolakan ayat 300 Al-Baqarah & surah 115, serta penolakan import Excel saat halaman tidak cocok dengan surah/ayat beserta nomor baris',
    pageCheckFatihah === 1 &&
      pageCheckBaqarah === 2 &&
      pageCheckMaryam === 305 &&
      pageCheckNas === 604 &&
      invalidAyahBaqarah.valid === false &&
      invalidSurah115.valid === false &&
      mismatchedSurahPageImport.validRows.length === 0 &&
      mismatchedSurahPageImport.errors.length === 1 &&
      mismatchedSurahPageImport.errors[0].rowNumber === 2,
    `pages: ${pageCheckFatihah},${pageCheckBaqarah},${pageCheckMaryam},${pageCheckNas}; baqarah300Valid: ${invalidAyahBaqarah.valid}; surah115Valid: ${invalidSurah115.valid}; mismatchValidCount: ${mismatchedSurahPageImport.validRows.length}`
  );

  // 35j. T1.2 Satu Definisi "Lengkap" (getStageCompletion) & Structured blockingReasonDetail Tanpa Pernah Menampilkan "0 peserta belum lengkap" Saat Terkunci
  const noJudgeCompletion = getStageCompletion({
    tenantId: 't-tb',
    stageId: 'stg-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieBreakParts,
    participants: [tieBreakPartA, tieBreakPartB],
    assessments: tieBreakAssessments,
    judgeAssignments: [],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }]
  });
  assert(
    '35j. T1.2 Konsistensi getStageCompletion & Structured blockingReason: Saat belum ada penugasan hakim (judgeAssignments kosong), completedParticipantsCount wajib 0 (bukan dianggap lengkap) dan kode blokir terstruktur NO_JUDGES dikembalikan',
    noJudgeCompletion.allComplete === false &&
      noJudgeCompletion.completedParticipantsCount === 0 &&
      noJudgeCompletion.incompleteParticipantsCount === 2 &&
      noJudgeCompletion.blockingReason?.code === 'NO_JUDGES' &&
      noAssignmentEval.incompleteCount === 2 &&
      (noAssignmentEval as unknown as { blockingReasonDetail?: { code: string } }).blockingReasonDetail?.code === 'NO_JUDGES',
    `completedCount: ${noJudgeCompletion.completedParticipantsCount}, incompleteEval: ${noAssignmentEval.incompleteCount}, code: ${(noAssignmentEval as unknown as { blockingReasonDetail?: { code: string } }).blockingReasonDetail?.code}`
  );

  // 35k. T2.2 Pengerasan Edge Function `admin-provision-user` (Rate-limit 20/jam -> 429, Anti-enumerasi, CORS allowlist, Validasi Input, Pinned SDK)
  const overLenNameCheck = validateProvisionUserPayload({
    tenantId: '11111111-1111-4111-8111-111111111101',
    name: 'A'.repeat(125),
    username: 'hakim_valid',
    email: 'hakim@lptq.id',
    role: 'judge'
  });
  const badUsernameCheck = validateProvisionUserPayload({
    tenantId: '11111111-1111-4111-8111-111111111101',
    name: 'KH. Hakim Valid',
    username: 'invalid user!@#',
    email: 'hakim@lptq.id',
    role: 'judge'
  });
  const overLenJudgeFieldCheck = validateProvisionUserPayload({
    tenantId: '11111111-1111-4111-8111-111111111101',
    name: 'KH. Hakim Valid',
    username: 'hakim_valid',
    email: 'hakim@lptq.id',
    role: 'judge',
    judgeField: 'F'.repeat(121)
  });
  const validPayloadCheck = validateProvisionUserPayload({
    tenantId: '11111111-1111-4111-8111-111111111101',
    name: 'KH. Hakim Valid',
    username: 'hakim.valid_01-jbr',
    email: 'hakim@lptq.id',
    role: 'judge',
    judgeCategory: 'Dewan Hakim',
    judgeField: 'Bidang Tajwid'
  });

  const rateLimitOk = evaluateProvisionRateLimit(19, 15, 20);
  const rateLimitCallerExceeded = evaluateProvisionRateLimit(20, 5, 20);
  const rateLimitTenantExceeded = evaluateProvisionRateLimit(3, 20, 20);

  const corsAllowedCheck = resolveCorsHeaders('https://mtq.lptq.id', 'https://mtq.lptq.id,https://admin.lptq.id');
  const corsBlockedCheck = resolveCorsHeaders('https://evil.example.com', 'https://mtq.lptq.id');

  const pubResp = buildPublicProvisionSuccessResponse({
    profileId: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb1',
    email: 'hakim@lptq.id',
    role: 'judge',
    status: 'Aktif'
  });

  const edgeFnSource = fs.readFileSync(
    path.resolve(process.cwd(), 'supabase/functions/admin-provision-user/index.ts'),
    'utf-8'
  );
  const hasPinnedSupabaseJs =
    /from\s+['"]https:\/\/esm\.sh\/@supabase\/supabase-js@\d+\.\d+\.\d+['"]/.test(edgeFnSource) &&
    !edgeFnSource.includes('@supabase/supabase-js@^') &&
    !edgeFnSource.includes('@2.45.0');
  const hasUnifiedMessageInEdge = edgeFnSource.includes('Undangan atau penautan akun telah diproses.');
  const hasRateLimit429InEdge = edgeFnSource.includes('429') && edgeFnSource.includes('USER_MEMBERSHIP_UPSERTED');
  const hasAllowedOriginsInEdge = edgeFnSource.includes('ALLOWED_ORIGINS');

  assert(
    '35k. T2.2 Keamanan Edge Function `admin-provision-user`: Rate-limit 20/jam (HTTP 429), anti-enumerasi tanpa bocor provisioningState, CORS allowlist ALLOWED_ORIGINS, batas input ketat, dan pin SDK',
    overLenNameCheck.valid === false &&
      badUsernameCheck.valid === false &&
      overLenJudgeFieldCheck.valid === false &&
      validPayloadCheck.valid === true &&
      rateLimitOk.allowed === true &&
      rateLimitCallerExceeded.allowed === false &&
      rateLimitCallerExceeded.status === 429 &&
      rateLimitTenantExceeded.allowed === false &&
      rateLimitTenantExceeded.status === 429 &&
      corsAllowedCheck.allowed === true &&
      corsAllowedCheck.headers['Access-Control-Allow-Origin'] === 'https://mtq.lptq.id' &&
      corsBlockedCheck.allowed === false &&
      pubResp.message === 'Undangan atau penautan akun telah diproses.' &&
      !('provisioningState' in pubResp) &&
      hasPinnedSupabaseJs &&
      hasUnifiedMessageInEdge &&
      hasRateLimit429InEdge &&
      hasAllowedOriginsInEdge,
    `overLenName: ${overLenNameCheck.valid}, badUser: ${badUsernameCheck.valid}, rl429: ${rateLimitCallerExceeded.status}, pubMsg: ${pubResp.message}, hasPinned: ${hasPinnedSupabaseJs}`
  );

  // 35l. T2.3 Pengamanan Parser Excel (Bebas `xlsx` rentan, batas 5 MB, batas 5.000 baris, blokir sel formula, & sanitasi `__proto__`)
  const pkgJsonRaw = JSON.parse(fs.readFileSync(path.resolve(process.cwd(), 'package.json'), 'utf-8'));
  const hasVulnerableXlsx = Boolean(pkgJsonRaw.dependencies?.xlsx || pkgJsonRaw.devDependencies?.xlsx);
  const hasSafeExcelJs = Boolean(pkgJsonRaw.dependencies?.exceljs);

  let over5MbRejected = false;
  let over5000RowsRejected = false;
  let formulaCellRejected = false;
  let protoHeaderSanitized = false;

  const excelGuards = excelHelperModule as unknown as {
    assertWorkbookBufferSize?: (buffer: ArrayBuffer | Uint8Array) => void;
    validateAndSanitizeRawSheetMatrix?: (matrix: unknown[][]) => Record<string, unknown>[];
  };

  if (typeof excelGuards.assertWorkbookBufferSize === 'function') {
    try {
      const bigBuffer = new Uint8Array(5 * 1024 * 1024 + 16);
      excelGuards.assertWorkbookBufferSize(bigBuffer);
    } catch {
      over5MbRejected = true;
    }
  }

  if (typeof excelGuards.validateAndSanitizeRawSheetMatrix === 'function') {
    try {
      const hugeMatrix: unknown[][] = [['ID_Peserta', 'Nama_Lengkap']];
      for (let i = 0; i < 5005; i++) {
        hugeMatrix.push([`TLW-${i}`, `Peserta ${i}`]);
      }
      excelGuards.validateAndSanitizeRawSheetMatrix(hugeMatrix);
    } catch {
      over5000RowsRejected = true;
    }

    try {
      excelGuards.validateAndSanitizeRawSheetMatrix([
        ['ID_Peserta', 'Nama_Lengkap'],
        ['TLW-01', { formula: 'SUM(1,2)', result: 3 }]
      ]);
    } catch {
      formulaCellRejected = true;
    }

    const sanitizedRows = excelGuards.validateAndSanitizeRawSheetMatrix([
      ['__proto__', 'constructor', 'prototype', 'ID_Peserta', 'Nama_Lengkap'],
      ['evil_proto', 'evil_ctor', 'evil_prototype', 'TLW-99', 'Peserta Aman']
    ]);
    protoHeaderSanitized =
      sanitizedRows.length === 1 &&
      !Object.prototype.hasOwnProperty.call(sanitizedRows[0], '__proto__') &&
      !Object.prototype.hasOwnProperty.call(sanitizedRows[0], 'constructor') &&
      !Object.prototype.hasOwnProperty.call(sanitizedRows[0], 'prototype') &&
      sanitizedRows[0]['ID_Peserta'] === 'TLW-99' &&
      (Object.prototype as Record<string, unknown>)['evil_proto'] === undefined;
  }

  assert(
    '35l. T2.3 Keamanan Excel (`exceljs`): Bebas paket `xlsx`, menolak file > 5 MB, menolak > 5.000 baris, menolak sel formula, dan membuang header `__proto__`/`constructor`/`prototype`',
    !hasVulnerableXlsx &&
      hasSafeExcelJs &&
      over5MbRejected &&
      over5000RowsRejected &&
      formulaCellRejected &&
      protoHeaderSanitized,
    `hasXlsx: ${hasVulnerableXlsx}, hasExcelJs: ${hasSafeExcelJs}, over5Mb: ${over5MbRejected}, over5000: ${over5000RowsRejected}, formula: ${formulaCellRejected}, proto: ${protoHeaderSanitized}`
  );

  // 35m. Fase 1.6 & 1.7 Validasi Role sebelum Auth di `admin-provision-user` & Penonaktifan Pendaftaran Mandiri Publik
  const callerNonSuperTrySuper = validateProvisionRoleForCaller('superadmin', false);
  const callerSuperTrySuper = validateProvisionRoleForCaller('superadmin', true);
  const callerUnknownRole = validateProvisionRoleForCaller('root_owner', true);
  const callerJudgeOk = validateProvisionRoleForCaller('judge', false);

  const hasDeleteUserRollbackInEdge = edgeFnSource.includes('adminClient.auth.admin.deleteUser(resolvedAuthUserId)');
  const configTomlRaw = fs.existsSync(path.resolve(process.cwd(), 'supabase/config.toml'))
    ? fs.readFileSync(path.resolve(process.cwd(), 'supabase/config.toml'), 'utf-8')
    : '';
  const hasSignupDisabledInConfigToml = /enable_signup\s*=\s*false/.test(configTomlRaw);
  const appTsxRaw = fs.readFileSync(path.resolve(process.cwd(), 'src/App.tsx'), 'utf-8');
  const hasNoPublicSignupTab = !appTsxRaw.includes('Daftar Akun Baru') && !appTsxRaw.includes("setAuthViewMode('signup')");

  assert(
    '35m. Fase 1.6 & 1.7 Validasi Role `admin-provision-user` Sebelum Auth, Rollback `deleteUser`, & Penonaktifan Pendaftaran Mandiri Publik (`enable_signup = false`)',
    callerNonSuperTrySuper.allowed === false &&
      callerNonSuperTrySuper.status === 403 &&
      callerSuperTrySuper.allowed === true &&
      callerUnknownRole.allowed === false &&
      callerUnknownRole.status === 400 &&
      callerJudgeOk.allowed === true &&
      hasDeleteUserRollbackInEdge &&
      hasSignupDisabledInConfigToml &&
      hasNoPublicSignupTab,
    `nonSuper403: ${callerNonSuperTrySuper.status}, unknown400: ${callerUnknownRole.status}, hasDeleteUser: ${hasDeleteUserRollbackInEdge}, configTomlSignupOff: ${hasSignupDisabledInConfigToml}, noPublicSignupTab: ${hasNoPublicSignupTab}`
  );

  // 35n. Fase 2: Bobot Bidang Rubrik (weight), Tie-Break NULLS LAST & Alias Kode/Nama, Eksklusi Hakim Nonaktif, dan Snapshot Kejuaraan Final Tanpa Juara Harapan
  const weightedRubric: RubricVersion = {
    id: 'rubric-weighted-2026',
    tenantId: 'tenant-test',
    code: 'RUBRIC-WGT-2026',
    name: 'Rubrik Berbobot',
    branchCode: 'TLW',
    branchName: 'Tilawah',
    version: '1.0',
    description: 'Uji bobot bidang Tajwid weight=2',
    status: 'Aktif',
    startingScore: 100,
    fields: [
      { id: 'f-tjw-w', code: 'TJW', name: 'Tajwid', maxScore: 30, minScore: 0, weight: 2, order: 1, status: 'Aktif' },
      { id: 'f-fsh-w', code: 'FSH', name: 'Fashahah', maxScore: 40, minScore: 0, weight: 1, order: 2, status: 'Aktif' }
    ],
    createdAt: new Date().toISOString()
  };
  const weightedCatList: ErrorCategory[] = [
    {
      id: 'cat-w-tjw',
      tenantId: 'tenant-test',
      fieldId: 'f-tjw-w',
      code: 'WTJ',
      name: 'Salah Tajwid',
      scope: 'Tajwid',
      defaultDeduction: 2.0,
      methodType: 'Pengurangan tetap',
      status: 'Aktif',
      order: 1
    }
  ];
  // 1 error * 2.0 = 2.0 deduction on Tajwid -> Tajwid score = 28.0.
  // Total active weighted max = 30*2 + 40*1 = 100 === startingScore(100).
  // Total weighted score = 28*2 + 40*1 = 96.0.
  const weightedScoreRes = calculateAssessmentScore({ 'cat-w-tjw': 1 }, weightedCatList, weightedRubric);

  // Test NULLS LAST & Inactive Judge Exclusion
  const nullsLastEval = RankingService.evaluateStageParticipants({
    tenantId: 't-tb',
    stageId: 'stg-1',
    stageName: 'Penyisihan',
    branchName: 'Tilawah Dewasa Putra',
    participations: tieBreakParts,
    participants: [tieBreakPartA, tieBreakPartB],
    assessments: [
      {
        ...tieBreakAssessments[0],
        // Qari A has explicit 0 on Tajwid
        fieldScores: { Tajwid: 0, Lagu: 25, Fashahah: 25, Suara: 15 },
        finalScore: 85.0
      },
      {
        ...tieBreakAssessments[1],
        // Qari B is missing Tajwid (NULL)
        fieldScores: { Lagu: 25, Fashahah: 25, Suara: 15 },
        finalScore: 85.0
      }
    ],
    judgeAssignments: [
      { id: 'ja-tb-active', tenantId: 't-tb', judgeId: 'j-tb', judgeName: 'Hakim TB', stageId: 'stg-1', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid', status: 'Aktif' },
      { id: 'ja-tb-inactive', tenantId: 't-tb', judgeId: 'j-inactive', judgeName: 'Hakim Cuti', stageId: 'stg-1', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Lagu', status: 'Nonaktif' }
    ],
    stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 300 }],
    quota: 1
  });

  const finalChampSnap = RankingService.createStageResultSnapshot({
    tenantId: 't-tb',
    stageId: 'stg-final',
    stageName: 'Final',
    branchName: 'Tilawah Dewasa Putra',
    quota: 3,
    finalizedBy: 'Ketua Majelis',
    evaluatedParticipants: nullsLastEval.evaluatedParticipants,
    isFinalChampionship: true,
    championCount: 1
  });

  assert(
    '35n. Fase 2 Bobot Rubrik, NULLS LAST Tie-Break, Eksklusi Hakim Nonaktif, & Snapshot Juara Final: Bobot bidang dihitung presisi (96.00), skor bidang 0 mengalahkan NULL (NULLS LAST), hakim Nonaktif diabaikan dari kuota kelengkapan, dan snapshot Final menetapkan Juara 1 tanpa Juara Harapan',
    weightedScoreRes.finalScore === 96.0 &&
      nullsLastEval.canFinalize === true &&
      nullsLastEval.evaluatedParticipants[0].participant.id === 'p-tb-a' &&
      nullsLastEval.evaluatedParticipants[0].totalAssignedJudges === 1 &&
      finalChampSnap.rankings[0].championRank === 1 &&
      finalChampSnap.rankings[0].championTitle === 'Juara 1' &&
      finalChampSnap.rankings[0].isQualified === false &&
      finalChampSnap.rankings[1].championRank === undefined &&
      finalChampSnap.rankings[1].championTitle === undefined,
    `weightedFinal: ${weightedScoreRes.finalScore}, rank1: ${nullsLastEval.evaluatedParticipants[0]?.participant.id}, champ1: ${finalChampSnap.rankings[0]?.championTitle}, champ2: ${finalChampSnap.rankings[1]?.championTitle}`
  );


  // ===== Seri: aturan "menentukan" selaras dengan server & panel pleno =====
  // scores: daftar nilai akhir per peserta (urutan = urutan masukan). Peserta dengan nilai sama diberi
  // fieldScores identik sehingga seri tak terpecahkan oleh tie-break.
  const buildTieScenario = (scores: number[]) => {
    const parts: Participant[] = [];
    const sps: StageParticipation[] = [];
    const asses: JudgeAssessment[] = [];
    scores.forEach((score, i) => {
      const pid = `p-sx-${i + 1}`;
      const spid = `sp-sx-${i + 1}`;
      parts.push({ ...partTied1, id: pid, participantId: `SX-${i + 1}`, lotteryNumber: String(i + 1), name: `Peserta ${i + 1}` });
      sps.push({ ...tieParticipations[0], id: spid, participantId: pid, lotteryNumber: String(i + 1) });
      const base = score - 60;
      asses.push({
        ...tieAssessments[0],
        id: `a-sx-${i + 1}`,
        stageParticipationId: spid,
        participantId: pid,
        finalScore: score,
        totalDeductions: 100 - score,
        fieldScores: { Tajwid: 20 + base / 4, Lagu: 20 + base / 4, Fashahah: 10 + base / 4, Suara: 10 + base / 4 }
      });
    });
    return { parts, sps, asses };
  };
  const runTieScenario = (
    scores: number[],
    opts: { quota: number; isFinalStage?: boolean; championCount?: number; overrides?: Record<string, boolean>; reasons?: Record<string, string> }
  ) => {
    const { parts, sps, asses } = buildTieScenario(scores);
    return RankingService.evaluateStageParticipants({
      tenantId: 't-1',
      stageName: 'Penyisihan',
      branchName: 'Tilawah Dewasa Putra',
      participations: sps,
      participants: parts,
      assessments: asses,
      judgeAssignments: [{ id: 'ja1', tenantId: 't-1', judgeId: 'j-1', judgeName: 'H1', stageName: 'Penyisihan', branchName: 'Tilawah Dewasa Putra', judgeField: 'Tajwid' }],
      stageQuestionsGetter: () => [{ questionId: 'q-1', title: 'M1', pageNumber: 305 }],
      quota: opts.quota,
      isFinalStage: opts.isFinalStage,
      championCount: opts.championCount,
      manualOverrides: opts.overrides,
      overrideReasons: opts.reasons
    });
  };
  const blockCode = (r: ReturnType<typeof runTieScenario>) => r.blockingReasonDetail?.code;

  // 36a. Non-final, seri di peringkat 1, kuota 7, 8 peserta → tidak diblokir, keduanya lolos
  const s36a = runTieScenario([95, 95, 90, 88, 86, 84, 82, 80], { quota: 7, isFinalStage: false });
  assert(
    '36a. Seri di peringkat 1 pada babak non-final (kuota 7) tidak memblokir pengesahan dan keduanya lolos',
    s36a.canFinalize === true &&
      blockCode(s36a) !== 'UNRESOLVED_TIE' &&
      s36a.evaluatedParticipants[0].isQualified === true &&
      s36a.evaluatedParticipants[1].isQualified === true &&
      s36a.evaluatedParticipants[0].isDecisiveTie === false,
    `canFinalize: ${s36a.canFinalize}, code: ${blockCode(s36a)}, reason: ${s36a.blockingReason}`
  );

  // 36b. Non-final, seri di peringkat 7 & 8, kuota 7 → diblokir (batas kuota)
  const s36b = runTieScenario([95, 93, 91, 89, 87, 85, 80, 80], { quota: 7, isFinalStage: false });
  assert(
    '36b. Seri tak terpecahkan di batas kuota (peringkat 7 & 8) tetap memblokir pengesahan',
    s36b.canFinalize === false && blockCode(s36b) === 'UNRESOLVED_TIE' && s36b.evaluatedParticipants[6].isDecisiveTie === true,
    `canFinalize: ${s36b.canFinalize}, code: ${blockCode(s36b)}`
  );

  // 36c. Final, seri di peringkat 2, championCount 3 → diblokir
  const s36c = runTieScenario([95, 90, 90, 85, 80], { quota: 5, isFinalStage: true, championCount: 3 });
  assert(
    '36c. Seri di peringkat 2 pada babak final (3 juara) memblokir pengesahan',
    s36c.canFinalize === false && blockCode(s36c) === 'UNRESOLVED_TIE' && (s36c.blockingReason || '').includes('1–3'),
    `canFinalize: ${s36c.canFinalize}, code: ${blockCode(s36c)}, reason: ${s36c.blockingReason}`
  );

  // 36d. Final, seri di peringkat 4, championCount 3 → tidak diblokir
  const s36d = runTieScenario([95, 92, 90, 85, 85], { quota: 5, isFinalStage: true, championCount: 3 });
  assert(
    '36d. Seri di peringkat 4 pada babak final (3 juara) tidak memblokir pengesahan',
    s36d.canFinalize === true && s36d.evaluatedParticipants[3].isDecisiveTie === false,
    `canFinalize: ${s36d.canFinalize}, code: ${blockCode(s36d)}, reason: ${s36d.blockingReason}`
  );

  // 36e. Final, seri di peringkat 2 yang sudah di-override dengan alasan → tidak diblokir
  const s36e = runTieScenario([95, 90, 90, 85, 80], {
    quota: 5,
    isFinalStage: true,
    championCount: 3,
    overrides: { 'p-sx-2': true, 'p-sx-3': true },
    reasons: { 'p-sx-2': 'Keputusan sidang pleno: Juara 2', 'p-sx-3': 'Keputusan sidang pleno: Juara 3' }
  });
  assert(
    '36e. Seri di peringkat 2 pada babak final yang sudah di-override dengan alasan tidak memblokir',
    s36e.canFinalize === true,
    `canFinalize: ${s36e.canFinalize}, code: ${blockCode(s36e)}, reason: ${s36e.blockingReason}`
  );

  // 36f. Non-final, kuota 7, seri di peringkat 11 & 12 → tidak diblokir, keduanya tidak lolos, nilai sama
  const s36f = runTieScenario([99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 80, 80], { quota: 7, isFinalStage: false });
  const p11 = s36f.evaluatedParticipants[10];
  const p12 = s36f.evaluatedParticipants[11];
  assert(
    '36f. Seri di peringkat 11 & 12 (di luar kuota 7) tidak memblokir; keduanya tidak lolos dan berbagi peringkat',
    s36f.canFinalize === true &&
      p11.isQualified === false &&
      p12.isQualified === false &&
      p11.hasUnresolvedTie === true &&
      p12.hasUnresolvedTie === true &&
      p11.displayScore === p12.displayScore &&
      p11.isDecisiveTie === false &&
      (p11.tieBreakResolvedBy || '').startsWith('Seri — berbagi peringkat'),
    `canFinalize: ${s36f.canFinalize}, code: ${blockCode(s36f)}, q11: ${p11.isQualified}, q12: ${p12.isQualified}`
  );

  // 37a. Klasifikasi kegagalan sinkronisasi: penolakan server vs gangguan jaringan
  assert(
    '37a. classifySyncFailure membedakan penolakan server (rejected) dari gangguan jaringan sementara (network)',
    classifySyncFailure('new row violates row-level security policy for table "judge_assessments"') === 'rejected' &&
      classifySyncFailure('permission denied for table judge_assessments (42501)') === 'rejected' &&
      classifySyncFailure('Babak Penyisihan sudah disahkan dan terkunci.') === 'rejected' &&
      classifySyncFailure('insert or update violates foreign key constraint') === 'rejected' &&
      classifySyncFailure('Failed to fetch') === 'network' &&
      classifySyncFailure('NetworkError when attempting to fetch resource.') === 'network',
    'Klasifikasi kegagalan sinkronisasi tidak sesuai'
  );

  // 37b. Terjemahan pesan ramah pengguna & jeda bertahap percobaan ulang
  assert(
    '37b. friendlySyncError menerjemahkan galat teknis ke kalimat ramah pengguna dan retryDelayMs meningkat bertahap (20s -> 60s -> 300s)',
    friendlySyncError('new row violates row-level security policy').includes('Ditolak server: akun ini tidak berhak') &&
      friendlySyncError('Lembar sudah difinalisasi').includes('sudah dikunci/disahkan') &&
      friendlySyncError('Failed to fetch').includes('Koneksi ke server terputus') &&
      retryDelayMs(1) === 20_000 &&
      retryDelayMs(2) === 60_000 &&
      retryDelayMs(3) === 300_000 &&
      retryDelayMs(10) === 300_000,
    `delays: ${retryDelayMs(1)}, ${retryDelayMs(2)}, ${retryDelayMs(3)}`
  );

  // 37c. Pencegahan lembar penilaian hanya-baca & dukungan multi-rubrik pada PenilaianDualPanelView
  const dualPanelSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/penilaian/PenilaianDualPanelView.tsx'),
    'utf-8'
  );
  assert(
    '37c. PenilaianDualPanelView mengunci lembar (hanya-baca) bila hakim tidak ditugaskan atau babak sudah disahkan serta menggabungkan kategori dari seluruh penugasan rubrik hakim',
    dualPanelSrc.includes('const activeJudgeAssignments = useMemo') &&
      dualPanelSrc.includes('const judgeLockReason: string | null') &&
      dualPanelSrc.includes('const isEditLocked = isAdminMode || Boolean(judgeLockReason)') &&
      dualPanelSrc.includes('data-testid="judge-lock-reason"'),
    'Penjaga isEditLocked / judgeLockReason / activeJudgeAssignments belum lengkap pada PenilaianDualPanelView.tsx'
  );

  // ===== 38. CMS ringan: penggabungan konten landing, rute halaman publik, meta statis =====
  const mergedEmpty = mergeLandingContent({ hero: { title: '   ', backgroundImage: '' } });
  const mergedCustom = mergeLandingContent({
    hero: { title: 'Judul Baru', backgroundImage: 'https://contoh.id/hero.webp' },
    features: { cards: [{ title: 'Kartu A', image: '' }, { title: 'Kartu B', image: 'javascript:alert(1)' }] },
    nav: [{ label: 'Diretas', href: 'https://jahat.example' }]
  });
  assert(
    '38a. CMS: kolom kosong / URL tidak aman memakai bawaan; URL https dipakai; navigasi tidak bisa diubah',
    mergedEmpty.hero.title === defaultLandingContent.hero.title &&
      mergedEmpty.hero.backgroundImage === defaultLandingContent.hero.backgroundImage &&
      mergedCustom.hero.title === 'Judul Baru' &&
      mergedCustom.hero.backgroundImage === 'https://contoh.id/hero.webp' &&
      mergedCustom.features.cards.length === 2 &&
      mergedCustom.features.cards[0].image === defaultLandingContent.features.cards[0].image &&
      mergedCustom.features.cards[1].image === defaultLandingContent.features.cards[1].image &&
      mergedCustom.features.cards[1].body === defaultLandingContent.features.cards[1].body &&
      mergedCustom.nav[0].href === defaultLandingContent.nav[0].href &&
      mergeLandingContent('rusak' as unknown) === defaultLandingContent,
    JSON.stringify({ t: mergedCustom.hero.title, img: mergedCustom.features.cards[1].image })
  );
  assert(
    '38b. Rute halaman publik: /panduan, /panduan/…, /privasi, /ketentuan, /halaman/…; rute aplikasi tidak tertangkap',
    slugFromPath('/panduan') === 'panduan' &&
      slugFromPath('/panduan/hakim/') === 'panduan/hakim' &&
      slugFromPath('/privasi') === 'privasi' &&
      slugFromPath('/halaman/faq') === 'faq' &&
      slugFromPath('/') === null &&
      slugFromPath('/app') === null &&
      slugFromPath('/dashboard') === null &&
      pageHref('panduan/admin') === '/panduan/admin' &&
      pageHref('faq') === '/halaman/faq',
    `${slugFromPath('/panduan/hakim/')}`
  );
  const indexHtml = fs.readFileSync(path.resolve(process.cwd(), 'index.html'), 'utf8');
  const htmlEsc = (t: string) => t.replace(/&/g, '&amp;');
  assert(
    '38c. Meta pratinjau tautan statis di index.html sama dengan src/content/seo.ts (tampil di halaman SEO Superadmin)',
    indexHtml.includes(`property="og:title" content="${htmlEsc(LANDING_SEO.title)}"`) &&
      indexHtml.includes(`property="og:description" content="${htmlEsc(LANDING_SEO.description)}"`) &&
      indexHtml.includes(`property="og:image" content="https://${LANDING_SEO.domain}${LANDING_SEO.ogImagePath}"`) &&
      indexHtml.includes(`property="og:url" content="${LANDING_SEO.siteUrl}"`),
    'index.html dan src/content/seo.ts berbeda'
  );

  return { passed, failed, results };
}





