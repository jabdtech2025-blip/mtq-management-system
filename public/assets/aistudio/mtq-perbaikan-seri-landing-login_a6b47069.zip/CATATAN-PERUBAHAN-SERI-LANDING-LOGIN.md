# Catatan Perubahan: Perbaikan Seri, Landing Page, dan Halaman Masuk

Dasar: `origin/main` commit `46a6690`. Zip ini berisi seluruh proyek setelah perubahan, siap diunggah ke AI Studio.

## 1. Perbaikan nilai seri (Hasil & Kelulusan)

**Masalah:** di babak penyisihan, dua peserta seri di peringkat 1 (keduanya lolos) tetap mengunci tombol pengesahan dengan pesan "Podium Juara (1/2/3)". Panel Sidang Pleno tidak muncul karena seri itu memang tidak menentukan.

**Perbaikan:**
- `src/services/rankingService.ts`
  - Parameter baru `isFinalStage` dan `championCount` (bawaan 3).
  - Pemeriksaan "posisi juara" sekarang hanya berlaku di babak final dan memakai `championCount`.
  - Pemeriksaan "batas kuota" hanya berlaku di babak yang punya babak berikutnya.
  - Setiap peserta seri kini ditandai `isDecisiveTie` (menentukan / tidak menentukan).
- `src/components/stages/HasilKelulusanView.tsx`
  - Meneruskan `isFinalStage` dan `championCount`.
  - Label baris dibedakan:
    - seri yang menentukan: lencana merah "Nilai Seri Identik · Perlu keputusan sidang pleno";
    - seri yang tidak menentukan: teks abu-abu "Seri — berbagi peringkat, tidak memengaruhi kelulusan".
  - Kata "Seri" di kolom peringkat juga merah atau abu-abu sesuai jenisnya.
- `src/tests/domainRules.test.ts`: 6 tes baru (36a–36f).
- SQL, trigger, RLS, `advance_stage_qualifiers`, dan `compute_stage_rankings` **tidak diubah**.

## 2. Landing page (desain FINAL)

- `/` = landing page, `/app` = aplikasi. Rute aplikasi lain (`/dashboard`, `/platform/...`) tetap seperti biasa.
- Tautan email Supabase (reset sandi, undangan) yang mendarat di `/` tetap diproses aplikasi.
- Tautan email baru diarahkan ke `/app`.
- Berkas:
  - `src/landing/LandingPage.tsx`
  - `src/content/landing.ts`: seluruh teks ada di sini, ubah di file ini saja.
  - `src/components/brand/Logo.tsx`: logo "Mushaf Terbuka".
  - `src/main.tsx`
- Gambar di `public/landing/`:
  - `hero-podium.webp`: latar hero, tanpa makhluk hidup.
  - `app-log.webp`: visual bagian Integritas.
  - 5 tangkapan layar aplikasi berisi data contoh.
- Font IBM Plex Sans di-host sendiri (`@fontsource/ibm-plex-sans`). Font aplikasi hanya dimuat saat aplikasi dibuka.
- SEO:
  - `index.html` memakai domain `mtqsystem.web.id`, `og-image.jpg`, dan `favicon.svg`;
  - `robots.txt` dan `sitemap.xml` diperbarui;
  - halaman aplikasi diberi `noindex`.

## 3. Halaman masuk baru

- `src/components/auth/AuthenticationGateView.tsx` menggantikan komponen lama di `App.tsx`.
- Tata letak terbagi: gambar podium di kiri (desktop) dan kepala ringkas di ponsel.
- Status yang ditangani:
  - **Masuk**, dengan tombol tampil/sembunyikan sandi.
  - **Galat**: kotak merah, kolom berbingkai merah, dan pesan teknis diterjemahkan (mis. "Invalid login credentials" → "Email atau kata sandi salah").
  - **Lupa kata sandi** → **Periksa email Anda**: 3 langkah dan tombol kirim ulang dengan hitung mundur 45 detik.
  - **Atur kata sandi baru**, dari tautan email: indikator kekuatan 4 tingkat, daftar syarat, dan konfirmasi "Kata sandi cocok".
  - **Diagnosis akses** (sudah login tetapi belum punya profil atau keanggotaan): tombol Bootstrap Superadmin, Periksa Ulang, dan Keluar tetap ada.
  - **Mode Demo** tetap ada.
- Bila Supabase belum dikonfigurasi, form diganti pemberitahuan dan Mode Demo tetap bisa dipakai.
- Kotak centang "Ingat saya" dari desain **tidak dipasang**, karena sesi Supabase selalu tersimpan. Kotak yang tidak berfungsi lebih baik tidak ditampilkan.

## 4. Pembersihan

- `public/assets/aistudio/` dihapus. Folder ini berisi dokumen audit dan catatan internal yang bisa dibuka siapa pun di internet.
- `package-lock.json` diselaraskan (sebelumnya tidak sinkron sehingga `npm ci` gagal); `bun.lock` diperbarui.

## Hasil gerbang kualitas

| Pemeriksaan | Hasil |
|---|---|
| `npm run lint` | lulus |
| `npm test` | 120 lulus, 0 gagal (114 lama + 6 baru) |
| `npm run build` | berhasil |
| `npm run test:e2e` | 38 lulus, 8 dilewati, 8 gagal |

Catatan e2e: 8 tes yang gagal (4 tes × 2 perangkat: Superadmin SEO, Health Check, Isolasi Menu, Manajemen Akun Global) **juga gagal pada `origin/main` sebelum perubahan ini**, jadi bukan akibat perubahan di sini. Penyebabnya, tes dan tampilan Superadmin sudah tidak cocok (mis. `data-testid="seo-favicon-section"` tidak ada lagi). Perlu diperbaiki terpisah.

## Langkah manual setelah deploy

1. Supabase → Authentication → URL Configuration:
   - **Site URL**: `https://mtqsystem.web.id/app`
   - **Redirect URLs**: tambahkan `https://mtqsystem.web.id/**`
2. Edge Function `admin-provision-user` (Supabase → Edge Functions → Secrets): tambahkan `https://mtqsystem.web.id` ke `ALLOWED_ORIGINS`.
3. Arahkan domain `mtqsystem.web.id` ke hosting (Vercel/Netlify). `_redirects` / rewrite SPA sudah ada.
4. Superadmin → SEO dan Meta Situs: periksa Canonical URL (`https://mtqsystem.web.id`) bila data lama masih menyimpan `mtq.id`.
