-- ==============================================================================
-- MTQ MANAGEMENT SYSTEM — FINAL PRODUCTION DATABASE SCHEMA (SUPABASE / POSTGRESQL)
-- Versi: 2026.3 (Multi-Tenant, Least-Privilege RLS, Immutable Triggers & Atomic RPCs)
-- Standar Regulasi: LPTQ Nasional / Buku Pedoman MTQ 2025 & Juknis 2026
-- Target: Database Supabase Kosong (Idempotent & Siap Dijalankan di SQL Editor)
-- ==============================================================================

-- 1. EXTENSIONS (PostgreSQL 13+ menyediakan gen_random_uuid() secara bawaan; blok DO menjaga kompatibilitas di seluruh engine Postgres)
DO $$ BEGIN
    CREATE EXTENSION IF NOT EXISTS "pgcrypto";
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- 2. TENANTS & COMPETITIONS
CREATE TABLE IF NOT EXISTS tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    event_name VARCHAR(255) NOT NULL,
    region VARCHAR(100) NOT NULL,
    edition VARCHAR(100),
    period VARCHAR(50),
    status VARCHAR(20) NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Aktif', 'Nonaktif')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Pastikan tenant sistem global (00000000-0000-0000-0000-000000000000) tersedia untuk template rubrik nasional
INSERT INTO tenants (id, code, name, event_name, region, edition, period, status)
VALUES (
    '00000000-0000-0000-0000-000000000000'::uuid,
    'LPTQ-SYSTEM',
    'Standar Nasional LPTQ (Template Sistem)',
    'Pedoman Nasional MTQ 2025/2026',
    'Nasional',
    'Pedoman 2025',
    '2025 - 2026',
    'Aktif'
)
ON CONFLICT (id) DO NOTHING;

-- 3. PROFILES & TENANT MEMBERSHIPS (Supabase Auth Integration)
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    username VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    role VARCHAR(30) NOT NULL DEFAULT 'judge' CHECK (role IN ('superadmin', 'admin', 'judge')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tenant_memberships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    role VARCHAR(30) NOT NULL DEFAULT 'judge' CHECK (role IN ('admin', 'judge', 'superadmin')),
    judge_category VARCHAR(100),
    judge_field VARCHAR(100),
    status VARCHAR(20) NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Aktif', 'Nonaktif')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, profile_id)
);

-- Trigger Sinkronisasi Otomatis auth.users -> public.profiles
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_username TEXT;
    v_name TEXT;
BEGIN
    v_username := COALESCE(
        NULLIF(TRIM(NEW.raw_user_meta_data ->> 'username'), ''),
        SPLIT_PART(COALESCE(NEW.email, NEW.id::text), '@', 1) || '_' || SUBSTRING(NEW.id::text FROM 1 FOR 6)
    );
    v_name := COALESCE(
        NULLIF(TRIM(NEW.raw_user_meta_data ->> 'name'), ''),
        NULLIF(TRIM(NEW.raw_user_meta_data ->> 'full_name'), ''),
        SPLIT_PART(COALESCE(NEW.email, 'Pengguna MTQ'), '@', 1)
    );

    -- Keamanan: Pendaftaran mandiri selalu mendapat role 'judge' secara default.
    -- Kenaikan role ke 'admin' atau 'superadmin' hanya dilakukan oleh administrator melalui manajemen profil/membership.
    INSERT INTO public.profiles (id, username, name, email, role)
    VALUES (NEW.id, v_username, v_name, NEW.email, 'judge')
    ON CONFLICT (id) DO UPDATE
    SET email = EXCLUDED.email,
        updated_at = now();

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();

-- 4. MASTER DATA: CABANG, GOLONGAN, & JENJANG
CREATE TABLE IF NOT EXISTS branches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Aktif', 'Nonaktif')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

CREATE TABLE IF NOT EXISTS levels (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Aktif', 'Nonaktif')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

-- 5. KAFILAHS, STAGES & PARTICIPANTS
CREATE TABLE IF NOT EXISTS kafilahs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    region VARCHAR(150) NOT NULL,
    leader_name VARCHAR(150),
    contact_person VARCHAR(150),
    contact_phone VARCHAR(50),
    status VARCHAR(20) NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Aktif', 'Nonaktif')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

CREATE TABLE IF NOT EXISTS stages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES branches(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    stage_order INT NOT NULL DEFAULT 1,
    qualification_quota INT NOT NULL DEFAULT 3,
    qualification_method VARCHAR(30) NOT NULL DEFAULT 'top_n' CHECK (qualification_method IN ('top_n', 'manual')),
    status VARCHAR(30) NOT NULL DEFAULT 'Menunggu' CHECK (status IN ('Menunggu', 'Aktif', 'Berlangsung', 'Selesai')),
    is_finalized BOOLEAN NOT NULL DEFAULT false,
    finalized_at TIMESTAMPTZ,
    finalized_by UUID REFERENCES profiles(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, branch_id, name)
);

CREATE TABLE IF NOT EXISTS participants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    admin_sequence_number VARCHAR(50),
    participant_code VARCHAR(50) NOT NULL, -- e.g. "TLW-004"
    lottery_number VARCHAR(20) NOT NULL,   -- e.g. "04"
    name VARCHAR(255) NOT NULL,
    father_name VARCHAR(255),
    gender VARCHAR(10) NOT NULL CHECK (gender IN ('Putra', 'Putri')),
    origin_city VARCHAR(150),
    origin_region VARCHAR(150),
    origin_institution VARCHAR(255),
    kafilah_id UUID NOT NULL REFERENCES kafilahs(id) ON DELETE RESTRICT,
    branch_id UUID NOT NULL REFERENCES branches(id) ON DELETE RESTRICT,
    level_id UUID REFERENCES levels(id) ON DELETE SET NULL,
    stage_id UUID REFERENCES stages(id) ON DELETE SET NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Menunggu' CHECK (status IN ('Menunggu', 'Berlangsung', 'Lolos', 'Gugur', 'Final')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, participant_code),
    UNIQUE (tenant_id, branch_id, lottery_number)
);

-- 6. STAGE PARTICIPATIONS
CREATE TABLE IF NOT EXISTS stage_participations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    participant_id UUID NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
    stage_id UUID NOT NULL REFERENCES stages(id) ON DELETE RESTRICT,
    lottery_number VARCHAR(20) NOT NULL,
    status VARCHAR(40) NOT NULL DEFAULT 'Maqra Belum Ditetapkan' 
        CHECK (status IN ('Maqra Belum Ditetapkan', 'Belum Dimulai', 'Berlangsung', 'Menunggu Hakim Lain', 'Lengkap')),
    provisional_score NUMERIC(5,2),
    final_score NUMERIC(5,2),
    rank INT,
    is_qualified BOOLEAN NOT NULL DEFAULT false,
    qualification_reason TEXT,
    finalized_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, stage_id, participant_id)
);

-- 7. QUESTIONS / MAQRAS & ASSIGNMENTS
CREATE TABLE IF NOT EXISTS questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    code VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    surah_name VARCHAR(100) NOT NULL,
    surah_number INT NOT NULL CHECK (surah_number BETWEEN 1 AND 114),
    start_ayah INT NOT NULL CHECK (start_ayah >= 1),
    end_ayah INT NOT NULL CHECK (end_ayah >= start_ayah),
    page_number INT NOT NULL CHECK (page_number BETWEEN 1 AND 604),
    page_start INT NOT NULL CHECK (page_start BETWEEN 1 AND 604),
    page_end INT NOT NULL CHECK (page_end BETWEEN 1 AND 604 AND page_start <= page_end),
    branch_id UUID REFERENCES branches(id) ON DELETE CASCADE,
    level_id UUID REFERENCES levels(id) ON DELETE SET NULL,
    stage_id UUID REFERENCES stages(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Aktif', 'Nonaktif', 'Perlu Verifikasi')),
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

CREATE OR REPLACE FUNCTION public.get_surah_max_ayah(p_surah_number INT)
RETURNS INT
LANGUAGE plpgsql
IMMUTABLE
AS $$
DECLARE
    v_verse_counts INT[] := ARRAY[
        7, 286, 200, 176, 120, 165, 206, 75, 129, 109,
        123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
        112, 78, 118, 64, 77, 227, 93, 88, 69, 60,
        34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
        54, 53, 89, 59, 37, 35, 38, 29, 18, 45,
        60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
        14, 11, 11, 18, 12, 12, 30, 52, 52, 44,
        28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
        29, 19, 36, 25, 22, 17, 19, 26, 30, 20,
        15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
        11, 8, 3, 9, 5, 4, 7, 3, 6, 3,
        5, 4, 5, 6
    ];
BEGIN
    IF p_surah_number IS NULL OR p_surah_number < 1 OR p_surah_number > 114 THEN
        RETURN NULL;
    END IF;
    RETURN v_verse_counts[p_surah_number];
END;
$$;

CREATE OR REPLACE FUNCTION public.validate_question_maqra_bounds()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    v_max_ayah INT;
BEGIN
    IF NEW.surah_number IS NULL OR NEW.surah_number < 1 OR NEW.surah_number > 114 THEN
        RAISE EXCEPTION 'Nomor surah tidak valid: % (harus antara 1 s.d. 114).', NEW.surah_number;
    END IF;

    v_max_ayah := public.get_surah_max_ayah(NEW.surah_number);
    IF v_max_ayah IS NULL THEN
        RAISE EXCEPTION 'Nomor surah % tidak ditemukan dalam indeks 114 surah.', NEW.surah_number;
    END IF;

    IF NEW.start_ayah IS NULL OR NEW.start_ayah < 1 OR NEW.start_ayah > v_max_ayah THEN
        RAISE EXCEPTION 'Ayat mulai (%) berada di luar batas surah ke-% (1..%).', NEW.start_ayah, NEW.surah_number, v_max_ayah;
    END IF;

    IF NEW.end_ayah IS NULL OR NEW.end_ayah < NEW.start_ayah OR NEW.end_ayah > v_max_ayah THEN
        RAISE EXCEPTION 'Ayat selesai (%) tidak valid untuk surah ke-% (harus antara %..%).', NEW.end_ayah, NEW.surah_number, NEW.start_ayah, v_max_ayah;
    END IF;

    IF NEW.page_start IS NULL OR NEW.page_start < 1 OR NEW.page_start > 604 THEN
        RAISE EXCEPTION 'Halaman mulai (%) harus berada di antara 1..604.', NEW.page_start;
    END IF;

    IF NEW.page_end IS NULL OR NEW.page_end < NEW.page_start OR NEW.page_end > 604 THEN
        RAISE EXCEPTION 'Halaman selesai (%) harus berada di antara %..604.', NEW.page_end, NEW.page_start;
    END IF;

    IF NEW.page_number IS NULL OR NEW.page_number < 1 OR NEW.page_number > 604 THEN
        NEW.page_number := NEW.page_start;
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_validate_question_maqra ON public.questions;
CREATE TRIGGER trg_validate_question_maqra
    BEFORE INSERT OR UPDATE ON public.questions
    FOR EACH ROW EXECUTE FUNCTION public.validate_question_maqra_bounds();

CREATE TABLE IF NOT EXISTS assigned_maqras (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    stage_participation_id UUID NOT NULL REFERENCES stage_participations(id) ON DELETE CASCADE,
    question_id UUID NOT NULL REFERENCES questions(id) ON DELETE RESTRICT,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    assigned_by UUID REFERENCES profiles(id),
    method VARCHAR(30) NOT NULL DEFAULT 'undian' CHECK (method IN ('undian', 'manual', 'jadwal')),
    notes TEXT,
    UNIQUE (stage_participation_id, question_id)
);

CREATE TABLE IF NOT EXISTS lottery_draw_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    stage_id UUID REFERENCES stages(id) ON DELETE SET NULL,
    stage_name VARCHAR(100) NOT NULL,
    branch_id UUID REFERENCES branches(id) ON DELETE SET NULL,
    branch_name VARCHAR(150) NOT NULL,
    level_id UUID REFERENCES levels(id) ON DELETE SET NULL,
    level_name VARCHAR(150),
    actor_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    actor_name VARCHAR(255) NOT NULL,
    questions_per_participant INT NOT NULL DEFAULT 1 CHECK (questions_per_participant >= 1),
    participant_ids TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
    question_pool_ids TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
    draw_results JSONB NOT NULL DEFAULT '[]'::jsonb,
    draw_version INT NOT NULL DEFAULT 1,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 8. RUBRIC ARCHITECTURE & COMPETITION RULES
CREATE TABLE IF NOT EXISTS rubric_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    branch_id UUID REFERENCES branches(id) ON DELETE SET NULL,
    branch_code VARCHAR(30),
    branch_name VARCHAR(150),
    level_id UUID REFERENCES levels(id) ON DELETE SET NULL,
    version VARCHAR(20) NOT NULL,
    description TEXT,
    official_source TEXT,
    starting_score NUMERIC(5,2) NOT NULL DEFAULT 100.00,
    status VARCHAR(20) NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Draft', 'Validasi', 'Aktif', 'Arsip')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code, version)
);

CREATE TABLE IF NOT EXISTS rubric_fields (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rubric_version_id UUID NOT NULL REFERENCES rubric_versions(id) ON DELETE CASCADE,
    code VARCHAR(20) NOT NULL,
    name VARCHAR(100) NOT NULL,
    max_score NUMERIC(5,2) NOT NULL,
    min_score NUMERIC(5,2) NOT NULL DEFAULT 0.00,
    max_deduction NUMERIC(5,2),
    field_order INT NOT NULL DEFAULT 1,
    status VARCHAR(20) NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Aktif', 'Nonaktif', 'Arsip')),
    description TEXT,
    UNIQUE (rubric_version_id, code)
);

CREATE TABLE IF NOT EXISTS rubric_criteria (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rubric_field_id UUID NOT NULL REFERENCES rubric_fields(id) ON DELETE CASCADE,
    code VARCHAR(40),
    name VARCHAR(150) NOT NULL,
    description TEXT,
    max_deduction NUMERIC(5,2),
    sort_order INT NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS deduction_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    criterion_id UUID NOT NULL REFERENCES rubric_criteria(id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    error_grade VARCHAR(30) DEFAULT 'Jali' CHECK (error_grade IN ('Jali', 'Khafi', 'Umum', 'Kecil', 'Sedang', 'Besar')),
    deduction_points NUMERIC(5,2) NOT NULL DEFAULT 0.50,
    max_deduction NUMERIC(5,2),
    method_type VARCHAR(40) NOT NULL DEFAULT 'Pengurangan tetap' CHECK (method_type IN ('Pengurangan tetap', 'Pengurangan berbobot'))
);

CREATE TABLE IF NOT EXISTS error_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    rubric_field_id UUID REFERENCES rubric_fields(id) ON DELETE SET NULL,
    criterion_id UUID REFERENCES rubric_criteria(id) ON DELETE SET NULL,
    deduction_rule_id UUID REFERENCES deduction_rules(id) ON DELETE SET NULL,
    code VARCHAR(20) NOT NULL,
    name VARCHAR(150) NOT NULL,
    scope VARCHAR(150),
    default_deduction NUMERIC(4,2) NOT NULL DEFAULT 0.50,
    max_deduction NUMERIC(5,2),
    method_type VARCHAR(40) NOT NULL DEFAULT 'Pengurangan tetap',
    status VARCHAR(20) NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Aktif', 'Nonaktif')),
    sort_order INT NOT NULL DEFAULT 1,
    UNIQUE (tenant_id, code)
);

CREATE TABLE IF NOT EXISTS competition_rule_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES branches(id) ON DELETE CASCADE,
    branch_name VARCHAR(150),
    rubric_version_id UUID NOT NULL REFERENCES rubric_versions(id) ON DELETE RESTRICT,
    tie_break_order TEXT[] NOT NULL DEFAULT ARRAY['total', 'Tajwid', 'Lagu', 'Fashahah'],
    quota_per_stage JSONB NOT NULL DEFAULT '{"Penyisihan": 3, "Final": 3}'::jsonb,
    official_source TEXT,
    is_verified_official BOOLEAN NOT NULL DEFAULT false,
    status VARCHAR(20) NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Draft', 'Validasi', 'Aktif', 'Arsip')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, branch_id)
);

-- 9. JUDGE ASSIGNMENTS & ASSESSMENTS
CREATE TABLE IF NOT EXISTS judge_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    stage_id UUID NOT NULL REFERENCES stages(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES branches(id) ON DELETE CASCADE,
    level_id UUID REFERENCES levels(id) ON DELETE SET NULL,
    level_name VARCHAR(150),
    rubric_field_id UUID REFERENCES rubric_fields(id) ON DELETE CASCADE,
    judge_field VARCHAR(150),
    judge_profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL DEFAULT 'Aktif' CHECK (status IN ('Aktif', 'Nonaktif')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, stage_id, judge_profile_id, rubric_field_id)
);

CREATE TABLE IF NOT EXISTS judge_assessments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    stage_participation_id UUID NOT NULL REFERENCES stage_participations(id) ON DELETE CASCADE,
    assigned_maqra_id UUID NOT NULL REFERENCES assigned_maqras(id) ON DELETE RESTRICT,
    judge_profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
    rubric_version_id UUID NOT NULL REFERENCES rubric_versions(id) ON DELETE RESTRICT,
    status VARCHAR(30) NOT NULL DEFAULT 'in_progress' CHECK (status IN ('not_started', 'in_progress', 'finalized')),
    total_deductions NUMERIC(5,2) NOT NULL DEFAULT 0.00,
    final_score NUMERIC(5,2) NOT NULL DEFAULT 100.00 CHECK (final_score >= 0 AND final_score <= 100),
    field_scores JSONB DEFAULT '{}'::jsonb,
    error_counts JSONB DEFAULT '{}'::jsonb,
    annotations JSONB DEFAULT '[]'::jsonb,
    is_locked BOOLEAN NOT NULL DEFAULT false,
    reopened_at TIMESTAMPTZ,
    reopened_by UUID REFERENCES profiles(id),
    reopen_reason TEXT,
    finalized_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (stage_participation_id, assigned_maqra_id, judge_profile_id)
);

-- 10. STAGE RESULT SNAPSHOTS (Permanent Audited Final Results)
CREATE TABLE IF NOT EXISTS stage_result_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    stage_id UUID NOT NULL REFERENCES stages(id) ON DELETE RESTRICT,
    branch_id UUID NOT NULL REFERENCES branches(id) ON DELETE RESTRICT,
    quota INT NOT NULL,
    rubric_version_id UUID REFERENCES rubric_versions(id),
    tie_break_rule_used TEXT NOT NULL,
    finalized_by UUID NOT NULL REFERENCES profiles(id),
    rankings_snapshot JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 11. AUDIT LOGS (Append-Only Immutable Table)
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    actor_id UUID REFERENCES profiles(id),
    actor_name VARCHAR(255) NOT NULL,
    action VARCHAR(100) NOT NULL,
    target VARCHAR(255) NOT NULL,
    summary TEXT NOT NULL,
    reason TEXT,
    outcome VARCHAR(20) NOT NULL CHECK (outcome IN ('Success', 'Failed', 'Warning')),
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 12. INDEXES (Optimized for Querying and Joins)
CREATE INDEX IF NOT EXISTS idx_participants_tenant_branch ON participants (tenant_id, branch_id);
CREATE INDEX IF NOT EXISTS idx_stage_participations_lookup ON stage_participations (tenant_id, stage_id, status);
CREATE INDEX IF NOT EXISTS idx_judge_assessments_lookup ON judge_assessments (tenant_id, stage_participation_id, judge_profile_id);
CREATE INDEX IF NOT EXISTS idx_assigned_maqras_lookup ON assigned_maqras (stage_participation_id, question_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_tenant_time ON audit_logs (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_competition_rules_lookup ON competition_rule_configs (tenant_id, branch_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_stage_result_snapshots_unique_stage_branch ON stage_result_snapshots (tenant_id, stage_id, branch_id);

-- 13. DATA INTEGRITY & IMMUTABILITY TRIGGERS

-- 13A. Proteksi Imutabilitas Lembar Penilaian Final (Mencegah finalisasi/perubahan/penghapusan langsung di luar RPC resmi)
CREATE OR REPLACE FUNCTION public.enforce_judge_assessment_immutability()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        IF OLD.status = 'finalized' OR OLD.is_locked = true THEN
            RAISE EXCEPTION 'Pelanggaran Integritas: Lembar penilaian yang sudah berstatus final dan terkunci tidak dapat dihapus.';
        END IF;
        RETURN OLD;
    END IF;

    IF TG_OP = 'INSERT' THEN
        IF (NEW.status = 'finalized' OR NEW.is_locked = true) THEN
            IF COALESCE(current_setting('mtq.rpc_finalize_active', true), 'false') <> 'true' THEN
                RAISE EXCEPTION 'Pelanggaran Keamanan: Lembar penilaian tidak dapat langsung dibuat dalam status final/terkunci melalui Data API. Gunakan prosedur resmi finalize_judge_assessment.';
            END IF;
            NEW.is_locked := true;
            NEW.finalized_at := COALESCE(NEW.finalized_at, now());
        END IF;
        RETURN NEW;
    END IF;

    IF TG_OP = 'UPDATE' THEN
        -- Cegah perubahan identitas referensi utama
        IF NEW.tenant_id <> OLD.tenant_id
           OR NEW.stage_participation_id <> OLD.stage_participation_id
           OR NEW.assigned_maqra_id <> OLD.assigned_maqra_id
           OR NEW.judge_profile_id <> OLD.judge_profile_id THEN
            RAISE EXCEPTION 'Pelanggaran Integritas: Kolom identitas lembar penilaian (tenant, partisipasi babak, maqra, atau hakim) tidak dapat diubah.';
        END IF;

        -- Jika lembar nilai sudah final atau terkunci, tolak semua UPDATE langsung kecuali melalui RPC reopen_judge_assessment
        IF (OLD.status = 'finalized' OR OLD.is_locked = true) THEN
            IF COALESCE(current_setting('mtq.rpc_reopen_active', true), 'false') <> 'true' THEN
                RAISE EXCEPTION 'Pelanggaran Keamanan: Lembar penilaian yang sudah final bersifat terkunci (read-only). Pembukaan kembali hanya dapat dilakukan oleh Administrator melalui prosedur resmi reopen_judge_assessment dengan alasan audit.';
            END IF;
        END IF;

        -- Cegah transisi status ke finalized atau penguncian langsung di luar RPC finalize_judge_assessment
        IF (OLD.status <> 'finalized' AND NOT OLD.is_locked)
           AND (NEW.status = 'finalized' OR NEW.is_locked = true) THEN
            IF COALESCE(current_setting('mtq.rpc_finalize_active', true), 'false') <> 'true' THEN
                RAISE EXCEPTION 'Pelanggaran Keamanan: Finalisasi dan penguncian lembar penilaian hanya dapat dilakukan melalui fungsi RPC resmi finalize_judge_assessment.';
            END IF;
            NEW.is_locked := true;
            NEW.finalized_at := COALESCE(NEW.finalized_at, now());
        END IF;

        NEW.updated_at := now();
        RETURN NEW;
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_judge_assessment_immutability ON judge_assessments;
CREATE TRIGGER trg_enforce_judge_assessment_immutability
    BEFORE INSERT OR UPDATE OR DELETE ON judge_assessments
    FOR EACH ROW EXECUTE FUNCTION public.enforce_judge_assessment_immutability();

-- 13B. Proteksi Append-Only & Trusted Insert pada Audit Logs & Stage Result Snapshots
CREATE OR REPLACE FUNCTION public.enforce_append_only_records()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    RAISE EXCEPTION 'Pelanggaran Integritas: Tabel % bersifat append-only (rekaman historis permanen) dan tidak dapat diubah atau dihapus.', TG_TABLE_NAME;
END;
$$;

CREATE OR REPLACE FUNCTION public.enforce_trusted_audit_log_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF COALESCE(current_setting('mtq.rpc_audit_active', true), 'false') <> 'true' THEN
        RAISE EXCEPTION 'Pelanggaran Keamanan: Pencatatan audit_logs secara langsung melalui Data API ditolak. Catatan audit hanya dapat dibuat melalui fungsi RPC tepercaya.';
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_audit_logs_trusted_insert ON audit_logs;
CREATE TRIGGER trg_audit_logs_trusted_insert
    BEFORE INSERT ON audit_logs
    FOR EACH ROW EXECUTE FUNCTION public.enforce_trusted_audit_log_insert();

DROP TRIGGER IF EXISTS trg_audit_logs_append_only ON audit_logs;
CREATE TRIGGER trg_audit_logs_append_only
    BEFORE UPDATE OR DELETE ON audit_logs
    FOR EACH ROW EXECUTE FUNCTION public.enforce_append_only_records();

CREATE OR REPLACE FUNCTION public.enforce_trusted_stage_snapshot_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF COALESCE(current_setting('mtq.rpc_stage_finalize_active', true), 'false') <> 'true' THEN
        RAISE EXCEPTION 'Pelanggaran Keamanan: Pembuatan stage_result_snapshots secara langsung melalui Data API ditolak. Snapshot hasil resmi hanya dapat dibuat oleh transaksi advance_stage_qualifiers(...).';
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_stage_snapshots_trusted_insert ON stage_result_snapshots;
CREATE TRIGGER trg_stage_snapshots_trusted_insert
    BEFORE INSERT ON stage_result_snapshots
    FOR EACH ROW EXECUTE FUNCTION public.enforce_trusted_stage_snapshot_insert();

DROP TRIGGER IF EXISTS trg_stage_snapshots_append_only ON stage_result_snapshots;
CREATE TRIGGER trg_stage_snapshots_append_only
    BEFORE UPDATE OR DELETE ON stage_result_snapshots
    FOR EACH ROW EXECUTE FUNCTION public.enforce_append_only_records();

-- 13C. Proteksi Pengesahan Babak & Imutabilitas Babak Final (Blokir Bypass Data API pada tabel stages)
CREATE OR REPLACE FUNCTION public.enforce_stage_finalization_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_rpc_stage_finalize BOOLEAN := COALESCE(current_setting('mtq.rpc_stage_finalize_active', true), 'false') = 'true';
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF (NEW.is_finalized = true OR NEW.status = 'Selesai' OR NEW.finalized_at IS NOT NULL OR NEW.finalized_by IS NOT NULL)
           AND NOT v_rpc_stage_finalize THEN
            RAISE EXCEPTION 'Pelanggaran Keamanan: Babak baru tidak dapat langsung dibuat dalam status selesai atau terfinalisasi tanpa prosedur pengesahan resmi.';
        END IF;
        RETURN NEW;
    END IF;

    IF TG_OP = 'DELETE' THEN
        IF OLD.is_finalized = true THEN
            RAISE EXCEPTION 'Pelanggaran Imutabilitas: Babak musabaqah yang sudah disahkan bersifat permanen dan tidak dapat dihapus.';
        END IF;
        RETURN OLD;
    END IF;

    IF TG_OP = 'UPDATE' THEN
        IF OLD.is_finalized = true THEN
            RAISE EXCEPTION 'Pelanggaran Imutabilitas: Babak musabaqah yang sudah disahkan secara resmi terkunci dan tidak dapat dimodifikasi.';
        END IF;

        IF (
            NEW.is_finalized = true
            OR NEW.status = 'Selesai'
            OR NEW.finalized_at IS DISTINCT FROM OLD.finalized_at
            OR NEW.finalized_by IS DISTINCT FROM OLD.finalized_by
        ) AND NOT v_rpc_stage_finalize THEN
            RAISE EXCEPTION 'Pelanggaran Keamanan: Pengesahan babak secara langsung melalui Data API ditolak. Gunakan prosedur resmi advance_stage_qualifiers(...).';
        END IF;

        RETURN NEW;
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_stage_finalization_integrity ON stages;
CREATE TRIGGER trg_enforce_stage_finalization_integrity
    BEFORE INSERT OR UPDATE OR DELETE ON stages
    FOR EACH ROW EXECUTE FUNCTION public.enforce_stage_finalization_integrity();

-- 13D. Proteksi Imutabilitas Historis Rubrik yang Sudah Dipakai Penilaian Final
CREATE OR REPLACE FUNCTION public.enforce_rubric_field_immutability()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_rubric_id UUID;
    v_used_count INT;
BEGIN
    v_rubric_id := COALESCE(OLD.rubric_version_id, NEW.rubric_version_id);

    SELECT COUNT(*) INTO v_used_count
    FROM judge_assessments ja
    WHERE ja.rubric_version_id = v_rubric_id
      AND ja.status = 'finalized';

    IF v_used_count > 0 THEN
        RAISE EXCEPTION 'Pelanggaran Imutabilitas Historis: Struktur bidang rubrik ini telah digunakan pada % lembar penilaian final dan tidak dapat dimodifikasi. Buat versi rubrik baru.', v_used_count;
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_rubric_field_immutability ON rubric_fields;
CREATE TRIGGER trg_enforce_rubric_field_immutability
    BEFORE UPDATE OR DELETE ON rubric_fields
    FOR EACH ROW EXECUTE FUNCTION public.enforce_rubric_field_immutability();

-- 14. ROW LEVEL SECURITY (RLS) POLICIES (LEAST PRIVILEGE — ZERO DUPLICATES)
ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE tenant_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE levels ENABLE ROW LEVEL SECURITY;
ALTER TABLE stages ENABLE ROW LEVEL SECURITY;
ALTER TABLE kafilahs ENABLE ROW LEVEL SECURITY;
ALTER TABLE participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE stage_participations ENABLE ROW LEVEL SECURITY;
ALTER TABLE questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE assigned_maqras ENABLE ROW LEVEL SECURITY;
ALTER TABLE rubric_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE rubric_fields ENABLE ROW LEVEL SECURITY;
ALTER TABLE rubric_criteria ENABLE ROW LEVEL SECURITY;
ALTER TABLE deduction_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE error_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE competition_rule_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE judge_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE judge_assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE stage_result_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE lottery_draw_logs ENABLE ROW LEVEL SECURITY;

-- Security Helper: Check if authenticated user is a verified platform superadmin
CREATE OR REPLACE FUNCTION is_superadmin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    SELECT EXISTS (
        SELECT 1 FROM profiles p
        WHERE p.id = auth.uid() AND p.role = 'superadmin'
    );
$$;

-- Security Helper: Get current user's profile role without recursive RLS evaluation
CREATE OR REPLACE FUNCTION get_my_profile_role()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    SELECT p.role::text FROM profiles p WHERE p.id = auth.uid();
$$;

-- Trigger Proteksi Role pada Profiles (Cegah Eskalasi Hak Akses Mandiri)
CREATE OR REPLACE FUNCTION public.enforce_profile_role_protection()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF NEW.role IS DISTINCT FROM OLD.role THEN
        IF COALESCE(current_setting('mtq.rpc_role_admin_active', true), 'false') <> 'true'
           AND NOT is_superadmin()
           AND (auth.uid() IS NOT NULL OR COALESCE(current_setting('role', true), '') IN ('authenticated', 'anon')) THEN
            RAISE EXCEPTION 'Pelanggaran Keamanan: Eskalasi atau perubahan peran (role) secara langsung melalui Data API ditolak.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_profile_role_protection ON profiles;
CREATE TRIGGER trg_enforce_profile_role_protection
    BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION public.enforce_profile_role_protection();

-- Security Helper: Get tenant memberships for authenticated user
CREATE OR REPLACE FUNCTION get_user_tenants()
RETURNS TABLE (tenant_id UUID) 
LANGUAGE sql 
STABLE 
SECURITY DEFINER 
SET search_path = public, pg_temp
AS $$
    SELECT tm.tenant_id FROM tenant_memberships tm
    WHERE tm.profile_id = auth.uid() AND tm.status = 'Aktif'
    UNION
    SELECT t.id FROM tenants t
    WHERE is_superadmin() AND t.id <> '00000000-0000-0000-0000-000000000000'::uuid;
$$;

-- Security Helper: Check if user is tenant admin or superadmin
CREATE OR REPLACE FUNCTION is_tenant_admin(p_tenant_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    SELECT EXISTS (
        SELECT 1 FROM tenant_memberships tm
        WHERE tm.tenant_id = p_tenant_id 
          AND tm.profile_id = auth.uid()
          AND tm.role IN ('admin', 'superadmin')
          AND tm.status = 'Aktif'
    ) OR is_superadmin();
$$;

-- Security Helper: Verify official judge assignment for a specific stage participation (Caller-restricted)
CREATE OR REPLACE FUNCTION is_assigned_judge(
    p_tenant_id UUID,
    p_stage_participation_id UUID,
    p_judge_id UUID
)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    SELECT (
        auth.uid() IS NOT NULL
        AND (p_judge_id = auth.uid() OR is_tenant_admin(p_tenant_id))
        AND EXISTS (
            SELECT 1
            FROM stage_participations sp
            JOIN stages s ON s.id = sp.stage_id
            JOIN participants p ON p.id = sp.participant_id
            JOIN judge_assignments ja ON ja.stage_id = sp.stage_id
                 AND ja.tenant_id = sp.tenant_id
                 AND (ja.branch_id IS NULL OR ja.branch_id = p.branch_id OR ja.branch_id = s.branch_id)
            WHERE sp.id = p_stage_participation_id
              AND sp.tenant_id = p_tenant_id
              AND ja.judge_profile_id = p_judge_id
              AND ja.status = 'Aktif'
        )
    );
$$;

-- Bersihkan kebijakan lama dan buat kebijakan kanonik tunggal tanpa duplikasi
-- RLS: Tenants
DROP POLICY IF EXISTS "Users can view assigned tenants" ON tenants;
DROP POLICY IF EXISTS tenants_select_policy ON tenants;
CREATE POLICY tenants_select_policy ON tenants FOR SELECT
USING (id IN (SELECT get_user_tenants()) OR id = '00000000-0000-0000-0000-000000000000'::uuid);

DROP POLICY IF EXISTS tenants_insert_policy ON tenants;
CREATE POLICY tenants_insert_policy ON tenants FOR INSERT
WITH CHECK (is_superadmin());

DROP POLICY IF EXISTS "Superadmins and tenant admins can update tenant" ON tenants;
DROP POLICY IF EXISTS tenants_update_policy ON tenants;
CREATE POLICY tenants_update_policy ON tenants FOR UPDATE
USING (is_tenant_admin(id))
WITH CHECK (is_tenant_admin(id));

DROP POLICY IF EXISTS tenants_delete_policy ON tenants;
CREATE POLICY tenants_delete_policy ON tenants FOR DELETE
USING (is_superadmin() AND id <> '00000000-0000-0000-0000-000000000000'::uuid);

-- RLS: Profiles (Prevent self role-escalation without recursive subquery)
DROP POLICY IF EXISTS "Users can view profiles in same tenant" ON profiles;
DROP POLICY IF EXISTS profiles_select_policy ON profiles;
CREATE POLICY profiles_select_policy ON profiles FOR SELECT
USING (
    id = auth.uid()
    OR is_superadmin()
    OR id IN (
        SELECT tm.profile_id FROM tenant_memberships tm 
        WHERE tm.tenant_id IN (SELECT get_user_tenants())
    )
);

DROP POLICY IF EXISTS profiles_delete_policy ON profiles;
CREATE POLICY profiles_delete_policy ON profiles FOR DELETE
USING (
    id <> auth.uid()
    AND (
        is_superadmin()
        OR id IN (
            SELECT tm.profile_id FROM tenant_memberships tm
            WHERE is_tenant_admin(tm.tenant_id)
        )
    )
);

DROP POLICY IF EXISTS "Users can update own profile without escalating role" ON profiles;
DROP POLICY IF EXISTS profiles_update_policy ON profiles;
CREATE POLICY profiles_update_policy ON profiles FOR UPDATE
USING (id = auth.uid() OR is_superadmin())
WITH CHECK (
    (id = auth.uid() AND role = get_my_profile_role())
    OR is_superadmin()
);

-- RLS: Tenant Memberships
DROP POLICY IF EXISTS "Users can view memberships of their tenants" ON tenant_memberships;
DROP POLICY IF EXISTS tenant_memberships_select_policy ON tenant_memberships;
CREATE POLICY tenant_memberships_select_policy ON tenant_memberships FOR SELECT
USING (profile_id = auth.uid() OR tenant_id IN (SELECT get_user_tenants()));

DROP POLICY IF EXISTS "Tenant admins can manage tenant memberships" ON tenant_memberships;
DROP POLICY IF EXISTS tenant_memberships_admin_policy ON tenant_memberships;
CREATE POLICY tenant_memberships_admin_policy ON tenant_memberships FOR ALL
USING (is_tenant_admin(tenant_id))
WITH CHECK (is_tenant_admin(tenant_id));

-- RLS: Strict Tenant-Scoped Operational & Master Tables (NO system tenant leakage on operational tables)
DO $$
DECLARE
    t TEXT;
    strict_tenant_tables TEXT[] := ARRAY[
        'branches', 'levels', 'kafilahs', 'participants', 'questions',
        'assigned_maqras', 'lottery_draw_logs', 'error_categories', 'competition_rule_configs',
        'stage_participations', 'judge_assignments'
    ];
BEGIN
    FOREACH t IN ARRAY strict_tenant_tables
    LOOP
        -- Drop legacy human-readable policy names if present
        EXECUTE format('DROP POLICY IF EXISTS "Tenant members can view %s" ON %I', replace(t, '_', ' '), t);
        EXECUTE format('DROP POLICY IF EXISTS "Tenant admins can manage %s" ON %I', replace(t, '_', ' '), t);
        EXECUTE format('DROP POLICY IF EXISTS "Tenant members can view competition rules" ON %I', t);
        EXECUTE format('DROP POLICY IF EXISTS "Tenant admins can manage competition rules" ON %I', t);

        -- Drop and recreate canonical policies
        EXECUTE format('DROP POLICY IF EXISTS %I_select_policy ON %I', t, t);
        EXECUTE format('CREATE POLICY %I_select_policy ON %I FOR SELECT USING (tenant_id IN (SELECT get_user_tenants()))', t, t);

        EXECUTE format('DROP POLICY IF EXISTS %I_admin_policy ON %I', t, t);
        EXECUTE format('CREATE POLICY %I_admin_policy ON %I FOR ALL USING (is_tenant_admin(tenant_id)) WITH CHECK (is_tenant_admin(tenant_id))', t, t);
    END LOOP;
END;
$$;

-- RLS: Stages (Granular policies to block direct ratification bypass via Data API)
DROP POLICY IF EXISTS "Tenant members can view stages" ON stages;
DROP POLICY IF EXISTS "Tenant admins can manage stages" ON stages;
DROP POLICY IF EXISTS stages_admin_policy ON stages;
DROP POLICY IF EXISTS stages_select_policy ON stages;
DROP POLICY IF EXISTS stages_insert_policy ON stages;
DROP POLICY IF EXISTS stages_update_policy ON stages;
DROP POLICY IF EXISTS stages_delete_policy ON stages;

CREATE POLICY stages_select_policy ON stages FOR SELECT
USING (tenant_id IN (SELECT get_user_tenants()));

CREATE POLICY stages_insert_policy ON stages FOR INSERT
WITH CHECK (
    is_tenant_admin(tenant_id)
    AND is_finalized = false
    AND status <> 'Selesai'
);

CREATE POLICY stages_update_policy ON stages FOR UPDATE
USING (
    is_tenant_admin(tenant_id)
    AND is_finalized = false
)
WITH CHECK (
    is_tenant_admin(tenant_id)
    AND (
        (is_finalized = false AND status <> 'Selesai')
        OR COALESCE(current_setting('mtq.rpc_stage_finalize_active', true), 'false') = 'true'
    )
);

CREATE POLICY stages_delete_policy ON stages FOR DELETE
USING (
    is_tenant_admin(tenant_id)
    AND is_finalized = false
);

-- RLS: Rubric Hierarchy (Allows reading National System Templates 00000000-0000-0000-0000-000000000000)
DROP POLICY IF EXISTS "Tenant members can view rubric versions" ON rubric_versions;
DROP POLICY IF EXISTS "Tenant admins can manage rubric versions" ON rubric_versions;
DROP POLICY IF EXISTS rubric_versions_select_policy ON rubric_versions;
DROP POLICY IF EXISTS rubric_versions_admin_policy ON rubric_versions;

CREATE POLICY rubric_versions_select_policy ON rubric_versions FOR SELECT
USING (tenant_id IN (SELECT get_user_tenants()) OR tenant_id = '00000000-0000-0000-0000-000000000000'::uuid);

CREATE POLICY rubric_versions_admin_policy ON rubric_versions FOR ALL
USING (is_tenant_admin(tenant_id))
WITH CHECK (is_tenant_admin(tenant_id));

DROP POLICY IF EXISTS "Tenant members can view rubric fields" ON rubric_fields;
DROP POLICY IF EXISTS "Tenant admins can manage rubric fields" ON rubric_fields;
DROP POLICY IF EXISTS rubric_fields_select_policy ON rubric_fields;
DROP POLICY IF EXISTS rubric_fields_admin_policy ON rubric_fields;

CREATE POLICY rubric_fields_select_policy ON rubric_fields FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM rubric_versions rv
        WHERE rv.id = rubric_fields.rubric_version_id
          AND (rv.tenant_id IN (SELECT get_user_tenants()) OR rv.tenant_id = '00000000-0000-0000-0000-000000000000'::uuid)
    )
);

CREATE POLICY rubric_fields_admin_policy ON rubric_fields FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM rubric_versions rv
        WHERE rv.id = rubric_fields.rubric_version_id
          AND is_tenant_admin(rv.tenant_id)
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM rubric_versions rv
        WHERE rv.id = rubric_fields.rubric_version_id
          AND is_tenant_admin(rv.tenant_id)
    )
);

DROP POLICY IF EXISTS rubric_criteria_select_policy ON rubric_criteria;
DROP POLICY IF EXISTS rubric_criteria_admin_policy ON rubric_criteria;

CREATE POLICY rubric_criteria_select_policy ON rubric_criteria FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM rubric_fields rf
        JOIN rubric_versions rv ON rv.id = rf.rubric_version_id
        WHERE rf.id = rubric_criteria.rubric_field_id
          AND (rv.tenant_id IN (SELECT get_user_tenants()) OR rv.tenant_id = '00000000-0000-0000-0000-000000000000'::uuid)
    )
);

CREATE POLICY rubric_criteria_admin_policy ON rubric_criteria FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM rubric_fields rf
        JOIN rubric_versions rv ON rv.id = rf.rubric_version_id
        WHERE rf.id = rubric_criteria.rubric_field_id
          AND is_tenant_admin(rv.tenant_id)
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM rubric_fields rf
        JOIN rubric_versions rv ON rv.id = rf.rubric_version_id
        WHERE rf.id = rubric_criteria.rubric_field_id
          AND is_tenant_admin(rv.tenant_id)
    )
);

DROP POLICY IF EXISTS deduction_rules_select_policy ON deduction_rules;
DROP POLICY IF EXISTS deduction_rules_admin_policy ON deduction_rules;

CREATE POLICY deduction_rules_select_policy ON deduction_rules FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM rubric_criteria rc
        JOIN rubric_fields rf ON rf.id = rc.rubric_field_id
        JOIN rubric_versions rv ON rv.id = rf.rubric_version_id
        WHERE rc.id = deduction_rules.criterion_id
          AND (rv.tenant_id IN (SELECT get_user_tenants()) OR rv.tenant_id = '00000000-0000-0000-0000-000000000000'::uuid)
    )
);

CREATE POLICY deduction_rules_admin_policy ON deduction_rules FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM rubric_criteria rc
        JOIN rubric_fields rf ON rf.id = rc.rubric_field_id
        JOIN rubric_versions rv ON rv.id = rf.rubric_version_id
        WHERE rc.id = deduction_rules.criterion_id
          AND is_tenant_admin(rv.tenant_id)
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM rubric_criteria rc
        JOIN rubric_fields rf ON rf.id = rc.rubric_field_id
        JOIN rubric_versions rv ON rv.id = rf.rubric_version_id
        WHERE rc.id = deduction_rules.criterion_id
          AND is_tenant_admin(rv.tenant_id)
    )
);

-- RLS: Judge Assessments (Least Privilege: NO Admin FOR ALL bypass; Judges only edit own assigned unlocked sheets)
DROP POLICY IF EXISTS "Tenant members can view judge_assessments" ON judge_assessments;
DROP POLICY IF EXISTS "Admins and assigned judges can view assessments" ON judge_assessments;
DROP POLICY IF EXISTS "Admins and assigned judges can view judge_assessments" ON judge_assessments;
DROP POLICY IF EXISTS "Assigned judges can insert unlocked assessments" ON judge_assessments;
DROP POLICY IF EXISTS "Assigned judges can insert unlocked judge_assessments" ON judge_assessments;
DROP POLICY IF EXISTS "Assigned judges can update own unlocked assessments" ON judge_assessments;
DROP POLICY IF EXISTS "Judges can update assigned unlocked judge_assessments" ON judge_assessments;
DROP POLICY IF EXISTS "Admins can manage assessments" ON judge_assessments;
DROP POLICY IF EXISTS "Admins can manage judge_assessments" ON judge_assessments;
DROP POLICY IF EXISTS judge_assessments_select_policy ON judge_assessments;
DROP POLICY IF EXISTS judge_assessments_insert_policy ON judge_assessments;
DROP POLICY IF EXISTS judge_assessments_update_policy ON judge_assessments;

CREATE POLICY judge_assessments_select_policy ON judge_assessments FOR SELECT
USING (
    is_tenant_admin(tenant_id)
    OR (
        judge_profile_id = auth.uid()
        AND tenant_id IN (SELECT get_user_tenants())
        AND is_assigned_judge(tenant_id, stage_participation_id, auth.uid())
    )
);

CREATE POLICY judge_assessments_insert_policy ON judge_assessments FOR INSERT
WITH CHECK (
    judge_profile_id = auth.uid()
    AND is_locked = false
    AND status IN ('not_started', 'in_progress')
    AND tenant_id IN (SELECT get_user_tenants())
    AND is_assigned_judge(tenant_id, stage_participation_id, auth.uid())
);

CREATE POLICY judge_assessments_update_policy ON judge_assessments FOR UPDATE
USING (
    judge_profile_id = auth.uid() 
    AND is_locked = false 
    AND status <> 'finalized'
    AND tenant_id IN (SELECT get_user_tenants())
    AND is_assigned_judge(tenant_id, stage_participation_id, auth.uid())
)
WITH CHECK (
    judge_profile_id = auth.uid()
    AND is_locked = false
    AND status IN ('not_started', 'in_progress')
    AND tenant_id IN (SELECT get_user_tenants())
    AND is_assigned_judge(tenant_id, stage_participation_id, auth.uid())
);

-- RLS: Stage Result Snapshots & Audit Logs (Append-Only Immutable & Trusted RPC Insert Only)
DROP POLICY IF EXISTS "Tenant members can view snapshots" ON stage_result_snapshots;
DROP POLICY IF EXISTS "Tenant members can view stage_result_snapshots" ON stage_result_snapshots;
DROP POLICY IF EXISTS "Admins can insert stage result snapshots" ON stage_result_snapshots;
DROP POLICY IF EXISTS "Admins can insert stage_result_snapshots" ON stage_result_snapshots;
DROP POLICY IF EXISTS stage_result_snapshots_select_policy ON stage_result_snapshots;
DROP POLICY IF EXISTS stage_result_snapshots_insert_policy ON stage_result_snapshots;

CREATE POLICY stage_result_snapshots_select_policy ON stage_result_snapshots FOR SELECT
USING (tenant_id IN (SELECT get_user_tenants()));

CREATE POLICY stage_result_snapshots_insert_policy ON stage_result_snapshots FOR INSERT
WITH CHECK (
    COALESCE(current_setting('mtq.rpc_stage_finalize_active', true), 'false') = 'true'
    AND is_tenant_admin(tenant_id)
);

DROP POLICY IF EXISTS "Tenant members can view audit logs" ON audit_logs;
DROP POLICY IF EXISTS "Tenant members can view audit_logs" ON audit_logs;
DROP POLICY IF EXISTS "System and admins can append audit logs" ON audit_logs;
DROP POLICY IF EXISTS "System and admins can append audit_logs" ON audit_logs;
DROP POLICY IF EXISTS audit_logs_select_policy ON audit_logs;
DROP POLICY IF EXISTS audit_logs_insert_policy ON audit_logs;

CREATE POLICY audit_logs_select_policy ON audit_logs FOR SELECT
USING (tenant_id IN (SELECT get_user_tenants()));

CREATE POLICY audit_logs_insert_policy ON audit_logs FOR INSERT
WITH CHECK (
    COALESCE(current_setting('mtq.rpc_audit_active', true), 'false') = 'true'
    AND tenant_id IN (SELECT get_user_tenants())
    AND actor_id = auth.uid()
);

-- 15. STORED PROCEDURES / RPC FUNCTIONS (ATOMIC & HARDENED)

-- RPC 0: Mesin Perhitungan Nilai Resmi Server (Server-Authoritative Scoring Engine — P0-01)
CREATE OR REPLACE FUNCTION public.calculate_assessment_score_sql(
    p_tenant_id UUID,
    p_rubric_version_id UUID,
    p_error_counts JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_rubric RECORD;
    v_field RECORD;
    v_cat RECORD;
    v_cat_key TEXT;
    v_count_val TEXT;
    v_count NUMERIC;
    v_target_field_name TEXT;
    v_field_max_deduction NUMERIC;
    v_deduction NUMERIC;
    v_rule_deduction_points NUMERIC;
    v_rule_max_deduction NUMERIC;
    v_crit_id UUID;
    v_crit_max_deduction NUMERIC;
    v_unit_deduction NUMERIC;
    v_raw_deduction NUMERIC;
    v_crit_deductions JSONB := '{}'::jsonb;
    v_field_deductions JSONB := '{}'::jsonb;
    v_field_scores JSONB := '{}'::jsonb;
    v_deductions JSONB := '{}'::jsonb;
    v_total_deductions NUMERIC := 0.00;
    v_final_score NUMERIC := 0.00;
    v_cur_crit_ded NUMERIC;
    v_allowed_crit NUMERIC;
    v_field_score NUMERIC;
BEGIN
    SELECT * INTO v_rubric FROM rubric_versions WHERE id = p_rubric_version_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Rubrik penilaian tidak ditemukan di database.';
    END IF;

    -- Inisialisasi bidang aktif
    FOR v_field IN
        SELECT * FROM rubric_fields
        WHERE rubric_version_id = p_rubric_version_id
          AND status = 'Aktif'
        ORDER BY field_order ASC
    LOOP
        v_field_deductions := jsonb_set(v_field_deductions, ARRAY[v_field.name], '0'::jsonb);
        v_field_scores := jsonb_set(v_field_scores, ARRAY[v_field.name], to_jsonb(v_field.max_score));
    END LOOP;

    -- Iterasi setiap entri error_counts
    IF p_error_counts IS NOT NULL AND jsonb_typeof(p_error_counts) = 'object' THEN
        FOR v_cat_key, v_count_val IN
            SELECT key, value #>> '{}' FROM jsonb_each(p_error_counts)
        LOOP
            IF v_count_val IS NULL OR TRIM(v_count_val) = '' THEN
                CONTINUE;
            END IF;

            IF NOT (v_count_val ~ '^[0-9]+$') THEN
                RAISE EXCEPTION 'Jumlah kejadian kesalahan kategori % wajib berupa bilangan bulat non-negatif.', v_cat_key;
            END IF;

            v_count := v_count_val::numeric;
            IF v_count <= 0 THEN
                CONTINUE;
            END IF;

            -- Cari error_categories berdasarkan ID atau CODE pada tenant
            SELECT * INTO v_cat
            FROM error_categories
            WHERE tenant_id = p_tenant_id
              AND (id::text = v_cat_key OR code = v_cat_key)
              AND status = 'Aktif'
            LIMIT 1;

            IF NOT FOUND THEN
                RAISE EXCEPTION 'Kategori kesalahan % tidak ditemukan atau tidak berstatus aktif pada tenant ini.', v_cat_key;
            END IF;

            -- Resolusi bidang rubrik
            v_target_field_name := NULL;
            IF v_cat.rubric_field_id IS NOT NULL THEN
                SELECT name INTO v_target_field_name
                FROM rubric_fields
                WHERE id = v_cat.rubric_field_id
                  AND rubric_version_id = p_rubric_version_id
                  AND status = 'Aktif';
            END IF;

            IF v_target_field_name IS NULL AND v_cat.criterion_id IS NOT NULL THEN
                SELECT rf.name INTO v_target_field_name
                FROM rubric_criteria rc
                JOIN rubric_fields rf ON rf.id = rc.rubric_field_id
                WHERE rc.id = v_cat.criterion_id
                  AND rf.rubric_version_id = p_rubric_version_id
                  AND rf.status = 'Aktif';
            END IF;

            IF v_target_field_name IS NULL AND v_cat.deduction_rule_id IS NOT NULL THEN
                SELECT rf.name INTO v_target_field_name
                FROM deduction_rules dr
                JOIN rubric_criteria rc ON rc.id = dr.criterion_id
                JOIN rubric_fields rf ON rf.id = rc.rubric_field_id
                WHERE dr.id = v_cat.deduction_rule_id
                  AND rf.rubric_version_id = p_rubric_version_id
                  AND rf.status = 'Aktif';
            END IF;

            IF v_target_field_name IS NULL THEN
                SELECT name INTO v_target_field_name
                FROM rubric_fields
                WHERE rubric_version_id = p_rubric_version_id
                  AND status = 'Aktif'
                  AND (
                      LOWER(name) = LOWER(v_cat.name)
                      OR LOWER(code) = LOWER(v_cat.code)
                      OR (v_cat.scope IS NOT NULL AND LOWER(name) = LOWER(v_cat.scope))
                  )
                LIMIT 1;
            END IF;

            IF v_target_field_name IS NULL AND (v_rubric.code = 'RUBRIC-SENI-BACA-2025' OR v_rubric.name ILIKE '%Seni Baca%') THEN
                IF v_cat.name ILIKE '%tajwid%' OR v_cat.name ILIKE '%makharij%' OR v_cat.code IN ('tjw', 'mkh', 'idg') OR COALESCE(v_cat.scope, '') ILIKE '%tajwid%' THEN
                    v_target_field_name := 'Tajwid';
                ELSIF v_cat.name ILIKE '%fashahah%' OR v_cat.name ILIKE '%fasahah%' OR v_cat.name ILIKE '%waqf%' OR v_cat.code = 'fsh' OR COALESCE(v_cat.scope, '') ILIKE '%fashahah%' THEN
                    v_target_field_name := 'Fashahah';
                ELSIF v_cat.name ILIKE '%lagu%' OR v_cat.name ILIKE '%irama%' OR v_cat.code IN ('lag', 'lgu') OR COALESCE(v_cat.scope, '') ILIKE '%lagu%' THEN
                    v_target_field_name := 'Lagu';
                ELSIF v_cat.name ILIKE '%suara%' OR v_cat.name ILIKE '%vokal%' OR v_cat.code IN ('sua', 'sur') OR COALESCE(v_cat.scope, '') ILIKE '%suara%' THEN
                    v_target_field_name := 'Suara';
                END IF;
            END IF;

            IF v_target_field_name IS NULL THEN
                RAISE EXCEPTION 'Kategori kesalahan "%" belum terpetakan ke bidang rubrik aktif pada rubrik "%". Dilarang fallback ke bidang lain.', v_cat.name, v_rubric.name;
            END IF;

            -- Dapatkan besaran pengurangan per kejadian
            v_unit_deduction := v_cat.default_deduction;
            v_raw_deduction := ROUND(v_count * v_unit_deduction, 2);

            IF v_cat.deduction_rule_id IS NOT NULL THEN
                SELECT dr.deduction_points, dr.max_deduction
                INTO v_rule_deduction_points, v_rule_max_deduction
                FROM deduction_rules dr
                WHERE dr.id = v_cat.deduction_rule_id;

                IF FOUND THEN
                    IF v_rule_deduction_points IS NOT NULL THEN
                        v_unit_deduction := v_rule_deduction_points;
                        v_raw_deduction := ROUND(v_count * v_unit_deduction, 2);
                    END IF;
                    IF v_rule_max_deduction IS NOT NULL AND v_rule_max_deduction >= 0 THEN
                        v_raw_deduction := LEAST(v_raw_deduction, v_rule_max_deduction);
                    END IF;
                END IF;
            END IF;

            IF v_cat.max_deduction IS NOT NULL AND v_cat.max_deduction >= 0 THEN
                v_raw_deduction := LEAST(v_raw_deduction, v_cat.max_deduction);
            END IF;

            IF v_cat.criterion_id IS NOT NULL THEN
                SELECT rc.id, rc.max_deduction
                INTO v_crit_id, v_crit_max_deduction
                FROM rubric_criteria rc
                WHERE rc.id = v_cat.criterion_id;

                IF FOUND AND v_crit_max_deduction IS NOT NULL AND v_crit_max_deduction >= 0 THEN
                    v_cur_crit_ded := COALESCE((v_crit_deductions ->> v_crit_id::text)::numeric, 0.00);
                    v_allowed_crit := GREATEST(0.00, v_crit_max_deduction - v_cur_crit_ded);
                    v_raw_deduction := LEAST(v_raw_deduction, v_allowed_crit);
                    v_crit_deductions := jsonb_set(
                        v_crit_deductions,
                        ARRAY[v_crit_id::text],
                        to_jsonb(ROUND(v_cur_crit_ded + v_raw_deduction, 2))
                    );
                END IF;
            END IF;

            v_deductions := jsonb_set(v_deductions, ARRAY[v_cat_key], to_jsonb(v_raw_deduction));

            v_deduction := COALESCE((v_field_deductions ->> v_target_field_name)::numeric, 0.00) + v_raw_deduction;
            v_field_deductions := jsonb_set(v_field_deductions, ARRAY[v_target_field_name], to_jsonb(ROUND(v_deduction, 2)));
        END LOOP;
    END IF;

    -- Hitung nilai akhir per bidang dengan batasan min_score, max_score, dan max_deduction bidang
    v_total_deductions := 0.00;
    v_final_score := 0.00;

    FOR v_field IN
        SELECT * FROM rubric_fields
        WHERE rubric_version_id = p_rubric_version_id
          AND status = 'Aktif'
        ORDER BY field_order ASC
    LOOP
        v_deduction := COALESCE((v_field_deductions ->> v_field.name)::numeric, 0.00);
        v_field_max_deduction := COALESCE(v_field.max_deduction, (v_field.max_score - v_field.min_score));
        v_deduction := LEAST(v_deduction, v_field_max_deduction);
        v_deduction := ROUND(v_deduction, 2);

        v_field_score := GREATEST(v_field.min_score, LEAST(v_field.max_score, v_field.max_score - v_deduction));
        v_field_score := ROUND(v_field_score, 2);

        v_field_scores := jsonb_set(v_field_scores, ARRAY[v_field.name], to_jsonb(v_field_score));
        v_field_deductions := jsonb_set(v_field_deductions, ARRAY[v_field.name], to_jsonb(v_deduction));

        v_total_deductions := v_total_deductions + v_deduction;
        v_final_score := v_final_score + v_field_score;
    END LOOP;

    v_total_deductions := ROUND(v_total_deductions, 2);
    v_final_score := ROUND(v_final_score, 2);

    RETURN jsonb_build_object(
        'final_score', v_final_score,
        'total_deductions', v_total_deductions,
        'field_scores', v_field_scores,
        'field_deductions', v_field_deductions,
        'deductions', v_deductions
    );
END;
$$;

-- RPC 1: Finalisasi & Penguncian Lembar Penilaian oleh Hakim Bertugas (Finalize Judge Assessment — P0-01 Server Authoritative)
CREATE OR REPLACE FUNCTION finalize_judge_assessment(
    p_assessment_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_assessment RECORD;
    v_sp RECORD;
    v_stage RECORD;
    v_calc JSONB;
    v_required_units INT;
    v_finalized_units INT;
    v_now TIMESTAMPTZ := now();
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Permintaan tidak memiliki sesi autentikasi.';
    END IF;

    SELECT * INTO v_assessment FROM judge_assessments WHERE id = p_assessment_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Finalisasi ditolak: Lembar penilaian belum diinisialisasi di database.';
    END IF;

    IF v_assessment.judge_profile_id <> v_actor_id THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya hakim pemilik lembar penilaian yang berwenang mengunci nilai.';
    END IF;

    IF NOT is_assigned_judge(v_assessment.tenant_id, v_assessment.stage_participation_id, v_actor_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Anda tidak terdaftar pada penugasan majelis hakim resmi (judge_assignments) untuk babak dan cabang peserta ini.';
    END IF;

    IF v_assessment.status = 'finalized' OR v_assessment.is_locked THEN
        RAISE EXCEPTION 'Lembar penilaian ini sudah berstatus final dan terkunci.';
    END IF;

    SELECT * INTO v_sp FROM stage_participations WHERE id = v_assessment.stage_participation_id;
    SELECT * INTO v_stage FROM stages WHERE id = v_sp.stage_id;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'Finalisasi ditolak: Babak musabaqah ini telah ditutup/disahkan.';
    END IF;

    -- P0-01: Hitung ulang nilai resmi secara otoritatif dari error_counts mentah & rubrik database
    v_calc := calculate_assessment_score_sql(
        v_assessment.tenant_id,
        v_assessment.rubric_version_id,
        COALESCE(v_assessment.error_counts, '{}'::jsonb)
    );

    -- Aktifkan flag transaksi lokal agar trigger imutabilitas mengizinkan finalisasi & audit resmi
    PERFORM set_config('mtq.rpc_finalize_active', 'true', true);
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    -- Kunci lembar penilaian dan simpan hasil perhitungan server resmi
    UPDATE judge_assessments
    SET status = 'finalized',
        is_locked = true,
        final_score = (v_calc ->> 'final_score')::numeric,
        total_deductions = (v_calc ->> 'total_deductions')::numeric,
        field_scores = (v_calc -> 'field_scores'),
        finalized_at = v_now,
        updated_at = v_now
    WHERE id = p_assessment_id;

    -- Hitung total kombinasi wajib (assigned_maqras x assigned_judges) untuk peserta ini
    SELECT COUNT(*) INTO v_required_units
    FROM assigned_maqras am
    CROSS JOIN (
        SELECT DISTINCT ja.judge_profile_id
        FROM judge_assignments ja
        JOIN participants p ON p.id = v_sp.participant_id
        WHERE ja.tenant_id = v_sp.tenant_id
          AND ja.stage_id = v_sp.stage_id
          AND (ja.branch_id IS NULL OR ja.branch_id = p.branch_id OR ja.branch_id = v_stage.branch_id)
          AND ja.status = 'Aktif'
    ) req_judges
    WHERE am.stage_participation_id = v_sp.id;

    SELECT COUNT(*) INTO v_finalized_units
    FROM assigned_maqras am
    JOIN judge_assessments jass
         ON jass.stage_participation_id = am.stage_participation_id
        AND jass.assigned_maqra_id = am.id
        AND jass.status = 'finalized'
        AND jass.is_locked = true
    WHERE am.stage_participation_id = v_sp.id;

    -- Perbarui status progres stage_participations
    UPDATE stage_participations
    SET status = CASE
            WHEN v_required_units > 0 AND v_finalized_units >= v_required_units THEN 'Lengkap'
            WHEN v_finalized_units > 0 THEN 'Menunggu Hakim Lain'
            ELSE 'Berlangsung'
        END,
        finalized_at = CASE
            WHEN v_required_units > 0 AND v_finalized_units >= v_required_units THEN v_now
            ELSE finalized_at
        END,
        updated_at = v_now
    WHERE id = v_sp.id;

    SELECT * INTO v_actor FROM profiles WHERE id = v_actor_id;

    INSERT INTO audit_logs (tenant_id, actor_id, actor_name, action, target, summary, outcome)
    VALUES (
        v_assessment.tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Dewan Hakim') || ' (judge)',
        'ASSESSMENT_FINALIZED',
        'Assessment ID: ' || p_assessment_id::text,
        'Finalisasi dan penguncian lembar penilaian dengan nilai akhir ' || v_assessment.final_score::text,
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Lembar penilaian berhasil dikunci dan difinalisasi secara permanen.',
        'participant_stage_status', CASE
            WHEN v_required_units > 0 AND v_finalized_units >= v_required_units THEN 'Lengkap'
            ELSE 'Menunggu Hakim Lain'
        END
    );
END;
$$;

-- RPC 2: Buka Kembali Penilaian Final (Reopen Assessment — Admin Only)
CREATE OR REPLACE FUNCTION reopen_judge_assessment(
    p_assessment_id UUID,
    p_reason TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_assessment RECORD;
    v_sp RECORD;
    v_stage RECORD;
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Permintaan tidak memiliki sesi autentikasi.';
    END IF;

    IF p_reason IS NULL OR LENGTH(TRIM(p_reason)) < 5 THEN
        RAISE EXCEPTION 'Alasan pembukaan kembali lembar nilai wajib diisi minimal 5 karakter untuk rekaman audit trail.';
    END IF;

    SELECT * INTO v_assessment FROM judge_assessments WHERE id = p_assessment_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Lembar penilaian dengan ID tersebut tidak ditemukan.';
    END IF;

    IF v_assessment.status <> 'finalized' THEN
        RAISE EXCEPTION 'Lembar penilaian belum berstatus final.';
    END IF;

    IF NOT is_tenant_admin(v_assessment.tenant_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator atau Superadmin yang berwenang membuka kembali penilaian final.';
    END IF;

    SELECT * INTO v_sp FROM stage_participations WHERE id = v_assessment.stage_participation_id;
    SELECT * INTO v_stage FROM stages WHERE id = v_sp.stage_id;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'Pembukaan kembali ditolak: Babak musabaqah ini sudah disahkan secara resmi.';
    END IF;

    SELECT * INTO v_actor FROM profiles WHERE id = v_actor_id;

    -- Aktifkan flag transaksi lokal agar trigger imutabilitas mengizinkan pembukaan kunci & audit resmi
    PERFORM set_config('mtq.rpc_reopen_active', 'true', true);
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    -- Update status kembali ke in_progress dan lepaskan kunci
    UPDATE judge_assessments
    SET status = 'in_progress',
        is_locked = false,
        reopened_at = now(),
        reopened_by = v_actor_id,
        reopen_reason = TRIM(p_reason),
        updated_at = now()
    WHERE id = p_assessment_id;

    -- Kembalikan status partisipasi babak jika sebelumnya Lengkap
    UPDATE stage_participations
    SET status = 'Berlangsung',
        updated_at = now()
    WHERE id = v_assessment.stage_participation_id
      AND status = 'Lengkap';

    -- Catat immutable audit log
    INSERT INTO audit_logs (tenant_id, actor_id, actor_name, action, target, summary, reason, outcome)
    VALUES (
        v_assessment.tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
        'ASSESSMENT_REOPENED',
        'Assessment ID: ' || p_assessment_id::text,
        'Pembukaan kembali lembar penilaian final dengan skor sebelum koreksi: ' || v_assessment.final_score::text,
        TRIM(p_reason),
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Lembar penilaian berhasil dibuka kembali. Dewan hakim dapat mengoreksi nilai.'
    );
END;
$$;

-- RPC 3: Pengesahan Babak & Pelolosan Kualifikasi Atomik (Advance Stage Qualifiers — Server-Calculated Scores)
CREATE OR REPLACE FUNCTION advance_stage_qualifiers(
    p_stage_id UUID,
    p_next_stage_id UUID,
    p_qualified_participant_ids UUID[],
    p_override_reasons JSONB DEFAULT '{}'::jsonb,
    p_rankings_snapshot JSONB DEFAULT '[]'::jsonb
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_stage RECORD;
    v_next_stage stages%ROWTYPE;
    v_rule competition_rule_configs%ROWTYPE;
    v_pid UUID;
    v_override_key TEXT;
    v_override_val TEXT;
    v_participation_count INT;
    v_qualified_count INT;
    v_assigned_judges_count INT;
    v_unassigned_maqra_count INT;
    v_incomplete_count INT;
    v_invalid_participant_count INT;
    v_unjustified_override_count INT;
    v_tie_break_fields TEXT[];
    v_crit_1 TEXT;
    v_crit_2 TEXT;
    v_crit_3 TEXT;
    v_crit_4 TEXT;
    v_authoritative_snapshot JSONB;
    v_now TIMESTAMPTZ := now();
BEGIN
    -- 1. Validasi sesi autentikasi
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    -- 2. Validasi babak asal ada dan belum difinalisasi
    SELECT * INTO v_stage FROM stages WHERE id = p_stage_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan.';
    END IF;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'Babak ini sudah pernah difinalisasi sebelumnya.';
    END IF;

    -- 3. Validasi hak akses admin pada tenant terkait
    IF NOT is_tenant_admin(v_stage.tenant_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Anda tidak memiliki wewenang administrator pada tenant ini.';
    END IF;

    SELECT * INTO v_actor FROM profiles WHERE id = v_actor_id;

    -- 4. Pastikan terdapat peserta terdaftar pada babak ini
    SELECT COUNT(*) INTO v_participation_count
    FROM stage_participations sp
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id;

    IF v_participation_count = 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Tidak ada peserta terdaftar pada babak ini.';
    END IF;

    -- 5. Validasi kuota kelulusan
    v_qualified_count := COALESCE(array_length(p_qualified_participant_ids, 1), 0);
    IF v_stage.qualification_quota <= 0 THEN
        RAISE EXCEPTION 'Kuota kelulusan pada babak ini tidak valid.';
    END IF;
    IF v_qualified_count > v_stage.qualification_quota THEN
        RAISE EXCEPTION 'Jumlah peserta yang diloloskan (%) melebihi kuota babak (%).', v_qualified_count, v_stage.qualification_quota;
    END IF;

    -- 6. Validasi alasan override manual (jika diberikan, wajib minimal 5 karakter)
    IF p_override_reasons IS NOT NULL AND jsonb_typeof(p_override_reasons) = 'object' THEN
        FOR v_override_key, v_override_val IN
            SELECT key, value #>> '{}' FROM jsonb_each(p_override_reasons)
        LOOP
            IF v_override_val IS NULL OR LENGTH(TRIM(v_override_val)) < 5 THEN
                RAISE EXCEPTION 'Pengesahan babak ditolak: Alasan override manual untuk peserta % wajib diisi minimal 5 karakter.', v_override_key;
            END IF;
        END LOOP;
    END IF;

    -- 7. Validasi bahwa penugasan majelis hakim resmi tersedia untuk babak & cabang ini
    SELECT COUNT(DISTINCT ja.judge_profile_id) INTO v_assigned_judges_count
    FROM judge_assignments ja
    WHERE ja.tenant_id = v_stage.tenant_id
      AND ja.stage_id = p_stage_id
      AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
      AND ja.status = 'Aktif';

    IF v_assigned_judges_count = 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Belum ada penugasan majelis hakim resmi (judge_assignments) pada babak ini.';
    END IF;

    -- 8. Validasi seluruh peserta yang diloloskan berasal dari babak & cabang yang benar
    IF v_qualified_count > 0 THEN
        SELECT COUNT(*) INTO v_invalid_participant_count
        FROM unnest(p_qualified_participant_ids) AS q_pid
        LEFT JOIN stage_participations sp
               ON sp.participant_id = q_pid
              AND sp.stage_id = p_stage_id
              AND sp.tenant_id = v_stage.tenant_id
        LEFT JOIN participants p
               ON p.id = q_pid
              AND p.tenant_id = v_stage.tenant_id
        WHERE sp.id IS NULL
           OR (v_stage.branch_id IS NOT NULL AND p.branch_id <> v_stage.branch_id);

        IF v_invalid_participant_count > 0 THEN
            RAISE EXCEPTION 'Pengesahan babak ditolak: Terdapat peserta lolos yang tidak terdaftar pada babak atau cabang lomba ini.';
        END IF;
    END IF;

    -- 9. Validasi seluruh peserta pada babak ini telah memiliki minimal 1 penetapan maqra (assigned_maqras)
    SELECT COUNT(*) INTO v_unassigned_maqra_count
    FROM stage_participations sp
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id
      AND NOT EXISTS (
          SELECT 1 FROM assigned_maqras am
          WHERE am.stage_participation_id = sp.id
            AND am.tenant_id = v_stage.tenant_id
      );

    IF v_unassigned_maqra_count > 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Masih terdapat % peserta yang belum memiliki penetapan maqra pada babak ini.', v_unassigned_maqra_count;
    END IF;

    -- 10. Validasi seluruh kombinasi (peserta x assigned_maqras x hakim bertugas) telah berstatus finalized & terkunci
    SELECT COUNT(*) INTO v_incomplete_count
    FROM stage_participations sp
    JOIN assigned_maqras am
      ON am.stage_participation_id = sp.id
     AND am.tenant_id = sp.tenant_id
    CROSS JOIN (
        SELECT DISTINCT ja.judge_profile_id
        FROM judge_assignments ja
        WHERE ja.tenant_id = v_stage.tenant_id
          AND ja.stage_id = p_stage_id
          AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
          AND ja.status = 'Aktif'
    ) req_judges
    LEFT JOIN judge_assessments jass
           ON jass.stage_participation_id = sp.id
          AND jass.assigned_maqra_id = am.id
          AND jass.judge_profile_id = req_judges.judge_profile_id
          AND jass.status = 'finalized'
          AND jass.is_locked = true
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id
      AND jass.id IS NULL;

    IF v_incomplete_count > 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Masih terdapat % lembar penilaian (peserta x maqra x hakim) yang belum difinalisasi.', v_incomplete_count;
    END IF;

    -- 11. Validasi babak lanjutan jika ada (harus dalam tenant dan cabang yang sama)
    IF p_next_stage_id IS NOT NULL THEN
        SELECT * INTO v_next_stage FROM stages WHERE id = p_next_stage_id FOR UPDATE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Babak lanjutan tidak ditemukan.';
        END IF;
        IF v_next_stage.tenant_id <> v_stage.tenant_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian tenant: Babak lanjutan berada pada tenant berbeda.';
        END IF;
        IF v_stage.branch_id IS NOT NULL AND v_next_stage.branch_id IS NOT NULL AND v_next_stage.branch_id <> v_stage.branch_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian cabang: Babak lanjutan berada pada cabang lomba berbeda.';
        END IF;
    END IF;

    -- Aktifkan flag transaksi resmi untuk stages, stage_result_snapshots, dan audit_logs
    PERFORM set_config('mtq.rpc_stage_finalize_active', 'true', true);
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    -- Ambil konfigurasi urutan tie-break resmi cabang untuk perhitungan otoritatif di server (P1-06)
    SELECT * INTO v_rule
    FROM competition_rule_configs crc
    WHERE crc.tenant_id = v_stage.tenant_id
      AND (v_stage.branch_id IS NULL OR crc.branch_id = v_stage.branch_id)
    LIMIT 1;

    IF FOUND AND v_rule.tie_break_order IS NOT NULL THEN
        SELECT COALESCE(
            ARRAY(
                SELECT elem
                FROM unnest(v_rule.tie_break_order) AS elem
                WHERE LOWER(elem) <> 'total'
            ),
            ARRAY['Tajwid', 'Lagu', 'Fashahah', 'Suara']
        ) INTO v_tie_break_fields;
    ELSE
        v_tie_break_fields := ARRAY['Tajwid', 'Lagu', 'Fashahah', 'Suara'];
    END IF;

    v_crit_1 := v_tie_break_fields[1];
    v_crit_2 := v_tie_break_fields[2];
    v_crit_3 := v_tie_break_fields[3];
    v_crit_4 := v_tie_break_fields[4];

    -- 12A. Hitung nilai akhir resmi & tie-break per bidang (server-authoritative) langsung dari judge_assessments yang terfinalisasi di database
    WITH participant_scores AS (
        SELECT
            sp.id AS stage_participation_id,
            sp.participant_id,
            sp.lottery_number,
            ROUND(AVG(jass.final_score)::numeric, 2) AS computed_score,
            ROUND(AVG(
                CASE
                    WHEN v_crit_1 IS NOT NULL AND COALESCE(
                        jass.field_scores ->> v_crit_1,
                        CASE UPPER(v_crit_1)
                            WHEN 'TAJWID' THEN COALESCE(jass.field_scores ->> 'TJW', jass.field_scores ->> 'Tajwid')
                            WHEN 'FASHAHAH' THEN COALESCE(jass.field_scores ->> 'FSH', jass.field_scores ->> 'Fashahah')
                            WHEN 'LAGU' THEN COALESCE(jass.field_scores ->> 'LGU', jass.field_scores ->> 'LAG', jass.field_scores ->> 'Lagu')
                            WHEN 'SUARA' THEN COALESCE(jass.field_scores ->> 'SUR', jass.field_scores ->> 'SUA', jass.field_scores ->> 'Suara')
                            WHEN 'TAHFIZH' THEN COALESCE(jass.field_scores ->> 'THF', jass.field_scores ->> 'Tahfizh')
                            ELSE NULL
                        END
                    ) ~ '^-?[0-9]+(\.[0-9]+)?$'
                    THEN COALESCE(
                        jass.field_scores ->> v_crit_1,
                        CASE UPPER(v_crit_1)
                            WHEN 'TAJWID' THEN COALESCE(jass.field_scores ->> 'TJW', jass.field_scores ->> 'Tajwid')
                            WHEN 'FASHAHAH' THEN COALESCE(jass.field_scores ->> 'FSH', jass.field_scores ->> 'Fashahah')
                            WHEN 'LAGU' THEN COALESCE(jass.field_scores ->> 'LGU', jass.field_scores ->> 'LAG', jass.field_scores ->> 'Lagu')
                            WHEN 'SUARA' THEN COALESCE(jass.field_scores ->> 'SUR', jass.field_scores ->> 'SUA', jass.field_scores ->> 'Suara')
                            WHEN 'TAHFIZH' THEN COALESCE(jass.field_scores ->> 'THF', jass.field_scores ->> 'Tahfizh')
                            ELSE NULL
                        END
                    )::numeric
                    ELSE NULL
                END
            ), 2) AS crit_1_score,
            ROUND(AVG(
                CASE
                    WHEN v_crit_2 IS NOT NULL AND COALESCE(
                        jass.field_scores ->> v_crit_2,
                        CASE UPPER(v_crit_2)
                            WHEN 'TAJWID' THEN COALESCE(jass.field_scores ->> 'TJW', jass.field_scores ->> 'Tajwid')
                            WHEN 'FASHAHAH' THEN COALESCE(jass.field_scores ->> 'FSH', jass.field_scores ->> 'Fashahah')
                            WHEN 'LAGU' THEN COALESCE(jass.field_scores ->> 'LGU', jass.field_scores ->> 'LAG', jass.field_scores ->> 'Lagu')
                            WHEN 'SUARA' THEN COALESCE(jass.field_scores ->> 'SUR', jass.field_scores ->> 'SUA', jass.field_scores ->> 'Suara')
                            WHEN 'TAHFIZH' THEN COALESCE(jass.field_scores ->> 'THF', jass.field_scores ->> 'Tahfizh')
                            ELSE NULL
                        END
                    ) ~ '^-?[0-9]+(\.[0-9]+)?$'
                    THEN COALESCE(
                        jass.field_scores ->> v_crit_2,
                        CASE UPPER(v_crit_2)
                            WHEN 'TAJWID' THEN COALESCE(jass.field_scores ->> 'TJW', jass.field_scores ->> 'Tajwid')
                            WHEN 'FASHAHAH' THEN COALESCE(jass.field_scores ->> 'FSH', jass.field_scores ->> 'Fashahah')
                            WHEN 'LAGU' THEN COALESCE(jass.field_scores ->> 'LGU', jass.field_scores ->> 'LAG', jass.field_scores ->> 'Lagu')
                            WHEN 'SUARA' THEN COALESCE(jass.field_scores ->> 'SUR', jass.field_scores ->> 'SUA', jass.field_scores ->> 'Suara')
                            WHEN 'TAHFIZH' THEN COALESCE(jass.field_scores ->> 'THF', jass.field_scores ->> 'Tahfizh')
                            ELSE NULL
                        END
                    )::numeric
                    ELSE NULL
                END
            ), 2) AS crit_2_score,
            ROUND(AVG(
                CASE
                    WHEN v_crit_3 IS NOT NULL AND COALESCE(
                        jass.field_scores ->> v_crit_3,
                        CASE UPPER(v_crit_3)
                            WHEN 'TAJWID' THEN COALESCE(jass.field_scores ->> 'TJW', jass.field_scores ->> 'Tajwid')
                            WHEN 'FASHAHAH' THEN COALESCE(jass.field_scores ->> 'FSH', jass.field_scores ->> 'Fashahah')
                            WHEN 'LAGU' THEN COALESCE(jass.field_scores ->> 'LGU', jass.field_scores ->> 'LAG', jass.field_scores ->> 'Lagu')
                            WHEN 'SUARA' THEN COALESCE(jass.field_scores ->> 'SUR', jass.field_scores ->> 'SUA', jass.field_scores ->> 'Suara')
                            WHEN 'TAHFIZH' THEN COALESCE(jass.field_scores ->> 'THF', jass.field_scores ->> 'Tahfizh')
                            ELSE NULL
                        END
                    ) ~ '^-?[0-9]+(\.[0-9]+)?$'
                    THEN COALESCE(
                        jass.field_scores ->> v_crit_3,
                        CASE UPPER(v_crit_3)
                            WHEN 'TAJWID' THEN COALESCE(jass.field_scores ->> 'TJW', jass.field_scores ->> 'Tajwid')
                            WHEN 'FASHAHAH' THEN COALESCE(jass.field_scores ->> 'FSH', jass.field_scores ->> 'Fashahah')
                            WHEN 'LAGU' THEN COALESCE(jass.field_scores ->> 'LGU', jass.field_scores ->> 'LAG', jass.field_scores ->> 'Lagu')
                            WHEN 'SUARA' THEN COALESCE(jass.field_scores ->> 'SUR', jass.field_scores ->> 'SUA', jass.field_scores ->> 'Suara')
                            WHEN 'TAHFIZH' THEN COALESCE(jass.field_scores ->> 'THF', jass.field_scores ->> 'Tahfizh')
                            ELSE NULL
                        END
                    )::numeric
                    ELSE NULL
                END
            ), 2) AS crit_3_score,
            ROUND(AVG(
                CASE
                    WHEN v_crit_4 IS NOT NULL AND COALESCE(
                        jass.field_scores ->> v_crit_4,
                        CASE UPPER(v_crit_4)
                            WHEN 'TAJWID' THEN COALESCE(jass.field_scores ->> 'TJW', jass.field_scores ->> 'Tajwid')
                            WHEN 'FASHAHAH' THEN COALESCE(jass.field_scores ->> 'FSH', jass.field_scores ->> 'Fashahah')
                            WHEN 'LAGU' THEN COALESCE(jass.field_scores ->> 'LGU', jass.field_scores ->> 'LAG', jass.field_scores ->> 'Lagu')
                            WHEN 'SUARA' THEN COALESCE(jass.field_scores ->> 'SUR', jass.field_scores ->> 'SUA', jass.field_scores ->> 'Suara')
                            WHEN 'TAHFIZH' THEN COALESCE(jass.field_scores ->> 'THF', jass.field_scores ->> 'Tahfizh')
                            ELSE NULL
                        END
                    ) ~ '^-?[0-9]+(\.[0-9]+)?$'
                    THEN COALESCE(
                        jass.field_scores ->> v_crit_4,
                        CASE UPPER(v_crit_4)
                            WHEN 'TAJWID' THEN COALESCE(jass.field_scores ->> 'TJW', jass.field_scores ->> 'Tajwid')
                            WHEN 'FASHAHAH' THEN COALESCE(jass.field_scores ->> 'FSH', jass.field_scores ->> 'Fashahah')
                            WHEN 'LAGU' THEN COALESCE(jass.field_scores ->> 'LGU', jass.field_scores ->> 'LAG', jass.field_scores ->> 'Lagu')
                            WHEN 'SUARA' THEN COALESCE(jass.field_scores ->> 'SUR', jass.field_scores ->> 'SUA', jass.field_scores ->> 'Suara')
                            WHEN 'TAHFIZH' THEN COALESCE(jass.field_scores ->> 'THF', jass.field_scores ->> 'Tahfizh')
                            ELSE NULL
                        END
                    )::numeric
                    ELSE NULL
                END
            ), 2) AS crit_4_score,
            (
                SELECT (snap.elem ->> 'rank')::int
                FROM jsonb_array_elements(
                    CASE
                        WHEN p_rankings_snapshot IS NOT NULL AND jsonb_typeof(p_rankings_snapshot) = 'array'
                        THEN p_rankings_snapshot
                        ELSE '[]'::jsonb
                    END
                ) AS snap(elem)
                WHERE (snap.elem ->> 'participant_id') = sp.participant_id::text
                  AND (snap.elem ->> 'rank') ~ '^[0-9]+$'
                LIMIT 1
            ) AS client_tie_break_rank
        FROM stage_participations sp
        JOIN judge_assessments jass
          ON jass.stage_participation_id = sp.id
         AND jass.tenant_id = sp.tenant_id
         AND jass.status = 'finalized'
         AND jass.is_locked = true
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id
        GROUP BY sp.id, sp.participant_id, sp.lottery_number
    ),
    ranked_scores AS (
        SELECT
            ps.stage_participation_id,
            ps.participant_id,
            ps.computed_score,
            ROW_NUMBER() OVER (
                ORDER BY
                    ps.computed_score DESC,
                    COALESCE(ps.crit_1_score, -1) DESC,
                    COALESCE(ps.crit_2_score, -1) DESC,
                    COALESCE(ps.crit_3_score, -1) DESC,
                    COALESCE(ps.crit_4_score, -1) DESC,
                    COALESCE(ps.client_tie_break_rank, 999999) ASC,
                    ps.lottery_number ASC NULLS LAST,
                    ps.participant_id ASC
            )::int AS authoritative_rank
        FROM participant_scores ps
    )
    UPDATE stage_participations sp
    SET final_score = rs.computed_score,
        rank = rs.authoritative_rank
    FROM ranked_scores rs
    WHERE sp.id = rs.stage_participation_id;

    -- 12B. Validasi 2 arah untuk override manual (P1-06):
    -- 1. Peserta di luar kuota yang diloloskan (rank > quota & qualified)
    -- 2. Peserta di dalam kuota yang digugurkan secara manual (rank <= quota & NOT qualified)
    SELECT COUNT(*) INTO v_unjustified_override_count
    FROM stage_participations sp
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id
      AND (
          (sp.participant_id = ANY(p_qualified_participant_ids) AND sp.rank > v_stage.qualification_quota)
          OR
          (NOT (sp.participant_id = ANY(p_qualified_participant_ids)) AND sp.rank <= v_stage.qualification_quota)
      )
      AND LENGTH(TRIM(COALESCE(p_override_reasons ->> sp.participant_id::text, ''))) < 5;

    IF v_unjustified_override_count > 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Setiap perubahan kelulusan terhadap peringkat kuota (meloloskan di luar kuota atau menggugurkan di dalam kuota) wajib disertai alasan override minimal 5 karakter.';
    END IF;

    -- 12C. Perbarui status kelulusan pada stage_participations babak asal
    UPDATE stage_participations sp
    SET is_qualified = (sp.participant_id = ANY(p_qualified_participant_ids)),
        status = 'Lengkap',
        qualification_reason = COALESCE(
            NULLIF(TRIM(p_override_reasons ->> sp.participant_id::text), ''),
            CASE WHEN sp.participant_id = ANY(p_qualified_participant_ids) THEN 'Lolos Kuota Peringkat' ELSE 'Tidak Masuk Kuota' END
        ),
        finalized_at = v_now,
        updated_at = v_now
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id;

    -- 13. Perbarui status participants sesuai hasil babak
    UPDATE participants p
    SET status = CASE
        WHEN p.id = ANY(p_qualified_participant_ids) THEN
            CASE WHEN p_next_stage_id IS NOT NULL THEN 'Menunggu' ELSE 'Final' END
        ELSE 'Final'
    END,
    updated_at = v_now
    FROM stage_participations sp
    WHERE sp.participant_id = p.id
      AND sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id;

    -- 14. Finalisasi babak saat ini & aktifkan babak berikutnya jika ada
    UPDATE stages
    SET is_finalized = true,
        status = 'Selesai',
        finalized_at = v_now,
        finalized_by = v_actor_id
    WHERE id = p_stage_id;

    IF p_next_stage_id IS NOT NULL THEN
        UPDATE stages
        SET status = 'Aktif'
        WHERE id = p_next_stage_id
          AND status = 'Menunggu';
    END IF;

    -- 15. Daftarkan peserta lolos ke stage_participations babak berikutnya (tanpa maqra palsu)
    IF p_next_stage_id IS NOT NULL AND v_qualified_count > 0 THEN
        FOREACH v_pid IN ARRAY p_qualified_participant_ids
        LOOP
            INSERT INTO stage_participations (
                tenant_id,
                participant_id,
                stage_id,
                lottery_number,
                status
            )
            SELECT
                v_stage.tenant_id,
                v_pid,
                p_next_stage_id,
                p.lottery_number,
                'Maqra Belum Ditetapkan'
            FROM participants p
            WHERE p.id = v_pid
              AND p.tenant_id = v_stage.tenant_id
            ON CONFLICT (tenant_id, stage_id, participant_id) DO NOTHING;
        END LOOP;
    END IF;

    -- 16. Susun snapshot peringkat resmi dari data terverifikasi server & simpan ke stage_result_snapshots
    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'participant_id', sp.participant_id,
                'participant_name', p.name,
                'lottery_number', sp.lottery_number,
                'final_score', sp.final_score,
                'rank', sp.rank,
                'is_qualified', sp.is_qualified,
                'qualification_reason', sp.qualification_reason
            )
            ORDER BY sp.rank ASC
        ),
        '[]'::jsonb
    ) INTO v_authoritative_snapshot
    FROM stage_participations sp
    JOIN participants p ON p.id = sp.participant_id
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id;

    SELECT * INTO v_rule
    FROM competition_rule_configs crc
    WHERE crc.tenant_id = v_stage.tenant_id
      AND (v_stage.branch_id IS NULL OR crc.branch_id = v_stage.branch_id)
    LIMIT 1;

    IF v_stage.branch_id IS NOT NULL THEN
        INSERT INTO stage_result_snapshots (
            tenant_id,
            stage_id,
            branch_id,
            quota,
            rubric_version_id,
            tie_break_rule_used,
            finalized_by,
            rankings_snapshot
        )
        VALUES (
            v_stage.tenant_id,
            p_stage_id,
            v_stage.branch_id,
            v_stage.qualification_quota,
            CASE WHEN FOUND AND v_rule.rubric_version_id IS NOT NULL THEN v_rule.rubric_version_id ELSE (SELECT id FROM rubric_versions WHERE tenant_id = v_stage.tenant_id LIMIT 1) END,
            CASE WHEN FOUND AND v_rule.tie_break_order IS NOT NULL THEN array_to_string(v_rule.tie_break_order, ' > ') ELSE 'total > Tajwid > Lagu > Fashahah' END,
            v_actor_id,
            v_authoritative_snapshot
        );
    END IF;

    -- 17. Catat immutable audit log melalui flag RPC resmi
    INSERT INTO audit_logs (tenant_id, actor_id, actor_name, action, target, summary, reason, outcome)
    VALUES (
        v_stage.tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
        'STAGE_FINALIZED',
        'Babak: ' || v_stage.name,
        CASE
            WHEN p_next_stage_id IS NOT NULL THEN
                'Pengesahan resmi babak ' || v_stage.name || ' dengan ' || v_qualified_count::text || ' peserta lolos ke babak lanjutan.'
            ELSE
                'Pengesahan resmi hasil kejuaraan babak final ' || v_stage.name || ' dengan ' || v_qualified_count::text || ' juara ditetapkan.'
        END,
        p_override_reasons::text,
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'message', CASE
            WHEN p_next_stage_id IS NOT NULL THEN
                'Babak berhasil difinalisasi dan peserta lolos telah didaftarkan ke babak berikutnya.'
            ELSE
                'Hasil kejuaraan babak final berhasil disahkan dan dikunci secara permanen di database.'
        END,
        'rankings_snapshot', v_authoritative_snapshot
    );
END;
$$;

-- RPC 4: Pencatatan Audit Log Terotentikasi Khusus Admin (Trusted Admin Audit Log)
CREATE OR REPLACE FUNCTION append_admin_audit_log(
    p_tenant_id UUID,
    p_action TEXT,
    p_target TEXT,
    p_summary TEXT,
    p_reason TEXT DEFAULT NULL,
    p_outcome TEXT DEFAULT 'Success'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_clean_action TEXT;
    v_clean_outcome TEXT;
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Permintaan tidak memiliki sesi autentikasi.';
    END IF;

    IF NOT is_tenant_admin(p_tenant_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator atau Superadmin yang berwenang mencatat audit administrasi.';
    END IF;

    v_clean_action := UPPER(TRIM(COALESCE(p_action, '')));
    IF v_clean_action = '' THEN
        RAISE EXCEPTION 'Tindakan audit (action) wajib diisi.';
    END IF;

    IF v_clean_action IN (
        'ASSESSMENT_FINALIZED',
        'ASSESSMENT_REOPENED',
        'STAGE_FINALIZED',
        'CHAMPIONSHIP_FINALIZED',
        'INITIAL_SUPERADMIN_BOOTSTRAPPED'
    ) THEN
        RAISE EXCEPTION 'Pelanggaran Keamanan: Tindakan sistem % hanya dapat dicatat oleh prosedur transaksi utamanya.', v_clean_action;
    END IF;

    v_clean_outcome := CASE
        WHEN p_outcome IN ('Success', 'Failed', 'Warning') THEN p_outcome
        ELSE 'Success'
    END;

    SELECT * INTO v_actor FROM profiles WHERE id = v_actor_id;

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    INSERT INTO audit_logs (tenant_id, actor_id, actor_name, action, target, summary, reason, outcome)
    VALUES (
        p_tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
        v_clean_action,
        LEFT(TRIM(COALESCE(p_target, '-')), 255),
        TRIM(COALESCE(p_summary, '-')),
        p_reason,
        v_clean_outcome
    );

    RETURN jsonb_build_object('success', true);
END;
$$;

-- RPC 5: Manajemen & Pemetaan Profil / Keanggotaan Tenant Terotorisasi (Admin / Superadmin)
CREATE OR REPLACE FUNCTION upsert_tenant_member_profile(
    p_tenant_id UUID,
    p_profile_id UUID,
    p_username TEXT,
    p_name TEXT,
    p_email TEXT,
    p_role TEXT,
    p_judge_category TEXT DEFAULT NULL,
    p_judge_field TEXT DEFAULT NULL,
    p_status TEXT DEFAULT 'Aktif'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_target_id UUID;
    v_auth_email TEXT;
    v_clean_role TEXT;
    v_clean_status TEXT;
    v_clean_username TEXT;
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    IF p_tenant_id IS NULL OR NOT EXISTS (SELECT 1 FROM public.tenants WHERE id = p_tenant_id) THEN
        RAISE EXCEPTION 'Tenant tujuan tidak ditemukan atau tidak valid.';
    END IF;

    IF NOT is_tenant_admin(p_tenant_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator Tenant atau Superadmin yang dapat mengelola keanggotaan pengguna.';
    END IF;

    v_clean_role := LOWER(TRIM(COALESCE(p_role, 'judge')));
    IF v_clean_role NOT IN ('judge', 'admin', 'superadmin') THEN
        RAISE EXCEPTION 'Peran pengguna tidak valid: %', v_clean_role;
    END IF;

    IF v_clean_role = 'superadmin' AND NOT is_superadmin() THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Superadmin yang dapat menetapkan peran superadmin.';
    END IF;

    v_clean_status := CASE WHEN p_status = 'Nonaktif' THEN 'Nonaktif' ELSE 'Aktif' END;

    -- Prioritaskan pencarian di auth.users berdasarkan ID atau Email agar retry pasca-undangan selalu sinkron
    IF p_profile_id IS NOT NULL THEN
        SELECT u.id, u.email INTO v_target_id, v_auth_email
        FROM auth.users u
        WHERE u.id = p_profile_id
        LIMIT 1;
    END IF;

    IF v_target_id IS NULL AND NULLIF(TRIM(p_email), '') IS NOT NULL THEN
        SELECT u.id, u.email INTO v_target_id, v_auth_email
        FROM auth.users u
        WHERE LOWER(u.email) = LOWER(TRIM(p_email))
        LIMIT 1;
    END IF;

    -- Fallback ke tabel profiles jika sudah terpetakan sebelumnya
    IF v_target_id IS NULL THEN
        SELECT p.id, p.email INTO v_target_id, v_auth_email
        FROM public.profiles p
        WHERE (p_profile_id IS NOT NULL AND p.id = p_profile_id)
           OR (NULLIF(TRIM(p_email), '') IS NOT NULL AND LOWER(p.email) = LOWER(TRIM(p_email)))
           OR (NULLIF(TRIM(p_username), '') IS NOT NULL AND LOWER(p.username) = LOWER(TRIM(p_username)))
        LIMIT 1;
    END IF;

    IF v_target_id IS NULL THEN
        RAISE EXCEPTION 'AUTH_USER_NOT_FOUND: Pengguna (%) belum terdaftar di Supabase Auth (auth.users). Gunakan layanan undangan akun (Edge Function admin-provision-user) atau daftarkan email di Supabase Authentication terlebih dahulu.', COALESCE(NULLIF(TRIM(p_email), ''), NULLIF(TRIM(p_username), ''), 'tanpa-identitas');
    END IF;

    -- Cegah admin tenant biasa memodifikasi akun milik Superadmin
    IF EXISTS (SELECT 1 FROM public.profiles WHERE id = v_target_id AND role = 'superadmin') AND NOT is_superadmin() THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Administrator Tenant tidak memiliki wewenang untuk mengubah profil atau keanggotaan Superadmin.';
    END IF;

    v_clean_username := COALESCE(
        NULLIF(TRIM(p_username), ''),
        'user_' || SUBSTRING(v_target_id::text FROM 1 FOR 8)
    );

    IF EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE LOWER(p.username) = LOWER(v_clean_username)
          AND p.id <> v_target_id
    ) THEN
        v_clean_username := v_clean_username || '_' || SUBSTRING(v_target_id::text FROM 1 FOR 4);
    END IF;

    PERFORM set_config('mtq.rpc_role_admin_active', 'true', true);
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    INSERT INTO public.profiles (id, username, name, email, role, updated_at)
    VALUES (
        v_target_id,
        v_clean_username,
        COALESCE(NULLIF(TRIM(p_name), ''), 'Pengguna MTQ'),
        COALESCE(NULLIF(TRIM(p_email), ''), v_auth_email),
        CASE WHEN is_superadmin() AND v_clean_role = 'superadmin' THEN 'superadmin'
             WHEN v_clean_role = 'admin' THEN 'admin'
             ELSE 'judge'
        END,
        now()
    )
    ON CONFLICT (id) DO UPDATE
    SET username = COALESCE(NULLIF(TRIM(EXCLUDED.username), ''), public.profiles.username),
        name = COALESCE(NULLIF(TRIM(EXCLUDED.name), ''), public.profiles.name),
        email = COALESCE(NULLIF(TRIM(EXCLUDED.email), ''), public.profiles.email),
        role = CASE
            WHEN public.profiles.role = 'superadmin' AND NOT is_superadmin() THEN 'superadmin'
            WHEN is_superadmin() AND v_clean_role = 'superadmin' THEN 'superadmin'
            WHEN public.profiles.role = 'admin' AND v_clean_role = 'judge' AND p_tenant_id <> (
                SELECT tm.tenant_id FROM public.tenant_memberships tm
                WHERE tm.profile_id = v_target_id AND tm.role = 'admin' AND tm.status = 'Aktif' LIMIT 1
            ) THEN 'admin'
            ELSE EXCLUDED.role
        END,
        updated_at = now();

    INSERT INTO public.tenant_memberships (
        tenant_id,
        profile_id,
        role,
        judge_category,
        judge_field,
        status
    )
    VALUES (
        p_tenant_id,
        v_target_id,
        v_clean_role,
        NULLIF(TRIM(p_judge_category), ''),
        NULLIF(TRIM(p_judge_field), ''),
        v_clean_status
    )
    ON CONFLICT (tenant_id, profile_id) DO UPDATE
    SET role = EXCLUDED.role,
        judge_category = EXCLUDED.judge_category,
        judge_field = EXCLUDED.judge_field,
        status = EXCLUDED.status;

    SELECT * INTO v_actor FROM public.profiles WHERE id = v_actor_id;

    INSERT INTO public.audit_logs (tenant_id, actor_id, actor_name, action, target, summary, outcome)
    VALUES (
        p_tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
        'USER_MEMBERSHIP_UPSERTED',
        'Profile ID: ' || v_target_id::text,
        'Pemetaan profil & keanggotaan ' || COALESCE(p_name, '') || ' dengan peran ' || v_clean_role || ' (' || v_clean_status || ')',
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'profile_id', v_target_id,
        'email', COALESCE(NULLIF(TRIM(p_email), ''), v_auth_email),
        'role', v_clean_role,
        'status', v_clean_status
    );
END;
$$;

-- RPC 6: Mekanisme Bootstrap Superadmin Pertama (One-Time Guarded RPC / SQL Function)
CREATE OR REPLACE FUNCTION public.bootstrap_first_superadmin(
    p_target_email TEXT DEFAULT NULL,
    p_initial_tenant_id UUID DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_caller_uid UUID;
    v_caller_role TEXT;
    v_auth_user RECORD;
    v_target_tenant_id UUID;
    v_username TEXT;
    v_display_name TEXT;
    v_tenant_rec RECORD;
BEGIN
    v_caller_uid := auth.uid();
    v_caller_role := COALESCE(current_setting('role', true), '');

    IF v_caller_uid IS NULL AND v_caller_role IN ('anon', 'authenticated') THEN
        RAISE EXCEPTION 'Otorisasi Bootstrap Ditolak: Fungsi ini tidak dapat dipanggil oleh sesi anonim.';
    END IF;

    LOCK TABLE public.profiles IN SHARE ROW EXCLUSIVE MODE;

    IF EXISTS (SELECT 1 FROM public.profiles WHERE role = 'superadmin') THEN
        RAISE EXCEPTION 'Bootstrap Ditolak: Akun Superadmin pertama sudah terdaftar di sistem. Mekanisme bootstrap satu kali telah terkunci permanen.';
    END IF;

    IF NULLIF(TRIM(p_target_email), '') IS NOT NULL THEN
        SELECT u.id, u.email, u.raw_user_meta_data
        INTO v_auth_user
        FROM auth.users u
        WHERE LOWER(u.email) = LOWER(TRIM(p_target_email))
        LIMIT 1;
    ELSIF v_caller_uid IS NOT NULL THEN
        SELECT u.id, u.email, u.raw_user_meta_data
        INTO v_auth_user
        FROM auth.users u
        WHERE u.id = v_caller_uid
        LIMIT 1;
    ELSE
        RAISE EXCEPTION 'Parameter p_target_email wajib diisi saat menjalankan bootstrap_first_superadmin dari SQL Editor.';
    END IF;

    IF v_auth_user.id IS NULL THEN
        RAISE EXCEPTION 'Bootstrap Gagal: Akun email (%) belum ditemukan di auth.users. Buat pengguna terlebih dahulu melalui Supabase Authentication -> Users.', COALESCE(p_target_email, 'UID saat ini');
    END IF;

    IF v_caller_uid IS NOT NULL AND v_caller_uid <> v_auth_user.id THEN
        RAISE EXCEPTION 'Otorisasi Bootstrap Ditolak: Sesi autentikasi aktif hanya diizinkan melakukan bootstrap untuk akun miliknya sendiri.';
    END IF;

    v_display_name := COALESCE(
        NULLIF(TRIM(v_auth_user.raw_user_meta_data->>'name'), ''),
        NULLIF(TRIM(v_auth_user.raw_user_meta_data->>'full_name'), ''),
        INITCAP(SPLIT_PART(v_auth_user.email, '@', 1)),
        'Superadmin LPTQ'
    );

    v_username := COALESCE(
        NULLIF(TRIM(v_auth_user.raw_user_meta_data->>'username'), ''),
        LOWER(REGEXP_REPLACE(SPLIT_PART(v_auth_user.email, '@', 1), '[^a-zA-Z0-9_]', '_', 'g'))
    );

    IF EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE LOWER(p.username) = LOWER(v_username)
          AND p.id <> v_auth_user.id
    ) THEN
        v_username := v_username || '_' || SUBSTRING(v_auth_user.id::text FROM 1 FOR 4);
    END IF;

    IF p_initial_tenant_id IS NOT NULL AND EXISTS (SELECT 1 FROM public.tenants WHERE id = p_initial_tenant_id) THEN
        v_target_tenant_id := p_initial_tenant_id;
    ELSE
        SELECT t.id INTO v_target_tenant_id
        FROM public.tenants t
        WHERE t.id <> '00000000-0000-0000-0000-000000000000'::uuid
          AND t.status = 'Aktif'
        ORDER BY t.created_at ASC
        LIMIT 1;

        IF v_target_tenant_id IS NULL THEN
            SELECT t.id INTO v_target_tenant_id
            FROM public.tenants t
            ORDER BY t.created_at ASC
            LIMIT 1;
        END IF;
    END IF;

    IF v_target_tenant_id IS NULL THEN
        RAISE EXCEPTION 'Bootstrap Gagal: Belum ada data tenant di tabel public.tenants. Jalankan schema.sql / seed.sql terlebih dahulu.';
    END IF;

    PERFORM set_config('mtq.rpc_role_admin_active', 'true', true);
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    INSERT INTO public.profiles (id, username, name, email, role, updated_at)
    VALUES (
        v_auth_user.id,
        v_username,
        v_display_name,
        v_auth_user.email,
        'superadmin',
        now()
    )
    ON CONFLICT (id) DO UPDATE
    SET role = 'superadmin',
        email = COALESCE(EXCLUDED.email, public.profiles.email),
        name = COALESCE(NULLIF(TRIM(public.profiles.name), ''), EXCLUDED.name),
        username = COALESCE(NULLIF(TRIM(public.profiles.username), ''), EXCLUDED.username),
        updated_at = now();

    FOR v_tenant_rec IN
        SELECT t.id
        FROM public.tenants t
        WHERE t.id = v_target_tenant_id
           OR (t.id <> '00000000-0000-0000-0000-000000000000'::uuid AND t.status = 'Aktif')
    LOOP
        INSERT INTO public.tenant_memberships (tenant_id, profile_id, role, status)
        VALUES (v_tenant_rec.id, v_auth_user.id, 'superadmin', 'Aktif')
        ON CONFLICT (tenant_id, profile_id) DO UPDATE
        SET role = 'superadmin',
            status = 'Aktif';
    END LOOP;

    INSERT INTO public.audit_logs (tenant_id, actor_id, actor_name, action, target, summary, outcome)
    VALUES (
        v_target_tenant_id,
        v_auth_user.id,
        v_display_name || ' (superadmin)',
        'INITIAL_SUPERADMIN_BOOTSTRAPPED',
        'Profile ID: ' || v_auth_user.id::text,
        'Promosi satu kali (one-time bootstrap) akun Superadmin pertama sistem untuk ' || v_auth_user.email,
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'profile_id', v_auth_user.id,
        'email', v_auth_user.email,
        'username', v_username,
        'role', 'superadmin',
        'initial_tenant_id', v_target_tenant_id,
        'message', 'Akun Superadmin pertama berhasil di-bootstrap dan diikat ke tenant operasional.'
    );
END;
$$;

-- RPC 7: Transaksi Atomik Undian & Penetapan Maqra (commit_lottery_draw — P0-04)
CREATE OR REPLACE FUNCTION public.commit_lottery_draw(
    p_tenant_id UUID,
    p_stage_id UUID,
    p_stage_name VARCHAR(100),
    p_branch_id UUID,
    p_branch_name VARCHAR(150),
    p_level_id UUID,
    p_level_name VARCHAR(150),
    p_actor_id UUID,
    p_actor_name VARCHAR(255),
    p_results JSONB,
    p_questions_per_participant INT DEFAULT 1,
    p_notes TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_stage RECORD;
    v_res_elem JSONB;
    v_participant_id UUID;
    v_q_ids_json JSONB;
    v_q_id_text TEXT;
    v_q_id UUID;
    v_question RECORD;
    v_part RECORD;
    v_sp RECORD;
    v_now TIMESTAMPTZ := now();
    v_draw_log_id UUID := gen_random_uuid();
    v_assigned_maqras JSONB := '[]'::jsonb;
    v_all_p_ids TEXT[] := ARRAY[]::TEXT[];
    v_all_q_ids TEXT[] := ARRAY[]::TEXT[];
    v_new_maqra_id UUID;
    v_questions_count INT;
BEGIN
    IF NOT is_tenant_admin(p_tenant_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator yang berwenang menetapkan hasil undian maqra.';
    END IF;

    SELECT * INTO v_stage FROM stages WHERE id = p_stage_id AND tenant_id = p_tenant_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan pada tenant ini.';
    END IF;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'Penetapan undian ditolak: Babak "%" telah difinalisasi secara resmi.', v_stage.name;
    END IF;

    IF jsonb_array_length(p_results) = 0 THEN
        RAISE EXCEPTION 'Hasil undian kosong.';
    END IF;

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    -- 1. Validasi ketat 3D untuk seluruh hasil undian
    FOR v_res_elem IN SELECT * FROM jsonb_array_elements(p_results)
    LOOP
        v_participant_id := (v_res_elem ->> 'participantId')::uuid;
        SELECT * INTO v_part FROM participants WHERE id = v_participant_id AND tenant_id = p_tenant_id;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Peserta dengan ID % tidak ditemukan pada tenant ini.', v_participant_id;
        END IF;

        IF p_branch_id IS NOT NULL AND v_part.branch_id IS NOT NULL AND v_part.branch_id <> p_branch_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian cabang: Peserta "%" terdaftar pada cabang berbeda.', v_part.name;
        END IF;

        IF p_level_id IS NOT NULL AND v_part.level_id IS NOT NULL AND v_part.level_id <> p_level_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian jenjang: Peserta "%" terdaftar pada jenjang berbeda.', v_part.name;
        END IF;

        v_q_ids_json := v_res_elem -> 'questionIds';
        v_questions_count := jsonb_array_length(v_q_ids_json);
        IF v_questions_count = 0 THEN
            RAISE EXCEPTION 'Tidak ada soal yang ditetapkan untuk peserta "%".', v_part.name;
        END IF;

        v_all_p_ids := array_append(v_all_p_ids, v_participant_id::text);

        FOR v_q_id_text IN SELECT * FROM jsonb_array_elements_text(v_q_ids_json)
        LOOP
            v_q_id := v_q_id_text::uuid;
            SELECT * INTO v_question FROM questions WHERE id = v_q_id AND tenant_id = p_tenant_id;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'Soal dengan ID % tidak ditemukan.', v_q_id;
            END IF;

            IF v_question.status <> 'Aktif' THEN
                RAISE EXCEPTION 'Soal "%" (%) tidak berstatus Aktif.', v_question.title, v_question.code;
            END IF;

            IF p_branch_id IS NOT NULL AND v_question.branch_id IS NOT NULL AND v_question.branch_id <> p_branch_id THEN
                RAISE EXCEPTION 'Ketidaksesuaian cabang: Soal "%" berada pada cabang berbeda.', v_question.title;
            END IF;

            IF p_level_id IS NOT NULL AND v_question.level_id IS NOT NULL AND v_question.level_id <> p_level_id THEN
                RAISE EXCEPTION 'Ketidaksesuaian jenjang: Soal "%" berada pada jenjang berbeda.', v_question.title;
            END IF;

            v_all_q_ids := array_append(v_all_q_ids, v_q_id::text);
        END LOOP;
    END LOOP;

    -- 2. Eksekusi atomik pembaruan database
    FOR v_res_elem IN SELECT * FROM jsonb_array_elements(p_results)
    LOOP
        v_participant_id := (v_res_elem ->> 'participantId')::uuid;

        SELECT * INTO v_sp FROM stage_participations
        WHERE stage_id = p_stage_id AND participant_id = v_participant_id AND tenant_id = p_tenant_id
        LIMIT 1;

        IF NOT FOUND THEN
            INSERT INTO stage_participations (
                id, tenant_id, stage_id, stage_name, participant_id, lottery_number, status, created_at, updated_at
            ) VALUES (
                gen_random_uuid(), p_tenant_id, p_stage_id, p_stage_name, v_participant_id,
                (SELECT lottery_number FROM participants WHERE id = v_participant_id),
                'Belum Dimulai', v_now, v_now
            ) RETURNING * INTO v_sp;
        END IF;

        -- Hapus penetapan lama yang belum memiliki penilaian final (mendukung re-draw aman)
        DELETE FROM assigned_maqras
        WHERE stage_participation_id = v_sp.id
          AND tenant_id = p_tenant_id
          AND id NOT IN (
              SELECT assigned_maqra_id FROM judge_assessments
              WHERE stage_participation_id = v_sp.id AND status = 'finalized'
          );

        -- Sisipkan assigned_maqras baru
        FOR v_q_id_text IN SELECT * FROM jsonb_array_elements_text(v_res_elem -> 'questionIds')
        LOOP
            v_q_id := v_q_id_text::uuid;
            v_new_maqra_id := gen_random_uuid();

            INSERT INTO assigned_maqras (
                id, tenant_id, stage_participation_id, question_id, assigned_at, method, notes
            ) VALUES (
                v_new_maqra_id, p_tenant_id, v_sp.id, v_q_id, v_now, 'undian', p_notes
            );

            v_assigned_maqras := v_assigned_maqras || jsonb_build_object(
                'id', v_new_maqra_id,
                'participantId', v_participant_id,
                'stageParticipationId', v_sp.id,
                'questionId', v_q_id
            );
        END LOOP;

        UPDATE stage_participations
        SET status = CASE WHEN status = 'Maqra Belum Ditetapkan' THEN 'Belum Dimulai' ELSE status END,
            updated_at = v_now
        WHERE id = v_sp.id;
    END LOOP;

    -- Simpan riwayat undian di lottery_draw_logs
    INSERT INTO lottery_draw_logs (
        id, tenant_id, stage_id, stage_name, branch_id, branch_name, level_id, level_name,
        actor_id, actor_name, questions_per_participant, participant_ids, question_pool_ids,
        draw_results, notes, created_at
    ) VALUES (
        v_draw_log_id, p_tenant_id, p_stage_id, p_stage_name, p_branch_id, p_branch_name, p_level_id, p_level_name,
        p_actor_id, p_actor_name, p_questions_per_participant, v_all_p_ids, v_all_q_ids,
        p_results, p_notes, v_now
    );

    -- Simpan audit log
    INSERT INTO audit_logs (
        tenant_id, actor_id, actor_name, action, target, summary, outcome
    ) VALUES (
        p_tenant_id, p_actor_id, p_actor_name, 'LOTTERY_DRAW_COMMITTED',
        'Stage: ' || p_stage_name || ', Branch: ' || p_branch_name,
        'Penetapan undian maqra atomik untuk ' || jsonb_array_length(p_results)::text || ' peserta (Log ID: ' || v_draw_log_id::text || ')',
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Penetapan undian maqra berhasil dicatat secara atomik di database.',
        'drawLogId', v_draw_log_id,
        'assignedMaqras', v_assigned_maqras
    );
END;
$$;

-- 16. EXPLICIT RPC & SECURITY HELPER EXECUTION PERMISSIONS
REVOKE EXECUTE ON FUNCTION is_superadmin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION is_superadmin() TO authenticated;

REVOKE EXECUTE ON FUNCTION get_my_profile_role() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION get_my_profile_role() TO authenticated;

REVOKE EXECUTE ON FUNCTION get_user_tenants() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION get_user_tenants() TO authenticated;

REVOKE EXECUTE ON FUNCTION is_tenant_admin(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION is_tenant_admin(UUID) TO authenticated;

REVOKE EXECUTE ON FUNCTION is_assigned_judge(UUID, UUID, UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION is_assigned_judge(UUID, UUID, UUID) TO authenticated;

REVOKE EXECUTE ON FUNCTION finalize_judge_assessment(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION finalize_judge_assessment(UUID) TO authenticated;

REVOKE EXECUTE ON FUNCTION calculate_assessment_score_sql(UUID, UUID, JSONB) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION calculate_assessment_score_sql(UUID, UUID, JSONB) TO authenticated;

REVOKE EXECUTE ON FUNCTION reopen_judge_assessment(UUID, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION reopen_judge_assessment(UUID, TEXT) TO authenticated;

REVOKE EXECUTE ON FUNCTION advance_stage_qualifiers(UUID, UUID, UUID[], JSONB, JSONB) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION advance_stage_qualifiers(UUID, UUID, UUID[], JSONB, JSONB) TO authenticated;

REVOKE EXECUTE ON FUNCTION commit_lottery_draw(UUID, UUID, VARCHAR, UUID, VARCHAR, UUID, VARCHAR, UUID, VARCHAR, JSONB, INT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION commit_lottery_draw(UUID, UUID, VARCHAR, UUID, VARCHAR, UUID, VARCHAR, UUID, VARCHAR, JSONB, INT, TEXT) TO authenticated;

REVOKE EXECUTE ON FUNCTION append_admin_audit_log(UUID, TEXT, TEXT, TEXT, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION append_admin_audit_log(UUID, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;

REVOKE EXECUTE ON FUNCTION upsert_tenant_member_profile(UUID, UUID, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION upsert_tenant_member_profile(UUID, UUID, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.bootstrap_first_superadmin(TEXT, UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.bootstrap_first_superadmin(TEXT, UUID) TO authenticated;

-- 17. T1.1 & T1.2: MAQRA INTEGRITY & CENTRALIZED STAGE COMPLETION
CREATE OR REPLACE FUNCTION public.get_surah_max_ayah(p_surah_number INT)
RETURNS INT
LANGUAGE plpgsql
IMMUTABLE
AS $$
DECLARE
    v_verse_counts INT[] := ARRAY[
        7, 286, 200, 176, 120, 165, 206, 75, 129, 109,
        123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
        112, 78, 118, 64, 77, 227, 93, 88, 69, 60,
        34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
        54, 53, 89, 59, 37, 35, 38, 29, 18, 45,
        60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
        14, 11, 11, 18, 12, 12, 30, 52, 52, 44,
        28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
        29, 19, 36, 25, 22, 17, 19, 26, 30, 20,
        15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
        11, 8, 3, 9, 5, 4, 7, 3, 6, 3,
        5, 4, 5, 6
    ];
BEGIN
    IF p_surah_number IS NULL OR p_surah_number < 1 OR p_surah_number > 114 THEN
        RETURN NULL;
    END IF;
    RETURN v_verse_counts[p_surah_number];
END;
$$;

CREATE OR REPLACE FUNCTION public.validate_question_maqra_bounds()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    v_max_ayah INT;
BEGIN
    IF NEW.surah_number IS NULL OR NEW.surah_number < 1 OR NEW.surah_number > 114 THEN
        RAISE EXCEPTION 'Nomor surah tidak valid: % (harus antara 1 s.d. 114).', NEW.surah_number;
    END IF;

    v_max_ayah := public.get_surah_max_ayah(NEW.surah_number);
    IF v_max_ayah IS NULL THEN
        RAISE EXCEPTION 'Nomor surah % tidak ditemukan dalam indeks 114 surah.', NEW.surah_number;
    END IF;

    IF NEW.start_ayah IS NULL OR NEW.start_ayah < 1 OR NEW.start_ayah > v_max_ayah THEN
        RAISE EXCEPTION 'Ayat mulai (%) berada di luar batas surah ke-% (1..%).', NEW.start_ayah, NEW.surah_number, v_max_ayah;
    END IF;

    IF NEW.end_ayah IS NULL OR NEW.end_ayah < NEW.start_ayah OR NEW.end_ayah > v_max_ayah THEN
        RAISE EXCEPTION 'Ayat selesai (%) tidak valid untuk surah ke-% (harus antara %..%).', NEW.end_ayah, NEW.surah_number, NEW.start_ayah, v_max_ayah;
    END IF;

    IF NEW.page_start IS NULL OR NEW.page_start < 1 OR NEW.page_start > 604 THEN
        RAISE EXCEPTION 'Halaman mulai (%) harus berada di antara 1..604.', NEW.page_start;
    END IF;

    IF NEW.page_end IS NULL OR NEW.page_end < NEW.page_start OR NEW.page_end > 604 THEN
        RAISE EXCEPTION 'Halaman selesai (%) harus berada di antara %..604.', NEW.page_end, NEW.page_start;
    END IF;

    IF NEW.page_number IS NULL OR NEW.page_number < 1 OR NEW.page_number > 604 THEN
        NEW.page_number := NEW.page_start;
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_validate_question_maqra ON public.questions;
CREATE TRIGGER trg_validate_question_maqra
    BEFORE INSERT OR UPDATE ON public.questions
    FOR EACH ROW EXECUTE FUNCTION public.validate_question_maqra_bounds();

CREATE OR REPLACE FUNCTION public.audit_questions_consistency(p_tenant_id UUID DEFAULT NULL)
RETURNS INT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_flagged_count INT := 0;
BEGIN
    UPDATE public.questions q
    SET status = 'Perlu Verifikasi'
    WHERE (p_tenant_id IS NULL OR q.tenant_id = p_tenant_id)
      AND q.status = 'Aktif'
      AND (
          q.surah_number < 1
          OR q.surah_number > 114
          OR q.start_ayah < 1
          OR q.end_ayah < q.start_ayah
          OR q.end_ayah > COALESCE(public.get_surah_max_ayah(q.surah_number), 0)
          OR q.page_start < 1
          OR q.page_end > 604
          OR q.page_end < q.page_start
      );

    GET DIAGNOSTICS v_flagged_count = ROW_COUNT;
    RETURN v_flagged_count;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_stage_completion_sql(p_stage_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_stage RECORD;
    v_required_judge_count INT := 0;
    v_total_participants INT := 0;
    v_completed_participants INT := 0;
    v_missing_maqra_participants INT := 0;
    v_total_required_units INT := 0;
    v_finalized_units INT := 0;
    v_sp RECORD;
    v_sp_maqra_count INT;
    v_sp_finalized_units INT;
    v_all_complete BOOLEAN := false;
    v_blocking_code TEXT := NULL;
BEGIN
    SELECT id, tenant_id, branch_id, name
    INTO v_stage
    FROM public.stages
    WHERE id = p_stage_id;

    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'stage_id', p_stage_id,
            'total_participants_count', 0,
            'completed_participants_count', 0,
            'incomplete_participants_count', 0,
            'missing_maqra_participants_count', 0,
            'required_judge_count', 0,
            'total_required_units', 0,
            'finalized_units_count', 0,
            'all_complete', false,
            'blocking_code', 'NO_PARTICIPANTS'
        );
    END IF;

    SELECT COUNT(DISTINCT ja.judge_profile_id)
    INTO v_required_judge_count
    FROM public.judge_assignments ja
    WHERE ja.tenant_id = v_stage.tenant_id
      AND ja.stage_id = v_stage.id
      AND ja.status = 'Aktif'
      AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id);

    FOR v_sp IN
        SELECT sp.id, sp.participant_id
        FROM public.stage_participations sp
        WHERE sp.tenant_id = v_stage.tenant_id
          AND sp.stage_id = v_stage.id
    LOOP
        v_total_participants := v_total_participants + 1;

        SELECT COUNT(*)
        INTO v_sp_maqra_count
        FROM public.assigned_maqras am
        WHERE am.stage_participation_id = v_sp.id;

        IF v_sp_maqra_count = 0 THEN
            v_missing_maqra_participants := v_missing_maqra_participants + 1;
        END IF;

        v_total_required_units := v_total_required_units + (v_sp_maqra_count * v_required_judge_count);

        SELECT COUNT(*)
        INTO v_sp_finalized_units
        FROM public.assigned_maqras am
        JOIN public.judge_assignments ja
          ON ja.tenant_id = v_stage.tenant_id
         AND ja.stage_id = v_stage.id
         AND ja.status = 'Aktif'
         AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
        JOIN public.judge_assessments asm
          ON asm.stage_participation_id = v_sp.id
         AND asm.assigned_maqra_id = am.id
         AND asm.judge_profile_id = ja.judge_profile_id
         AND asm.status = 'finalized'
         AND asm.is_locked = true
        WHERE am.stage_participation_id = v_sp.id;

        v_finalized_units := v_finalized_units + v_sp_finalized_units;

        IF v_sp_maqra_count >= 1
           AND v_required_judge_count >= 1
           AND v_sp_finalized_units = (v_sp_maqra_count * v_required_judge_count)
        THEN
            v_completed_participants := v_completed_participants + 1;
        END IF;
    END LOOP;

    v_all_complete := (
        v_total_participants > 0
        AND v_required_judge_count > 0
        AND v_missing_maqra_participants = 0
        AND v_completed_participants = v_total_participants
    );

    IF v_total_participants = 0 THEN
        v_blocking_code := 'NO_PARTICIPANTS';
    ELSIF v_required_judge_count = 0 THEN
        v_blocking_code := 'NO_JUDGES';
    ELSIF v_missing_maqra_participants > 0 THEN
        v_blocking_code := 'NO_MAQRA';
    ELSIF v_completed_participants < v_total_participants THEN
        v_blocking_code := 'INCOMPLETE_ASSESSMENTS';
    END IF;

    RETURN jsonb_build_object(
        'stage_id', v_stage.id,
        'total_participants_count', v_total_participants,
        'completed_participants_count', v_completed_participants,
        'incomplete_participants_count', (v_total_participants - v_completed_participants),
        'missing_maqra_participants_count', v_missing_maqra_participants,
        'required_judge_count', v_required_judge_count,
        'total_required_units', v_total_required_units,
        'finalized_units_count', v_finalized_units,
        'all_complete', v_all_complete,
        'blocking_code', v_blocking_code
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.delete_rubric_field_cascade(
    p_rubric_version_id UUID,
    p_field_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_rf RECORD;
    v_rv RECORD;
    v_is_used BOOLEAN;
BEGIN
    SELECT * INTO v_rf FROM public.rubric_fields WHERE id = p_field_id AND rubric_version_id = p_rubric_version_id;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Bidang rubrik tidak ditemukan.');
    END IF;

    SELECT * INTO v_rv FROM public.rubric_versions WHERE id = p_rubric_version_id;
    SELECT EXISTS (
        SELECT 1 FROM public.judge_assessments ja
        WHERE (ja.rubric_version_id = p_rubric_version_id OR ja.rubric_version = v_rv.code)
          AND ja.status = 'finalized'
    ) INTO v_is_used;

    IF v_is_used THEN
        RETURN jsonb_build_object(
            'success', false,
            'message', 'Bidang tidak dapat dihapus permanen karena versi rubrik ini telah digunakan pada lembar penilaian yang sudah difinalisasi. Nonaktifkan bidang sebagai gantinya.'
        );
    END IF;

    UPDATE public.error_categories
    SET rubric_field_id = NULL
    WHERE rubric_field_id = p_field_id;

    UPDATE public.judge_assignments
    SET rubric_field_id = NULL
    WHERE rubric_field_id = p_field_id;

    DELETE FROM public.deduction_rules
    WHERE criterion_id IN (SELECT id FROM public.rubric_criteria WHERE rubric_field_id = p_field_id);

    DELETE FROM public.rubric_criteria
    WHERE rubric_field_id = p_field_id;

    DELETE FROM public.rubric_fields WHERE id = p_field_id;

    RETURN jsonb_build_object(
        'success', true,
        'message', format('Bidang "%s" berhasil dihapus permanen dari versi rubrik.', v_rf.name)
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.delete_rubric_field_cascade(UUID, UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_rubric_field_cascade(UUID, UUID) TO authenticated;

-- 18. T2.1: ISOLASI PROFIL LINTAS-TENANT PADA upsert_tenant_member_profile
CREATE OR REPLACE FUNCTION public.upsert_tenant_member_profile(
    p_tenant_id UUID,
    p_profile_id UUID,
    p_username TEXT,
    p_name TEXT,
    p_email TEXT,
    p_role TEXT,
    p_judge_category TEXT DEFAULT NULL,
    p_judge_field TEXT DEFAULT NULL,
    p_status TEXT DEFAULT 'Aktif'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_target_id UUID;
    v_auth_email TEXT;
    v_existing_profile RECORD;
    v_has_other_tenant_membership BOOLEAN := false;
    v_preserve_global_profile BOOLEAN := false;
    v_clean_role TEXT;
    v_clean_status TEXT;
    v_clean_username TEXT;
    v_audit_summary TEXT;
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    IF p_tenant_id IS NULL OR NOT EXISTS (SELECT 1 FROM public.tenants WHERE id = p_tenant_id) THEN
        RAISE EXCEPTION 'Tenant tujuan tidak ditemukan atau tidak valid.';
    END IF;

    IF NOT public.is_tenant_admin(p_tenant_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator Tenant atau Superadmin yang dapat mengelola keanggotaan pengguna.';
    END IF;

    v_clean_role := LOWER(TRIM(COALESCE(p_role, 'judge')));
    IF v_clean_role NOT IN ('judge', 'admin', 'superadmin') THEN
        RAISE EXCEPTION 'Peran pengguna tidak valid: %', v_clean_role;
    END IF;

    IF v_clean_role = 'superadmin' AND NOT public.is_superadmin() THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Superadmin yang dapat menetapkan peran superadmin.';
    END IF;

    v_clean_status := CASE WHEN p_status = 'Nonaktif' THEN 'Nonaktif' ELSE 'Aktif' END;

    IF p_profile_id IS NOT NULL THEN
        SELECT u.id, u.email INTO v_target_id, v_auth_email
        FROM auth.users u
        WHERE u.id = p_profile_id
        LIMIT 1;
    END IF;

    IF v_target_id IS NULL AND NULLIF(TRIM(p_email), '') IS NOT NULL THEN
        SELECT u.id, u.email INTO v_target_id, v_auth_email
        FROM auth.users u
        WHERE LOWER(u.email) = LOWER(TRIM(p_email))
        LIMIT 1;
    END IF;

    IF v_target_id IS NULL THEN
        SELECT p.id, p.email INTO v_target_id, v_auth_email
        FROM public.profiles p
        WHERE (p_profile_id IS NOT NULL AND p.id = p_profile_id)
           OR (NULLIF(TRIM(p_email), '') IS NOT NULL AND LOWER(p.email) = LOWER(TRIM(p_email)))
           OR (NULLIF(TRIM(p_username), '') IS NOT NULL AND LOWER(p.username) = LOWER(TRIM(p_username)))
        LIMIT 1;
    END IF;

    IF v_target_id IS NULL THEN
        RAISE EXCEPTION 'AUTH_USER_NOT_FOUND: Pengguna (%) belum terdaftar di Supabase Auth (auth.users). Gunakan layanan undangan akun (Edge Function admin-provision-user) atau daftarkan email di Supabase Authentication terlebih dahulu.', COALESCE(NULLIF(TRIM(p_email), ''), NULLIF(TRIM(p_username), ''), 'tanpa-identitas');
    END IF;

    SELECT * INTO v_existing_profile FROM public.profiles WHERE id = v_target_id;
    IF FOUND AND v_existing_profile.role = 'superadmin' AND NOT public.is_superadmin() THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Administrator Tenant tidak memiliki wewenang untuk mengubah profil atau keanggotaan Superadmin.';
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.tenant_memberships tm
        WHERE tm.profile_id = v_target_id
          AND tm.tenant_id <> p_tenant_id
    ) INTO v_has_other_tenant_membership;

    IF v_existing_profile.id IS NOT NULL
       AND NOT public.is_superadmin()
       AND v_has_other_tenant_membership
    THEN
        v_preserve_global_profile := true;
    END IF;

    PERFORM set_config('mtq.rpc_role_admin_active', 'true', true);
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    IF NOT v_preserve_global_profile THEN
        v_clean_username := COALESCE(
            NULLIF(TRIM(p_username), ''),
            v_existing_profile.username,
            'user_' || SUBSTRING(v_target_id::text FROM 1 FOR 8)
        );

        IF EXISTS (
            SELECT 1 FROM public.profiles p
            WHERE LOWER(p.username) = LOWER(v_clean_username)
              AND p.id <> v_target_id
        ) THEN
            v_clean_username := v_clean_username || '_' || SUBSTRING(v_target_id::text FROM 1 FOR 4);
        END IF;

        INSERT INTO public.profiles (id, username, name, email, role, updated_at)
        VALUES (
            v_target_id,
            v_clean_username,
            COALESCE(NULLIF(TRIM(p_name), ''), 'Pengguna MTQ'),
            COALESCE(NULLIF(TRIM(p_email), ''), v_auth_email),
            CASE
                WHEN public.is_superadmin() AND v_clean_role = 'superadmin' THEN 'superadmin'
                WHEN v_clean_role = 'admin' THEN 'admin'
                ELSE 'judge'
            END,
            now()
        )
        ON CONFLICT (id) DO UPDATE
        SET username = COALESCE(NULLIF(TRIM(EXCLUDED.username), ''), public.profiles.username),
            name = COALESCE(NULLIF(TRIM(EXCLUDED.name), ''), public.profiles.name),
            email = COALESCE(NULLIF(TRIM(EXCLUDED.email), ''), public.profiles.email),
            role = CASE
                WHEN public.profiles.role = 'superadmin' AND NOT public.is_superadmin() THEN 'superadmin'
                WHEN public.is_superadmin() AND v_clean_role = 'superadmin' THEN 'superadmin'
                ELSE EXCLUDED.role
            END,
            updated_at = now();
    END IF;

    INSERT INTO public.tenant_memberships (
        tenant_id,
        profile_id,
        role,
        judge_category,
        judge_field,
        status
    )
    VALUES (
        p_tenant_id,
        v_target_id,
        v_clean_role,
        NULLIF(TRIM(p_judge_category), ''),
        NULLIF(TRIM(p_judge_field), ''),
        v_clean_status
    )
    ON CONFLICT (tenant_id, profile_id) DO UPDATE
    SET role = EXCLUDED.role,
        judge_category = EXCLUDED.judge_category,
        judge_field = EXCLUDED.judge_field,
        status = EXCLUDED.status;

    SELECT * INTO v_actor FROM public.profiles WHERE id = v_actor_id;

    IF v_preserve_global_profile THEN
        v_audit_summary := 'Penautan keanggotaan lintas-tenant untuk ' || COALESCE(v_existing_profile.email, '') ||
                           ' sebagai ' || v_clean_role || ' (' || v_clean_status ||
                           '); profil global (nama/username/role) dipertahankan demi isolasi lintas-tenant.';
    ELSE
        v_audit_summary := 'Pemetaan profil & keanggotaan ' || COALESCE(p_name, '') ||
                           ' dengan peran ' || v_clean_role || ' (' || v_clean_status || ')';
    END IF;

    INSERT INTO public.audit_logs (tenant_id, actor_id, actor_name, action, target, summary, outcome)
    VALUES (
        p_tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
        'USER_MEMBERSHIP_UPSERTED',
        'Profile ID: ' || v_target_id::text,
        v_audit_summary,
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'profile_id', v_target_id,
        'email', COALESCE(v_existing_profile.email, NULLIF(TRIM(p_email), ''), v_auth_email),
        'role', v_clean_role,
        'status', v_clean_status,
        'global_profile_preserved', v_preserve_global_profile
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.upsert_tenant_member_profile(UUID, UUID, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.upsert_tenant_member_profile(UUID, UUID, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- ==============================================================================
-- 19. AUDIT FIXES 20261114 — FASE 1: KEAMANAN & MULTI-TENANT (1.1 s.d. 1.7)
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.audit_questions_consistency(p_tenant_id UUID DEFAULT NULL)
RETURNS INT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_flagged_count INT := 0;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    IF p_tenant_id IS NULL AND NOT public.is_superadmin() THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Parameter p_tenant_id wajib diisi kecuali oleh Superadmin.';
    END IF;

    IF NOT (public.is_superadmin() OR (p_tenant_id IS NOT NULL AND public.is_tenant_admin(p_tenant_id))) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator Tenant atau Superadmin yang berwenang menjalankan audit konsistensi soal.';
    END IF;

    UPDATE public.questions q
    SET status = 'Perlu Verifikasi'
    WHERE (p_tenant_id IS NULL OR q.tenant_id = p_tenant_id)
      AND q.status = 'Aktif'
      AND (
          q.surah_number < 1
          OR q.surah_number > 114
          OR q.start_ayah < 1
          OR q.end_ayah < q.start_ayah
          OR q.end_ayah > COALESCE(public.get_surah_max_ayah(q.surah_number), 0)
          OR q.page_start < 1
          OR q.page_end > 604
          OR q.page_end < q.page_start
      );

    GET DIAGNOSTICS v_flagged_count = ROW_COUNT;
    RETURN v_flagged_count;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.audit_questions_consistency(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.audit_questions_consistency(UUID) TO authenticated;

CREATE OR REPLACE FUNCTION public.delete_rubric_field_cascade(
    p_rubric_version_id UUID,
    p_field_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_rf RECORD;
    v_rv RECORD;
    v_is_used BOOLEAN;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    SELECT * INTO v_rf FROM public.rubric_fields WHERE id = p_field_id AND rubric_version_id = p_rubric_version_id;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Bidang rubrik tidak ditemukan.');
    END IF;

    SELECT * INTO v_rv FROM public.rubric_versions WHERE id = p_rubric_version_id;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Versi rubrik tidak ditemukan.');
    END IF;

    IF NOT (public.is_tenant_admin(v_rv.tenant_id) OR public.is_superadmin()) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator Tenant atau Superadmin yang dapat menghapus bidang rubrik.';
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.judge_assessments ja
        WHERE ja.rubric_version_id = p_rubric_version_id
          AND ja.status = 'finalized'
    ) INTO v_is_used;

    IF v_is_used THEN
        RETURN jsonb_build_object(
            'success', false,
            'message', 'Bidang tidak dapat dihapus permanen karena versi rubrik ini telah digunakan pada lembar penilaian yang sudah difinalisasi. Nonaktifkan bidang sebagai gantinya.'
        );
    END IF;

    UPDATE public.error_categories
    SET rubric_field_id = NULL
    WHERE rubric_field_id = p_field_id;

    UPDATE public.judge_assignments
    SET rubric_field_id = NULL
    WHERE rubric_field_id = p_field_id;

    DELETE FROM public.deduction_rules
    WHERE criterion_id IN (SELECT id FROM public.rubric_criteria WHERE rubric_field_id = p_field_id);

    DELETE FROM public.rubric_criteria
    WHERE rubric_field_id = p_field_id;

    DELETE FROM public.rubric_fields WHERE id = p_field_id;

    RETURN jsonb_build_object(
        'success', true,
        'message', format('Bidang "%s" berhasil dihapus permanen dari versi rubrik.', v_rf.name)
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.delete_rubric_field_cascade(UUID, UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_rubric_field_cascade(UUID, UUID) TO authenticated;

CREATE OR REPLACE FUNCTION public.get_stage_completion_sql(p_stage_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_stage RECORD;
    v_required_judge_count INT := 0;
    v_total_participants INT := 0;
    v_completed_participants INT := 0;
    v_missing_maqra_participants INT := 0;
    v_total_required_units INT := 0;
    v_finalized_units INT := 0;
    v_sp RECORD;
    v_sp_maqra_count INT;
    v_sp_finalized_units INT;
    v_all_complete BOOLEAN := false;
    v_blocking_code TEXT := NULL;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    SELECT id, tenant_id, branch_id, name
    INTO v_stage
    FROM public.stages
    WHERE id = p_stage_id;

    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'stage_id', p_stage_id,
            'total_participants_count', 0,
            'completed_participants_count', 0,
            'incomplete_participants_count', 0,
            'missing_maqra_participants_count', 0,
            'required_judge_count', 0,
            'total_required_units', 0,
            'finalized_units_count', 0,
            'all_complete', false,
            'blocking_code', 'NO_PARTICIPANTS'
        );
    END IF;

    IF NOT (public.is_superadmin() OR v_stage.tenant_id IN (SELECT public.get_user_tenants())) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Anda tidak memiliki hak akses untuk membaca kelengkapan babak pada tenant lain.';
    END IF;

    SELECT COUNT(DISTINCT ja.judge_profile_id)
    INTO v_required_judge_count
    FROM public.judge_assignments ja
    WHERE ja.tenant_id = v_stage.tenant_id
      AND ja.stage_id = v_stage.id
      AND ja.status = 'Aktif'
      AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id);

    FOR v_sp IN
        SELECT sp.id, sp.participant_id
        FROM public.stage_participations sp
        WHERE sp.tenant_id = v_stage.tenant_id
          AND sp.stage_id = v_stage.id
    LOOP
        v_total_participants := v_total_participants + 1;

        SELECT COUNT(*)
        INTO v_sp_maqra_count
        FROM public.assigned_maqras am
        WHERE am.stage_participation_id = v_sp.id;

        IF v_sp_maqra_count = 0 THEN
            v_missing_maqra_participants := v_missing_maqra_participants + 1;
        END IF;

        v_total_required_units := v_total_required_units + (v_sp_maqra_count * v_required_judge_count);

        SELECT COUNT(*)
        INTO v_sp_finalized_units
        FROM public.assigned_maqras am
        JOIN public.judge_assignments ja
          ON ja.tenant_id = v_stage.tenant_id
         AND ja.stage_id = v_stage.id
         AND ja.status = 'Aktif'
         AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
        JOIN public.judge_assessments asm
          ON asm.stage_participation_id = v_sp.id
         AND asm.assigned_maqra_id = am.id
         AND asm.judge_profile_id = ja.judge_profile_id
         AND asm.status = 'finalized'
         AND asm.is_locked = true
        WHERE am.stage_participation_id = v_sp.id;

        v_finalized_units := v_finalized_units + v_sp_finalized_units;

        IF v_sp_maqra_count >= 1
           AND v_required_judge_count >= 1
           AND v_sp_finalized_units = (v_sp_maqra_count * v_required_judge_count)
        THEN
            v_completed_participants := v_completed_participants + 1;
        END IF;
    END LOOP;

    v_all_complete := (
        v_total_participants > 0
        AND v_required_judge_count > 0
        AND v_missing_maqra_participants = 0
        AND v_completed_participants = v_total_participants
    );

    IF v_total_participants = 0 THEN
        v_blocking_code := 'NO_PARTICIPANTS';
    ELSIF v_required_judge_count = 0 THEN
        v_blocking_code := 'NO_JUDGES';
    ELSIF v_missing_maqra_participants > 0 THEN
        v_blocking_code := 'NO_MAQRA';
    ELSIF v_completed_participants < v_total_participants THEN
        v_blocking_code := 'INCOMPLETE_ASSESSMENTS';
    END IF;

    RETURN jsonb_build_object(
        'stage_id', v_stage.id,
        'total_participants_count', v_total_participants,
        'completed_participants_count', v_completed_participants,
        'incomplete_participants_count', (v_total_participants - v_completed_participants),
        'missing_maqra_participants_count', v_missing_maqra_participants,
        'required_judge_count', v_required_judge_count,
        'total_required_units', v_total_required_units,
        'finalized_units_count', v_finalized_units,
        'all_complete', v_all_complete,
        'blocking_code', v_blocking_code
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.get_stage_completion_sql(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_stage_completion_sql(UUID) TO authenticated;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'kafilahs_tenant_id_id_key') THEN
        ALTER TABLE public.kafilahs ADD CONSTRAINT kafilahs_tenant_id_id_key UNIQUE (tenant_id, id);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'branches_tenant_id_id_key') THEN
        ALTER TABLE public.branches ADD CONSTRAINT branches_tenant_id_id_key UNIQUE (tenant_id, id);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'levels_tenant_id_id_key') THEN
        ALTER TABLE public.levels ADD CONSTRAINT levels_tenant_id_id_key UNIQUE (tenant_id, id);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'stages_tenant_id_id_key') THEN
        ALTER TABLE public.stages ADD CONSTRAINT stages_tenant_id_id_key UNIQUE (tenant_id, id);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'participants_tenant_id_id_key') THEN
        ALTER TABLE public.participants ADD CONSTRAINT participants_tenant_id_id_key UNIQUE (tenant_id, id);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'stage_participations_tenant_id_id_key') THEN
        ALTER TABLE public.stage_participations ADD CONSTRAINT stage_participations_tenant_id_id_key UNIQUE (tenant_id, id);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'questions_tenant_id_id_key') THEN
        ALTER TABLE public.questions ADD CONSTRAINT questions_tenant_id_id_key UNIQUE (tenant_id, id);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'assigned_maqras_tenant_id_id_key') THEN
        ALTER TABLE public.assigned_maqras ADD CONSTRAINT assigned_maqras_tenant_id_id_key UNIQUE (tenant_id, id);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'rubric_versions_tenant_id_id_key') THEN
        ALTER TABLE public.rubric_versions ADD CONSTRAINT rubric_versions_tenant_id_id_key UNIQUE (tenant_id, id);
    END IF;
END $$;

CREATE OR REPLACE FUNCTION public.enforce_cross_tenant_reference_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_ref_tenant UUID;
    v_system_tenant UUID := '00000000-0000-0000-0000-000000000000'::uuid;
BEGIN
    IF TG_TABLE_NAME = 'participants' THEN
        IF NEW.kafilah_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.kafilahs WHERE id = NEW.kafilah_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: kafilah_id (%) bukan milik tenant peserta (%).', NEW.kafilah_id, NEW.tenant_id;
            END IF;
        END IF;

        IF NEW.branch_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.branches WHERE id = NEW.branch_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: branch_id (%) bukan milik tenant peserta (%).', NEW.branch_id, NEW.tenant_id;
            END IF;
        END IF;

        IF NEW.level_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.levels WHERE id = NEW.level_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: level_id (%) bukan milik tenant peserta (%).', NEW.level_id, NEW.tenant_id;
            END IF;
        END IF;

        IF NEW.stage_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.stages WHERE id = NEW.stage_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: stage_id (%) bukan milik tenant peserta (%).', NEW.stage_id, NEW.tenant_id;
            END IF;
        END IF;

    ELSIF TG_TABLE_NAME = 'stage_participations' THEN
        IF NEW.stage_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.stages WHERE id = NEW.stage_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: stage_id (%) pada stage_participations bukan milik tenant (%).', NEW.stage_id, NEW.tenant_id;
            END IF;
        END IF;

        IF NEW.participant_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.participants WHERE id = NEW.participant_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: participant_id (%) pada stage_participations bukan milik tenant (%).', NEW.participant_id, NEW.tenant_id;
            END IF;
        END IF;

    ELSIF TG_TABLE_NAME = 'judge_assignments' THEN
        IF NEW.stage_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.stages WHERE id = NEW.stage_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: stage_id (%) pada judge_assignments bukan milik tenant (%).', NEW.stage_id, NEW.tenant_id;
            END IF;
        END IF;

        IF NEW.branch_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.branches WHERE id = NEW.branch_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: branch_id (%) pada judge_assignments bukan milik tenant (%).', NEW.branch_id, NEW.tenant_id;
            END IF;
        END IF;

        IF NEW.level_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.levels WHERE id = NEW.level_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: level_id (%) pada judge_assignments bukan milik tenant (%).', NEW.level_id, NEW.tenant_id;
            END IF;
        END IF;

        IF NEW.rubric_field_id IS NOT NULL THEN
            SELECT rv.tenant_id INTO v_ref_tenant
            FROM public.rubric_fields rf
            JOIN public.rubric_versions rv ON rv.id = rf.rubric_version_id
            WHERE rf.id = NEW.rubric_field_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id AND v_ref_tenant IS DISTINCT FROM v_system_tenant THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: rubric_field_id (%) pada judge_assignments bukan milik tenant (%).', NEW.rubric_field_id, NEW.tenant_id;
            END IF;
        END IF;

    ELSIF TG_TABLE_NAME = 'assigned_maqras' THEN
        IF NEW.stage_participation_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.stage_participations WHERE id = NEW.stage_participation_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: stage_participation_id (%) pada assigned_maqras bukan milik tenant (%).', NEW.stage_participation_id, NEW.tenant_id;
            END IF;
        END IF;

        IF NEW.question_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.questions WHERE id = NEW.question_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: question_id (%) pada assigned_maqras bukan milik tenant (%).', NEW.question_id, NEW.tenant_id;
            END IF;
        END IF;

    ELSIF TG_TABLE_NAME = 'judge_assessments' THEN
        IF NEW.stage_participation_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.stage_participations WHERE id = NEW.stage_participation_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: stage_participation_id (%) pada judge_assessments bukan milik tenant (%).', NEW.stage_participation_id, NEW.tenant_id;
            END IF;
        END IF;

        IF NEW.assigned_maqra_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.assigned_maqras WHERE id = NEW.assigned_maqra_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: assigned_maqra_id (%) pada judge_assessments bukan milik tenant (%).', NEW.assigned_maqra_id, NEW.tenant_id;
            END IF;
        END IF;

        IF NEW.rubric_version_id IS NOT NULL THEN
            SELECT tenant_id INTO v_ref_tenant FROM public.rubric_versions WHERE id = NEW.rubric_version_id;
            IF v_ref_tenant IS DISTINCT FROM NEW.tenant_id AND v_ref_tenant IS DISTINCT FROM v_system_tenant THEN
                RAISE EXCEPTION 'Pelanggaran Isolasi Lintas-Tenant: rubric_version_id (%) pada judge_assessments bukan milik tenant (%).', NEW.rubric_version_id, NEW.tenant_id;
            END IF;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_cross_tenant_participants ON public.participants;
CREATE TRIGGER trg_cross_tenant_participants
    BEFORE INSERT OR UPDATE ON public.participants
    FOR EACH ROW EXECUTE FUNCTION public.enforce_cross_tenant_reference_integrity();

DROP TRIGGER IF EXISTS trg_cross_tenant_stage_participations ON public.stage_participations;
CREATE TRIGGER trg_cross_tenant_stage_participations
    BEFORE INSERT OR UPDATE ON public.stage_participations
    FOR EACH ROW EXECUTE FUNCTION public.enforce_cross_tenant_reference_integrity();

DROP TRIGGER IF EXISTS trg_cross_tenant_judge_assignments ON public.judge_assignments;
CREATE TRIGGER trg_cross_tenant_judge_assignments
    BEFORE INSERT OR UPDATE ON public.judge_assignments
    FOR EACH ROW EXECUTE FUNCTION public.enforce_cross_tenant_reference_integrity();

DROP TRIGGER IF EXISTS trg_cross_tenant_assigned_maqras ON public.assigned_maqras;
CREATE TRIGGER trg_cross_tenant_assigned_maqras
    BEFORE INSERT OR UPDATE ON public.assigned_maqras
    FOR EACH ROW EXECUTE FUNCTION public.enforce_cross_tenant_reference_integrity();

DROP TRIGGER IF EXISTS trg_cross_tenant_judge_assessments ON public.judge_assessments;
CREATE TRIGGER trg_cross_tenant_judge_assessments
    BEFORE INSERT OR UPDATE ON public.judge_assessments
    FOR EACH ROW EXECUTE FUNCTION public.enforce_cross_tenant_reference_integrity();

CREATE OR REPLACE FUNCTION public.commit_lottery_draw(
    p_tenant_id UUID,
    p_stage_id UUID,
    p_stage_name VARCHAR(100),
    p_branch_id UUID,
    p_branch_name VARCHAR(150),
    p_level_id UUID,
    p_level_name VARCHAR(150),
    p_actor_id UUID,
    p_actor_name VARCHAR(255),
    p_results JSONB,
    p_questions_per_participant INT DEFAULT 1,
    p_notes TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_real_actor_id UUID;
    v_real_actor_name VARCHAR(255);
    v_actor_profile RECORD;
    v_stage RECORD;
    v_res_elem JSONB;
    v_participant_id UUID;
    v_q_ids_json JSONB;
    v_q_id_text TEXT;
    v_q_id UUID;
    v_question RECORD;
    v_part RECORD;
    v_sp RECORD;
    v_now TIMESTAMPTZ := now();
    v_draw_log_id UUID := gen_random_uuid();
    v_assigned_maqras JSONB := '[]'::jsonb;
    v_all_p_ids TEXT[] := ARRAY[]::TEXT[];
    v_all_q_ids TEXT[] := ARRAY[]::TEXT[];
    v_new_maqra_id UUID;
    v_questions_count INT;
BEGIN
    v_real_actor_id := auth.uid();
    IF v_real_actor_id IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    IF NOT public.is_tenant_admin(p_tenant_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator yang berwenang menetapkan hasil undian maqra.';
    END IF;

    SELECT name, role INTO v_actor_profile FROM public.profiles WHERE id = v_real_actor_id;
    v_real_actor_name := COALESCE(NULLIF(TRIM(v_actor_profile.name), ''), 'Administrator MTQ');

    SELECT * INTO v_stage FROM public.stages WHERE id = p_stage_id AND tenant_id = p_tenant_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan pada tenant ini.';
    END IF;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'Penetapan undian ditolak: Babak "%" telah difinalisasi secara resmi.', v_stage.name;
    END IF;

    IF EXISTS (
        SELECT 1
        FROM public.judge_assessments ja
        JOIN public.stage_participations sp ON sp.id = ja.stage_participation_id
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = p_tenant_id
    ) THEN
        RAISE EXCEPTION 'STAGE_ASSESSMENTS_ALREADY_STARTED: Penetapan undian ditolak karena penilaian dewan hakim sudah dimulai pada babak "%".', v_stage.name;
    END IF;

    IF LENGTH(TRIM(COALESCE(p_notes, ''))) < 5 THEN
        RAISE EXCEPTION 'LOTTERY_OVERRIDE_REASON_REQUIRED: Penetapan maqra manual wajib menyertakan alasan override minimal 5 karakter.';
    END IF;

    IF jsonb_array_length(p_results) = 0 THEN
        RAISE EXCEPTION 'Hasil undian kosong.';
    END IF;

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    FOR v_res_elem IN SELECT * FROM jsonb_array_elements(p_results)
    LOOP
        v_participant_id := (v_res_elem ->> 'participantId')::uuid;
        SELECT * INTO v_part FROM public.participants WHERE id = v_participant_id AND tenant_id = p_tenant_id;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Peserta dengan ID % tidak ditemukan pada tenant ini.', v_participant_id;
        END IF;

        IF COALESCE(v_part.verification_status, 'Diverifikasi') <> 'Diverifikasi' THEN
            RAISE EXCEPTION 'PARTICIPANT_NOT_VERIFIED: Peserta "%" belum diverifikasi berkasnya (status: %). Hanya peserta berstatus Diverifikasi yang dapat mengikuti undian.', v_part.name, v_part.verification_status;
        END IF;

        IF p_branch_id IS NOT NULL AND v_part.branch_id IS NOT NULL AND v_part.branch_id <> p_branch_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian cabang: Peserta "%" terdaftar pada cabang berbeda.', v_part.name;
        END IF;

        IF p_level_id IS NOT NULL AND v_part.level_id IS NOT NULL AND v_part.level_id <> p_level_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian jenjang: Peserta "%" terdaftar pada jenjang berbeda.', v_part.name;
        END IF;

        v_q_ids_json := v_res_elem -> 'questionIds';
        v_questions_count := jsonb_array_length(v_q_ids_json);
        IF v_questions_count = 0 THEN
            RAISE EXCEPTION 'Tidak ada soal yang ditetapkan untuk peserta "%".', v_part.name;
        END IF;

        v_all_p_ids := array_append(v_all_p_ids, v_participant_id::text);

        FOR v_q_id_text IN SELECT * FROM jsonb_array_elements_text(v_q_ids_json)
        LOOP
            v_q_id := v_q_id_text::uuid;
            SELECT * INTO v_question FROM public.questions WHERE id = v_q_id AND tenant_id = p_tenant_id;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'Soal dengan ID % tidak ditemukan.', v_q_id;
            END IF;

            IF v_question.status <> 'Aktif' THEN
                RAISE EXCEPTION 'Soal "%" (%) tidak berstatus Aktif.', v_question.title, v_question.code;
            END IF;

            IF p_branch_id IS NOT NULL AND v_question.branch_id IS NOT NULL AND v_question.branch_id <> p_branch_id THEN
                RAISE EXCEPTION 'Ketidaksesuaian cabang: Soal "%" berada pada cabang berbeda.', v_question.title;
            END IF;

            IF p_level_id IS NOT NULL AND v_question.level_id IS NOT NULL AND v_question.level_id <> p_level_id THEN
                RAISE EXCEPTION 'Ketidaksesuaian jenjang: Soal "%" berada pada jenjang berbeda.', v_question.title;
            END IF;

            v_all_q_ids := array_append(v_all_q_ids, v_q_id::text);
        END LOOP;
    END LOOP;

    FOR v_res_elem IN SELECT * FROM jsonb_array_elements(p_results)
    LOOP
        v_participant_id := (v_res_elem ->> 'participantId')::uuid;

        SELECT * INTO v_sp FROM public.stage_participations
        WHERE stage_id = p_stage_id AND participant_id = v_participant_id AND tenant_id = p_tenant_id
        LIMIT 1;

        IF NOT FOUND THEN
            INSERT INTO public.stage_participations (
                id, tenant_id, stage_id, participant_id, lottery_number, status, created_at, updated_at
            ) VALUES (
                gen_random_uuid(), p_tenant_id, p_stage_id, v_participant_id,
                (SELECT lottery_number FROM public.participants WHERE id = v_participant_id),
                'Belum Dimulai', v_now, v_now
            ) RETURNING * INTO v_sp;
        END IF;

        DELETE FROM public.assigned_maqras
        WHERE stage_participation_id = v_sp.id
          AND tenant_id = p_tenant_id
          AND id NOT IN (
              SELECT assigned_maqra_id FROM public.judge_assessments
              WHERE stage_participation_id = v_sp.id AND status = 'finalized'
          );

        FOR v_q_id_text IN SELECT * FROM jsonb_array_elements_text(v_res_elem -> 'questionIds')
        LOOP
            v_q_id := v_q_id_text::uuid;
            v_new_maqra_id := gen_random_uuid();

            INSERT INTO public.assigned_maqras (
                id, tenant_id, stage_participation_id, question_id, assigned_at, assigned_by, method, notes
            ) VALUES (
                v_new_maqra_id, p_tenant_id, v_sp.id, v_q_id, v_now, v_real_actor_id, 'undian', p_notes
            );

            v_assigned_maqras := v_assigned_maqras || jsonb_build_object(
                'id', v_new_maqra_id,
                'participantId', v_participant_id,
                'stageParticipationId', v_sp.id,
                'questionId', v_q_id
            );
        END LOOP;

        UPDATE public.stage_participations
        SET status = CASE WHEN status = 'Maqra Belum Ditetapkan' THEN 'Belum Dimulai' ELSE status END,
            updated_at = v_now
        WHERE id = v_sp.id;
    END LOOP;

    INSERT INTO public.lottery_draw_logs (
        id, tenant_id, stage_id, stage_name, branch_id, branch_name, level_id, level_name,
        actor_id, actor_name, questions_per_participant, participant_ids, question_pool_ids,
        draw_results, notes, created_at
    ) VALUES (
        v_draw_log_id, p_tenant_id, p_stage_id, p_stage_name, p_branch_id, p_branch_name, p_level_id, p_level_name,
        v_real_actor_id, v_real_actor_name, p_questions_per_participant, v_all_p_ids, v_all_q_ids,
        p_results, p_notes, v_now
    );

    INSERT INTO public.audit_logs (
        tenant_id, actor_id, actor_name, action, target, summary, outcome
    ) VALUES (
        p_tenant_id, v_real_actor_id, v_real_actor_name, 'LOTTERY_DRAW_COMMITTED',
        'Stage: ' || p_stage_name || ', Branch: ' || COALESCE(p_branch_name, '-'),
        'Penetapan undian maqra atomik untuk ' || jsonb_array_length(p_results)::text || ' peserta (Log ID: ' || v_draw_log_id::text || ')',
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Penetapan undian maqra berhasil dicatat secara atomik di database.',
        'drawLogId', v_draw_log_id,
        'actorId', v_real_actor_id,
        'actorName', v_real_actor_name,
        'assignedMaqras', v_assigned_maqras
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.commit_lottery_draw(UUID, UUID, VARCHAR, UUID, VARCHAR, UUID, VARCHAR, UUID, VARCHAR, JSONB, INT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.commit_lottery_draw(UUID, UUID, VARCHAR, UUID, VARCHAR, UUID, VARCHAR, UUID, VARCHAR, JSONB, INT, TEXT) TO authenticated;

CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_raw_username TEXT;
    v_username TEXT;
    v_name TEXT;
    v_uid_short TEXT;
BEGIN
    v_uid_short := LOWER(SUBSTRING(REPLACE(NEW.id::text, '-', '') FROM 1 FOR 6));

    v_raw_username := COALESCE(
        NULLIF(TRIM(NEW.raw_user_meta_data ->> 'username'), ''),
        SPLIT_PART(COALESCE(NEW.email, 'user_' || v_uid_short), '@', 1)
    );

    v_username := LOWER(v_raw_username);
    v_username := REGEXP_REPLACE(v_username, '[^a-z0-9_.-]+', '_', 'g');
    v_username := REGEXP_REPLACE(v_username, '^[_.-]+|[_.-]+$', '', 'g');

    IF v_username IN ('admin', 'superadmin', 'root', 'support') THEN
        v_username := 'user_' || v_uid_short;
    END IF;

    IF LENGTH(v_username) < 3 THEN
        v_username := 'user_' || v_uid_short;
    END IF;

    IF LENGTH(v_username) > 30 THEN
        v_username := LEFT(v_username, 30);
        v_username := REGEXP_REPLACE(v_username, '[_.-]+$', '', 'g');
    END IF;

    IF EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE LOWER(p.username) = LOWER(v_username)
          AND p.id <> NEW.id
    ) THEN
        v_username := LEFT(v_username, 23) || '_' || v_uid_short;
    END IF;

    v_name := COALESCE(
        NULLIF(TRIM(NEW.raw_user_meta_data ->> 'name'), ''),
        NULLIF(TRIM(NEW.raw_user_meta_data ->> 'full_name'), ''),
        SPLIT_PART(COALESCE(NEW.email, 'Pengguna MTQ'), '@', 1)
    );

    INSERT INTO public.profiles (id, username, name, email, role)
    VALUES (NEW.id, v_username, v_name, NEW.email, 'judge')
    ON CONFLICT (id) DO UPDATE
    SET email = EXCLUDED.email,
        updated_at = now();

    RETURN NEW;
END;
$$;

-- ------------------------------------------------------------------------------
-- FASE 2 — PENENTUAN PERINGKAT, KELULUSAN, DAN JUARA (SERVER-AUTHORITATIVE)
-- ------------------------------------------------------------------------------
ALTER TABLE public.competition_rule_configs
    ADD COLUMN IF NOT EXISTS level_id UUID REFERENCES public.levels(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT now();

ALTER TABLE public.competition_rule_configs
    DROP CONSTRAINT IF EXISTS competition_rule_configs_tenant_id_branch_id_key;

CREATE UNIQUE INDEX IF NOT EXISTS idx_competition_rule_configs_unique_scope
    ON public.competition_rule_configs (
        tenant_id,
        COALESCE(branch_id, '00000000-0000-0000-0000-000000000000'::uuid),
        COALESCE(level_id, '00000000-0000-0000-0000-000000000000'::uuid)
    );

ALTER TABLE public.rubric_fields
    ADD COLUMN IF NOT EXISTS weight NUMERIC NOT NULL DEFAULT 1;

DO $$
BEGIN
    ALTER TABLE public.rubric_fields DROP CONSTRAINT IF EXISTS rubric_fields_weight_check;
    ALTER TABLE public.rubric_fields
        ADD CONSTRAINT rubric_fields_weight_check CHECK (weight > 0);
END $$;

ALTER TABLE public.stages
    ADD COLUMN IF NOT EXISTS champion_count INT NOT NULL DEFAULT 3;

DO $$
BEGIN
    ALTER TABLE public.stages DROP CONSTRAINT IF EXISTS stages_champion_count_check;
    ALTER TABLE public.stages
        ADD CONSTRAINT stages_champion_count_check CHECK (champion_count >= 1);
END $$;

ALTER TABLE public.stage_participations
    ADD COLUMN IF NOT EXISTS champion_rank INT NULL,
    ADD COLUMN IF NOT EXISTS champion_title TEXT NULL;

ALTER TABLE public.stage_result_snapshots
    ALTER COLUMN branch_id DROP NOT NULL;

DROP INDEX IF EXISTS public.idx_stage_result_snapshots_unique_stage_branch;
CREATE UNIQUE INDEX IF NOT EXISTS idx_stage_result_snapshots_unique_stage
    ON public.stage_result_snapshots (tenant_id, stage_id);

CREATE OR REPLACE FUNCTION public.get_stage_completion_sql(p_stage_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_stage RECORD;
    v_required_judge_count INT := 0;
    v_total_participants INT := 0;
    v_completed_participants INT := 0;
    v_missing_maqra_participants INT := 0;
    v_total_required_units INT := 0;
    v_finalized_units INT := 0;
    v_sp RECORD;
    v_sp_maqra_count INT;
    v_sp_finalized_units INT;
    v_all_complete BOOLEAN := false;
    v_blocking_code TEXT := NULL;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    SELECT id, tenant_id, branch_id, name
    INTO v_stage
    FROM public.stages
    WHERE id = p_stage_id;

    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'stage_id', p_stage_id,
            'total_participants_count', 0,
            'completed_participants_count', 0,
            'incomplete_participants_count', 0,
            'missing_maqra_participants_count', 0,
            'required_judge_count', 0,
            'total_required_units', 0,
            'finalized_units_count', 0,
            'all_complete', false,
            'blocking_code', 'NO_PARTICIPANTS'
        );
    END IF;

    IF NOT (public.is_superadmin() OR v_stage.tenant_id IN (SELECT public.get_user_tenants())) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Anda tidak memiliki hak akses untuk membaca kelengkapan babak pada tenant lain.';
    END IF;

    SELECT COUNT(DISTINCT ja.judge_profile_id)
    INTO v_required_judge_count
    FROM public.judge_assignments ja
    JOIN public.tenant_memberships tm
      ON tm.tenant_id = ja.tenant_id
     AND tm.profile_id = ja.judge_profile_id
     AND tm.status = 'Aktif'
    WHERE ja.tenant_id = v_stage.tenant_id
      AND ja.stage_id = v_stage.id
      AND ja.status = 'Aktif'
      AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id);

    FOR v_sp IN
        SELECT sp.id, sp.participant_id
        FROM public.stage_participations sp
        WHERE sp.tenant_id = v_stage.tenant_id
          AND sp.stage_id = v_stage.id
    LOOP
        v_total_participants := v_total_participants + 1;

        SELECT COUNT(*)
        INTO v_sp_maqra_count
        FROM public.assigned_maqras am
        WHERE am.stage_participation_id = v_sp.id;

        IF v_sp_maqra_count = 0 THEN
            v_missing_maqra_participants := v_missing_maqra_participants + 1;
        END IF;

        v_total_required_units := v_total_required_units + (v_sp_maqra_count * v_required_judge_count);

        SELECT COUNT(*)
        INTO v_sp_finalized_units
        FROM public.assigned_maqras am
        JOIN (
            SELECT DISTINCT ja.judge_profile_id
            FROM public.judge_assignments ja
            JOIN public.tenant_memberships tm
              ON tm.tenant_id = ja.tenant_id
             AND tm.profile_id = ja.judge_profile_id
             AND tm.status = 'Aktif'
            WHERE ja.tenant_id = v_stage.tenant_id
              AND ja.stage_id = v_stage.id
              AND ja.status = 'Aktif'
              AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
        ) active_judges ON true
        JOIN public.judge_assessments asm
          ON asm.stage_participation_id = v_sp.id
         AND asm.assigned_maqra_id = am.id
         AND asm.judge_profile_id = active_judges.judge_profile_id
         AND asm.status = 'finalized'
         AND asm.is_locked = true
        WHERE am.stage_participation_id = v_sp.id;

        v_finalized_units := v_finalized_units + v_sp_finalized_units;

        IF v_sp_maqra_count >= 1
           AND v_required_judge_count >= 1
           AND v_sp_finalized_units = (v_sp_maqra_count * v_required_judge_count)
        THEN
            v_completed_participants := v_completed_participants + 1;
        END IF;
    END LOOP;

    v_all_complete := (
        v_total_participants > 0
        AND v_required_judge_count > 0
        AND v_missing_maqra_participants = 0
        AND v_completed_participants = v_total_participants
    );

    IF v_total_participants = 0 THEN
        v_blocking_code := 'NO_PARTICIPANTS';
    ELSIF v_required_judge_count = 0 THEN
        v_blocking_code := 'NO_JUDGES';
    ELSIF v_missing_maqra_participants > 0 THEN
        v_blocking_code := 'NO_MAQRA';
    ELSIF v_completed_participants < v_total_participants THEN
        v_blocking_code := 'INCOMPLETE_ASSESSMENTS';
    END IF;

    RETURN jsonb_build_object(
        'stage_id', v_stage.id,
        'total_participants_count', v_total_participants,
        'completed_participants_count', v_completed_participants,
        'incomplete_participants_count', (v_total_participants - v_completed_participants),
        'missing_maqra_participants_count', v_missing_maqra_participants,
        'required_judge_count', v_required_judge_count,
        'total_required_units', v_total_required_units,
        'finalized_units_count', v_finalized_units,
        'all_complete', v_all_complete,
        'blocking_code', v_blocking_code
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.get_stage_completion_sql(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_stage_completion_sql(UUID) TO authenticated;

CREATE OR REPLACE FUNCTION public.calculate_assessment_score_sql(
    p_tenant_id UUID,
    p_rubric_version_id UUID,
    p_error_counts JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_rubric RECORD;
    v_field RECORD;
    v_cat RECORD;
    v_cat_key TEXT;
    v_count_val TEXT;
    v_count NUMERIC;
    v_target_field_name TEXT;
    v_field_max_deduction NUMERIC;
    v_deduction NUMERIC;
    v_rule_deduction_points NUMERIC;
    v_rule_max_deduction NUMERIC;
    v_crit_id UUID;
    v_crit_max_deduction NUMERIC;
    v_unit_deduction NUMERIC;
    v_raw_deduction NUMERIC;
    v_crit_deductions JSONB := '{}'::jsonb;
    v_field_deductions JSONB := '{}'::jsonb;
    v_field_scores JSONB := '{}'::jsonb;
    v_deductions JSONB := '{}'::jsonb;
    v_total_deductions NUMERIC := 0.00;
    v_final_score NUMERIC := 0.00;
    v_cur_crit_ded NUMERIC;
    v_allowed_crit NUMERIC;
    v_field_score NUMERIC;
BEGIN
    SELECT * INTO v_rubric FROM public.rubric_versions WHERE id = p_rubric_version_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Rubrik penilaian tidak ditemukan di database.';
    END IF;

    FOR v_field IN
        SELECT * FROM public.rubric_fields
        WHERE rubric_version_id = p_rubric_version_id
          AND status = 'Aktif'
        ORDER BY field_order ASC
    LOOP
        v_field_deductions := jsonb_set(v_field_deductions, ARRAY[v_field.name], '0'::jsonb);
        v_field_scores := jsonb_set(v_field_scores, ARRAY[v_field.name], to_jsonb(v_field.max_score));
    END LOOP;

    IF p_error_counts IS NOT NULL AND jsonb_typeof(p_error_counts) = 'object' THEN
        FOR v_cat_key, v_count_val IN
            SELECT key, value #>> '{}' FROM jsonb_each(p_error_counts)
        LOOP
            IF v_count_val IS NULL OR TRIM(v_count_val) = '' THEN
                CONTINUE;
            END IF;

            IF NOT (v_count_val ~ '^[0-9]+$') THEN
                RAISE EXCEPTION 'Jumlah kejadian kesalahan kategori % wajib berupa bilangan bulat non-negatif.', v_cat_key;
            END IF;

            v_count := v_count_val::numeric;
            IF v_count <= 0 THEN
                CONTINUE;
            END IF;

            SELECT * INTO v_cat
            FROM public.error_categories
            WHERE tenant_id = p_tenant_id
              AND (id::text = v_cat_key OR code = v_cat_key)
              AND status = 'Aktif'
            LIMIT 1;

            IF NOT FOUND THEN
                RAISE EXCEPTION 'Kategori kesalahan % tidak ditemukan atau tidak berstatus aktif pada tenant ini.', v_cat_key;
            END IF;

            v_target_field_name := NULL;
            IF v_cat.rubric_field_id IS NOT NULL THEN
                SELECT name INTO v_target_field_name
                FROM public.rubric_fields
                WHERE id = v_cat.rubric_field_id
                  AND rubric_version_id = p_rubric_version_id
                  AND status = 'Aktif';
            END IF;

            IF v_target_field_name IS NULL AND v_cat.criterion_id IS NOT NULL THEN
                SELECT rf.name INTO v_target_field_name
                FROM public.rubric_criteria rc
                JOIN public.rubric_fields rf ON rf.id = rc.rubric_field_id
                WHERE rc.id = v_cat.criterion_id
                  AND rf.rubric_version_id = p_rubric_version_id
                  AND rf.status = 'Aktif';
            END IF;

            IF v_target_field_name IS NULL AND v_cat.deduction_rule_id IS NOT NULL THEN
                SELECT rf.name INTO v_target_field_name
                FROM public.deduction_rules dr
                JOIN public.rubric_criteria rc ON rc.id = dr.criterion_id
                JOIN public.rubric_fields rf ON rf.id = rc.rubric_field_id
                WHERE dr.id = v_cat.deduction_rule_id
                  AND rf.rubric_version_id = p_rubric_version_id
                  AND rf.status = 'Aktif';
            END IF;

            IF v_target_field_name IS NULL THEN
                SELECT name INTO v_target_field_name
                FROM public.rubric_fields
                WHERE rubric_version_id = p_rubric_version_id
                  AND status = 'Aktif'
                  AND (
                      LOWER(name) = LOWER(v_cat.name)
                      OR LOWER(code) = LOWER(v_cat.code)
                      OR (v_cat.scope IS NOT NULL AND LOWER(name) = LOWER(v_cat.scope))
                  )
                LIMIT 1;
            END IF;

            IF v_target_field_name IS NULL AND (v_rubric.code = 'RUBRIC-SENI-BACA-2025' OR v_rubric.name ILIKE '%Seni Baca%') THEN
                IF v_cat.name ILIKE '%tajwid%' OR v_cat.name ILIKE '%makharij%' OR v_cat.code IN ('tjw', 'mkh', 'idg') OR COALESCE(v_cat.scope, '') ILIKE '%tajwid%' THEN
                    v_target_field_name := 'Tajwid';
                ELSIF v_cat.name ILIKE '%fashahah%' OR v_cat.name ILIKE '%fasahah%' OR v_cat.name ILIKE '%waqf%' OR v_cat.code = 'fsh' OR COALESCE(v_cat.scope, '') ILIKE '%fashahah%' THEN
                    v_target_field_name := 'Fashahah';
                ELSIF v_cat.name ILIKE '%lagu%' OR v_cat.name ILIKE '%irama%' OR v_cat.code IN ('lag', 'lgu') OR COALESCE(v_cat.scope, '') ILIKE '%lagu%' THEN
                    v_target_field_name := 'Lagu';
                ELSIF v_cat.name ILIKE '%suara%' OR v_cat.name ILIKE '%vokal%' OR v_cat.code IN ('sua', 'sur') OR COALESCE(v_cat.scope, '') ILIKE '%suara%' THEN
                    v_target_field_name := 'Suara';
                END IF;
            END IF;

            IF v_target_field_name IS NULL THEN
                RAISE EXCEPTION 'Kategori kesalahan "%" belum terpetakan ke bidang rubrik aktif pada rubrik "%". Dilarang fallback ke bidang lain.', v_cat.name, v_rubric.name;
            END IF;

            v_unit_deduction := v_cat.default_deduction;
            v_raw_deduction := ROUND(v_count * v_unit_deduction, 2);

            IF v_cat.deduction_rule_id IS NOT NULL THEN
                SELECT dr.deduction_points, dr.max_deduction
                INTO v_rule_deduction_points, v_rule_max_deduction
                FROM public.deduction_rules dr
                WHERE dr.id = v_cat.deduction_rule_id;

                IF FOUND THEN
                    IF v_rule_deduction_points IS NOT NULL THEN
                        v_unit_deduction := v_rule_deduction_points;
                        v_raw_deduction := ROUND(v_count * v_unit_deduction, 2);
                    END IF;
                    IF v_rule_max_deduction IS NOT NULL AND v_rule_max_deduction >= 0 THEN
                        v_raw_deduction := LEAST(v_raw_deduction, v_rule_max_deduction);
                    END IF;
                END IF;
            END IF;

            IF v_cat.max_deduction IS NOT NULL AND v_cat.max_deduction >= 0 THEN
                v_raw_deduction := LEAST(v_raw_deduction, v_cat.max_deduction);
            END IF;

            IF v_cat.criterion_id IS NOT NULL THEN
                SELECT rc.id, rc.max_deduction
                INTO v_crit_id, v_crit_max_deduction
                FROM public.rubric_criteria rc
                WHERE rc.id = v_cat.criterion_id;

                IF FOUND AND v_crit_max_deduction IS NOT NULL AND v_crit_max_deduction >= 0 THEN
                    v_cur_crit_ded := COALESCE((v_crit_deductions ->> v_crit_id::text)::numeric, 0.00);
                    v_allowed_crit := GREATEST(0.00, v_crit_max_deduction - v_cur_crit_ded);
                    v_raw_deduction := LEAST(v_raw_deduction, v_allowed_crit);
                    v_crit_deductions := jsonb_set(
                        v_crit_deductions,
                        ARRAY[v_crit_id::text],
                        to_jsonb(ROUND(v_cur_crit_ded + v_raw_deduction, 2))
                    );
                END IF;
            END IF;

            v_deductions := jsonb_set(v_deductions, ARRAY[v_cat_key], to_jsonb(v_raw_deduction));

            v_deduction := COALESCE((v_field_deductions ->> v_target_field_name)::numeric, 0.00) + v_raw_deduction;
            v_field_deductions := jsonb_set(v_field_deductions, ARRAY[v_target_field_name], to_jsonb(ROUND(v_deduction, 2)));
        END LOOP;
    END IF;

    v_total_deductions := 0.00;
    v_final_score := 0.00;

    FOR v_field IN
        SELECT * FROM public.rubric_fields
        WHERE rubric_version_id = p_rubric_version_id
          AND status = 'Aktif'
        ORDER BY field_order ASC
    LOOP
        v_deduction := COALESCE((v_field_deductions ->> v_field.name)::numeric, 0.00);
        v_field_max_deduction := COALESCE(v_field.max_deduction, (v_field.max_score - v_field.min_score));
        v_deduction := LEAST(v_deduction, v_field_max_deduction);
        v_deduction := ROUND(v_deduction, 2);

        v_field_score := GREATEST(v_field.min_score, LEAST(v_field.max_score, v_field.max_score - v_deduction));
        v_field_score := ROUND(v_field_score, 2);

        v_field_scores := jsonb_set(v_field_scores, ARRAY[v_field.name], to_jsonb(v_field_score));
        v_field_deductions := jsonb_set(v_field_deductions, ARRAY[v_field.name], to_jsonb(v_deduction));

        v_total_deductions := v_total_deductions + v_deduction;
        v_final_score := v_final_score + ROUND(v_field_score * COALESCE(v_field.weight, 1), 2);
    END LOOP;

    v_total_deductions := ROUND(v_total_deductions, 2);
    v_final_score := ROUND(v_final_score, 2);

    RETURN jsonb_build_object(
        'final_score', v_final_score,
        'total_deductions', v_total_deductions,
        'field_scores', v_field_scores,
        'field_deductions', v_field_deductions,
        'deductions', v_deductions
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.calculate_assessment_score_sql(UUID, UUID, JSONB) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.calculate_assessment_score_sql(UUID, UUID, JSONB) TO authenticated;

CREATE OR REPLACE FUNCTION public.get_field_score(
    p_field_scores JSONB,
    p_field_name TEXT
)
RETURNS NUMERIC
LANGUAGE plpgsql
IMMUTABLE
SET search_path = public, pg_temp
AS $$
DECLARE
    v_clean_name TEXT;
    v_upper_name TEXT;
    v_raw_val TEXT;
    v_key TEXT;
    v_val TEXT;
BEGIN
    IF p_field_scores IS NULL OR jsonb_typeof(p_field_scores) <> 'object' OR p_field_name IS NULL THEN
        RETURN NULL;
    END IF;

    v_clean_name := TRIM(p_field_name);
    IF v_clean_name = '' THEN
        RETURN NULL;
    END IF;

    v_upper_name := UPPER(v_clean_name);

    v_raw_val := p_field_scores ->> v_clean_name;

    IF v_raw_val IS NULL THEN
        CASE v_upper_name
            WHEN 'TAJWID', 'TJW' THEN
                v_raw_val := COALESCE(p_field_scores ->> 'Tajwid', p_field_scores ->> 'TJW', p_field_scores ->> 'tajwid', p_field_scores ->> 'tjw');
            WHEN 'FASHAHAH', 'FSH' THEN
                v_raw_val := COALESCE(p_field_scores ->> 'Fashahah', p_field_scores ->> 'FSH', p_field_scores ->> 'fashahah', p_field_scores ->> 'fsh');
            WHEN 'LAGU', 'LGU', 'LAG' THEN
                v_raw_val := COALESCE(p_field_scores ->> 'Lagu', p_field_scores ->> 'LGU', p_field_scores ->> 'LAG', p_field_scores ->> 'lagu', p_field_scores ->> 'lgu', p_field_scores ->> 'lag');
            WHEN 'SUARA', 'SUR', 'SUA' THEN
                v_raw_val := COALESCE(p_field_scores ->> 'Suara', p_field_scores ->> 'SUR', p_field_scores ->> 'SUA', p_field_scores ->> 'suara', p_field_scores ->> 'sur', p_field_scores ->> 'sua');
            WHEN 'TAHFIZH', 'THF' THEN
                v_raw_val := COALESCE(p_field_scores ->> 'Tahfizh', p_field_scores ->> 'THF', p_field_scores ->> 'tahfizh', p_field_scores ->> 'thf');
            WHEN 'ITQAN', 'ITQ' THEN
                v_raw_val := COALESCE(p_field_scores ->> 'Itqan', p_field_scores ->> 'ITQ', p_field_scores ->> 'itqan', p_field_scores ->> 'itq');
            ELSE
                NULL;
        END CASE;
    END IF;

    IF v_raw_val IS NULL THEN
        FOR v_key, v_val IN SELECT key, value #>> '{}' FROM jsonb_each(p_field_scores)
        LOOP
            IF UPPER(TRIM(v_key)) = v_upper_name THEN
                v_raw_val := v_val;
                EXIT;
            END IF;
        END LOOP;
    END IF;

    IF v_raw_val IS NULL OR NOT (TRIM(v_raw_val) ~ '^-?[0-9]+(\.[0-9]+)?$') THEN
        RETURN NULL;
    END IF;

    RETURN TRIM(v_raw_val)::numeric;
END;
$$;

CREATE OR REPLACE FUNCTION public.compare_tie_vectors(
    p_vec_a NUMERIC[],
    p_vec_b NUMERIC[]
)
RETURNS INT
LANGUAGE plpgsql
IMMUTABLE
SET search_path = public, pg_temp
AS $$
DECLARE
    v_len INT;
    v_i INT;
    v_a NUMERIC;
    v_b NUMERIC;
BEGIN
    v_len := GREATEST(COALESCE(array_length(p_vec_a, 1), 0), COALESCE(array_length(p_vec_b, 1), 0));
    IF v_len = 0 THEN
        RETURN 0;
    END IF;

    FOR v_i IN 1..v_len LOOP
        v_a := p_vec_a[v_i];
        v_b := p_vec_b[v_i];

        IF v_a IS NULL AND v_b IS NULL THEN
            CONTINUE;
        ELSIF v_a IS NOT NULL AND v_b IS NULL THEN
            RETURN -1;
        ELSIF v_a IS NULL AND v_b IS NOT NULL THEN
            RETURN 1;
        ELSIF v_a > v_b THEN
            RETURN -1;
        ELSIF v_a < v_b THEN
            RETURN 1;
        END IF;
    END LOOP;

    RETURN 0;
END;
$$;

CREATE OR REPLACE FUNCTION public.compute_stage_rankings(p_stage_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_stage RECORD;
    v_rule RECORD;
    v_has_rule BOOLEAN := false;
    v_active_rules_count INT := 0;
    v_tie_break_fields TEXT[];
    v_rubric_version_id UUID := NULL;
    v_has_custom_weights BOOLEAN := false;
    v_required_judge_count INT := 0;
    v_rankings JSONB := '[]'::jsonb;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    SELECT * INTO v_stage FROM public.stages WHERE id = p_stage_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan.';
    END IF;

    IF NOT (public.is_superadmin() OR v_stage.tenant_id IN (SELECT public.get_user_tenants())) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Anda tidak memiliki akses ke tenant babak ini.';
    END IF;

    SELECT COUNT(*) INTO v_active_rules_count
    FROM public.competition_rule_configs crc
    WHERE crc.tenant_id = v_stage.tenant_id
      AND crc.status = 'Aktif'
      AND (
          (v_stage.branch_id IS NOT NULL AND crc.branch_id = v_stage.branch_id)
          OR (v_stage.branch_id IS NULL AND crc.branch_id IS NULL)
      );

    IF v_active_rules_count > 1 THEN
        RAISE EXCEPTION 'Konflik konfigurasi aturan kompetisi: Ditemukan % aturan berstatus Aktif untuk cabang pada babak ini.', v_active_rules_count;
    END IF;

    SELECT * INTO v_rule
    FROM public.competition_rule_configs crc
    WHERE crc.tenant_id = v_stage.tenant_id
      AND crc.status = 'Aktif'
      AND (v_stage.branch_id IS NULL OR crc.branch_id = v_stage.branch_id OR crc.branch_id IS NULL)
    ORDER BY
        CASE WHEN v_stage.branch_id IS NOT NULL AND crc.branch_id = v_stage.branch_id THEN 0 ELSE 1 END ASC,
        crc.updated_at DESC,
        crc.created_at DESC
    LIMIT 1;

    v_has_rule := FOUND;

    IF v_has_rule AND v_rule.tie_break_order IS NOT NULL THEN
        SELECT COALESCE(
            ARRAY(
                SELECT TRIM(elem)
                FROM unnest(v_rule.tie_break_order) WITH ORDINALITY AS t(elem, ord)
                WHERE LOWER(TRIM(elem)) <> 'total' AND TRIM(elem) <> ''
                ORDER BY ord ASC
            ),
            ARRAY['Tajwid', 'Lagu', 'Fashahah', 'Suara']
        ) INTO v_tie_break_fields;
        v_rubric_version_id := v_rule.rubric_version_id;
    ELSE
        v_tie_break_fields := ARRAY['Tajwid', 'Lagu', 'Fashahah', 'Suara'];
    END IF;

    IF v_rubric_version_id IS NULL THEN
        SELECT jass.rubric_version_id INTO v_rubric_version_id
        FROM public.stage_participations sp
        JOIN public.judge_assessments jass ON jass.stage_participation_id = sp.id
        WHERE sp.stage_id = p_stage_id AND sp.tenant_id = v_stage.tenant_id
        LIMIT 1;
    END IF;

    IF v_rubric_version_id IS NULL THEN
        SELECT rv.id INTO v_rubric_version_id
        FROM public.rubric_versions rv
        WHERE rv.tenant_id = v_stage.tenant_id AND rv.status = 'Aktif'
        ORDER BY CASE WHEN v_stage.branch_id IS NOT NULL AND rv.branch_id = v_stage.branch_id THEN 0 ELSE 1 END ASC
        LIMIT 1;
    END IF;

    IF v_rubric_version_id IS NOT NULL THEN
        SELECT EXISTS (
            SELECT 1 FROM public.rubric_fields rf
            WHERE rf.rubric_version_id = v_rubric_version_id
              AND rf.status = 'Aktif'
              AND COALESCE(rf.weight, 1) <> 1
        ) INTO v_has_custom_weights;
    END IF;

    SELECT COUNT(DISTINCT ja.judge_profile_id) INTO v_required_judge_count
    FROM public.judge_assignments ja
    JOIN public.tenant_memberships tm
      ON tm.tenant_id = ja.tenant_id
     AND tm.profile_id = ja.judge_profile_id
     AND tm.status = 'Aktif'
    WHERE ja.tenant_id = v_stage.tenant_id
      AND ja.stage_id = p_stage_id
      AND ja.status = 'Aktif'
      AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id);

    WITH active_judges AS (
        SELECT DISTINCT ja.judge_profile_id
        FROM public.judge_assignments ja
        JOIN public.tenant_memberships tm
          ON tm.tenant_id = ja.tenant_id
         AND tm.profile_id = ja.judge_profile_id
         AND tm.status = 'Aktif'
        WHERE ja.tenant_id = v_stage.tenant_id
          AND ja.stage_id = p_stage_id
          AND ja.status = 'Aktif'
          AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
    ),
    valid_assessments AS (
        SELECT jass.*
        FROM public.judge_assessments jass
        JOIN active_judges aj ON aj.judge_profile_id = jass.judge_profile_id
        WHERE jass.tenant_id = v_stage.tenant_id
          AND jass.status = 'finalized'
          AND jass.is_locked = true
    ),
    participant_agg AS (
        SELECT
            sp.id AS stage_participation_id,
            sp.participant_id,
            p.name AS participant_name,
            sp.lottery_number,
            COALESCE(k.name, '-') AS kafilah_name,
            COALESCE(v_stage.branch_id, p.branch_id) AS branch_id,
            COALESCE(b.name, 'Semua Cabang') AS branch_name,
            (
                SELECT COUNT(*) FROM public.assigned_maqras am
                WHERE am.stage_participation_id = sp.id
            )::int AS maqra_count,
            (
                SELECT COUNT(*)
                FROM public.assigned_maqras am
                JOIN valid_assessments va
                  ON va.stage_participation_id = sp.id
                 AND va.assigned_maqra_id = am.id
                WHERE am.stage_participation_id = sp.id
            )::int AS finalized_units_count,
            (
                SELECT COUNT(DISTINCT va.judge_profile_id)
                FROM valid_assessments va
                WHERE va.stage_participation_id = sp.id
            )::int AS finalized_judge_count,
            (
                SELECT CASE
                    WHEN COUNT(va.id) = 0 THEN NULL
                    WHEN v_has_custom_weights AND v_rubric_version_id IS NOT NULL THEN
                        COALESCE(
                            (
                                SELECT ROUND(SUM(field_avg * COALESCE(rf.weight, 1)), 2)
                                FROM public.rubric_fields rf
                                CROSS JOIN LATERAL (
                                    SELECT AVG(public.get_field_score(va2.field_scores, rf.name)) AS field_avg
                                    FROM valid_assessments va2
                                    WHERE va2.stage_participation_id = sp.id
                                ) fa
                                WHERE rf.rubric_version_id = v_rubric_version_id
                                  AND rf.status = 'Aktif'
                                  AND fa.field_avg IS NOT NULL
                            ),
                            ROUND(AVG(va.final_score)::numeric, 2)
                        )
                    ELSE
                        ROUND(AVG(va.final_score)::numeric, 2)
                END
                FROM valid_assessments va
                WHERE va.stage_participation_id = sp.id
            ) AS computed_score,
            (
                SELECT COALESCE(
                    jsonb_object_agg(fname, fval) FILTER (WHERE fval IS NOT NULL),
                    '{}'::jsonb
                )
                FROM (
                    SELECT DISTINCT fname
                    FROM (
                        SELECT rf.name AS fname
                        FROM public.rubric_fields rf
                        WHERE rf.rubric_version_id = v_rubric_version_id
                          AND rf.status = 'Aktif'
                        UNION
                        SELECT unnest(v_tie_break_fields) AS fname
                    ) fn
                    WHERE fname IS NOT NULL AND TRIM(fname) <> ''
                ) all_fields
                CROSS JOIN LATERAL (
                    SELECT ROUND(AVG(public.get_field_score(va.field_scores, all_fields.fname)), 2) AS fval
                    FROM valid_assessments va
                    WHERE va.stage_participation_id = sp.id
                ) calc
            ) AS field_scores
        FROM public.stage_participations sp
        JOIN public.participants p ON p.id = sp.participant_id
        LEFT JOIN public.kafilahs k ON k.id = p.kafilah_id
        LEFT JOIN public.branches b ON b.id = COALESCE(v_stage.branch_id, p.branch_id)
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id
    ),
    participant_vectors AS (
        SELECT
            pa.*,
            (
                pa.maqra_count >= 1
                AND v_required_judge_count >= 1
                AND pa.finalized_units_count = (pa.maqra_count * v_required_judge_count)
            ) AS is_complete,
            CASE
                WHEN pa.computed_score IS NULL THEN NULL::numeric[]
                ELSE ARRAY[pa.computed_score] || COALESCE(
                    ARRAY(
                        SELECT (
                            SELECT ROUND(AVG(public.get_field_score(va.field_scores, crit_name)), 2)
                            FROM valid_assessments va
                            WHERE va.stage_participation_id = pa.stage_participation_id
                        )
                        FROM unnest(v_tie_break_fields) WITH ORDINALITY AS t(crit_name, ord)
                        ORDER BY ord ASC
                    ),
                    ARRAY[]::numeric[]
                )
            END AS tie_vector
        FROM participant_agg pa
    ),
    ranked_participants AS (
        SELECT
            pv.*,
            CASE
                WHEN pv.computed_score IS NULL THEN NULL::int
                ELSE (
                    1 + (
                        SELECT COUNT(*)
                        FROM participant_vectors other
                        WHERE other.computed_score IS NOT NULL
                          AND other.participant_id <> pv.participant_id
                          AND public.compare_tie_vectors(other.tie_vector, pv.tie_vector) < 0
                    )
                )::int
            END AS true_rank,
            CASE
                WHEN pv.computed_score IS NULL THEN false
                ELSE EXISTS (
                    SELECT 1
                    FROM participant_vectors other
                    WHERE other.computed_score IS NOT NULL
                      AND other.participant_id <> pv.participant_id
                      AND public.compare_tie_vectors(pv.tie_vector, other.tie_vector) = 0
                )
            END AS is_tied,
            CASE
                WHEN pv.computed_score IS NULL THEN false
                ELSE EXISTS (
                    SELECT 1
                    FROM participant_vectors other
                    WHERE other.computed_score IS NOT NULL
                      AND other.participant_id <> pv.participant_id
                      AND other.computed_score = pv.computed_score
                )
            END AS has_same_total_score
        FROM participant_vectors pv
    ),
    ordered_participants AS (
        SELECT
            rp.*,
            ROW_NUMBER() OVER (
                ORDER BY
                    CASE WHEN rp.computed_score IS NULL THEN 1 ELSE 0 END ASC,
                    rp.true_rank ASC NULLS LAST,
                    rp.lottery_number ASC NULLS LAST,
                    rp.participant_id ASC
            )::int AS display_order
        FROM ranked_participants rp
    )
    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'stage_participation_id', op.stage_participation_id,
                'participant_id', op.participant_id,
                'participant_name', op.participant_name,
                'lottery_number', op.lottery_number,
                'kafilah_name', op.kafilah_name,
                'branch_id', op.branch_id,
                'branch_name', op.branch_name,
                'computed_score', op.computed_score,
                'final_score', op.computed_score,
                'field_scores', op.field_scores,
                'tie_vector', to_jsonb(op.tie_vector),
                'rank', op.true_rank,
                'display_order', op.display_order,
                'is_tied', op.is_tied,
                'has_same_total_score', op.has_same_total_score,
                'is_complete', op.is_complete,
                'finalized_judge_count', op.finalized_judge_count,
                'required_judge_count', v_required_judge_count,
                'tie_break_note', CASE
                    WHEN op.is_tied THEN 'Nilai seri identik pada seluruh kriteria bidang (Perlu Keputusan Sidang Pleno / Resolusi Seri)'
                    WHEN op.has_same_total_score THEN 'Diselesaikan melalui urutan tie-break resmi (' || array_to_string(v_tie_break_fields, ' > ') || ')'
                    ELSE NULL
                END
            )
            ORDER BY op.display_order ASC
        ),
        '[]'::jsonb
    ) INTO v_rankings
    FROM ordered_participants op;

    RETURN jsonb_build_object(
        'stage_id', v_stage.id,
        'tenant_id', v_stage.tenant_id,
        'branch_id', v_stage.branch_id,
        'qualification_quota', v_stage.qualification_quota,
        'champion_count', COALESCE(v_stage.champion_count, 3),
        'rubric_version_id', v_rubric_version_id,
        'tie_break_order', CASE
            WHEN v_has_rule AND v_rule.tie_break_order IS NOT NULL THEN to_jsonb(v_rule.tie_break_order)
            ELSE to_jsonb(ARRAY['total'] || v_tie_break_fields)
        END,
        'required_judge_count', v_required_judge_count,
        'all_finalized', (
            v_required_judge_count >= 1
            AND jsonb_array_length(v_rankings) > 0
            AND NOT EXISTS (
                SELECT 1
                FROM jsonb_array_elements(v_rankings) elem
                WHERE COALESCE((elem ->> 'is_complete')::boolean, false) = false
            )
        ),
        'can_finalize', (
            v_required_judge_count >= 1
            AND jsonb_array_length(v_rankings) > 0
            AND NOT EXISTS (
                SELECT 1
                FROM jsonb_array_elements(v_rankings) elem
                WHERE COALESCE((elem ->> 'is_complete')::boolean, false) = false
            )
        ),
        'rankings', v_rankings
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.compute_stage_rankings(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.compute_stage_rankings(UUID) TO authenticated;

DROP FUNCTION IF EXISTS public.advance_stage_qualifiers(UUID, UUID, UUID[], JSONB, JSONB);

CREATE OR REPLACE FUNCTION public.advance_stage_qualifiers(
    p_stage_id UUID,
    p_next_stage_id UUID,
    p_qualified_participant_ids UUID[],
    p_override_reasons JSONB DEFAULT '{}'::jsonb,
    p_rankings_snapshot JSONB DEFAULT '[]'::jsonb,
    p_tie_resolution JSONB DEFAULT '{}'::jsonb
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_stage RECORD;
    v_next_stage public.stages%ROWTYPE;
    v_override_key TEXT;
    v_override_val TEXT;
    v_participation_count INT;
    v_qualified_count INT;
    v_assigned_judges_count INT;
    v_unassigned_maqra_count INT;
    v_incomplete_count INT;
    v_invalid_participant_count INT;
    v_unjustified_override_count INT;
    v_unresolved_critical_tie_count INT := 0;
    v_computed_data JSONB;
    v_rankings_arr JSONB;
    v_rubric_version_id UUID;
    v_tie_break_rule_used TEXT;
    v_champion_count INT;
    v_authoritative_snapshot JSONB;
    v_now TIMESTAMPTZ := now();
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    SELECT * INTO v_stage FROM public.stages WHERE id = p_stage_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan.';
    END IF;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'Babak ini sudah pernah difinalisasi sebelumnya.';
    END IF;

    IF NOT public.is_tenant_admin(v_stage.tenant_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Anda tidak memiliki wewenang administrator pada tenant ini.';
    END IF;

    SELECT * INTO v_actor FROM public.profiles WHERE id = v_actor_id;

    SELECT COUNT(*) INTO v_participation_count
    FROM public.stage_participations sp
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id;

    IF v_participation_count = 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Tidak ada peserta terdaftar pada babak ini.';
    END IF;

    v_qualified_count := COALESCE(array_length(p_qualified_participant_ids, 1), 0);
    v_champion_count := GREATEST(1, COALESCE(v_stage.champion_count, 3));

    IF p_next_stage_id IS NOT NULL THEN
        IF v_stage.qualification_quota <= 0 THEN
            RAISE EXCEPTION 'Kuota kelulusan pada babak ini tidak valid.';
        END IF;
        IF v_qualified_count > v_stage.qualification_quota THEN
            RAISE EXCEPTION 'Jumlah peserta yang diloloskan (%) melebihi kuota babak (%).', v_qualified_count, v_stage.qualification_quota;
        END IF;
    END IF;

    IF p_override_reasons IS NOT NULL AND jsonb_typeof(p_override_reasons) = 'object' THEN
        FOR v_override_key, v_override_val IN
            SELECT key, value #>> '{}' FROM jsonb_each(p_override_reasons)
        LOOP
            IF v_override_val IS NULL OR LENGTH(TRIM(v_override_val)) < 5 THEN
                RAISE EXCEPTION 'Pengesahan babak ditolak: Alasan override manual untuk peserta % wajib diisi minimal 5 karakter.', v_override_key;
            END IF;
        END LOOP;
    END IF;

    SELECT COUNT(DISTINCT ja.judge_profile_id) INTO v_assigned_judges_count
    FROM public.judge_assignments ja
    JOIN public.tenant_memberships tm
      ON tm.tenant_id = ja.tenant_id
     AND tm.profile_id = ja.judge_profile_id
     AND tm.status = 'Aktif'
    WHERE ja.tenant_id = v_stage.tenant_id
      AND ja.stage_id = p_stage_id
      AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
      AND ja.status = 'Aktif';

    IF v_assigned_judges_count = 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Belum ada penugasan majelis hakim resmi (judge_assignments) yang aktif pada babak ini.';
    END IF;

    IF v_qualified_count > 0 THEN
        SELECT COUNT(*) INTO v_invalid_participant_count
        FROM unnest(p_qualified_participant_ids) AS q_pid
        LEFT JOIN public.stage_participations sp
               ON sp.participant_id = q_pid
              AND sp.stage_id = p_stage_id
              AND sp.tenant_id = v_stage.tenant_id
        LEFT JOIN public.participants p
               ON p.id = q_pid
              AND p.tenant_id = v_stage.tenant_id
        WHERE sp.id IS NULL
           OR (v_stage.branch_id IS NOT NULL AND p.branch_id <> v_stage.branch_id);

        IF v_invalid_participant_count > 0 THEN
            RAISE EXCEPTION 'Pengesahan babak ditolak: Terdapat peserta lolos yang tidak terdaftar pada babak atau cabang lomba ini.';
        END IF;
    END IF;

    SELECT COUNT(*) INTO v_unassigned_maqra_count
    FROM public.stage_participations sp
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id
      AND NOT EXISTS (
          SELECT 1 FROM public.assigned_maqras am
          WHERE am.stage_participation_id = sp.id
            AND am.tenant_id = v_stage.tenant_id
      );

    IF v_unassigned_maqra_count > 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Masih terdapat % peserta yang belum memiliki penetapan maqra pada babak ini.', v_unassigned_maqra_count;
    END IF;

    SELECT COUNT(*) INTO v_incomplete_count
    FROM public.stage_participations sp
    JOIN public.assigned_maqras am
      ON am.stage_participation_id = sp.id
     AND am.tenant_id = sp.tenant_id
    CROSS JOIN (
        SELECT DISTINCT ja.judge_profile_id
        FROM public.judge_assignments ja
        JOIN public.tenant_memberships tm
          ON tm.tenant_id = ja.tenant_id
         AND tm.profile_id = ja.judge_profile_id
         AND tm.status = 'Aktif'
        WHERE ja.tenant_id = v_stage.tenant_id
          AND ja.stage_id = p_stage_id
          AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
          AND ja.status = 'Aktif'
    ) req_judges
    LEFT JOIN public.judge_assessments jass
           ON jass.stage_participation_id = sp.id
          AND jass.assigned_maqra_id = am.id
          AND jass.judge_profile_id = req_judges.judge_profile_id
          AND jass.status = 'finalized'
          AND jass.is_locked = true
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id
      AND jass.id IS NULL;

    IF v_incomplete_count > 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Masih terdapat % lembar penilaian (peserta x maqra x hakim) yang belum difinalisasi.', v_incomplete_count;
    END IF;

    IF p_next_stage_id IS NOT NULL THEN
        SELECT * INTO v_next_stage FROM public.stages WHERE id = p_next_stage_id FOR UPDATE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Babak lanjutan tidak ditemukan.';
        END IF;
        IF v_next_stage.tenant_id <> v_stage.tenant_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian tenant: Babak lanjutan berada pada tenant berbeda.';
        END IF;
        IF v_stage.branch_id IS NOT NULL AND v_next_stage.branch_id IS NOT NULL AND v_next_stage.branch_id <> v_stage.branch_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian cabang: Babak lanjutan berada pada cabang lomba berbeda.';
        END IF;
    END IF;

    PERFORM set_config('mtq.rpc_stage_finalize_active', 'true', true);
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    v_computed_data := public.compute_stage_rankings(p_stage_id);
    v_rankings_arr := COALESCE(v_computed_data -> 'rankings', '[]'::jsonb);
    v_rubric_version_id := NULLIF(v_computed_data ->> 'rubric_version_id', '')::uuid;
    SELECT COALESCE(string_agg(elem, ' > '), 'total > Tajwid > Lagu > Fashahah')
    INTO v_tie_break_rule_used
    FROM jsonb_array_elements_text(COALESCE(v_computed_data -> 'tie_break_order', '["total","Tajwid","Lagu","Fashahah"]'::jsonb)) AS elem;

    WITH parsed_rankings AS (
        SELECT
            (elem ->> 'stage_participation_id')::uuid AS stage_participation_id,
            (elem ->> 'participant_id')::uuid AS participant_id,
            elem ->> 'lottery_number' AS lottery_number,
            (elem ->> 'computed_score')::numeric AS computed_score,
            (elem ->> 'rank')::int AS true_rank,
            (elem ->> 'display_order')::int AS display_order,
            COALESCE((elem ->> 'is_tied')::boolean, false) AS is_tied
        FROM jsonb_array_elements(v_rankings_arr) AS elem
    ),
    tie_groups AS (
        SELECT
            pr.true_rank,
            COUNT(*) AS group_size,
            MIN(pr.display_order) AS min_order,
            MAX(pr.display_order) AS max_order,
            BOOL_OR(
                p_tie_resolution IS NOT NULL
                AND jsonb_typeof(p_tie_resolution) = 'object'
                AND (p_tie_resolution ? pr.participant_id::text)
            ) AS has_tie_resolution,
            BOOL_OR(
                p_override_reasons IS NOT NULL
                AND jsonb_typeof(p_override_reasons) = 'object'
                AND LENGTH(TRIM(COALESCE(p_override_reasons ->> pr.participant_id::text, ''))) >= 5
            ) AS has_override_reason
        FROM parsed_rankings pr
        WHERE pr.is_tied = true
        GROUP BY pr.true_rank
    )
    SELECT COUNT(*) INTO v_unresolved_critical_tie_count
    FROM tie_groups tg
    WHERE (
        (p_next_stage_id IS NOT NULL AND tg.min_order <= v_stage.qualification_quota AND tg.max_order > v_stage.qualification_quota)
        OR
        (p_next_stage_id IS NULL AND tg.true_rank <= v_champion_count)
    )
    AND NOT (tg.has_tie_resolution AND tg.has_override_reason);

    IF v_unresolved_critical_tie_count > 0 THEN
        RAISE EXCEPTION 'UNRESOLVED_CRITICAL_TIE: Pengesahan babak diblokir: Terjadi nilai seri identik pada seluruh kriteria tie-break di batas kuota atau podium juara. Keputusan wajib menyertakan resolusi seri (p_tie_resolution) dan alasan override resmi (p_override_reasons minimal 5 karakter).';
    END IF;

    WITH parsed_rankings AS (
        SELECT
            (elem ->> 'stage_participation_id')::uuid AS stage_participation_id,
            (elem ->> 'participant_id')::uuid AS participant_id,
            elem ->> 'lottery_number' AS lottery_number,
            (elem ->> 'computed_score')::numeric AS computed_score,
            (elem ->> 'rank')::int AS true_rank,
            (elem ->> 'display_order')::int AS display_order,
            COALESCE((elem ->> 'is_tied')::boolean, false) AS is_tied
        FROM jsonb_array_elements(v_rankings_arr) AS elem
    ),
    resolved_order AS (
        SELECT
            pr.stage_participation_id,
            pr.participant_id,
            pr.computed_score,
            pr.true_rank,
            pr.is_tied,
            ROW_NUMBER() OVER (
                ORDER BY
                    pr.true_rank ASC NULLS LAST,
                    CASE
                        WHEN pr.is_tied
                             AND p_tie_resolution IS NOT NULL
                             AND jsonb_typeof(p_tie_resolution) = 'object'
                             AND (p_tie_resolution ->> pr.participant_id::text) ~ '^[0-9]+(\.[0-9]+)?$'
                        THEN (p_tie_resolution ->> pr.participant_id::text)::numeric
                        ELSE NULL
                    END ASC NULLS LAST,
                    CASE
                        WHEN pr.is_tied
                             AND p_tie_resolution IS NOT NULL
                             AND jsonb_typeof(p_tie_resolution) = 'object'
                             AND LOWER(COALESCE(p_tie_resolution ->> pr.participant_id::text, '')) IN ('true', 'qualified', 'lolos', 'winner')
                        THEN 0
                        WHEN pr.is_tied AND (pr.participant_id = ANY(p_qualified_participant_ids))
                        THEN 0
                        ELSE 1
                    END ASC,
                    pr.display_order ASC
            )::int AS resolved_rank
        FROM parsed_rankings pr
    )
    UPDATE public.stage_participations sp
    SET final_score = ro.computed_score,
        rank = ro.resolved_rank
    FROM resolved_order ro
    WHERE sp.id = ro.stage_participation_id;

    IF p_next_stage_id IS NOT NULL THEN
        SELECT COUNT(*) INTO v_unjustified_override_count
        FROM public.stage_participations sp
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id
          AND (
              (sp.participant_id = ANY(p_qualified_participant_ids) AND sp.rank > v_stage.qualification_quota)
              OR
              (NOT (sp.participant_id = ANY(p_qualified_participant_ids)) AND sp.rank <= v_stage.qualification_quota)
          )
          AND LENGTH(TRIM(COALESCE(p_override_reasons ->> sp.participant_id::text, ''))) < 5;

        IF v_unjustified_override_count > 0 THEN
            RAISE EXCEPTION 'Pengesahan babak ditolak: Setiap perubahan kelulusan terhadap peringkat kuota (meloloskan di luar kuota atau menggugurkan di dalam kuota) wajib disertai alasan override minimal 5 karakter.';
        END IF;
    END IF;

    IF p_next_stage_id IS NOT NULL THEN
        UPDATE public.stage_participations sp
        SET is_qualified = (sp.participant_id = ANY(p_qualified_participant_ids)),
            champion_rank = NULL,
            champion_title = NULL,
            status = 'Lengkap',
            qualification_reason = COALESCE(
                NULLIF(TRIM(p_override_reasons ->> sp.participant_id::text), ''),
                CASE WHEN sp.participant_id = ANY(p_qualified_participant_ids) THEN 'Lolos Kuota Peringkat' ELSE 'Tidak Masuk Kuota' END
            ),
            finalized_at = v_now,
            updated_at = v_now
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id;
    ELSE
        UPDATE public.stage_participations sp
        SET is_qualified = false,
            champion_rank = CASE WHEN sp.rank <= v_champion_count THEN sp.rank ELSE NULL END,
            champion_title = CASE WHEN sp.rank <= v_champion_count THEN 'Juara ' || sp.rank::text ELSE NULL END,
            status = 'Lengkap',
            qualification_reason = COALESCE(
                NULLIF(TRIM(p_override_reasons ->> sp.participant_id::text), ''),
                CASE
                    WHEN sp.rank <= v_champion_count THEN 'Juara ' || sp.rank::text
                    ELSE 'Finalis Peringkat ' || sp.rank::text
                END
            ),
            finalized_at = v_now,
            updated_at = v_now
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id;
    END IF;

    UPDATE public.participants p
    SET status = CASE
        WHEN p_next_stage_id IS NOT NULL THEN
            CASE WHEN p.id = ANY(p_qualified_participant_ids) THEN 'Menunggu' ELSE 'Gugur' END
        ELSE 'Final'
    END,
    updated_at = v_now
    WHERE p.id IN (
        SELECT participant_id FROM public.stage_participations
        WHERE stage_id = p_stage_id AND tenant_id = v_stage.tenant_id
    );

    IF p_next_stage_id IS NOT NULL AND v_qualified_count > 0 THEN
        INSERT INTO public.stage_participations (
            id,
            tenant_id,
            stage_id,
            participant_id,
            lottery_number,
            status,
            created_at,
            updated_at
        )
        SELECT
            gen_random_uuid(),
            v_stage.tenant_id,
            v_next_stage.id,
            q_pid,
            (SELECT lottery_number FROM public.participants WHERE id = q_pid),
            'Belum Dimulai',
            v_now,
            v_now
        FROM unnest(p_qualified_participant_ids) AS q_pid
        WHERE NOT EXISTS (
            SELECT 1 FROM public.stage_participations sp_exist
            WHERE sp_exist.stage_id = v_next_stage.id
              AND sp_exist.participant_id = q_pid
        );
    END IF;

    UPDATE public.stages
    SET is_finalized = true,
        finalized_at = v_now,
        status = 'Selesai'
    WHERE id = p_stage_id;

    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'participant_id', sp.participant_id,
                'participantId', sp.participant_id,
                'participant_name', p.name,
                'participantName', p.name,
                'lottery_number', sp.lottery_number,
                'lotteryNumber', sp.lottery_number,
                'kafilah_name', COALESCE(k.name, '-'),
                'kafilahName', COALESCE(k.name, '-'),
                'branch_id', COALESCE(v_stage.branch_id, p.branch_id),
                'branchId', COALESCE(v_stage.branch_id, p.branch_id),
                'branch_name', COALESCE(b.name, 'Semua Cabang'),
                'branchName', COALESCE(b.name, 'Semua Cabang'),
                'stage_id', p_stage_id,
                'stageId', p_stage_id,
                'stage_name', v_stage.name,
                'stageName', v_stage.name,
                'final_score', sp.final_score,
                'totalScore', sp.final_score,
                'field_scores', COALESCE(r_elem -> 'field_scores', '{}'::jsonb),
                'fieldScores', COALESCE(r_elem -> 'field_scores', '{}'::jsonb),
                'rank', sp.rank,
                'is_qualified', sp.is_qualified,
                'isQualified', sp.is_qualified,
                'champion_rank', sp.champion_rank,
                'championRank', sp.champion_rank,
                'champion_title', sp.champion_title,
                'championTitle', sp.champion_title,
                'qualification_reason', sp.qualification_reason,
                'reason', sp.qualification_reason,
                'tieBreakResolvedBy', r_elem ->> 'tie_break_note'
            )
            ORDER BY sp.rank ASC, sp.lottery_number ASC
        ),
        '[]'::jsonb
    ) INTO v_authoritative_snapshot
    FROM public.stage_participations sp
    JOIN public.participants p ON p.id = sp.participant_id
    LEFT JOIN public.kafilahs k ON k.id = p.kafilah_id
    LEFT JOIN public.branches b ON b.id = COALESCE(v_stage.branch_id, p.branch_id)
    LEFT JOIN LATERAL (
        SELECT elem
        FROM jsonb_array_elements(v_rankings_arr) AS elem
        WHERE (elem ->> 'participant_id')::uuid = sp.participant_id
        LIMIT 1
    ) r_match(r_elem) ON true
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id;

    INSERT INTO public.stage_result_snapshots (
        tenant_id,
        stage_id,
        branch_id,
        quota,
        rubric_version_id,
        tie_break_rule_used,
        finalized_by,
        rankings_snapshot
    )
    VALUES (
        v_stage.tenant_id,
        p_stage_id,
        v_stage.branch_id,
        CASE WHEN p_next_stage_id IS NOT NULL THEN v_stage.qualification_quota ELSE v_champion_count END,
        v_rubric_version_id,
        v_tie_break_rule_used,
        v_actor_id,
        v_authoritative_snapshot
    )
    ON CONFLICT (tenant_id, stage_id) DO NOTHING;

    INSERT INTO public.audit_logs (tenant_id, actor_id, actor_name, action, target, summary, outcome)
    VALUES (
        v_stage.tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
        'STAGE_FINALIZED',
        'Stage: ' || v_stage.name || ' (ID: ' || p_stage_id::text || ')',
        CASE
            WHEN p_next_stage_id IS NOT NULL THEN
                'Pengesahan resmi babak ' || v_stage.name || ' dengan ' || v_qualified_count::text || ' peserta diloloskan ke ' || COALESCE(v_next_stage.name, 'Babak Lanjutan')
            ELSE
                'Pengesahan resmi hasil kejuaraan babak final ' || v_stage.name || ' dengan ' || LEAST(v_participation_count, v_champion_count)::text || ' juara ditetapkan.'
        END,
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Babak berhasil disahkan secara resmi dan peserta lolos telah dipindahkan.',
        'qualified_count', v_qualified_count,
        'champion_count', CASE WHEN p_next_stage_id IS NULL THEN LEAST(v_participation_count, v_champion_count) ELSE 0 END,
        'next_stage_id', p_next_stage_id
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.advance_stage_qualifiers(UUID, UUID, UUID[], JSONB, JSONB, JSONB) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.advance_stage_qualifiers(UUID, UUID, UUID[], JSONB, JSONB, JSONB) TO authenticated;

-- T7 (Audit Lanjutan): backfill 'Diverifikasi' hanya sekali, saat kolom pertama kali dibuat.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = 'participants' AND column_name = 'verification_status'
    ) THEN
        ALTER TABLE public.participants
          ADD COLUMN verification_status VARCHAR(20) NOT NULL DEFAULT 'Diajukan'
            CHECK (verification_status IN ('Diajukan', 'Diverifikasi', 'Ditolak'));
        UPDATE public.participants
        SET verification_status = 'Diverifikasi'
        WHERE verification_status = 'Diajukan';
    END IF;
END $$;

ALTER TABLE public.participants
  ADD COLUMN IF NOT EXISTS verification_note TEXT NULL,
  ADD COLUMN IF NOT EXISTS verified_by UUID NULL REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ NULL;

CREATE OR REPLACE FUNCTION public.verify_participant(
    p_tenant_id UUID,
    p_participant_id UUID,
    p_status VARCHAR,
    p_note TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_part public.participants%ROWTYPE;
    v_clean_note TEXT;
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Tidak terautentikasi.';
    END IF;

    IF NOT (public.is_tenant_admin(p_tenant_id) OR public.is_superadmin()) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator Tenant atau Superadmin yang berwenang memverifikasi berkas peserta.';
    END IF;

    IF p_status NOT IN ('Diajukan', 'Diverifikasi', 'Ditolak') THEN
        RAISE EXCEPTION 'Status verifikasi "%" tidak valid. Gunakan Diajukan, Diverifikasi, atau Ditolak.', p_status;
    END IF;

    v_clean_note := NULLIF(TRIM(COALESCE(p_note, '')), '');
    IF p_status = 'Ditolak' AND (v_clean_note IS NULL OR LENGTH(v_clean_note) < 3) THEN
        RAISE EXCEPTION 'VERIFICATION_NOTE_REQUIRED: Penolakan berkas peserta wajib menyertakan alasan penolakan (minimal 3 karakter).';
    END IF;

    SELECT * INTO v_part
    FROM public.participants
    WHERE id = p_participant_id AND tenant_id = p_tenant_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Peserta tidak ditemukan pada tenant ini.';
    END IF;

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    UPDATE public.participants
    SET verification_status = p_status,
        verification_note = v_clean_note,
        verified_by = v_actor_id,
        verified_at = now(),
        updated_at = now()
    WHERE id = p_participant_id
      AND tenant_id = p_tenant_id;

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    SELECT name, role INTO v_actor FROM public.profiles WHERE id = v_actor_id;

    INSERT INTO public.audit_logs (
        tenant_id, actor_id, actor_name, action, target, summary, outcome
    ) VALUES (
        p_tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
        'PARTICIPANT_VERIFICATION_UPDATED',
        'Participant: ' || v_part.name || ' (' || v_part.participant_code || ')',
        'Status verifikasi berkas peserta diubah menjadi ' || p_status || COALESCE(' — Catatan: ' || v_clean_note, ''),
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'participant_id', p_participant_id,
        'verification_status', p_status,
        'verification_note', v_clean_note,
        'verified_by', v_actor_id,
        'verified_at', now()
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.verify_participant(UUID, UUID, VARCHAR, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.verify_participant(UUID, UUID, VARCHAR, TEXT) TO authenticated;

ALTER TABLE public.lottery_draw_logs
  ADD COLUMN IF NOT EXISTS seed_hex TEXT NULL,
  ADD COLUMN IF NOT EXISTS seed_sha256 TEXT NULL,
  ADD COLUMN IF NOT EXISTS draw_mode VARCHAR(30) NOT NULL DEFAULT 'both'
    CHECK (draw_mode IN ('lottery_number', 'maqra', 'both'));

CREATE OR REPLACE FUNCTION public.lottery_sort_key(p_seed TEXT, p_a TEXT, p_b TEXT)
RETURNS TEXT
LANGUAGE sql
IMMUTABLE
STRICT
SET search_path = public, pg_temp
AS $$
    SELECT encode(sha256(convert_to(p_seed || ':' || p_a || ':' || p_b, 'UTF8')), 'hex');
$$;

CREATE OR REPLACE FUNCTION public.draw_lottery_server(
    p_tenant_id UUID,
    p_stage_id UUID,
    p_branch_id UUID DEFAULT NULL,
    p_level_id UUID DEFAULT NULL,
    p_questions_per_participant INT DEFAULT 1,
    p_draw_mode VARCHAR DEFAULT 'both',
    p_notes TEXT DEFAULT NULL,
    p_participant_ids UUID[] DEFAULT NULL,
    p_question_pool_ids UUID[] DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor_profile RECORD;
    v_actor_name VARCHAR(150);
    v_stage public.stages%ROWTYPE;
    v_branch_name VARCHAR(150);
    v_level_name VARCHAR(150);
    v_seed_hex TEXT;
    v_seed_sha256 TEXT;
    v_draw_version INT;
    v_draw_log_id UUID := gen_random_uuid();
    v_now TIMESTAMPTZ := now();
    v_unverified RECORD;
    v_part RECORD;
    v_sp public.stage_participations%ROWTYPE;
    v_idx INT := 0;
    v_new_lottery_no VARCHAR(30);
    v_used_q_ids UUID[] := ARRAY[]::uuid[];
    v_picked_q_ids UUID[];
    v_picked_q_codes TEXT[];
    v_first_q public.questions%ROWTYPE;
    v_q_id UUID;
    v_all_p_ids TEXT[] := ARRAY[]::text[];
    v_all_q_ids TEXT[] := ARRAY[]::text[];
    v_draw_results JSONB := '[]'::jsonb;
    v_target_count INT := 0;
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Tidak terautentikasi: Sesi pengguna tidak ditemukan.';
    END IF;

    IF NOT (public.is_tenant_admin(p_tenant_id) OR public.is_superadmin()) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator Tenant atau Superadmin yang berwenang menjalankan undian server.';
    END IF;

    IF p_draw_mode NOT IN ('lottery_number', 'maqra', 'both') THEN
        RAISE EXCEPTION 'Mode undian "%" tidak valid. Gunakan lottery_number, maqra, atau both.', p_draw_mode;
    END IF;

    IF COALESCE(p_questions_per_participant, 1) < 1 THEN
        RAISE EXCEPTION 'Jumlah maqra per peserta minimal 1.';
    END IF;

    SELECT * INTO v_stage FROM public.stages WHERE id = p_stage_id AND tenant_id = p_tenant_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan pada tenant ini.';
    END IF;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'STAGE_ALREADY_FINALIZED: Pengundian ditolak karena Babak "%" telah difinalisasi secara resmi.', v_stage.name;
    END IF;

    -- Blokir pengundian ulang apabila sudah ada lembar penilaian pada babak ini
    IF EXISTS (
        SELECT 1
        FROM public.judge_assessments ja
        JOIN public.stage_participations sp ON sp.id = ja.stage_participation_id
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = p_tenant_id
    ) THEN
        RAISE EXCEPTION 'STAGE_ASSESSMENTS_ALREADY_STARTED: Pengundian ditolak karena penilaian dewan hakim sudah dimulai pada babak "%".', v_stage.name;
    END IF;

    SELECT name, role INTO v_actor_profile FROM public.profiles WHERE id = v_actor_id;
    v_actor_name := COALESCE(NULLIF(TRIM(v_actor_profile.name), ''), 'Administrator MTQ');

    IF p_branch_id IS NOT NULL THEN
        SELECT name INTO v_branch_name FROM public.branches WHERE id = p_branch_id AND tenant_id = p_tenant_id;
    ELSIF v_stage.branch_id IS NOT NULL THEN
        SELECT name INTO v_branch_name FROM public.branches WHERE id = v_stage.branch_id AND tenant_id = p_tenant_id;
    END IF;

    IF p_level_id IS NOT NULL THEN
        SELECT name INTO v_level_name FROM public.levels WHERE id = p_level_id AND tenant_id = p_tenant_id;
    END IF;

    -- Periksa apakah ada peserta dalam cakupan undian yang belum berstatus 'Diverifikasi'
    SELECT p.id, p.name, p.verification_status
    INTO v_unverified
    FROM public.participants p
    LEFT JOIN public.stage_participations sp
      ON sp.participant_id = p.id
     AND sp.stage_id = p_stage_id
     AND sp.tenant_id = p_tenant_id
    WHERE p.tenant_id = p_tenant_id
      AND (
          (p_participant_ids IS NOT NULL AND array_length(p_participant_ids, 1) > 0 AND p.id = ANY(p_participant_ids))
          OR (
              (p_participant_ids IS NULL OR array_length(p_participant_ids, 1) IS NULL)
              AND (sp.id IS NOT NULL OR p.stage_id = p_stage_id OR (p.stage_id IS NULL AND v_stage.stage_order = 1))
              AND (COALESCE(p_branch_id, v_stage.branch_id) IS NULL OR p.branch_id = COALESCE(p_branch_id, v_stage.branch_id))
              AND (p_level_id IS NULL OR p.level_id = p_level_id)
          )
      )
      AND COALESCE(p.verification_status, 'Diajukan') <> 'Diverifikasi'
    LIMIT 1;

    IF FOUND THEN
        RAISE EXCEPTION 'PARTICIPANT_NOT_VERIFIED: Peserta "%" belum diverifikasi berkasnya (status: %). Hanya peserta berstatus Diverifikasi yang dapat mengikuti undian.', v_unverified.name, v_unverified.verification_status;
    END IF;

    -- Benih acak kriptografis di server. gen_random_bytes (pgcrypto) bila tersedia;
    -- jika tidak, gen_random_uuid() bawaan PostgreSQL 13+ (juga CSPRNG). Tidak ada fallback deterministik.
    BEGIN
        EXECUTE 'SELECT encode(gen_random_bytes(16), ''hex'')' INTO v_seed_hex;
    EXCEPTION WHEN undefined_function THEN
        v_seed_hex := replace(gen_random_uuid()::text, '-', '');
    END;
    IF v_seed_hex IS NULL OR length(v_seed_hex) < 32 THEN
        RAISE EXCEPTION 'LOTTERY_SEED_UNAVAILABLE: Benih acak server tidak dapat dibangkitkan.';
    END IF;

    -- SHA-256 asli (fungsi bawaan PostgreSQL 11+), dicatat agar benih dapat diverifikasi publik
    v_seed_sha256 := encode(sha256(convert_to(v_seed_hex, 'UTF8')), 'hex');

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    -- Acak urutan peserta secara deterministik dari benih (dapat direproduksi via verify_lottery_draw)
    FOR v_part IN
        SELECT p.*
        FROM public.participants p
        LEFT JOIN public.stage_participations sp
          ON sp.participant_id = p.id
         AND sp.stage_id = p_stage_id
         AND sp.tenant_id = p_tenant_id
        WHERE p.tenant_id = p_tenant_id
          AND COALESCE(p.verification_status, 'Diajukan') = 'Diverifikasi'
          AND (
              (p_participant_ids IS NOT NULL AND array_length(p_participant_ids, 1) > 0 AND p.id = ANY(p_participant_ids))
              OR (
                  (p_participant_ids IS NULL OR array_length(p_participant_ids, 1) IS NULL)
                  AND (sp.id IS NOT NULL OR p.stage_id = p_stage_id OR (p.stage_id IS NULL AND v_stage.stage_order = 1))
                  AND (COALESCE(p_branch_id, v_stage.branch_id) IS NULL OR p.branch_id = COALESCE(p_branch_id, v_stage.branch_id))
                  AND (p_level_id IS NULL OR p.level_id = p_level_id)
              )
          )
        ORDER BY public.lottery_sort_key(v_seed_hex, p.id::text, ''), p.id
    LOOP
        v_idx := v_idx + 1;
        v_target_count := v_target_count + 1;
        v_all_p_ids := array_append(v_all_p_ids, v_part.id::text);

        SELECT * INTO v_sp
        FROM public.stage_participations
        WHERE stage_id = p_stage_id
          AND participant_id = v_part.id
          AND tenant_id = p_tenant_id
        LIMIT 1;

        IF NOT FOUND THEN
            INSERT INTO public.stage_participations (
                id, tenant_id, stage_id, participant_id, lottery_number, status, created_at, updated_at
            ) VALUES (
                gen_random_uuid(), p_tenant_id, p_stage_id, v_part.id,
                v_part.lottery_number, 'Belum Dimulai', v_now, v_now
            ) RETURNING * INTO v_sp;
        END IF;

        IF p_draw_mode IN ('lottery_number', 'both') THEN
            v_new_lottery_no := LPAD(v_idx::text, 2, '0');
            UPDATE public.stage_participations
            SET lottery_number = v_new_lottery_no,
                updated_at = v_now
            WHERE id = v_sp.id;

            UPDATE public.participants
            SET stage_id = COALESCE(stage_id, p_stage_id),
                updated_at = v_now
            WHERE id = v_part.id
              AND tenant_id = p_tenant_id;
        ELSE
            v_new_lottery_no := COALESCE(v_sp.lottery_number, v_part.lottery_number, LPAD(v_idx::text, 2, '0'));
        END IF;

        v_picked_q_ids := ARRAY[]::uuid[];
        v_picked_q_codes := ARRAY[]::text[];

        IF p_draw_mode IN ('maqra', 'both') THEN
            -- Pilih p_questions_per_participant soal aktif yang sesuai 3D (cabang + jenjang + babak),
            -- prioritaskan soal yang belum terpakai pada batch ini (sampling without replacement sebelum daur ulang)
            SELECT
                ARRAY_AGG(sub.id ORDER BY sub.ord),
                ARRAY_AGG((sub.code || ' - ' || sub.title) ORDER BY sub.ord)
            INTO v_picked_q_ids, v_picked_q_codes
            FROM (
                SELECT
                    q.id,
                    q.code,
                    q.title,
                    ROW_NUMBER() OVER (
                        ORDER BY
                            CASE WHEN q.id = ANY(v_used_q_ids) THEN 1 ELSE 0 END ASC,
                            public.lottery_sort_key(v_seed_hex, v_part.id::text, q.id::text) ASC,
                            q.id ASC
                    ) AS ord
                FROM public.questions q
                WHERE q.tenant_id = p_tenant_id
                  AND q.status = 'Aktif'
                  AND (q.stage_id IS NULL OR q.stage_id = p_stage_id)
                  AND (COALESCE(p_branch_id, v_stage.branch_id, v_part.branch_id) IS NULL OR q.branch_id IS NULL OR q.branch_id = COALESCE(p_branch_id, v_stage.branch_id, v_part.branch_id))
                  AND (COALESCE(p_level_id, v_part.level_id) IS NULL OR q.level_id IS NULL OR q.level_id = COALESCE(p_level_id, v_part.level_id))
                  AND (p_question_pool_ids IS NULL OR array_length(p_question_pool_ids, 1) IS NULL OR q.id = ANY(p_question_pool_ids))
                LIMIT p_questions_per_participant
            ) sub;

            IF v_picked_q_ids IS NULL OR COALESCE(array_length(v_picked_q_ids, 1), 0) < p_questions_per_participant THEN
                RAISE EXCEPTION 'INSUFFICIENT_QUESTION_POOL: Jumlah soal aktif yang sesuai cabang/jenjang/babak tidak mencukupi untuk peserta "%" (butuh %, tersedia %).',
                    v_part.name, p_questions_per_participant, COALESCE(array_length(v_picked_q_ids, 1), 0);
            END IF;

            DELETE FROM public.assigned_maqras
            WHERE stage_participation_id = v_sp.id
              AND tenant_id = p_tenant_id;

            FOREACH v_q_id IN ARRAY v_picked_q_ids
            LOOP
                INSERT INTO public.assigned_maqras (
                    id, tenant_id, stage_participation_id, question_id, assigned_at, assigned_by, method, notes
                ) VALUES (
                    gen_random_uuid(),
                    p_tenant_id,
                    v_sp.id,
                    v_q_id,
                    v_now,
                    v_actor_id,
                    'undian',
                    COALESCE(p_notes, 'Undian Server Terverifikasi (SHA-256: ' || LEFT(v_seed_sha256, 12) || ')')
                );
                v_used_q_ids := array_append(v_used_q_ids, v_q_id);
                IF NOT (v_q_id::text = ANY(v_all_q_ids)) THEN
                    v_all_q_ids := array_append(v_all_q_ids, v_q_id::text);
                END IF;
            END LOOP;

            SELECT * INTO v_first_q FROM public.questions WHERE id = v_picked_q_ids[1];

            UPDATE public.stage_participations
            SET status = 'Belum Dimulai',
                updated_at = v_now
            WHERE id = v_sp.id;

            UPDATE public.participants
            SET stage_id = COALESCE(stage_id, p_stage_id),
                updated_at = v_now
            WHERE id = v_part.id
              AND tenant_id = p_tenant_id;
        ELSE
            -- Jika hanya mengundi nomor tampil, pertahankan daftar maqra yang sudah ada untuk catatan log
            SELECT
                COALESCE(ARRAY_AGG(q.id), ARRAY[]::uuid[]),
                COALESCE(ARRAY_AGG(q.code || ' - ' || q.title), ARRAY[]::text[])
            INTO v_picked_q_ids, v_picked_q_codes
            FROM public.assigned_maqras am
            JOIN public.questions q ON q.id = am.question_id
            WHERE am.stage_participation_id = v_sp.id;
        END IF;

        v_draw_results := v_draw_results || jsonb_build_array(
            jsonb_build_object(
                'participantId', v_part.id,
                'participantCode', v_part.participant_code,
                'participantName', v_part.name,
                'lotteryNumber', v_new_lottery_no,
                'questionIds', to_jsonb(v_picked_q_ids),
                'assignedQuestionIds', to_jsonb(v_picked_q_ids),
                'questionTitles', to_jsonb(v_picked_q_codes),
                'assignedQuestionCodes', to_jsonb(v_picked_q_codes)
            )
        );
    END LOOP;

    IF v_target_count = 0 THEN
        RAISE EXCEPTION 'NO_ELIGIBLE_PARTICIPANTS: Tidak ada peserta berstatus Diverifikasi yang ditemukan untuk cakupan undian ini.';
    END IF;

    SELECT COALESCE(MAX(draw_version), 0) + 1 INTO v_draw_version
    FROM public.lottery_draw_logs
    WHERE tenant_id = p_tenant_id AND stage_id = p_stage_id;

    INSERT INTO public.lottery_draw_logs (
        id, tenant_id, stage_id, stage_name, branch_id, branch_name, level_id, level_name,
        actor_id, actor_name, questions_per_participant, participant_ids, question_pool_ids,
        draw_results, draw_version, notes, seed_hex, seed_sha256, draw_mode, created_at
    ) VALUES (
        v_draw_log_id, p_tenant_id, p_stage_id, v_stage.name,
        COALESCE(p_branch_id, v_stage.branch_id), COALESCE(v_branch_name, 'Semua Cabang'),
        p_level_id, COALESCE(v_level_name, 'Semua Jenjang'),
        v_actor_id, v_actor_name, p_questions_per_participant,
        v_all_p_ids, v_all_q_ids,
        v_draw_results, v_draw_version,
        COALESCE(p_notes, 'Undian Server (' || p_draw_mode || ') SHA-256: ' || LEFT(v_seed_sha256, 16)),
        v_seed_hex, v_seed_sha256, p_draw_mode, v_now
    );

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    INSERT INTO public.audit_logs (
        tenant_id, actor_id, actor_name, action, target, summary, outcome, created_at
    ) VALUES (
        p_tenant_id, v_actor_id, v_actor_name,
        'LOTTERY_DRAW_COMMITTED',
        v_stage.name || ' - ' || COALESCE(v_branch_name, 'Semua Cabang'),
        'Undian Server (' || p_draw_mode || ') versi #' || v_draw_version || ': ' || v_target_count || ' peserta (SHA-256: ' || LEFT(v_seed_sha256, 12) || ').',
        'Success', v_now
    );

    RETURN jsonb_build_object(
        'success', true,
        'draw_log_id', v_draw_log_id,
        'draw_version', v_draw_version,
        'draw_mode', p_draw_mode,
        'seed_hex', v_seed_hex,
        'seed_sha256', v_seed_sha256,
        'participants_count', v_target_count,
        'results', v_draw_results
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.draw_lottery_server(UUID, UUID, UUID, UUID, INT, VARCHAR, TEXT, UUID[], UUID[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.draw_lottery_server(UUID, UUID, UUID, UUID, INT, VARCHAR, TEXT, UUID[], UUID[]) TO authenticated;

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS group_label VARCHAR(40) NOT NULL DEFAULT 'Kafilah / Utusan';

DO $$
DECLARE
    v_fn RECORD;
BEGIN
    FOR v_fn IN
        SELECT
            p.oid,
            n.nspname,
            p.proname,
            pg_get_function_identity_arguments(p.oid) AS ident_args,
            p.proconfig
        FROM pg_proc p
        JOIN pg_namespace n ON n.oid = p.pronamespace
        WHERE n.nspname = 'public'
          AND p.prosecdef = true
          AND p.prorettype <> 'pg_catalog.trigger'::regtype
    LOOP
        IF v_fn.proconfig IS NULL OR NOT EXISTS (
            SELECT 1 FROM unnest(v_fn.proconfig) cfg WHERE cfg LIKE 'search_path=%'
        ) THEN
            EXECUTE format(
                'ALTER FUNCTION %I.%I(%s) SET search_path = public, pg_temp',
                v_fn.nspname, v_fn.proname, v_fn.ident_args
            );
        END IF;

        EXECUTE format(
            'REVOKE EXECUTE ON FUNCTION %I.%I(%s) FROM PUBLIC, anon',
            v_fn.nspname, v_fn.proname, v_fn.ident_args
        );
        EXECUTE format(
            'GRANT EXECUTE ON FUNCTION %I.%I(%s) TO authenticated',
            v_fn.nspname, v_fn.proname, v_fn.ident_args
        );
    END LOOP;
END $$;


CREATE OR REPLACE FUNCTION public.verify_lottery_draw(p_draw_log_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_log RECORD;
    v_expected TEXT[];
    v_sha_ok BOOLEAN;
BEGIN
    SELECT * INTO v_log FROM public.lottery_draw_logs WHERE id = p_draw_log_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Log undian tidak ditemukan.';
    END IF;
    IF NOT (v_log.tenant_id IN (SELECT public.get_user_tenants()) OR public.is_superadmin()) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Log undian berada di luar tenant Anda.';
    END IF;
    IF v_log.seed_hex IS NULL THEN
        RETURN jsonb_build_object('verifiable', false, 'reason', 'Log ini dibuat sebelum undian dapat direproduksi (tanpa seed).');
    END IF;

    SELECT ARRAY_AGG(pid ORDER BY public.lottery_sort_key(v_log.seed_hex, pid, ''), pid::uuid)
    INTO v_expected
    FROM unnest(v_log.participant_ids) AS pid;

    v_sha_ok := encode(sha256(convert_to(v_log.seed_hex, 'UTF8')), 'hex') = v_log.seed_sha256;

    RETURN jsonb_build_object(
        'verifiable', true,
        'seed_sha256_valid', v_sha_ok,
        'participant_order_valid', v_expected = v_log.participant_ids,
        'expected_order', to_jsonb(v_expected),
        'recorded_order', to_jsonb(v_log.participant_ids)
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.lottery_sort_key(TEXT, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.lottery_sort_key(TEXT, TEXT, TEXT) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.draw_lottery_server(UUID, UUID, UUID, UUID, INT, VARCHAR, TEXT, UUID[], UUID[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.draw_lottery_server(UUID, UUID, UUID, UUID, INT, VARCHAR, TEXT, UUID[], UUID[]) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.verify_lottery_draw(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.verify_lottery_draw(UUID) TO authenticated;

-- ============================================================================
-- 20261116 — Pengerasan integritas hasil lomba (Audit Lanjutan Kelompok 1–2)
--   K1 Hasil babak yang disahkan tidak bisa diubah; kolom hasil hanya via RPC
--   K2 Lembar nilai wajib memakai maqra milik peserta yang sama
--   K3 Hakim hanya boleh memotong nilai di bidang tugasnya
--   K4 Log undian bersifat append-only
--   T1 Keputusan pleno wajib lengkap & valid untuk seluruh peserta seri
--   T2 Hakim yang sudah memfinalisasi nilai tidak bisa dinonaktifkan diam-diam
--   T3 Kategori kesalahan & aturan potongan terkunci setelah dipakai
--   T4 Peserta Ditolak tidak lagi memblokir undian
--   T5 Status verifikasi hanya lewat RPC; tidak bisa dicabut setelah penilaian dimulai
--   T8 Peringkat sementara (compute_stage_rankings) hanya untuk admin
-- ============================================================================

-- ---------------------------------------------------------------------------
-- K1. Imutabilitas stage_participations
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_stage_participation_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    -- mtq.rpc_participation_setup hanya dapat diset dari SQL sisi server (tidak dapat lewat Data API/PostgREST)
    v_rpc BOOLEAN := COALESCE(current_setting('mtq.rpc_stage_finalize_active', true), 'false') = 'true'
                  OR COALESCE(current_setting('mtq.rpc_participation_setup', true), 'false') = 'true';
    v_stage_id UUID;
    v_finalized BOOLEAN;
    v_stage RECORD;
BEGIN
    IF v_rpc THEN
        RETURN COALESCE(NEW, OLD);
    END IF;

    v_stage_id := CASE WHEN TG_OP = 'DELETE' THEN OLD.stage_id ELSE NEW.stage_id END;
    SELECT * INTO v_stage FROM public.stages WHERE id = v_stage_id;
    v_finalized := COALESCE(v_stage.is_finalized, false);

    IF TG_OP = 'DELETE' THEN
        IF v_finalized THEN
            RAISE EXCEPTION 'STAGE_RESULT_LOCKED: Data peserta pada babak "%" yang sudah disahkan tidak dapat dihapus.', v_stage.name;
        END IF;
        RETURN OLD;
    END IF;

    IF TG_OP = 'INSERT' THEN
        IF v_finalized THEN
            RAISE EXCEPTION 'STAGE_RESULT_LOCKED: Tidak dapat menambahkan peserta ke babak "%" yang sudah disahkan.', v_stage.name;
        END IF;
        -- Babak lanjutan: peserta hanya boleh masuk lewat pengesahan resmi bila babak sebelumnya sudah disahkan
        IF EXISTS (
            SELECT 1 FROM public.stages prev
            WHERE prev.tenant_id = v_stage.tenant_id
              AND prev.id <> v_stage.id
              AND prev.stage_order < v_stage.stage_order
              AND prev.is_finalized = true
              AND (v_stage.branch_id IS NULL OR prev.branch_id IS NULL OR prev.branch_id = v_stage.branch_id)
        ) THEN
            RAISE EXCEPTION 'STAGE_ENTRY_VIA_QUALIFICATION_ONLY: Peserta hanya dapat masuk ke babak "%" melalui pengesahan babak sebelumnya (advance_stage_qualifiers).', v_stage.name;
        END IF;
        IF NEW.final_score IS NOT NULL OR NEW.rank IS NOT NULL OR COALESCE(NEW.is_qualified, false) = true
           OR NEW.champion_rank IS NOT NULL OR NEW.champion_title IS NOT NULL THEN
            RAISE EXCEPTION 'STAGE_RESULT_RPC_ONLY: Nilai akhir, peringkat, kelulusan, dan gelar juara hanya dapat ditetapkan melalui pengesahan resmi.';
        END IF;
        RETURN NEW;
    END IF;

    -- UPDATE
    IF NEW.stage_id IS DISTINCT FROM OLD.stage_id OR NEW.participant_id IS DISTINCT FROM OLD.participant_id
       OR NEW.tenant_id IS DISTINCT FROM OLD.tenant_id THEN
        RAISE EXCEPTION 'STAGE_RESULT_LOCKED: Babak, peserta, atau tenant pada data partisipasi tidak dapat dipindahkan.';
    END IF;

    IF v_finalized AND (
        NEW.lottery_number IS DISTINCT FROM OLD.lottery_number
        OR NEW.status IS DISTINCT FROM OLD.status
        OR NEW.final_score IS DISTINCT FROM OLD.final_score
        OR NEW.rank IS DISTINCT FROM OLD.rank
        OR NEW.is_qualified IS DISTINCT FROM OLD.is_qualified
        OR NEW.champion_rank IS DISTINCT FROM OLD.champion_rank
        OR NEW.champion_title IS DISTINCT FROM OLD.champion_title
        OR NEW.qualification_reason IS DISTINCT FROM OLD.qualification_reason
        OR NEW.finalized_at IS DISTINCT FROM OLD.finalized_at
    ) THEN
        RAISE EXCEPTION 'STAGE_RESULT_LOCKED: Hasil babak "%" sudah disahkan dan tidak dapat diubah.', v_stage.name;
    END IF;

    IF NEW.final_score IS DISTINCT FROM OLD.final_score
       OR NEW.rank IS DISTINCT FROM OLD.rank
       OR NEW.is_qualified IS DISTINCT FROM OLD.is_qualified
       OR NEW.champion_rank IS DISTINCT FROM OLD.champion_rank
       OR NEW.champion_title IS DISTINCT FROM OLD.champion_title
       OR NEW.qualification_reason IS DISTINCT FROM OLD.qualification_reason THEN
        RAISE EXCEPTION 'STAGE_RESULT_RPC_ONLY: Nilai akhir, peringkat, kelulusan, dan gelar juara hanya dapat diubah melalui pengesahan resmi.';
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_stage_participation_integrity ON public.stage_participations;
CREATE TRIGGER trg_stage_participation_integrity
    BEFORE INSERT OR UPDATE OR DELETE ON public.stage_participations
    FOR EACH ROW EXECUTE FUNCTION public.enforce_stage_participation_integrity();

-- ---------------------------------------------------------------------------
-- K2. Lembar nilai wajib memakai maqra milik peserta yang sama
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_assessment_maqra_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM public.assigned_maqras am
        WHERE am.id = NEW.assigned_maqra_id
          AND am.stage_participation_id = NEW.stage_participation_id
    ) THEN
        RAISE EXCEPTION 'ASSESSMENT_MAQRA_MISMATCH: Maqra pada lembar penilaian bukan milik peserta tersebut.';
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_assessment_maqra_ownership ON public.judge_assessments;
CREATE TRIGGER trg_assessment_maqra_ownership
    BEFORE INSERT OR UPDATE OF assigned_maqra_id, stage_participation_id ON public.judge_assessments
    FOR EACH ROW EXECUTE FUNCTION public.enforce_assessment_maqra_ownership();

-- ---------------------------------------------------------------------------
-- K3. Daftar bidang yang boleh dipotong oleh seorang hakim pada sebuah lembar.
--     NULL = tanpa batasan (penugasan semua bidang / bidang tidak dapat dipetakan).
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_judge_allowed_fields(
    p_judge_id UUID,
    p_stage_participation_id UUID,
    p_rubric_version_id UUID
)
RETURNS TEXT[]
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_unrestricted BOOLEAN := false;
    v_fields TEXT[] := ARRAY[]::text[];
    v_ja RECORD;
    v_name TEXT;
BEGIN
    FOR v_ja IN
        SELECT ja.rubric_field_id, ja.judge_field
        FROM public.judge_assignments ja
        JOIN public.stage_participations sp ON sp.id = p_stage_participation_id
        JOIN public.stages s ON s.id = sp.stage_id
        JOIN public.participants p ON p.id = sp.participant_id
        WHERE ja.stage_id = sp.stage_id
          AND ja.tenant_id = sp.tenant_id
          AND ja.judge_profile_id = p_judge_id
          AND ja.status = 'Aktif'
          AND (ja.branch_id IS NULL OR ja.branch_id = p.branch_id OR ja.branch_id = s.branch_id)
    LOOP
        v_name := NULL;
        IF v_ja.rubric_field_id IS NOT NULL THEN
            SELECT rf.name INTO v_name FROM public.rubric_fields rf WHERE rf.id = v_ja.rubric_field_id;
        ELSIF NULLIF(TRIM(COALESCE(v_ja.judge_field, '')), '') IS NOT NULL THEN
            SELECT rf.name INTO v_name
            FROM public.rubric_fields rf
            WHERE rf.rubric_version_id = p_rubric_version_id
              AND rf.status = 'Aktif'
              AND (
                  LOWER(rf.name) = regexp_replace(LOWER(TRIM(v_ja.judge_field)), '^bidang\s+', '')
                  OR LOWER(rf.code) = regexp_replace(LOWER(TRIM(v_ja.judge_field)), '^bidang\s+', '')
              )
            LIMIT 1;
        END IF;

        IF v_name IS NULL THEN
            v_unrestricted := true;
        ELSE
            v_fields := array_append(v_fields, v_name);
        END IF;
    END LOOP;

    IF v_unrestricted OR COALESCE(array_length(v_fields, 1), 0) = 0 THEN
        RETURN NULL;
    END IF;
    RETURN v_fields;
END;
$$;

-- ---------------------------------------------------------------------------
-- K4. Log undian append-only
-- ---------------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_lottery_draw_logs_append_only ON public.lottery_draw_logs;
CREATE TRIGGER trg_lottery_draw_logs_append_only
    BEFORE UPDATE OR DELETE ON public.lottery_draw_logs
    FOR EACH ROW EXECUTE FUNCTION public.enforce_append_only_records();

-- ---------------------------------------------------------------------------
-- T2. Hakim yang sudah memfinalisasi nilai pada babak berjalan tidak dapat
--     dinonaktifkan / dipindahkan tanpa RPC beralasan.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.judge_has_finalized_sheets_in_open_stage(
    p_tenant_id UUID,
    p_judge_id UUID,
    p_stage_id UUID DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM public.judge_assessments jass
        JOIN public.stage_participations sp ON sp.id = jass.stage_participation_id
        JOIN public.stages s ON s.id = sp.stage_id
        WHERE jass.tenant_id = p_tenant_id
          AND jass.judge_profile_id = p_judge_id
          AND jass.status = 'finalized'
          AND s.is_finalized = false
          AND (p_stage_id IS NULL OR s.id = p_stage_id)
          AND EXISTS (
              SELECT 1 FROM public.judge_assignments ja
              WHERE ja.tenant_id = p_tenant_id
                AND ja.judge_profile_id = p_judge_id
                AND ja.stage_id = s.id
                AND ja.status = 'Aktif'
          )
    );
$$;

CREATE OR REPLACE FUNCTION public.enforce_judge_assignment_stability()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF COALESCE(current_setting('mtq.rpc_judge_change_active', true), 'false') = 'true' THEN
        RETURN COALESCE(NEW, OLD);
    END IF;

    IF OLD.status = 'Aktif' AND (
        TG_OP = 'DELETE'
        OR NEW.status IS DISTINCT FROM OLD.status
        OR NEW.judge_profile_id IS DISTINCT FROM OLD.judge_profile_id
        OR NEW.stage_id IS DISTINCT FROM OLD.stage_id
        OR NEW.branch_id IS DISTINCT FROM OLD.branch_id
        OR NEW.rubric_field_id IS DISTINCT FROM OLD.rubric_field_id
    ) AND public.judge_has_finalized_sheets_in_open_stage(OLD.tenant_id, OLD.judge_profile_id, OLD.stage_id) THEN
        RAISE EXCEPTION 'JUDGE_HAS_FINALIZED_SHEETS: Hakim ini sudah memfinalisasi lembar nilai pada babak yang belum disahkan. Perubahan penugasan akan mengubah nilai peserta; gunakan release_judge_with_reason dengan alasan tertulis.';
    END IF;

    RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trg_judge_assignment_stability ON public.judge_assignments;
CREATE TRIGGER trg_judge_assignment_stability
    BEFORE UPDATE OR DELETE ON public.judge_assignments
    FOR EACH ROW EXECUTE FUNCTION public.enforce_judge_assignment_stability();

CREATE OR REPLACE FUNCTION public.enforce_judge_membership_stability()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF COALESCE(current_setting('mtq.rpc_judge_change_active', true), 'false') = 'true' THEN
        RETURN COALESCE(NEW, OLD);
    END IF;

    IF OLD.status = 'Aktif' AND (TG_OP = 'DELETE' OR NEW.status IS DISTINCT FROM OLD.status)
       AND public.judge_has_finalized_sheets_in_open_stage(OLD.tenant_id, OLD.profile_id, NULL) THEN
        RAISE EXCEPTION 'JUDGE_HAS_FINALIZED_SHEETS: Akun ini sudah memfinalisasi lembar nilai pada babak yang belum disahkan dan tidak dapat dinonaktifkan langsung. Gunakan release_judge_with_reason dengan alasan tertulis.';
    END IF;

    RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trg_judge_membership_stability ON public.tenant_memberships;
CREATE TRIGGER trg_judge_membership_stability
    BEFORE UPDATE OR DELETE ON public.tenant_memberships
    FOR EACH ROW EXECUTE FUNCTION public.enforce_judge_membership_stability();

CREATE OR REPLACE FUNCTION public.release_judge_with_reason(
    p_tenant_id UUID,
    p_judge_profile_id UUID,
    p_reason TEXT,
    p_stage_id UUID DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID := auth.uid();
    v_actor RECORD;
    v_judge RECORD;
    v_count INT := 0;
BEGIN
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Tidak terautentikasi.';
    END IF;
    IF NOT (public.is_tenant_admin(p_tenant_id) OR public.is_superadmin()) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator Tenant atau Superadmin.';
    END IF;
    IF LENGTH(TRIM(COALESCE(p_reason, ''))) < 10 THEN
        RAISE EXCEPTION 'JUDGE_RELEASE_REASON_REQUIRED: Alasan pelepasan hakim wajib diisi minimal 10 karakter.';
    END IF;

    PERFORM set_config('mtq.rpc_judge_change_active', 'true', true);
    UPDATE public.judge_assignments ja
    SET status = 'Nonaktif'
    WHERE ja.tenant_id = p_tenant_id
      AND ja.judge_profile_id = p_judge_profile_id
      AND ja.status = 'Aktif'
      AND (p_stage_id IS NULL OR ja.stage_id = p_stage_id)
      AND EXISTS (SELECT 1 FROM public.stages s WHERE s.id = ja.stage_id AND s.is_finalized = false);
    GET DIAGNOSTICS v_count = ROW_COUNT;
    PERFORM set_config('mtq.rpc_judge_change_active', 'false', true);

    SELECT name, role INTO v_actor FROM public.profiles WHERE id = v_actor_id;
    SELECT name INTO v_judge FROM public.profiles WHERE id = p_judge_profile_id;
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);
    INSERT INTO public.audit_logs (tenant_id, actor_id, actor_name, action, target, summary, reason, outcome)
    VALUES (
        p_tenant_id, v_actor_id,
        COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
        'JUDGE_RELEASED',
        'Hakim: ' || COALESCE(v_judge.name, p_judge_profile_id::text),
        v_count || ' penugasan aktif pada babak berjalan dinonaktifkan. Lembar nilai hakim ini tidak lagi dihitung pada babak tersebut.',
        TRIM(p_reason),
        'Success'
    );

    RETURN jsonb_build_object('success', true, 'released_assignments', v_count);
END;
$$;

-- ---------------------------------------------------------------------------
-- T3. Kategori kesalahan & aturan potongan terkunci setelah dipakai lembar final
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.error_category_is_used(p_tenant_id UUID, p_category_id UUID, p_code TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.judge_assessments ja
        WHERE ja.tenant_id = p_tenant_id
          AND ja.status = 'finalized'
          AND (ja.error_counts ? p_category_id::text OR (p_code IS NOT NULL AND ja.error_counts ? p_code))
    );
$$;

CREATE OR REPLACE FUNCTION public.enforce_error_category_immutability()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        IF public.error_category_is_used(OLD.tenant_id, OLD.id, OLD.code) THEN
            RAISE EXCEPTION 'ERROR_CATEGORY_LOCKED: Kategori "%" sudah dipakai pada lembar nilai final dan tidak dapat dihapus. Nonaktifkan dan buat kategori baru.', OLD.name;
        END IF;
        RETURN OLD;
    END IF;

    IF (
        NEW.default_deduction IS DISTINCT FROM OLD.default_deduction
        OR NEW.max_deduction IS DISTINCT FROM OLD.max_deduction
        OR NEW.rubric_field_id IS DISTINCT FROM OLD.rubric_field_id
        OR NEW.criterion_id IS DISTINCT FROM OLD.criterion_id
        OR NEW.deduction_rule_id IS DISTINCT FROM OLD.deduction_rule_id
        OR NEW.code IS DISTINCT FROM OLD.code
        OR NEW.tenant_id IS DISTINCT FROM OLD.tenant_id
    ) AND public.error_category_is_used(OLD.tenant_id, OLD.id, OLD.code) THEN
        RAISE EXCEPTION 'ERROR_CATEGORY_LOCKED: Bobot/pemetaan kategori "%" sudah dipakai pada lembar nilai final dan tidak dapat diubah di tengah lomba. Buat kategori baru untuk lomba berikutnya.', OLD.name;
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_error_category_immutability ON public.error_categories;
CREATE TRIGGER trg_error_category_immutability
    BEFORE UPDATE OR DELETE ON public.error_categories
    FOR EACH ROW EXECUTE FUNCTION public.enforce_error_category_immutability();

CREATE OR REPLACE FUNCTION public.enforce_deduction_rule_immutability()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF (TG_OP = 'DELETE' OR NEW.deduction_points IS DISTINCT FROM OLD.deduction_points OR NEW.max_deduction IS DISTINCT FROM OLD.max_deduction)
       AND EXISTS (
           SELECT 1 FROM public.error_categories ec
           WHERE ec.deduction_rule_id = OLD.id
             AND public.error_category_is_used(ec.tenant_id, ec.id, ec.code)
       ) THEN
        RAISE EXCEPTION 'DEDUCTION_RULE_LOCKED: Aturan potongan ini sudah dipakai pada lembar nilai final dan tidak dapat diubah atau dihapus.';
    END IF;
    RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trg_deduction_rule_immutability ON public.deduction_rules;
CREATE TRIGGER trg_deduction_rule_immutability
    BEFORE UPDATE OR DELETE ON public.deduction_rules
    FOR EACH ROW EXECUTE FUNCTION public.enforce_deduction_rule_immutability();

-- ---------------------------------------------------------------------------
-- T5. Status verifikasi peserta hanya dapat diubah melalui verify_participant
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_verification_via_rpc()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF NEW.verification_status IS DISTINCT FROM OLD.verification_status
       AND COALESCE(current_setting('mtq.rpc_verify_active', true), 'false') <> 'true' THEN
        RAISE EXCEPTION 'VERIFICATION_RPC_ONLY: Status verifikasi peserta hanya dapat diubah melalui menu verifikasi berkas (verify_participant).';
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_verification_via_rpc ON public.participants;
CREATE TRIGGER trg_verification_via_rpc
    BEFORE UPDATE OF verification_status ON public.participants
    FOR EACH ROW EXECUTE FUNCTION public.enforce_verification_via_rpc();


CREATE OR REPLACE FUNCTION public.compute_stage_rankings(p_stage_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_stage RECORD;
    v_rule RECORD;
    v_has_rule BOOLEAN := false;
    v_active_rules_count INT := 0;
    v_tie_break_fields TEXT[];
    v_rubric_version_id UUID := NULL;
    v_has_custom_weights BOOLEAN := false;
    v_required_judge_count INT := 0;
    v_rankings JSONB := '[]'::jsonb;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    SELECT * INTO v_stage FROM public.stages WHERE id = p_stage_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan.';
    END IF;

    -- T8: peringkat sementara hanya untuk admin/superadmin (menjaga independensi dewan hakim sebelum pleno)
    IF NOT (public.is_superadmin() OR public.is_tenant_admin(v_stage.tenant_id)) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Peringkat sementara hanya dapat dilihat Administrator penyelenggara.';
    END IF;

    SELECT COUNT(*) INTO v_active_rules_count
    FROM public.competition_rule_configs crc
    WHERE crc.tenant_id = v_stage.tenant_id
      AND crc.status = 'Aktif'
      AND (
          (v_stage.branch_id IS NOT NULL AND crc.branch_id = v_stage.branch_id)
          OR (v_stage.branch_id IS NULL AND crc.branch_id IS NULL)
      );

    IF v_active_rules_count > 1 THEN
        RAISE EXCEPTION 'Konflik konfigurasi aturan kompetisi: Ditemukan % aturan berstatus Aktif untuk cabang pada babak ini.', v_active_rules_count;
    END IF;

    SELECT * INTO v_rule
    FROM public.competition_rule_configs crc
    WHERE crc.tenant_id = v_stage.tenant_id
      AND crc.status = 'Aktif'
      AND (v_stage.branch_id IS NULL OR crc.branch_id = v_stage.branch_id OR crc.branch_id IS NULL)
    ORDER BY
        CASE WHEN v_stage.branch_id IS NOT NULL AND crc.branch_id = v_stage.branch_id THEN 0 ELSE 1 END ASC,
        crc.updated_at DESC,
        crc.created_at DESC
    LIMIT 1;

    v_has_rule := FOUND;

    IF v_has_rule AND v_rule.tie_break_order IS NOT NULL THEN
        SELECT COALESCE(
            ARRAY(
                SELECT TRIM(elem)
                FROM unnest(v_rule.tie_break_order) WITH ORDINALITY AS t(elem, ord)
                WHERE LOWER(TRIM(elem)) <> 'total' AND TRIM(elem) <> ''
                ORDER BY ord ASC
            ),
            ARRAY['Tajwid', 'Lagu', 'Fashahah', 'Suara']
        ) INTO v_tie_break_fields;
        v_rubric_version_id := v_rule.rubric_version_id;
    ELSE
        v_tie_break_fields := ARRAY['Tajwid', 'Lagu', 'Fashahah', 'Suara'];
    END IF;

    IF v_rubric_version_id IS NULL THEN
        SELECT jass.rubric_version_id INTO v_rubric_version_id
        FROM public.stage_participations sp
        JOIN public.judge_assessments jass ON jass.stage_participation_id = sp.id
        WHERE sp.stage_id = p_stage_id AND sp.tenant_id = v_stage.tenant_id
        LIMIT 1;
    END IF;

    IF v_rubric_version_id IS NULL THEN
        SELECT rv.id INTO v_rubric_version_id
        FROM public.rubric_versions rv
        WHERE rv.tenant_id = v_stage.tenant_id AND rv.status = 'Aktif'
        ORDER BY CASE WHEN v_stage.branch_id IS NOT NULL AND rv.branch_id = v_stage.branch_id THEN 0 ELSE 1 END ASC
        LIMIT 1;
    END IF;

    IF v_rubric_version_id IS NOT NULL THEN
        SELECT EXISTS (
            SELECT 1 FROM public.rubric_fields rf
            WHERE rf.rubric_version_id = v_rubric_version_id
              AND rf.status = 'Aktif'
              AND COALESCE(rf.weight, 1) <> 1
        ) INTO v_has_custom_weights;
    END IF;

    SELECT COUNT(DISTINCT ja.judge_profile_id) INTO v_required_judge_count
    FROM public.judge_assignments ja
    JOIN public.tenant_memberships tm
      ON tm.tenant_id = ja.tenant_id
     AND tm.profile_id = ja.judge_profile_id
     AND tm.status = 'Aktif'
    WHERE ja.tenant_id = v_stage.tenant_id
      AND ja.stage_id = p_stage_id
      AND ja.status = 'Aktif'
      AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id);

    WITH active_judges AS (
        SELECT DISTINCT ja.judge_profile_id
        FROM public.judge_assignments ja
        JOIN public.tenant_memberships tm
          ON tm.tenant_id = ja.tenant_id
         AND tm.profile_id = ja.judge_profile_id
         AND tm.status = 'Aktif'
        WHERE ja.tenant_id = v_stage.tenant_id
          AND ja.stage_id = p_stage_id
          AND ja.status = 'Aktif'
          AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
    ),
    valid_assessments AS (
        SELECT jass.*
        FROM public.judge_assessments jass
        JOIN active_judges aj ON aj.judge_profile_id = jass.judge_profile_id
        -- K2: hanya lembar yang memakai maqra milik peserta itu sendiri
        JOIN public.assigned_maqras am_own
          ON am_own.id = jass.assigned_maqra_id
         AND am_own.stage_participation_id = jass.stage_participation_id
        WHERE jass.tenant_id = v_stage.tenant_id
          AND jass.status = 'finalized'
          AND jass.is_locked = true
    ),
    participant_agg AS (
        SELECT
            sp.id AS stage_participation_id,
            sp.participant_id,
            p.name AS participant_name,
            sp.lottery_number,
            COALESCE(k.name, '-') AS kafilah_name,
            COALESCE(v_stage.branch_id, p.branch_id) AS branch_id,
            COALESCE(b.name, 'Semua Cabang') AS branch_name,
            (
                SELECT COUNT(*) FROM public.assigned_maqras am
                WHERE am.stage_participation_id = sp.id
            )::int AS maqra_count,
            (
                SELECT COUNT(*)
                FROM public.assigned_maqras am
                JOIN valid_assessments va
                  ON va.stage_participation_id = sp.id
                 AND va.assigned_maqra_id = am.id
                WHERE am.stage_participation_id = sp.id
            )::int AS finalized_units_count,
            (
                SELECT COUNT(DISTINCT va.judge_profile_id)
                FROM valid_assessments va
                WHERE va.stage_participation_id = sp.id
            )::int AS finalized_judge_count,
            (
                SELECT CASE
                    WHEN COUNT(va.id) = 0 THEN NULL
                    WHEN v_has_custom_weights AND v_rubric_version_id IS NOT NULL THEN
                        COALESCE(
                            (
                                SELECT ROUND(SUM(field_avg * COALESCE(rf.weight, 1)), 2)
                                FROM public.rubric_fields rf
                                CROSS JOIN LATERAL (
                                    SELECT AVG(public.get_field_score(va2.field_scores, rf.name)) AS field_avg
                                    FROM valid_assessments va2
                                    WHERE va2.stage_participation_id = sp.id
                                ) fa
                                WHERE rf.rubric_version_id = v_rubric_version_id
                                  AND rf.status = 'Aktif'
                                  AND fa.field_avg IS NOT NULL
                            ),
                            ROUND(AVG(va.final_score)::numeric, 2)
                        )
                    ELSE
                        ROUND(AVG(va.final_score)::numeric, 2)
                END
                FROM valid_assessments va
                WHERE va.stage_participation_id = sp.id
            ) AS computed_score,
            (
                SELECT COALESCE(
                    jsonb_object_agg(fname, fval) FILTER (WHERE fval IS NOT NULL),
                    '{}'::jsonb
                )
                FROM (
                    SELECT DISTINCT fname
                    FROM (
                        SELECT rf.name AS fname
                        FROM public.rubric_fields rf
                        WHERE rf.rubric_version_id = v_rubric_version_id
                          AND rf.status = 'Aktif'
                        UNION
                        SELECT unnest(v_tie_break_fields) AS fname
                    ) fn
                    WHERE fname IS NOT NULL AND TRIM(fname) <> ''
                ) all_fields
                CROSS JOIN LATERAL (
                    SELECT ROUND(AVG(public.get_field_score(va.field_scores, all_fields.fname)), 2) AS fval
                    FROM valid_assessments va
                    WHERE va.stage_participation_id = sp.id
                ) calc
            ) AS field_scores
        FROM public.stage_participations sp
        JOIN public.participants p ON p.id = sp.participant_id
        LEFT JOIN public.kafilahs k ON k.id = p.kafilah_id
        LEFT JOIN public.branches b ON b.id = COALESCE(v_stage.branch_id, p.branch_id)
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id
    ),
    participant_vectors AS (
        SELECT
            pa.*,
            (
                pa.maqra_count >= 1
                AND v_required_judge_count >= 1
                AND pa.finalized_units_count = (pa.maqra_count * v_required_judge_count)
            ) AS is_complete,
            CASE
                WHEN pa.computed_score IS NULL THEN NULL::numeric[]
                ELSE ARRAY[pa.computed_score] || COALESCE(
                    ARRAY(
                        SELECT (
                            SELECT ROUND(AVG(public.get_field_score(va.field_scores, crit_name)), 2)
                            FROM valid_assessments va
                            WHERE va.stage_participation_id = pa.stage_participation_id
                        )
                        FROM unnest(v_tie_break_fields) WITH ORDINALITY AS t(crit_name, ord)
                        ORDER BY ord ASC
                    ),
                    ARRAY[]::numeric[]
                )
            END AS tie_vector
        FROM participant_agg pa
    ),
    ranked_participants AS (
        SELECT
            pv.*,
            CASE
                WHEN pv.computed_score IS NULL THEN NULL::int
                ELSE (
                    1 + (
                        SELECT COUNT(*)
                        FROM participant_vectors other
                        WHERE other.computed_score IS NOT NULL
                          AND other.participant_id <> pv.participant_id
                          AND public.compare_tie_vectors(other.tie_vector, pv.tie_vector) < 0
                    )
                )::int
            END AS true_rank,
            CASE
                WHEN pv.computed_score IS NULL THEN false
                ELSE EXISTS (
                    SELECT 1
                    FROM participant_vectors other
                    WHERE other.computed_score IS NOT NULL
                      AND other.participant_id <> pv.participant_id
                      AND public.compare_tie_vectors(pv.tie_vector, other.tie_vector) = 0
                )
            END AS is_tied,
            CASE
                WHEN pv.computed_score IS NULL THEN false
                ELSE EXISTS (
                    SELECT 1
                    FROM participant_vectors other
                    WHERE other.computed_score IS NOT NULL
                      AND other.participant_id <> pv.participant_id
                      AND other.computed_score = pv.computed_score
                )
            END AS has_same_total_score
        FROM participant_vectors pv
    ),
    ordered_participants AS (
        SELECT
            rp.*,
            ROW_NUMBER() OVER (
                ORDER BY
                    CASE WHEN rp.computed_score IS NULL THEN 1 ELSE 0 END ASC,
                    rp.true_rank ASC NULLS LAST,
                    rp.lottery_number ASC NULLS LAST,
                    rp.participant_id ASC
            )::int AS display_order
        FROM ranked_participants rp
    )
    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'stage_participation_id', op.stage_participation_id,
                'participant_id', op.participant_id,
                'participant_name', op.participant_name,
                'lottery_number', op.lottery_number,
                'kafilah_name', op.kafilah_name,
                'branch_id', op.branch_id,
                'branch_name', op.branch_name,
                'computed_score', op.computed_score,
                'final_score', op.computed_score,
                'field_scores', op.field_scores,
                'tie_vector', to_jsonb(op.tie_vector),
                'rank', op.true_rank,
                'display_order', op.display_order,
                'is_tied', op.is_tied,
                'has_same_total_score', op.has_same_total_score,
                'is_complete', op.is_complete,
                'finalized_judge_count', op.finalized_judge_count,
                'required_judge_count', v_required_judge_count,
                'tie_break_note', CASE
                    WHEN op.is_tied THEN 'Nilai seri identik pada seluruh kriteria bidang (Perlu Keputusan Sidang Pleno / Resolusi Seri)'
                    WHEN op.has_same_total_score THEN 'Diselesaikan melalui urutan tie-break resmi (' || array_to_string(v_tie_break_fields, ' > ') || ')'
                    ELSE NULL
                END
            )
            ORDER BY op.display_order ASC
        ),
        '[]'::jsonb
    ) INTO v_rankings
    FROM ordered_participants op;

    RETURN jsonb_build_object(
        'stage_id', v_stage.id,
        'tenant_id', v_stage.tenant_id,
        'branch_id', v_stage.branch_id,
        'qualification_quota', v_stage.qualification_quota,
        'champion_count', COALESCE(v_stage.champion_count, 3),
        'rubric_version_id', v_rubric_version_id,
        'tie_break_order', CASE
            WHEN v_has_rule AND v_rule.tie_break_order IS NOT NULL THEN to_jsonb(v_rule.tie_break_order)
            ELSE to_jsonb(ARRAY['total'] || v_tie_break_fields)
        END,
        'required_judge_count', v_required_judge_count,
        'all_finalized', (
            v_required_judge_count >= 1
            AND jsonb_array_length(v_rankings) > 0
            AND NOT EXISTS (
                SELECT 1
                FROM jsonb_array_elements(v_rankings) elem
                WHERE COALESCE((elem ->> 'is_complete')::boolean, false) = false
            )
        ),
        'can_finalize', (
            v_required_judge_count >= 1
            AND jsonb_array_length(v_rankings) > 0
            AND NOT EXISTS (
                SELECT 1
                FROM jsonb_array_elements(v_rankings) elem
                WHERE COALESCE((elem ->> 'is_complete')::boolean, false) = false
            )
        ),
        'rankings', v_rankings
    );
END;
$$;

CREATE OR REPLACE FUNCTION finalize_judge_assessment(
    p_assessment_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_assessment RECORD;
    v_sp RECORD;
    v_stage RECORD;
    v_calc JSONB;
    v_required_units INT;
    v_finalized_units INT;
    v_now TIMESTAMPTZ := now();
    v_allowed_fields TEXT[];
    v_foreign_fields TEXT;
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Permintaan tidak memiliki sesi autentikasi.';
    END IF;

    SELECT * INTO v_assessment FROM judge_assessments WHERE id = p_assessment_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Finalisasi ditolak: Lembar penilaian belum diinisialisasi di database.';
    END IF;

    IF v_assessment.judge_profile_id <> v_actor_id THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya hakim pemilik lembar penilaian yang berwenang mengunci nilai.';
    END IF;

    IF NOT is_assigned_judge(v_assessment.tenant_id, v_assessment.stage_participation_id, v_actor_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Anda tidak terdaftar pada penugasan majelis hakim resmi (judge_assignments) untuk babak dan cabang peserta ini.';
    END IF;

    IF v_assessment.status = 'finalized' OR v_assessment.is_locked THEN
        RAISE EXCEPTION 'Lembar penilaian ini sudah berstatus final dan terkunci.';
    END IF;

    SELECT * INTO v_sp FROM stage_participations WHERE id = v_assessment.stage_participation_id;
    SELECT * INTO v_stage FROM stages WHERE id = v_sp.stage_id;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'Finalisasi ditolak: Babak musabaqah ini telah ditutup/disahkan.';
    END IF;

    -- P0-01: Hitung ulang nilai resmi secara otoritatif dari error_counts mentah & rubrik database
    v_calc := calculate_assessment_score_sql(
        v_assessment.tenant_id,
        v_assessment.rubric_version_id,
        COALESCE(v_assessment.error_counts, '{}'::jsonb)
    );

    -- K3: hakim hanya boleh memotong nilai pada bidang tugasnya
    v_allowed_fields := public.get_judge_allowed_fields(v_actor_id, v_assessment.stage_participation_id, v_assessment.rubric_version_id);
    IF v_allowed_fields IS NOT NULL THEN
        SELECT string_agg(fd.key, ', ')
        INTO v_foreign_fields
        FROM jsonb_each_text(COALESCE(v_calc -> 'field_deductions', '{}'::jsonb)) AS fd(key, value)
        WHERE fd.value ~ '^-?[0-9]+(\.[0-9]+)?$'
          AND fd.value::numeric > 0
          AND NOT (fd.key = ANY(v_allowed_fields));
        IF v_foreign_fields IS NOT NULL THEN
            RAISE EXCEPTION 'JUDGE_FIELD_VIOLATION: Lembar ini memuat potongan pada bidang di luar tugas Anda (%). Bidang tugas: %.', v_foreign_fields, array_to_string(v_allowed_fields, ', ');
        END IF;
    END IF;

    -- Aktifkan flag transaksi lokal agar trigger imutabilitas mengizinkan finalisasi & audit resmi
    PERFORM set_config('mtq.rpc_finalize_active', 'true', true);
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    -- Kunci lembar penilaian dan simpan hasil perhitungan server resmi
    UPDATE judge_assessments
    SET status = 'finalized',
        is_locked = true,
        final_score = (v_calc ->> 'final_score')::numeric,
        total_deductions = (v_calc ->> 'total_deductions')::numeric,
        field_scores = (v_calc -> 'field_scores'),
        finalized_at = v_now,
        updated_at = v_now
    WHERE id = p_assessment_id;

    -- Hitung total kombinasi wajib (assigned_maqras x assigned_judges) untuk peserta ini
    SELECT COUNT(*) INTO v_required_units
    FROM assigned_maqras am
    CROSS JOIN (
        SELECT DISTINCT ja.judge_profile_id
        FROM judge_assignments ja
        JOIN participants p ON p.id = v_sp.participant_id
        WHERE ja.tenant_id = v_sp.tenant_id
          AND ja.stage_id = v_sp.stage_id
          AND (ja.branch_id IS NULL OR ja.branch_id = p.branch_id OR ja.branch_id = v_stage.branch_id)
          AND ja.status = 'Aktif'
    ) req_judges
    WHERE am.stage_participation_id = v_sp.id;

    SELECT COUNT(*) INTO v_finalized_units
    FROM assigned_maqras am
    JOIN judge_assessments jass
         ON jass.stage_participation_id = am.stage_participation_id
        AND jass.assigned_maqra_id = am.id
        AND jass.status = 'finalized'
        AND jass.is_locked = true
    WHERE am.stage_participation_id = v_sp.id;

    -- Perbarui status progres stage_participations
    UPDATE stage_participations
    SET status = CASE
            WHEN v_required_units > 0 AND v_finalized_units >= v_required_units THEN 'Lengkap'
            WHEN v_finalized_units > 0 THEN 'Menunggu Hakim Lain'
            ELSE 'Berlangsung'
        END,
        finalized_at = CASE
            WHEN v_required_units > 0 AND v_finalized_units >= v_required_units THEN v_now
            ELSE finalized_at
        END,
        updated_at = v_now
    WHERE id = v_sp.id;

    SELECT * INTO v_actor FROM profiles WHERE id = v_actor_id;

    INSERT INTO audit_logs (tenant_id, actor_id, actor_name, action, target, summary, outcome)
    VALUES (
        v_assessment.tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Dewan Hakim') || ' (judge)',
        'ASSESSMENT_FINALIZED',
        'Assessment ID: ' || p_assessment_id::text,
        'Finalisasi dan penguncian lembar penilaian dengan nilai akhir ' || v_assessment.final_score::text,
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Lembar penilaian berhasil dikunci dan difinalisasi secara permanen.',
        'participant_stage_status', CASE
            WHEN v_required_units > 0 AND v_finalized_units >= v_required_units THEN 'Lengkap'
            ELSE 'Menunggu Hakim Lain'
        END
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.advance_stage_qualifiers(
    p_stage_id UUID,
    p_next_stage_id UUID,
    p_qualified_participant_ids UUID[],
    p_override_reasons JSONB DEFAULT '{}'::jsonb,
    p_rankings_snapshot JSONB DEFAULT '[]'::jsonb,
    p_tie_resolution JSONB DEFAULT '{}'::jsonb
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_stage RECORD;
    v_next_stage public.stages%ROWTYPE;
    v_override_key TEXT;
    v_override_val TEXT;
    v_participation_count INT;
    v_qualified_count INT;
    v_assigned_judges_count INT;
    v_unassigned_maqra_count INT;
    v_incomplete_count INT;
    v_invalid_participant_count INT;
    v_unjustified_override_count INT;
    v_unresolved_critical_tie_count INT := 0;
    v_computed_data JSONB;
    v_rankings_arr JSONB;
    v_rubric_version_id UUID;
    v_tie_break_rule_used TEXT;
    v_champion_count INT;
    v_authoritative_snapshot JSONB;
    v_now TIMESTAMPTZ := now();
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    SELECT * INTO v_stage FROM public.stages WHERE id = p_stage_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan.';
    END IF;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'Babak ini sudah pernah difinalisasi sebelumnya.';
    END IF;

    IF NOT public.is_tenant_admin(v_stage.tenant_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Anda tidak memiliki wewenang administrator pada tenant ini.';
    END IF;

    SELECT * INTO v_actor FROM public.profiles WHERE id = v_actor_id;

    SELECT COUNT(*) INTO v_participation_count
    FROM public.stage_participations sp
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id;

    IF v_participation_count = 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Tidak ada peserta terdaftar pada babak ini.';
    END IF;

    v_qualified_count := COALESCE(array_length(p_qualified_participant_ids, 1), 0);
    v_champion_count := GREATEST(1, COALESCE(v_stage.champion_count, 3));

    IF p_next_stage_id IS NOT NULL THEN
        IF v_stage.qualification_quota <= 0 THEN
            RAISE EXCEPTION 'Kuota kelulusan pada babak ini tidak valid.';
        END IF;
        IF v_qualified_count > v_stage.qualification_quota THEN
            RAISE EXCEPTION 'Jumlah peserta yang diloloskan (%) melebihi kuota babak (%).', v_qualified_count, v_stage.qualification_quota;
        END IF;
    END IF;

    IF p_override_reasons IS NOT NULL AND jsonb_typeof(p_override_reasons) = 'object' THEN
        FOR v_override_key, v_override_val IN
            SELECT key, value #>> '{}' FROM jsonb_each(p_override_reasons)
        LOOP
            IF v_override_val IS NULL OR LENGTH(TRIM(v_override_val)) < 5 THEN
                RAISE EXCEPTION 'Pengesahan babak ditolak: Alasan override manual untuk peserta % wajib diisi minimal 5 karakter.', v_override_key;
            END IF;
        END LOOP;
    END IF;

    SELECT COUNT(DISTINCT ja.judge_profile_id) INTO v_assigned_judges_count
    FROM public.judge_assignments ja
    JOIN public.tenant_memberships tm
      ON tm.tenant_id = ja.tenant_id
     AND tm.profile_id = ja.judge_profile_id
     AND tm.status = 'Aktif'
    WHERE ja.tenant_id = v_stage.tenant_id
      AND ja.stage_id = p_stage_id
      AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
      AND ja.status = 'Aktif';

    IF v_assigned_judges_count = 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Belum ada penugasan majelis hakim resmi (judge_assignments) yang aktif pada babak ini.';
    END IF;

    IF v_qualified_count > 0 THEN
        SELECT COUNT(*) INTO v_invalid_participant_count
        FROM unnest(p_qualified_participant_ids) AS q_pid
        LEFT JOIN public.stage_participations sp
               ON sp.participant_id = q_pid
              AND sp.stage_id = p_stage_id
              AND sp.tenant_id = v_stage.tenant_id
        LEFT JOIN public.participants p
               ON p.id = q_pid
              AND p.tenant_id = v_stage.tenant_id
        WHERE sp.id IS NULL
           OR (v_stage.branch_id IS NOT NULL AND p.branch_id <> v_stage.branch_id);

        IF v_invalid_participant_count > 0 THEN
            RAISE EXCEPTION 'Pengesahan babak ditolak: Terdapat peserta lolos yang tidak terdaftar pada babak atau cabang lomba ini.';
        END IF;
    END IF;

    SELECT COUNT(*) INTO v_unassigned_maqra_count
    FROM public.stage_participations sp
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id
      AND NOT EXISTS (
          SELECT 1 FROM public.assigned_maqras am
          WHERE am.stage_participation_id = sp.id
            AND am.tenant_id = v_stage.tenant_id
      );

    IF v_unassigned_maqra_count > 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Masih terdapat % peserta yang belum memiliki penetapan maqra pada babak ini.', v_unassigned_maqra_count;
    END IF;

    SELECT COUNT(*) INTO v_incomplete_count
    FROM public.stage_participations sp
    JOIN public.assigned_maqras am
      ON am.stage_participation_id = sp.id
     AND am.tenant_id = sp.tenant_id
    CROSS JOIN (
        SELECT DISTINCT ja.judge_profile_id
        FROM public.judge_assignments ja
        JOIN public.tenant_memberships tm
          ON tm.tenant_id = ja.tenant_id
         AND tm.profile_id = ja.judge_profile_id
         AND tm.status = 'Aktif'
        WHERE ja.tenant_id = v_stage.tenant_id
          AND ja.stage_id = p_stage_id
          AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
          AND ja.status = 'Aktif'
    ) req_judges
    LEFT JOIN public.judge_assessments jass
           ON jass.stage_participation_id = sp.id
          AND jass.assigned_maqra_id = am.id
          AND jass.judge_profile_id = req_judges.judge_profile_id
          AND jass.status = 'finalized'
          AND jass.is_locked = true
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id
      AND jass.id IS NULL;

    IF v_incomplete_count > 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Masih terdapat % lembar penilaian (peserta x maqra x hakim) yang belum difinalisasi.', v_incomplete_count;
    END IF;

    IF p_next_stage_id IS NOT NULL THEN
        SELECT * INTO v_next_stage FROM public.stages WHERE id = p_next_stage_id FOR UPDATE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Babak lanjutan tidak ditemukan.';
        END IF;
        IF v_next_stage.tenant_id <> v_stage.tenant_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian tenant: Babak lanjutan berada pada tenant berbeda.';
        END IF;
        IF v_stage.branch_id IS NOT NULL AND v_next_stage.branch_id IS NOT NULL AND v_next_stage.branch_id <> v_stage.branch_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian cabang: Babak lanjutan berada pada cabang lomba berbeda.';
        END IF;
    END IF;

    PERFORM set_config('mtq.rpc_stage_finalize_active', 'true', true);
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    v_computed_data := public.compute_stage_rankings(p_stage_id);
    v_rankings_arr := COALESCE(v_computed_data -> 'rankings', '[]'::jsonb);
    v_rubric_version_id := NULLIF(v_computed_data ->> 'rubric_version_id', '')::uuid;
    SELECT COALESCE(string_agg(elem, ' > '), 'total > Tajwid > Lagu > Fashahah')
    INTO v_tie_break_rule_used
    FROM jsonb_array_elements_text(COALESCE(v_computed_data -> 'tie_break_order', '["total","Tajwid","Lagu","Fashahah"]'::jsonb)) AS elem;

    WITH parsed_rankings AS (
        SELECT
            (elem ->> 'stage_participation_id')::uuid AS stage_participation_id,
            (elem ->> 'participant_id')::uuid AS participant_id,
            elem ->> 'lottery_number' AS lottery_number,
            (elem ->> 'computed_score')::numeric AS computed_score,
            (elem ->> 'rank')::int AS true_rank,
            (elem ->> 'display_order')::int AS display_order,
            COALESCE((elem ->> 'is_tied')::boolean, false) AS is_tied
        FROM jsonb_array_elements(v_rankings_arr) AS elem
    ),
    tie_groups AS (
        SELECT
            pr.true_rank,
            COUNT(*) AS group_size,
            MIN(pr.display_order) AS min_order,
            MAX(pr.display_order) AS max_order,
            -- T1: SETIAP peserta dalam kelompok seri wajib punya urutan pleno (bilangan bulat) dan alasan >= 5 karakter
            BOOL_AND(
                p_tie_resolution IS NOT NULL
                AND jsonb_typeof(p_tie_resolution) = 'object'
                AND COALESCE(p_tie_resolution ->> pr.participant_id::text, '') ~ '^[0-9]+$'
            ) AS has_tie_resolution,
            BOOL_AND(
                p_override_reasons IS NOT NULL
                AND jsonb_typeof(p_override_reasons) = 'object'
                AND LENGTH(TRIM(COALESCE(p_override_reasons ->> pr.participant_id::text, ''))) >= 5
            ) AS has_override_reason,
            COUNT(DISTINCT CASE
                WHEN COALESCE(p_tie_resolution ->> pr.participant_id::text, '') ~ '^[0-9]+$'
                THEN (p_tie_resolution ->> pr.participant_id::text)::int
            END) AS distinct_positions,
            MIN(CASE WHEN COALESCE(p_tie_resolution ->> pr.participant_id::text, '') ~ '^[0-9]+$'
                     THEN (p_tie_resolution ->> pr.participant_id::text)::int END) AS min_position,
            MAX(CASE WHEN COALESCE(p_tie_resolution ->> pr.participant_id::text, '') ~ '^[0-9]+$'
                     THEN (p_tie_resolution ->> pr.participant_id::text)::int END) AS max_position
        FROM parsed_rankings pr
        WHERE pr.is_tied = true
        GROUP BY pr.true_rank
    )
    SELECT COUNT(*) INTO v_unresolved_critical_tie_count
    FROM tie_groups tg
    WHERE (
        (p_next_stage_id IS NOT NULL AND tg.min_order <= v_stage.qualification_quota AND tg.max_order > v_stage.qualification_quota)
        OR
        (p_next_stage_id IS NULL AND tg.true_rank <= v_champion_count)
    )
    AND NOT (
        tg.has_tie_resolution
        AND tg.has_override_reason
        AND tg.distinct_positions = tg.group_size
        AND tg.min_position = 1
        AND tg.max_position = tg.group_size
    );

    IF v_unresolved_critical_tie_count > 0 THEN
        RAISE EXCEPTION 'UNRESOLVED_CRITICAL_TIE: Pengesahan babak diblokir: Terjadi nilai seri identik pada seluruh kriteria tie-break di batas kuota atau podium juara. Keputusan pleno wajib mencakup SELURUH peserta yang seri dengan urutan unik 1..n (p_tie_resolution) dan alasan minimal 5 karakter untuk setiap peserta (p_override_reasons).';
    END IF;

    WITH parsed_rankings AS (
        SELECT
            (elem ->> 'stage_participation_id')::uuid AS stage_participation_id,
            (elem ->> 'participant_id')::uuid AS participant_id,
            elem ->> 'lottery_number' AS lottery_number,
            (elem ->> 'computed_score')::numeric AS computed_score,
            (elem ->> 'rank')::int AS true_rank,
            (elem ->> 'display_order')::int AS display_order,
            COALESCE((elem ->> 'is_tied')::boolean, false) AS is_tied
        FROM jsonb_array_elements(v_rankings_arr) AS elem
    ),
    resolved_order AS (
        SELECT
            pr.stage_participation_id,
            pr.participant_id,
            pr.computed_score,
            pr.true_rank,
            pr.is_tied,
            ROW_NUMBER() OVER (
                ORDER BY
                    pr.true_rank ASC NULLS LAST,
                    CASE
                        WHEN pr.is_tied
                             AND p_tie_resolution IS NOT NULL
                             AND jsonb_typeof(p_tie_resolution) = 'object'
                             AND (p_tie_resolution ->> pr.participant_id::text) ~ '^[0-9]+(\.[0-9]+)?$'
                        THEN (p_tie_resolution ->> pr.participant_id::text)::numeric
                        ELSE NULL
                    END ASC NULLS LAST,
                    CASE
                        WHEN pr.is_tied
                             AND p_tie_resolution IS NOT NULL
                             AND jsonb_typeof(p_tie_resolution) = 'object'
                             AND LOWER(COALESCE(p_tie_resolution ->> pr.participant_id::text, '')) IN ('true', 'qualified', 'lolos', 'winner')
                        THEN 0
                        WHEN pr.is_tied AND (pr.participant_id = ANY(p_qualified_participant_ids))
                        THEN 0
                        ELSE 1
                    END ASC,
                    pr.display_order ASC
            )::int AS resolved_rank
        FROM parsed_rankings pr
    )
    UPDATE public.stage_participations sp
    SET final_score = ro.computed_score,
        rank = ro.resolved_rank
    FROM resolved_order ro
    WHERE sp.id = ro.stage_participation_id;

    IF p_next_stage_id IS NOT NULL THEN
        SELECT COUNT(*) INTO v_unjustified_override_count
        FROM public.stage_participations sp
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id
          AND (
              (sp.participant_id = ANY(p_qualified_participant_ids) AND sp.rank > v_stage.qualification_quota)
              OR
              (NOT (sp.participant_id = ANY(p_qualified_participant_ids)) AND sp.rank <= v_stage.qualification_quota)
          )
          AND LENGTH(TRIM(COALESCE(p_override_reasons ->> sp.participant_id::text, ''))) < 5;

        IF v_unjustified_override_count > 0 THEN
            RAISE EXCEPTION 'Pengesahan babak ditolak: Setiap perubahan kelulusan terhadap peringkat kuota (meloloskan di luar kuota atau menggugurkan di dalam kuota) wajib disertai alasan override minimal 5 karakter.';
        END IF;
    END IF;

    IF p_next_stage_id IS NOT NULL THEN
        UPDATE public.stage_participations sp
        SET is_qualified = (sp.participant_id = ANY(p_qualified_participant_ids)),
            champion_rank = NULL,
            champion_title = NULL,
            status = 'Lengkap',
            qualification_reason = COALESCE(
                NULLIF(TRIM(p_override_reasons ->> sp.participant_id::text), ''),
                CASE WHEN sp.participant_id = ANY(p_qualified_participant_ids) THEN 'Lolos Kuota Peringkat' ELSE 'Tidak Masuk Kuota' END
            ),
            finalized_at = v_now,
            updated_at = v_now
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id;
    ELSE
        UPDATE public.stage_participations sp
        SET is_qualified = false,
            champion_rank = CASE WHEN sp.rank <= v_champion_count THEN sp.rank ELSE NULL END,
            champion_title = CASE WHEN sp.rank <= v_champion_count THEN 'Juara ' || sp.rank::text ELSE NULL END,
            status = 'Lengkap',
            qualification_reason = COALESCE(
                NULLIF(TRIM(p_override_reasons ->> sp.participant_id::text), ''),
                CASE
                    WHEN sp.rank <= v_champion_count THEN 'Juara ' || sp.rank::text
                    ELSE 'Finalis Peringkat ' || sp.rank::text
                END
            ),
            finalized_at = v_now,
            updated_at = v_now
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id;
    END IF;

    UPDATE public.participants p
    SET status = CASE
        WHEN p_next_stage_id IS NOT NULL THEN
            CASE WHEN p.id = ANY(p_qualified_participant_ids) THEN 'Menunggu' ELSE 'Gugur' END
        ELSE 'Final'
    END,
    updated_at = v_now
    WHERE p.id IN (
        SELECT participant_id FROM public.stage_participations
        WHERE stage_id = p_stage_id AND tenant_id = v_stage.tenant_id
    );

    IF p_next_stage_id IS NOT NULL AND v_qualified_count > 0 THEN
        INSERT INTO public.stage_participations (
            id,
            tenant_id,
            stage_id,
            participant_id,
            lottery_number,
            status,
            created_at,
            updated_at
        )
        SELECT
            gen_random_uuid(),
            v_stage.tenant_id,
            v_next_stage.id,
            q_pid,
            (SELECT lottery_number FROM public.participants WHERE id = q_pid),
            'Belum Dimulai',
            v_now,
            v_now
        FROM unnest(p_qualified_participant_ids) AS q_pid
        WHERE NOT EXISTS (
            SELECT 1 FROM public.stage_participations sp_exist
            WHERE sp_exist.stage_id = v_next_stage.id
              AND sp_exist.participant_id = q_pid
        );
    END IF;

    UPDATE public.stages
    SET is_finalized = true,
        finalized_at = v_now,
        status = 'Selesai'
    WHERE id = p_stage_id;

    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'participant_id', sp.participant_id,
                'participantId', sp.participant_id,
                'participant_name', p.name,
                'participantName', p.name,
                'lottery_number', sp.lottery_number,
                'lotteryNumber', sp.lottery_number,
                'kafilah_name', COALESCE(k.name, '-'),
                'kafilahName', COALESCE(k.name, '-'),
                'branch_id', COALESCE(v_stage.branch_id, p.branch_id),
                'branchId', COALESCE(v_stage.branch_id, p.branch_id),
                'branch_name', COALESCE(b.name, 'Semua Cabang'),
                'branchName', COALESCE(b.name, 'Semua Cabang'),
                'stage_id', p_stage_id,
                'stageId', p_stage_id,
                'stage_name', v_stage.name,
                'stageName', v_stage.name,
                'final_score', sp.final_score,
                'totalScore', sp.final_score,
                'field_scores', COALESCE(r_elem -> 'field_scores', '{}'::jsonb),
                'fieldScores', COALESCE(r_elem -> 'field_scores', '{}'::jsonb),
                'rank', sp.rank,
                'is_qualified', sp.is_qualified,
                'isQualified', sp.is_qualified,
                'champion_rank', sp.champion_rank,
                'championRank', sp.champion_rank,
                'champion_title', sp.champion_title,
                'championTitle', sp.champion_title,
                'qualification_reason', sp.qualification_reason,
                'reason', sp.qualification_reason,
                'tieBreakResolvedBy', r_elem ->> 'tie_break_note'
            )
            ORDER BY sp.rank ASC, sp.lottery_number ASC
        ),
        '[]'::jsonb
    ) INTO v_authoritative_snapshot
    FROM public.stage_participations sp
    JOIN public.participants p ON p.id = sp.participant_id
    LEFT JOIN public.kafilahs k ON k.id = p.kafilah_id
    LEFT JOIN public.branches b ON b.id = COALESCE(v_stage.branch_id, p.branch_id)
    LEFT JOIN LATERAL (
        SELECT elem
        FROM jsonb_array_elements(v_rankings_arr) AS elem
        WHERE (elem ->> 'participant_id')::uuid = sp.participant_id
        LIMIT 1
    ) r_match(r_elem) ON true
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id;

    INSERT INTO public.stage_result_snapshots (
        tenant_id,
        stage_id,
        branch_id,
        quota,
        rubric_version_id,
        tie_break_rule_used,
        finalized_by,
        rankings_snapshot
    )
    VALUES (
        v_stage.tenant_id,
        p_stage_id,
        v_stage.branch_id,
        CASE WHEN p_next_stage_id IS NOT NULL THEN v_stage.qualification_quota ELSE v_champion_count END,
        v_rubric_version_id,
        v_tie_break_rule_used,
        v_actor_id,
        v_authoritative_snapshot
    )
    ON CONFLICT (tenant_id, stage_id) DO NOTHING;

    INSERT INTO public.audit_logs (tenant_id, actor_id, actor_name, action, target, summary, outcome)
    VALUES (
        v_stage.tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
        'STAGE_FINALIZED',
        'Stage: ' || v_stage.name || ' (ID: ' || p_stage_id::text || ')',
        CASE
            WHEN p_next_stage_id IS NOT NULL THEN
                'Pengesahan resmi babak ' || v_stage.name || ' dengan ' || v_qualified_count::text || ' peserta diloloskan ke ' || COALESCE(v_next_stage.name, 'Babak Lanjutan')
            ELSE
                'Pengesahan resmi hasil kejuaraan babak final ' || v_stage.name || ' dengan ' || LEAST(v_participation_count, v_champion_count)::text || ' juara ditetapkan.'
        END,
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Babak berhasil disahkan secara resmi dan peserta lolos telah dipindahkan.',
        'qualified_count', v_qualified_count,
        'champion_count', CASE WHEN p_next_stage_id IS NULL THEN LEAST(v_participation_count, v_champion_count) ELSE 0 END,
        'next_stage_id', p_next_stage_id
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.draw_lottery_server(
    p_tenant_id UUID,
    p_stage_id UUID,
    p_branch_id UUID DEFAULT NULL,
    p_level_id UUID DEFAULT NULL,
    p_questions_per_participant INT DEFAULT 1,
    p_draw_mode VARCHAR DEFAULT 'both',
    p_notes TEXT DEFAULT NULL,
    p_participant_ids UUID[] DEFAULT NULL,
    p_question_pool_ids UUID[] DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor_profile RECORD;
    v_actor_name VARCHAR(150);
    v_stage public.stages%ROWTYPE;
    v_branch_name VARCHAR(150);
    v_level_name VARCHAR(150);
    v_seed_hex TEXT;
    v_seed_sha256 TEXT;
    v_draw_version INT;
    v_draw_log_id UUID := gen_random_uuid();
    v_now TIMESTAMPTZ := now();
    v_unverified RECORD;
    v_part RECORD;
    v_sp public.stage_participations%ROWTYPE;
    v_idx INT := 0;
    v_new_lottery_no VARCHAR(30);
    v_used_q_ids UUID[] := ARRAY[]::uuid[];
    v_picked_q_ids UUID[];
    v_picked_q_codes TEXT[];
    v_first_q public.questions%ROWTYPE;
    v_q_id UUID;
    v_all_p_ids TEXT[] := ARRAY[]::text[];
    v_all_q_ids TEXT[] := ARRAY[]::text[];
    v_draw_results JSONB := '[]'::jsonb;
    v_target_count INT := 0;
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Tidak terautentikasi: Sesi pengguna tidak ditemukan.';
    END IF;

    IF NOT (public.is_tenant_admin(p_tenant_id) OR public.is_superadmin()) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator Tenant atau Superadmin yang berwenang menjalankan undian server.';
    END IF;

    IF p_draw_mode NOT IN ('lottery_number', 'maqra', 'both') THEN
        RAISE EXCEPTION 'Mode undian "%" tidak valid. Gunakan lottery_number, maqra, atau both.', p_draw_mode;
    END IF;

    IF COALESCE(p_questions_per_participant, 1) < 1 THEN
        RAISE EXCEPTION 'Jumlah maqra per peserta minimal 1.';
    END IF;

    SELECT * INTO v_stage FROM public.stages WHERE id = p_stage_id AND tenant_id = p_tenant_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan pada tenant ini.';
    END IF;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'STAGE_ALREADY_FINALIZED: Pengundian ditolak karena Babak "%" telah difinalisasi secara resmi.', v_stage.name;
    END IF;

    -- Blokir pengundian ulang apabila sudah ada lembar penilaian pada babak ini
    IF EXISTS (
        SELECT 1
        FROM public.judge_assessments ja
        JOIN public.stage_participations sp ON sp.id = ja.stage_participation_id
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = p_tenant_id
    ) THEN
        RAISE EXCEPTION 'STAGE_ASSESSMENTS_ALREADY_STARTED: Pengundian ditolak karena penilaian dewan hakim sudah dimulai pada babak "%".', v_stage.name;
    END IF;

    SELECT name, role INTO v_actor_profile FROM public.profiles WHERE id = v_actor_id;
    v_actor_name := COALESCE(NULLIF(TRIM(v_actor_profile.name), ''), 'Administrator MTQ');

    IF p_branch_id IS NOT NULL THEN
        SELECT name INTO v_branch_name FROM public.branches WHERE id = p_branch_id AND tenant_id = p_tenant_id;
    ELSIF v_stage.branch_id IS NOT NULL THEN
        SELECT name INTO v_branch_name FROM public.branches WHERE id = v_stage.branch_id AND tenant_id = p_tenant_id;
    END IF;

    IF p_level_id IS NOT NULL THEN
        SELECT name INTO v_level_name FROM public.levels WHERE id = p_level_id AND tenant_id = p_tenant_id;
    END IF;

    -- Periksa apakah ada peserta dalam cakupan undian yang belum berstatus 'Diverifikasi'
    SELECT p.id, p.name, p.verification_status
    INTO v_unverified
    FROM public.participants p
    LEFT JOIN public.stage_participations sp
      ON sp.participant_id = p.id
     AND sp.stage_id = p_stage_id
     AND sp.tenant_id = p_tenant_id
    WHERE p.tenant_id = p_tenant_id
      AND (
          (p_participant_ids IS NOT NULL AND array_length(p_participant_ids, 1) > 0 AND p.id = ANY(p_participant_ids))
          OR (
              (p_participant_ids IS NULL OR array_length(p_participant_ids, 1) IS NULL)
              AND (sp.id IS NOT NULL OR p.stage_id = p_stage_id OR (p.stage_id IS NULL AND v_stage.stage_order = 1))
              AND (COALESCE(p_branch_id, v_stage.branch_id) IS NULL OR p.branch_id = COALESCE(p_branch_id, v_stage.branch_id))
              AND (p_level_id IS NULL OR p.level_id = p_level_id)
          )
      )
      -- T4: hanya peserta yang masih menunggu verifikasi yang memblokir; peserta Ditolak dikeluarkan dari undian
      AND COALESCE(p.verification_status, 'Diajukan') = 'Diajukan'
    LIMIT 1;

    IF FOUND THEN
        RAISE EXCEPTION 'PARTICIPANT_NOT_VERIFIED: Peserta "%" belum diverifikasi berkasnya (status: %). Selesaikan verifikasi (Diverifikasi/Ditolak) sebelum undian; peserta Ditolak otomatis tidak diundi.', v_unverified.name, v_unverified.verification_status;
    END IF;

    -- Benih acak kriptografis di server. gen_random_bytes (pgcrypto) bila tersedia;
    -- jika tidak, gen_random_uuid() bawaan PostgreSQL 13+ (juga CSPRNG). Tidak ada fallback deterministik.
    BEGIN
        EXECUTE 'SELECT encode(gen_random_bytes(16), ''hex'')' INTO v_seed_hex;
    EXCEPTION WHEN undefined_function THEN
        v_seed_hex := replace(gen_random_uuid()::text, '-', '');
    END;
    IF v_seed_hex IS NULL OR length(v_seed_hex) < 32 THEN
        RAISE EXCEPTION 'LOTTERY_SEED_UNAVAILABLE: Benih acak server tidak dapat dibangkitkan.';
    END IF;

    -- SHA-256 asli (fungsi bawaan PostgreSQL 11+), dicatat agar benih dapat diverifikasi publik
    v_seed_sha256 := encode(sha256(convert_to(v_seed_hex, 'UTF8')), 'hex');

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    -- Acak urutan peserta secara deterministik dari benih (dapat direproduksi via verify_lottery_draw)
    FOR v_part IN
        SELECT p.*
        FROM public.participants p
        LEFT JOIN public.stage_participations sp
          ON sp.participant_id = p.id
         AND sp.stage_id = p_stage_id
         AND sp.tenant_id = p_tenant_id
        WHERE p.tenant_id = p_tenant_id
          AND COALESCE(p.verification_status, 'Diajukan') = 'Diverifikasi'
          AND (
              (p_participant_ids IS NOT NULL AND array_length(p_participant_ids, 1) > 0 AND p.id = ANY(p_participant_ids))
              OR (
                  (p_participant_ids IS NULL OR array_length(p_participant_ids, 1) IS NULL)
                  AND (sp.id IS NOT NULL OR p.stage_id = p_stage_id OR (p.stage_id IS NULL AND v_stage.stage_order = 1))
                  AND (COALESCE(p_branch_id, v_stage.branch_id) IS NULL OR p.branch_id = COALESCE(p_branch_id, v_stage.branch_id))
                  AND (p_level_id IS NULL OR p.level_id = p_level_id)
              )
          )
        ORDER BY public.lottery_sort_key(v_seed_hex, p.id::text, ''), p.id
    LOOP
        v_idx := v_idx + 1;
        v_target_count := v_target_count + 1;
        v_all_p_ids := array_append(v_all_p_ids, v_part.id::text);

        SELECT * INTO v_sp
        FROM public.stage_participations
        WHERE stage_id = p_stage_id
          AND participant_id = v_part.id
          AND tenant_id = p_tenant_id
        LIMIT 1;

        IF NOT FOUND THEN
            INSERT INTO public.stage_participations (
                id, tenant_id, stage_id, participant_id, lottery_number, status, created_at, updated_at
            ) VALUES (
                gen_random_uuid(), p_tenant_id, p_stage_id, v_part.id,
                v_part.lottery_number, 'Belum Dimulai', v_now, v_now
            ) RETURNING * INTO v_sp;
        END IF;

        IF p_draw_mode IN ('lottery_number', 'both') THEN
            v_new_lottery_no := LPAD(v_idx::text, 2, '0');
            UPDATE public.stage_participations
            SET lottery_number = v_new_lottery_no,
                updated_at = v_now
            WHERE id = v_sp.id;

            UPDATE public.participants
            SET stage_id = COALESCE(stage_id, p_stage_id),
                updated_at = v_now
            WHERE id = v_part.id
              AND tenant_id = p_tenant_id;
        ELSE
            v_new_lottery_no := COALESCE(v_sp.lottery_number, v_part.lottery_number, LPAD(v_idx::text, 2, '0'));
        END IF;

        v_picked_q_ids := ARRAY[]::uuid[];
        v_picked_q_codes := ARRAY[]::text[];

        IF p_draw_mode IN ('maqra', 'both') THEN
            -- Pilih p_questions_per_participant soal aktif yang sesuai 3D (cabang + jenjang + babak),
            -- prioritaskan soal yang belum terpakai pada batch ini (sampling without replacement sebelum daur ulang)
            SELECT
                ARRAY_AGG(sub.id ORDER BY sub.ord),
                ARRAY_AGG((sub.code || ' - ' || sub.title) ORDER BY sub.ord)
            INTO v_picked_q_ids, v_picked_q_codes
            FROM (
                SELECT
                    q.id,
                    q.code,
                    q.title,
                    ROW_NUMBER() OVER (
                        ORDER BY
                            CASE WHEN q.id = ANY(v_used_q_ids) THEN 1 ELSE 0 END ASC,
                            public.lottery_sort_key(v_seed_hex, v_part.id::text, q.id::text) ASC,
                            q.id ASC
                    ) AS ord
                FROM public.questions q
                WHERE q.tenant_id = p_tenant_id
                  AND q.status = 'Aktif'
                  AND (q.stage_id IS NULL OR q.stage_id = p_stage_id)
                  AND (COALESCE(p_branch_id, v_stage.branch_id, v_part.branch_id) IS NULL OR q.branch_id IS NULL OR q.branch_id = COALESCE(p_branch_id, v_stage.branch_id, v_part.branch_id))
                  AND (COALESCE(p_level_id, v_part.level_id) IS NULL OR q.level_id IS NULL OR q.level_id = COALESCE(p_level_id, v_part.level_id))
                  AND (p_question_pool_ids IS NULL OR array_length(p_question_pool_ids, 1) IS NULL OR q.id = ANY(p_question_pool_ids))
                LIMIT p_questions_per_participant
            ) sub;

            IF v_picked_q_ids IS NULL OR COALESCE(array_length(v_picked_q_ids, 1), 0) < p_questions_per_participant THEN
                RAISE EXCEPTION 'INSUFFICIENT_QUESTION_POOL: Jumlah soal aktif yang sesuai cabang/jenjang/babak tidak mencukupi untuk peserta "%" (butuh %, tersedia %).',
                    v_part.name, p_questions_per_participant, COALESCE(array_length(v_picked_q_ids, 1), 0);
            END IF;

            DELETE FROM public.assigned_maqras
            WHERE stage_participation_id = v_sp.id
              AND tenant_id = p_tenant_id;

            FOREACH v_q_id IN ARRAY v_picked_q_ids
            LOOP
                INSERT INTO public.assigned_maqras (
                    id, tenant_id, stage_participation_id, question_id, assigned_at, assigned_by, method, notes
                ) VALUES (
                    gen_random_uuid(),
                    p_tenant_id,
                    v_sp.id,
                    v_q_id,
                    v_now,
                    v_actor_id,
                    'undian',
                    COALESCE(p_notes, 'Undian Server Terverifikasi (SHA-256: ' || LEFT(v_seed_sha256, 12) || ')')
                );
                v_used_q_ids := array_append(v_used_q_ids, v_q_id);
                IF NOT (v_q_id::text = ANY(v_all_q_ids)) THEN
                    v_all_q_ids := array_append(v_all_q_ids, v_q_id::text);
                END IF;
            END LOOP;

            SELECT * INTO v_first_q FROM public.questions WHERE id = v_picked_q_ids[1];

            UPDATE public.stage_participations
            SET status = 'Belum Dimulai',
                updated_at = v_now
            WHERE id = v_sp.id;

            UPDATE public.participants
            SET stage_id = COALESCE(stage_id, p_stage_id),
                updated_at = v_now
            WHERE id = v_part.id
              AND tenant_id = p_tenant_id;
        ELSE
            -- Jika hanya mengundi nomor tampil, pertahankan daftar maqra yang sudah ada untuk catatan log
            SELECT
                COALESCE(ARRAY_AGG(q.id), ARRAY[]::uuid[]),
                COALESCE(ARRAY_AGG(q.code || ' - ' || q.title), ARRAY[]::text[])
            INTO v_picked_q_ids, v_picked_q_codes
            FROM public.assigned_maqras am
            JOIN public.questions q ON q.id = am.question_id
            WHERE am.stage_participation_id = v_sp.id;
        END IF;

        v_draw_results := v_draw_results || jsonb_build_array(
            jsonb_build_object(
                'participantId', v_part.id,
                'participantCode', v_part.participant_code,
                'participantName', v_part.name,
                'lotteryNumber', v_new_lottery_no,
                'questionIds', to_jsonb(v_picked_q_ids),
                'assignedQuestionIds', to_jsonb(v_picked_q_ids),
                'questionTitles', to_jsonb(v_picked_q_codes),
                'assignedQuestionCodes', to_jsonb(v_picked_q_codes)
            )
        );
    END LOOP;

    IF v_target_count = 0 THEN
        RAISE EXCEPTION 'NO_ELIGIBLE_PARTICIPANTS: Tidak ada peserta berstatus Diverifikasi yang ditemukan untuk cakupan undian ini.';
    END IF;

    SELECT COALESCE(MAX(draw_version), 0) + 1 INTO v_draw_version
    FROM public.lottery_draw_logs
    WHERE tenant_id = p_tenant_id AND stage_id = p_stage_id;

    INSERT INTO public.lottery_draw_logs (
        id, tenant_id, stage_id, stage_name, branch_id, branch_name, level_id, level_name,
        actor_id, actor_name, questions_per_participant, participant_ids, question_pool_ids,
        draw_results, draw_version, notes, seed_hex, seed_sha256, draw_mode, created_at
    ) VALUES (
        v_draw_log_id, p_tenant_id, p_stage_id, v_stage.name,
        COALESCE(p_branch_id, v_stage.branch_id), COALESCE(v_branch_name, 'Semua Cabang'),
        p_level_id, COALESCE(v_level_name, 'Semua Jenjang'),
        v_actor_id, v_actor_name, p_questions_per_participant,
        v_all_p_ids, v_all_q_ids,
        v_draw_results, v_draw_version,
        COALESCE(p_notes, 'Undian Server (' || p_draw_mode || ') SHA-256: ' || LEFT(v_seed_sha256, 16)),
        v_seed_hex, v_seed_sha256, p_draw_mode, v_now
    );

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    INSERT INTO public.audit_logs (
        tenant_id, actor_id, actor_name, action, target, summary, outcome, created_at
    ) VALUES (
        p_tenant_id, v_actor_id, v_actor_name,
        'LOTTERY_DRAW_COMMITTED',
        v_stage.name || ' - ' || COALESCE(v_branch_name, 'Semua Cabang'),
        'Undian Server (' || p_draw_mode || ') versi #' || v_draw_version || ': ' || v_target_count || ' peserta (SHA-256: ' || LEFT(v_seed_sha256, 12) || ').',
        'Success', v_now
    );

    RETURN jsonb_build_object(
        'success', true,
        'draw_log_id', v_draw_log_id,
        'draw_version', v_draw_version,
        'draw_mode', p_draw_mode,
        'seed_hex', v_seed_hex,
        'seed_sha256', v_seed_sha256,
        'participants_count', v_target_count,
        'results', v_draw_results
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.verify_participant(
    p_tenant_id UUID,
    p_participant_id UUID,
    p_status VARCHAR,
    p_note TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_part public.participants%ROWTYPE;
    v_clean_note TEXT;
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Tidak terautentikasi.';
    END IF;

    IF NOT (public.is_tenant_admin(p_tenant_id) OR public.is_superadmin()) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator Tenant atau Superadmin yang berwenang memverifikasi berkas peserta.';
    END IF;

    IF p_status NOT IN ('Diajukan', 'Diverifikasi', 'Ditolak') THEN
        RAISE EXCEPTION 'Status verifikasi "%" tidak valid. Gunakan Diajukan, Diverifikasi, atau Ditolak.', p_status;
    END IF;

    v_clean_note := NULLIF(TRIM(COALESCE(p_note, '')), '');
    IF p_status = 'Ditolak' AND (v_clean_note IS NULL OR LENGTH(v_clean_note) < 3) THEN
        RAISE EXCEPTION 'VERIFICATION_NOTE_REQUIRED: Penolakan berkas peserta wajib menyertakan alasan penolakan (minimal 3 karakter).';
    END IF;

    SELECT * INTO v_part
    FROM public.participants
    WHERE id = p_participant_id AND tenant_id = p_tenant_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Peserta tidak ditemukan pada tenant ini.';
    END IF;

    -- T5: status Diverifikasi tidak dapat dicabut setelah penilaian peserta dimulai pada babak yang belum disahkan
    IF COALESCE(v_part.verification_status, 'Diajukan') = 'Diverifikasi' AND p_status <> 'Diverifikasi' AND EXISTS (
        SELECT 1
        FROM public.judge_assessments ja
        JOIN public.stage_participations sp ON sp.id = ja.stage_participation_id
        JOIN public.stages s ON s.id = sp.stage_id
        WHERE sp.participant_id = p_participant_id
          AND s.is_finalized = false
    ) THEN
        RAISE EXCEPTION 'VERIFICATION_LOCKED_DURING_JUDGING: Penilaian peserta "%" sudah dimulai. Status verifikasi tidak dapat dicabut di tengah babak; ajukan diskualifikasi melalui keputusan dewan hakim.', v_part.name;
    END IF;

    PERFORM set_config('mtq.rpc_verify_active', 'true', true);
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    UPDATE public.participants
    SET verification_status = p_status,
        verification_note = v_clean_note,
        verified_by = v_actor_id,
        verified_at = now(),
        updated_at = now()
    WHERE id = p_participant_id
      AND tenant_id = p_tenant_id;

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    SELECT name, role INTO v_actor FROM public.profiles WHERE id = v_actor_id;

    INSERT INTO public.audit_logs (
        tenant_id, actor_id, actor_name, action, target, summary, outcome
    ) VALUES (
        p_tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
        'PARTICIPANT_VERIFICATION_UPDATED',
        'Participant: ' || v_part.name || ' (' || v_part.participant_code || ')',
        'Status verifikasi berkas peserta diubah menjadi ' || p_status || COALESCE(' — Catatan: ' || v_clean_note, ''),
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'participant_id', p_participant_id,
        'verification_status', p_status,
        'verification_note', v_clean_note,
        'verified_by', v_actor_id,
        'verified_at', now()
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.get_judge_allowed_fields(UUID, UUID, UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_judge_allowed_fields(UUID, UUID, UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.judge_has_finalized_sheets_in_open_stage(UUID, UUID, UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.judge_has_finalized_sheets_in_open_stage(UUID, UUID, UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.release_judge_with_reason(UUID, UUID, TEXT, UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.release_judge_with_reason(UUID, UUID, TEXT, UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.error_category_is_used(UUID, UUID, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.error_category_is_used(UUID, UUID, TEXT) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.compute_stage_rankings(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.compute_stage_rankings(UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.finalize_judge_assessment(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.finalize_judge_assessment(UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.advance_stage_qualifiers(UUID, UUID, UUID[], JSONB, JSONB, JSONB) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.advance_stage_qualifiers(UUID, UUID, UUID[], JSONB, JSONB, JSONB) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.draw_lottery_server(UUID, UUID, UUID, UUID, INT, VARCHAR, TEXT, UUID[], UUID[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.draw_lottery_server(UUID, UUID, UUID, UUID, INT, VARCHAR, TEXT, UUID[], UUID[]) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.verify_participant(UUID, UUID, VARCHAR, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.verify_participant(UUID, UUID, VARCHAR, TEXT) TO authenticated;

-- ============================================================================
-- 20261117 — Konsistensi alur lomba (Audit Lanjutan Kelompok 3–4)
--   S1 Peserta seri di luar posisi kritis berbagi peringkat yang sama di hasil resmi
--   S2 Rubrik lembar nilai ditetapkan server dari aturan kompetisi babak
--   S3 is_assigned_judge mewajibkan keanggotaan tenant aktif
--   S5 Undian server mengunci baris babak (cegah undian ganda bersamaan)
--   S6 Hapus peserta / tenant lewat RPC transaksional
--   S7 Nilai akhir tidak melebihi nilai maksimal rubrik (paritas dengan klien)
--   S8 Perubahan kuota/jumlah juara tercatat di audit; soal yang sudah dinilai terkunci
--   J6 Hapus pemetaan heuristik kategori -> bidang berdasarkan nama
-- ============================================================================

-- ---------------------------------------------------------------------------
-- S2. Rubrik lembar nilai = rubrik aturan kompetisi babak (bila aturan ada)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.resolve_stage_rubric_version(p_stage_participation_id UUID)
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    SELECT crc.rubric_version_id
    FROM public.stage_participations sp
    JOIN public.stages s ON s.id = sp.stage_id
    JOIN public.participants p ON p.id = sp.participant_id
    JOIN public.competition_rule_configs crc
      ON crc.tenant_id = sp.tenant_id
     AND crc.status = 'Aktif'
     AND crc.rubric_version_id IS NOT NULL
     AND (crc.branch_id IS NULL OR crc.branch_id = COALESCE(s.branch_id, p.branch_id))
    WHERE sp.id = p_stage_participation_id
    ORDER BY CASE WHEN crc.branch_id = COALESCE(s.branch_id, p.branch_id) THEN 0 ELSE 1 END,
             crc.created_at DESC
    LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.enforce_assessment_rubric_from_rule()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_rule_rubric UUID;
BEGIN
    IF TG_OP = 'UPDATE' AND NEW.rubric_version_id IS DISTINCT FROM OLD.rubric_version_id THEN
        RAISE EXCEPTION 'ASSESSMENT_RUBRIC_LOCKED: Rubrik lembar penilaian tidak dapat diganti setelah lembar dibuat.';
    END IF;
    IF TG_OP = 'INSERT' THEN
        v_rule_rubric := public.resolve_stage_rubric_version(NEW.stage_participation_id);
        IF v_rule_rubric IS NOT NULL THEN
            NEW.rubric_version_id := v_rule_rubric;
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_assessment_rubric_from_rule ON public.judge_assessments;
CREATE TRIGGER trg_assessment_rubric_from_rule
    BEFORE INSERT OR UPDATE OF rubric_version_id ON public.judge_assessments
    FOR EACH ROW EXECUTE FUNCTION public.enforce_assessment_rubric_from_rule();

-- ---------------------------------------------------------------------------
-- S6. Penghapusan transaksional
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.delete_participant_safe(p_tenant_id UUID, p_participant_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_part RECORD;
    v_actor RECORD;
    v_sheet_count INT;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Tidak terautentikasi.';
    END IF;
    IF NOT (public.is_tenant_admin(p_tenant_id) OR public.is_superadmin()) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator Tenant atau Superadmin.';
    END IF;
    SELECT * INTO v_part FROM public.participants WHERE id = p_participant_id AND tenant_id = p_tenant_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Peserta tidak ditemukan pada tenant ini.';
    END IF;

    SELECT COUNT(*) INTO v_sheet_count
    FROM public.judge_assessments ja
    JOIN public.stage_participations sp ON sp.id = ja.stage_participation_id
    WHERE sp.participant_id = p_participant_id;
    IF v_sheet_count > 0 THEN
        RAISE EXCEPTION 'PARTICIPANT_HAS_ASSESSMENTS: Peserta "%" sudah memiliki % lembar penilaian (termasuk draf) dan tidak dapat dihapus. Gunakan keputusan diskualifikasi.', v_part.name, v_sheet_count;
    END IF;

    -- Semua langkah berjalan dalam satu transaksi: bila satu gagal, seluruhnya dibatalkan
    DELETE FROM public.assigned_maqras am
    USING public.stage_participations sp
    WHERE am.stage_participation_id = sp.id AND sp.participant_id = p_participant_id;
    DELETE FROM public.stage_participations WHERE participant_id = p_participant_id;
    DELETE FROM public.participants WHERE id = p_participant_id;

    SELECT name, role INTO v_actor FROM public.profiles WHERE id = auth.uid();
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);
    INSERT INTO public.audit_logs (tenant_id, actor_id, actor_name, action, target, summary, outcome)
    VALUES (p_tenant_id, auth.uid(), COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
            'PARTICIPANT_DELETED', 'Peserta: ' || v_part.name || ' (' || v_part.participant_code || ')',
            'Peserta dihapus beserta data babak dan maqra yang belum dinilai.', 'Success');

    RETURN jsonb_build_object('success', true, 'participant_id', p_participant_id);
END;
$$;

CREATE OR REPLACE FUNCTION public.delete_tenant_safe(p_tenant_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_tenant RECORD;
BEGIN
    IF NOT public.is_superadmin() THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Superadmin yang dapat menghapus penyelenggara.';
    END IF;
    IF p_tenant_id = '00000000-0000-0000-0000-000000000000'::uuid THEN
        RAISE EXCEPTION 'Tenant sistem tidak dapat dihapus.';
    END IF;
    SELECT * INTO v_tenant FROM public.tenants WHERE id = p_tenant_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Penyelenggara tidak ditemukan.';
    END IF;
    IF EXISTS (SELECT 1 FROM public.judge_assessments WHERE tenant_id = p_tenant_id)
       OR EXISTS (SELECT 1 FROM public.stages WHERE tenant_id = p_tenant_id AND is_finalized = true)
       OR EXISTS (SELECT 1 FROM public.audit_logs WHERE tenant_id = p_tenant_id)
       OR EXISTS (SELECT 1 FROM public.lottery_draw_logs WHERE tenant_id = p_tenant_id) THEN
        RAISE EXCEPTION 'TENANT_HAS_HISTORY: Penyelenggara "%" sudah memiliki riwayat penilaian, undian, atau audit dan tidak dapat dihapus. Ubah statusnya menjadi Nonaktif untuk mengarsipkan.', v_tenant.name;
    END IF;

    -- Satu transaksi: seluruh data anak terhapus bersama tenant, atau tidak sama sekali
    DELETE FROM public.assigned_maqras WHERE tenant_id = p_tenant_id;
    DELETE FROM public.stage_participations WHERE tenant_id = p_tenant_id;
    DELETE FROM public.judge_assignments WHERE tenant_id = p_tenant_id;
    DELETE FROM public.questions WHERE tenant_id = p_tenant_id;
    DELETE FROM public.participants WHERE tenant_id = p_tenant_id;
    DELETE FROM public.stages WHERE tenant_id = p_tenant_id;
    DELETE FROM public.kafilahs WHERE tenant_id = p_tenant_id;
    DELETE FROM public.competition_rule_configs WHERE tenant_id = p_tenant_id;
    DELETE FROM public.error_categories WHERE tenant_id = p_tenant_id;
    DELETE FROM public.branches WHERE tenant_id = p_tenant_id;
    DELETE FROM public.levels WHERE tenant_id = p_tenant_id;
    DELETE FROM public.tenant_memberships WHERE tenant_id = p_tenant_id;
    DELETE FROM public.tenants WHERE id = p_tenant_id;

    RETURN jsonb_build_object('success', true, 'tenant_id', p_tenant_id);
END;
$$;

-- ---------------------------------------------------------------------------
-- S8. Audit perubahan konfigurasi babak & kunci soal yang sudah dinilai
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.audit_stage_config_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor RECORD;
BEGIN
    IF NEW.qualification_quota IS DISTINCT FROM OLD.qualification_quota
       OR NEW.champion_count IS DISTINCT FROM OLD.champion_count
       OR NEW.branch_id IS DISTINCT FROM OLD.branch_id
       OR NEW.stage_order IS DISTINCT FROM OLD.stage_order THEN
        SELECT name, role INTO v_actor FROM public.profiles WHERE id = auth.uid();
        PERFORM set_config('mtq.rpc_audit_active', 'true', true);
        INSERT INTO public.audit_logs (tenant_id, actor_id, actor_name, action, target, summary, outcome)
        VALUES (
            NEW.tenant_id, auth.uid(),
            COALESCE(v_actor.name, 'Sistem') || ' (' || COALESCE(v_actor.role, 'sistem') || ')',
            'STAGE_CONFIG_CHANGED',
            'Babak: ' || NEW.name,
            format('Kuota %s -> %s; jumlah juara %s -> %s; urutan %s -> %s; cabang %s -> %s',
                   OLD.qualification_quota, NEW.qualification_quota,
                   COALESCE(OLD.champion_count::text, '-'), COALESCE(NEW.champion_count::text, '-'),
                   OLD.stage_order, NEW.stage_order,
                   COALESCE(OLD.branch_id::text, '-'), COALESCE(NEW.branch_id::text, '-')),
            'Success'
        );
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_audit_stage_config_change ON public.stages;
CREATE TRIGGER trg_audit_stage_config_change
    AFTER UPDATE ON public.stages
    FOR EACH ROW EXECUTE FUNCTION public.audit_stage_config_change();

CREATE OR REPLACE FUNCTION public.enforce_question_content_lock()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    IF TG_OP = 'DELETE' OR (
        NEW.surah_number IS DISTINCT FROM OLD.surah_number
        OR NEW.start_ayah IS DISTINCT FROM OLD.start_ayah
        OR NEW.end_ayah IS DISTINCT FROM OLD.end_ayah
        OR NEW.page_number IS DISTINCT FROM OLD.page_number
        OR NEW.page_start IS DISTINCT FROM OLD.page_start
        OR NEW.page_end IS DISTINCT FROM OLD.page_end
    ) THEN
        IF EXISTS (
            SELECT 1
            FROM public.assigned_maqras am
            JOIN public.judge_assessments ja ON ja.assigned_maqra_id = am.id
            WHERE am.question_id = OLD.id
        ) THEN
            RAISE EXCEPTION 'QUESTION_LOCKED: Soal "%" sudah dipakai pada lembar penilaian; rentang ayat/halaman tidak dapat diubah atau dihapus. Buat soal baru.', OLD.code;
        END IF;
    END IF;
    RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trg_question_content_lock ON public.questions;
CREATE TRIGGER trg_question_content_lock
    BEFORE UPDATE OR DELETE ON public.questions
    FOR EACH ROW EXECUTE FUNCTION public.enforce_question_content_lock();


CREATE OR REPLACE FUNCTION public.advance_stage_qualifiers(
    p_stage_id UUID,
    p_next_stage_id UUID,
    p_qualified_participant_ids UUID[],
    p_override_reasons JSONB DEFAULT '{}'::jsonb,
    p_rankings_snapshot JSONB DEFAULT '[]'::jsonb,
    p_tie_resolution JSONB DEFAULT '{}'::jsonb
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor RECORD;
    v_stage RECORD;
    v_next_stage public.stages%ROWTYPE;
    v_override_key TEXT;
    v_override_val TEXT;
    v_participation_count INT;
    v_qualified_count INT;
    v_assigned_judges_count INT;
    v_unassigned_maqra_count INT;
    v_incomplete_count INT;
    v_invalid_participant_count INT;
    v_unjustified_override_count INT;
    v_unresolved_critical_tie_count INT := 0;
    v_computed_data JSONB;
    v_rankings_arr JSONB;
    v_rubric_version_id UUID;
    v_tie_break_rule_used TEXT;
    v_champion_count INT;
    v_authoritative_snapshot JSONB;
    v_now TIMESTAMPTZ := now();
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    SELECT * INTO v_stage FROM public.stages WHERE id = p_stage_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan.';
    END IF;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'Babak ini sudah pernah difinalisasi sebelumnya.';
    END IF;

    IF NOT public.is_tenant_admin(v_stage.tenant_id) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Anda tidak memiliki wewenang administrator pada tenant ini.';
    END IF;

    SELECT * INTO v_actor FROM public.profiles WHERE id = v_actor_id;

    SELECT COUNT(*) INTO v_participation_count
    FROM public.stage_participations sp
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id;

    IF v_participation_count = 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Tidak ada peserta terdaftar pada babak ini.';
    END IF;

    v_qualified_count := COALESCE(array_length(p_qualified_participant_ids, 1), 0);
    v_champion_count := GREATEST(1, COALESCE(v_stage.champion_count, 3));

    IF p_next_stage_id IS NOT NULL THEN
        IF v_stage.qualification_quota <= 0 THEN
            RAISE EXCEPTION 'Kuota kelulusan pada babak ini tidak valid.';
        END IF;
        IF v_qualified_count > v_stage.qualification_quota THEN
            RAISE EXCEPTION 'Jumlah peserta yang diloloskan (%) melebihi kuota babak (%).', v_qualified_count, v_stage.qualification_quota;
        END IF;
    END IF;

    IF p_override_reasons IS NOT NULL AND jsonb_typeof(p_override_reasons) = 'object' THEN
        FOR v_override_key, v_override_val IN
            SELECT key, value #>> '{}' FROM jsonb_each(p_override_reasons)
        LOOP
            IF v_override_val IS NULL OR LENGTH(TRIM(v_override_val)) < 5 THEN
                RAISE EXCEPTION 'Pengesahan babak ditolak: Alasan override manual untuk peserta % wajib diisi minimal 5 karakter.', v_override_key;
            END IF;
        END LOOP;
    END IF;

    SELECT COUNT(DISTINCT ja.judge_profile_id) INTO v_assigned_judges_count
    FROM public.judge_assignments ja
    JOIN public.tenant_memberships tm
      ON tm.tenant_id = ja.tenant_id
     AND tm.profile_id = ja.judge_profile_id
     AND tm.status = 'Aktif'
    WHERE ja.tenant_id = v_stage.tenant_id
      AND ja.stage_id = p_stage_id
      AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
      AND ja.status = 'Aktif';

    IF v_assigned_judges_count = 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Belum ada penugasan majelis hakim resmi (judge_assignments) yang aktif pada babak ini.';
    END IF;

    IF v_qualified_count > 0 THEN
        SELECT COUNT(*) INTO v_invalid_participant_count
        FROM unnest(p_qualified_participant_ids) AS q_pid
        LEFT JOIN public.stage_participations sp
               ON sp.participant_id = q_pid
              AND sp.stage_id = p_stage_id
              AND sp.tenant_id = v_stage.tenant_id
        LEFT JOIN public.participants p
               ON p.id = q_pid
              AND p.tenant_id = v_stage.tenant_id
        WHERE sp.id IS NULL
           OR (v_stage.branch_id IS NOT NULL AND p.branch_id <> v_stage.branch_id);

        IF v_invalid_participant_count > 0 THEN
            RAISE EXCEPTION 'Pengesahan babak ditolak: Terdapat peserta lolos yang tidak terdaftar pada babak atau cabang lomba ini.';
        END IF;
    END IF;

    SELECT COUNT(*) INTO v_unassigned_maqra_count
    FROM public.stage_participations sp
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id
      AND NOT EXISTS (
          SELECT 1 FROM public.assigned_maqras am
          WHERE am.stage_participation_id = sp.id
            AND am.tenant_id = v_stage.tenant_id
      );

    IF v_unassigned_maqra_count > 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Masih terdapat % peserta yang belum memiliki penetapan maqra pada babak ini.', v_unassigned_maqra_count;
    END IF;

    SELECT COUNT(*) INTO v_incomplete_count
    FROM public.stage_participations sp
    JOIN public.assigned_maqras am
      ON am.stage_participation_id = sp.id
     AND am.tenant_id = sp.tenant_id
    CROSS JOIN (
        SELECT DISTINCT ja.judge_profile_id
        FROM public.judge_assignments ja
        JOIN public.tenant_memberships tm
          ON tm.tenant_id = ja.tenant_id
         AND tm.profile_id = ja.judge_profile_id
         AND tm.status = 'Aktif'
        WHERE ja.tenant_id = v_stage.tenant_id
          AND ja.stage_id = p_stage_id
          AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
          AND ja.status = 'Aktif'
    ) req_judges
    LEFT JOIN public.judge_assessments jass
           ON jass.stage_participation_id = sp.id
          AND jass.assigned_maqra_id = am.id
          AND jass.judge_profile_id = req_judges.judge_profile_id
          AND jass.status = 'finalized'
          AND jass.is_locked = true
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id
      AND jass.id IS NULL;

    IF v_incomplete_count > 0 THEN
        RAISE EXCEPTION 'Pengesahan babak ditolak: Masih terdapat % lembar penilaian (peserta x maqra x hakim) yang belum difinalisasi.', v_incomplete_count;
    END IF;

    IF p_next_stage_id IS NOT NULL THEN
        SELECT * INTO v_next_stage FROM public.stages WHERE id = p_next_stage_id FOR UPDATE;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Babak lanjutan tidak ditemukan.';
        END IF;
        IF v_next_stage.tenant_id <> v_stage.tenant_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian tenant: Babak lanjutan berada pada tenant berbeda.';
        END IF;
        IF v_stage.branch_id IS NOT NULL AND v_next_stage.branch_id IS NOT NULL AND v_next_stage.branch_id <> v_stage.branch_id THEN
            RAISE EXCEPTION 'Ketidaksesuaian cabang: Babak lanjutan berada pada cabang lomba berbeda.';
        END IF;
    END IF;

    PERFORM set_config('mtq.rpc_stage_finalize_active', 'true', true);
    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    v_computed_data := public.compute_stage_rankings(p_stage_id);
    v_rankings_arr := COALESCE(v_computed_data -> 'rankings', '[]'::jsonb);
    v_rubric_version_id := NULLIF(v_computed_data ->> 'rubric_version_id', '')::uuid;
    SELECT COALESCE(string_agg(elem, ' > '), 'total > Tajwid > Lagu > Fashahah')
    INTO v_tie_break_rule_used
    FROM jsonb_array_elements_text(COALESCE(v_computed_data -> 'tie_break_order', '["total","Tajwid","Lagu","Fashahah"]'::jsonb)) AS elem;

    WITH parsed_rankings AS (
        SELECT
            (elem ->> 'stage_participation_id')::uuid AS stage_participation_id,
            (elem ->> 'participant_id')::uuid AS participant_id,
            elem ->> 'lottery_number' AS lottery_number,
            (elem ->> 'computed_score')::numeric AS computed_score,
            (elem ->> 'rank')::int AS true_rank,
            (elem ->> 'display_order')::int AS display_order,
            COALESCE((elem ->> 'is_tied')::boolean, false) AS is_tied
        FROM jsonb_array_elements(v_rankings_arr) AS elem
    ),
    tie_groups AS (
        SELECT
            pr.true_rank,
            COUNT(*) AS group_size,
            MIN(pr.display_order) AS min_order,
            MAX(pr.display_order) AS max_order,
            -- T1: SETIAP peserta dalam kelompok seri wajib punya urutan pleno (bilangan bulat) dan alasan >= 5 karakter
            BOOL_AND(
                p_tie_resolution IS NOT NULL
                AND jsonb_typeof(p_tie_resolution) = 'object'
                AND COALESCE(p_tie_resolution ->> pr.participant_id::text, '') ~ '^[0-9]+$'
            ) AS has_tie_resolution,
            BOOL_AND(
                p_override_reasons IS NOT NULL
                AND jsonb_typeof(p_override_reasons) = 'object'
                AND LENGTH(TRIM(COALESCE(p_override_reasons ->> pr.participant_id::text, ''))) >= 5
            ) AS has_override_reason,
            COUNT(DISTINCT CASE
                WHEN COALESCE(p_tie_resolution ->> pr.participant_id::text, '') ~ '^[0-9]+$'
                THEN (p_tie_resolution ->> pr.participant_id::text)::int
            END) AS distinct_positions,
            MIN(CASE WHEN COALESCE(p_tie_resolution ->> pr.participant_id::text, '') ~ '^[0-9]+$'
                     THEN (p_tie_resolution ->> pr.participant_id::text)::int END) AS min_position,
            MAX(CASE WHEN COALESCE(p_tie_resolution ->> pr.participant_id::text, '') ~ '^[0-9]+$'
                     THEN (p_tie_resolution ->> pr.participant_id::text)::int END) AS max_position
        FROM parsed_rankings pr
        WHERE pr.is_tied = true
        GROUP BY pr.true_rank
    )
    SELECT COUNT(*) INTO v_unresolved_critical_tie_count
    FROM tie_groups tg
    WHERE (
        (p_next_stage_id IS NOT NULL AND tg.min_order <= v_stage.qualification_quota AND tg.max_order > v_stage.qualification_quota)
        OR
        (p_next_stage_id IS NULL AND tg.true_rank <= v_champion_count)
    )
    AND NOT (
        tg.has_tie_resolution
        AND tg.has_override_reason
        AND tg.distinct_positions = tg.group_size
        AND tg.min_position = 1
        AND tg.max_position = tg.group_size
    );

    IF v_unresolved_critical_tie_count > 0 THEN
        RAISE EXCEPTION 'UNRESOLVED_CRITICAL_TIE: Pengesahan babak diblokir: Terjadi nilai seri identik pada seluruh kriteria tie-break di batas kuota atau podium juara. Keputusan pleno wajib mencakup SELURUH peserta yang seri dengan urutan unik 1..n (p_tie_resolution) dan alasan minimal 5 karakter untuk setiap peserta (p_override_reasons).';
    END IF;

    WITH parsed_rankings AS (
        SELECT
            (elem ->> 'stage_participation_id')::uuid AS stage_participation_id,
            (elem ->> 'participant_id')::uuid AS participant_id,
            elem ->> 'lottery_number' AS lottery_number,
            (elem ->> 'computed_score')::numeric AS computed_score,
            (elem ->> 'rank')::int AS true_rank,
            (elem ->> 'display_order')::int AS display_order,
            COALESCE((elem ->> 'is_tied')::boolean, false) AS is_tied
        FROM jsonb_array_elements(v_rankings_arr) AS elem
    ),
    resolved_order AS (
        SELECT
            pr.stage_participation_id,
            pr.participant_id,
            pr.computed_score,
            pr.true_rank,
            pr.is_tied,
            ROW_NUMBER() OVER (
                ORDER BY
                    pr.true_rank ASC NULLS LAST,
                    CASE
                        WHEN pr.is_tied
                             AND p_tie_resolution IS NOT NULL
                             AND jsonb_typeof(p_tie_resolution) = 'object'
                             AND (p_tie_resolution ->> pr.participant_id::text) ~ '^[0-9]+(\.[0-9]+)?$'
                        THEN (p_tie_resolution ->> pr.participant_id::text)::numeric
                        ELSE NULL
                    END ASC NULLS LAST,
                    CASE
                        WHEN pr.is_tied
                             AND p_tie_resolution IS NOT NULL
                             AND jsonb_typeof(p_tie_resolution) = 'object'
                             AND LOWER(COALESCE(p_tie_resolution ->> pr.participant_id::text, '')) IN ('true', 'qualified', 'lolos', 'winner')
                        THEN 0
                        WHEN pr.is_tied AND (pr.participant_id = ANY(p_qualified_participant_ids))
                        THEN 0
                        ELSE 1
                    END ASC,
                    pr.display_order ASC
            )::int AS resolved_rank
        FROM parsed_rankings pr
    )
    UPDATE public.stage_participations sp
    SET final_score = ro.computed_score,
        -- S1: seri yang tidak diputus pleno (di luar posisi kritis) berbagi peringkat yang sama;
        --     nomor undian hanya dipakai untuk urutan tampilan, bukan peringkat resmi
        rank = CASE
            WHEN ro.is_tied
                 AND NOT (COALESCE(p_tie_resolution ->> ro.participant_id::text, '') ~ '^[0-9]+$')
            THEN ro.true_rank
            ELSE ro.resolved_rank
        END
    FROM resolved_order ro
    WHERE sp.id = ro.stage_participation_id;

    IF p_next_stage_id IS NOT NULL THEN
        SELECT COUNT(*) INTO v_unjustified_override_count
        FROM public.stage_participations sp
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id
          AND (
              (sp.participant_id = ANY(p_qualified_participant_ids) AND sp.rank > v_stage.qualification_quota)
              OR
              (NOT (sp.participant_id = ANY(p_qualified_participant_ids)) AND sp.rank <= v_stage.qualification_quota)
          )
          AND LENGTH(TRIM(COALESCE(p_override_reasons ->> sp.participant_id::text, ''))) < 5;

        IF v_unjustified_override_count > 0 THEN
            RAISE EXCEPTION 'Pengesahan babak ditolak: Setiap perubahan kelulusan terhadap peringkat kuota (meloloskan di luar kuota atau menggugurkan di dalam kuota) wajib disertai alasan override minimal 5 karakter.';
        END IF;
    END IF;

    IF p_next_stage_id IS NOT NULL THEN
        UPDATE public.stage_participations sp
        SET is_qualified = (sp.participant_id = ANY(p_qualified_participant_ids)),
            champion_rank = NULL,
            champion_title = NULL,
            status = 'Lengkap',
            qualification_reason = COALESCE(
                NULLIF(TRIM(p_override_reasons ->> sp.participant_id::text), ''),
                CASE WHEN sp.participant_id = ANY(p_qualified_participant_ids) THEN 'Lolos Kuota Peringkat' ELSE 'Tidak Masuk Kuota' END
            ),
            finalized_at = v_now,
            updated_at = v_now
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id;
    ELSE
        UPDATE public.stage_participations sp
        SET is_qualified = false,
            champion_rank = CASE WHEN sp.rank <= v_champion_count THEN sp.rank ELSE NULL END,
            champion_title = CASE WHEN sp.rank <= v_champion_count THEN 'Juara ' || sp.rank::text ELSE NULL END,
            status = 'Lengkap',
            qualification_reason = COALESCE(
                NULLIF(TRIM(p_override_reasons ->> sp.participant_id::text), ''),
                CASE
                    WHEN sp.rank <= v_champion_count THEN 'Juara ' || sp.rank::text
                    ELSE 'Finalis Peringkat ' || sp.rank::text
                END
            ),
            finalized_at = v_now,
            updated_at = v_now
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id;
    END IF;

    UPDATE public.participants p
    SET status = CASE
        WHEN p_next_stage_id IS NOT NULL THEN
            CASE WHEN p.id = ANY(p_qualified_participant_ids) THEN 'Menunggu' ELSE 'Gugur' END
        ELSE 'Final'
    END,
    updated_at = v_now
    WHERE p.id IN (
        SELECT participant_id FROM public.stage_participations
        WHERE stage_id = p_stage_id AND tenant_id = v_stage.tenant_id
    );

    IF p_next_stage_id IS NOT NULL AND v_qualified_count > 0 THEN
        INSERT INTO public.stage_participations (
            id,
            tenant_id,
            stage_id,
            participant_id,
            lottery_number,
            status,
            created_at,
            updated_at
        )
        SELECT
            gen_random_uuid(),
            v_stage.tenant_id,
            v_next_stage.id,
            q_pid,
            (SELECT lottery_number FROM public.participants WHERE id = q_pid),
            'Belum Dimulai',
            v_now,
            v_now
        FROM unnest(p_qualified_participant_ids) AS q_pid
        WHERE NOT EXISTS (
            SELECT 1 FROM public.stage_participations sp_exist
            WHERE sp_exist.stage_id = v_next_stage.id
              AND sp_exist.participant_id = q_pid
        );
    END IF;

    UPDATE public.stages
    SET is_finalized = true,
        finalized_at = v_now,
        status = 'Selesai'
    WHERE id = p_stage_id;

    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'participant_id', sp.participant_id,
                'participantId', sp.participant_id,
                'participant_name', p.name,
                'participantName', p.name,
                'lottery_number', sp.lottery_number,
                'lotteryNumber', sp.lottery_number,
                'kafilah_name', COALESCE(k.name, '-'),
                'kafilahName', COALESCE(k.name, '-'),
                'branch_id', COALESCE(v_stage.branch_id, p.branch_id),
                'branchId', COALESCE(v_stage.branch_id, p.branch_id),
                'branch_name', COALESCE(b.name, 'Semua Cabang'),
                'branchName', COALESCE(b.name, 'Semua Cabang'),
                'stage_id', p_stage_id,
                'stageId', p_stage_id,
                'stage_name', v_stage.name,
                'stageName', v_stage.name,
                'final_score', sp.final_score,
                'totalScore', sp.final_score,
                'field_scores', COALESCE(r_elem -> 'field_scores', '{}'::jsonb),
                'fieldScores', COALESCE(r_elem -> 'field_scores', '{}'::jsonb),
                'rank', sp.rank,
                'is_qualified', sp.is_qualified,
                'isQualified', sp.is_qualified,
                'champion_rank', sp.champion_rank,
                'championRank', sp.champion_rank,
                'champion_title', sp.champion_title,
                'championTitle', sp.champion_title,
                'qualification_reason', sp.qualification_reason,
                'reason', sp.qualification_reason,
                'tieBreakResolvedBy', r_elem ->> 'tie_break_note'
            )
            ORDER BY sp.rank ASC, sp.lottery_number ASC
        ),
        '[]'::jsonb
    ) INTO v_authoritative_snapshot
    FROM public.stage_participations sp
    JOIN public.participants p ON p.id = sp.participant_id
    LEFT JOIN public.kafilahs k ON k.id = p.kafilah_id
    LEFT JOIN public.branches b ON b.id = COALESCE(v_stage.branch_id, p.branch_id)
    LEFT JOIN LATERAL (
        SELECT elem
        FROM jsonb_array_elements(v_rankings_arr) AS elem
        WHERE (elem ->> 'participant_id')::uuid = sp.participant_id
        LIMIT 1
    ) r_match(r_elem) ON true
    WHERE sp.stage_id = p_stage_id
      AND sp.tenant_id = v_stage.tenant_id;

    INSERT INTO public.stage_result_snapshots (
        tenant_id,
        stage_id,
        branch_id,
        quota,
        rubric_version_id,
        tie_break_rule_used,
        finalized_by,
        rankings_snapshot
    )
    VALUES (
        v_stage.tenant_id,
        p_stage_id,
        v_stage.branch_id,
        CASE WHEN p_next_stage_id IS NOT NULL THEN v_stage.qualification_quota ELSE v_champion_count END,
        v_rubric_version_id,
        v_tie_break_rule_used,
        v_actor_id,
        v_authoritative_snapshot
    )
    ON CONFLICT (tenant_id, stage_id) DO NOTHING;

    INSERT INTO public.audit_logs (tenant_id, actor_id, actor_name, action, target, summary, outcome)
    VALUES (
        v_stage.tenant_id,
        v_actor_id,
        COALESCE(v_actor.name, 'Admin') || ' (' || COALESCE(v_actor.role, 'admin') || ')',
        'STAGE_FINALIZED',
        'Stage: ' || v_stage.name || ' (ID: ' || p_stage_id::text || ')',
        CASE
            WHEN p_next_stage_id IS NOT NULL THEN
                'Pengesahan resmi babak ' || v_stage.name || ' dengan ' || v_qualified_count::text || ' peserta diloloskan ke ' || COALESCE(v_next_stage.name, 'Babak Lanjutan')
            ELSE
                'Pengesahan resmi hasil kejuaraan babak final ' || v_stage.name || ' dengan ' || LEAST(v_participation_count, v_champion_count)::text || ' juara ditetapkan.'
        END,
        'Success'
    );

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Babak berhasil disahkan secara resmi dan peserta lolos telah dipindahkan.',
        'qualified_count', v_qualified_count,
        'champion_count', CASE WHEN p_next_stage_id IS NULL THEN LEAST(v_participation_count, v_champion_count) ELSE 0 END,
        'next_stage_id', p_next_stage_id
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.draw_lottery_server(
    p_tenant_id UUID,
    p_stage_id UUID,
    p_branch_id UUID DEFAULT NULL,
    p_level_id UUID DEFAULT NULL,
    p_questions_per_participant INT DEFAULT 1,
    p_draw_mode VARCHAR DEFAULT 'both',
    p_notes TEXT DEFAULT NULL,
    p_participant_ids UUID[] DEFAULT NULL,
    p_question_pool_ids UUID[] DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor_id UUID;
    v_actor_profile RECORD;
    v_actor_name VARCHAR(150);
    v_stage public.stages%ROWTYPE;
    v_branch_name VARCHAR(150);
    v_level_name VARCHAR(150);
    v_seed_hex TEXT;
    v_seed_sha256 TEXT;
    v_draw_version INT;
    v_draw_log_id UUID := gen_random_uuid();
    v_now TIMESTAMPTZ := now();
    v_unverified RECORD;
    v_part RECORD;
    v_sp public.stage_participations%ROWTYPE;
    v_idx INT := 0;
    v_new_lottery_no VARCHAR(30);
    v_used_q_ids UUID[] := ARRAY[]::uuid[];
    v_picked_q_ids UUID[];
    v_picked_q_codes TEXT[];
    v_first_q public.questions%ROWTYPE;
    v_q_id UUID;
    v_all_p_ids TEXT[] := ARRAY[]::text[];
    v_all_q_ids TEXT[] := ARRAY[]::text[];
    v_draw_results JSONB := '[]'::jsonb;
    v_target_count INT := 0;
BEGIN
    v_actor_id := auth.uid();
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'Tidak terautentikasi: Sesi pengguna tidak ditemukan.';
    END IF;

    IF NOT (public.is_tenant_admin(p_tenant_id) OR public.is_superadmin()) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Administrator Tenant atau Superadmin yang berwenang menjalankan undian server.';
    END IF;

    IF p_draw_mode NOT IN ('lottery_number', 'maqra', 'both') THEN
        RAISE EXCEPTION 'Mode undian "%" tidak valid. Gunakan lottery_number, maqra, atau both.', p_draw_mode;
    END IF;

    IF COALESCE(p_questions_per_participant, 1) < 1 THEN
        RAISE EXCEPTION 'Jumlah maqra per peserta minimal 1.';
    END IF;

    -- S5: kunci baris babak agar dua undian bersamaan tidak saling menimpa
    SELECT * INTO v_stage FROM public.stages WHERE id = p_stage_id AND tenant_id = p_tenant_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan pada tenant ini.';
    END IF;

    IF v_stage.is_finalized THEN
        RAISE EXCEPTION 'STAGE_ALREADY_FINALIZED: Pengundian ditolak karena Babak "%" telah difinalisasi secara resmi.', v_stage.name;
    END IF;

    -- Blokir pengundian ulang apabila sudah ada lembar penilaian pada babak ini
    IF EXISTS (
        SELECT 1
        FROM public.judge_assessments ja
        JOIN public.stage_participations sp ON sp.id = ja.stage_participation_id
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = p_tenant_id
    ) THEN
        RAISE EXCEPTION 'STAGE_ASSESSMENTS_ALREADY_STARTED: Pengundian ditolak karena penilaian dewan hakim sudah dimulai pada babak "%".', v_stage.name;
    END IF;

    SELECT name, role INTO v_actor_profile FROM public.profiles WHERE id = v_actor_id;
    v_actor_name := COALESCE(NULLIF(TRIM(v_actor_profile.name), ''), 'Administrator MTQ');

    IF p_branch_id IS NOT NULL THEN
        SELECT name INTO v_branch_name FROM public.branches WHERE id = p_branch_id AND tenant_id = p_tenant_id;
    ELSIF v_stage.branch_id IS NOT NULL THEN
        SELECT name INTO v_branch_name FROM public.branches WHERE id = v_stage.branch_id AND tenant_id = p_tenant_id;
    END IF;

    IF p_level_id IS NOT NULL THEN
        SELECT name INTO v_level_name FROM public.levels WHERE id = p_level_id AND tenant_id = p_tenant_id;
    END IF;

    -- Periksa apakah ada peserta dalam cakupan undian yang belum berstatus 'Diverifikasi'
    SELECT p.id, p.name, p.verification_status
    INTO v_unverified
    FROM public.participants p
    LEFT JOIN public.stage_participations sp
      ON sp.participant_id = p.id
     AND sp.stage_id = p_stage_id
     AND sp.tenant_id = p_tenant_id
    WHERE p.tenant_id = p_tenant_id
      AND (
          (p_participant_ids IS NOT NULL AND array_length(p_participant_ids, 1) > 0 AND p.id = ANY(p_participant_ids))
          OR (
              (p_participant_ids IS NULL OR array_length(p_participant_ids, 1) IS NULL)
              AND (sp.id IS NOT NULL OR p.stage_id = p_stage_id OR (p.stage_id IS NULL AND v_stage.stage_order = 1))
              AND (COALESCE(p_branch_id, v_stage.branch_id) IS NULL OR p.branch_id = COALESCE(p_branch_id, v_stage.branch_id))
              AND (p_level_id IS NULL OR p.level_id = p_level_id)
          )
      )
      -- T4: hanya peserta yang masih menunggu verifikasi yang memblokir; peserta Ditolak dikeluarkan dari undian
      AND COALESCE(p.verification_status, 'Diajukan') = 'Diajukan'
    LIMIT 1;

    IF FOUND THEN
        RAISE EXCEPTION 'PARTICIPANT_NOT_VERIFIED: Peserta "%" belum diverifikasi berkasnya (status: %). Selesaikan verifikasi (Diverifikasi/Ditolak) sebelum undian; peserta Ditolak otomatis tidak diundi.', v_unverified.name, v_unverified.verification_status;
    END IF;

    -- Benih acak kriptografis di server. gen_random_bytes (pgcrypto) bila tersedia;
    -- jika tidak, gen_random_uuid() bawaan PostgreSQL 13+ (juga CSPRNG). Tidak ada fallback deterministik.
    BEGIN
        EXECUTE 'SELECT encode(gen_random_bytes(16), ''hex'')' INTO v_seed_hex;
    EXCEPTION WHEN undefined_function THEN
        v_seed_hex := replace(gen_random_uuid()::text, '-', '');
    END;
    IF v_seed_hex IS NULL OR length(v_seed_hex) < 32 THEN
        RAISE EXCEPTION 'LOTTERY_SEED_UNAVAILABLE: Benih acak server tidak dapat dibangkitkan.';
    END IF;

    -- SHA-256 asli (fungsi bawaan PostgreSQL 11+), dicatat agar benih dapat diverifikasi publik
    v_seed_sha256 := encode(sha256(convert_to(v_seed_hex, 'UTF8')), 'hex');

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    -- Acak urutan peserta secara deterministik dari benih (dapat direproduksi via verify_lottery_draw)
    FOR v_part IN
        SELECT p.*
        FROM public.participants p
        LEFT JOIN public.stage_participations sp
          ON sp.participant_id = p.id
         AND sp.stage_id = p_stage_id
         AND sp.tenant_id = p_tenant_id
        WHERE p.tenant_id = p_tenant_id
          AND COALESCE(p.verification_status, 'Diajukan') = 'Diverifikasi'
          AND (
              (p_participant_ids IS NOT NULL AND array_length(p_participant_ids, 1) > 0 AND p.id = ANY(p_participant_ids))
              OR (
                  (p_participant_ids IS NULL OR array_length(p_participant_ids, 1) IS NULL)
                  AND (sp.id IS NOT NULL OR p.stage_id = p_stage_id OR (p.stage_id IS NULL AND v_stage.stage_order = 1))
                  AND (COALESCE(p_branch_id, v_stage.branch_id) IS NULL OR p.branch_id = COALESCE(p_branch_id, v_stage.branch_id))
                  AND (p_level_id IS NULL OR p.level_id = p_level_id)
              )
          )
        ORDER BY public.lottery_sort_key(v_seed_hex, p.id::text, ''), p.id
    LOOP
        v_idx := v_idx + 1;
        v_target_count := v_target_count + 1;
        v_all_p_ids := array_append(v_all_p_ids, v_part.id::text);

        SELECT * INTO v_sp
        FROM public.stage_participations
        WHERE stage_id = p_stage_id
          AND participant_id = v_part.id
          AND tenant_id = p_tenant_id
        LIMIT 1;

        IF NOT FOUND THEN
            INSERT INTO public.stage_participations (
                id, tenant_id, stage_id, participant_id, lottery_number, status, created_at, updated_at
            ) VALUES (
                gen_random_uuid(), p_tenant_id, p_stage_id, v_part.id,
                v_part.lottery_number, 'Belum Dimulai', v_now, v_now
            ) RETURNING * INTO v_sp;
        END IF;

        IF p_draw_mode IN ('lottery_number', 'both') THEN
            v_new_lottery_no := LPAD(v_idx::text, 2, '0');
            UPDATE public.stage_participations
            SET lottery_number = v_new_lottery_no,
                updated_at = v_now
            WHERE id = v_sp.id;

            UPDATE public.participants
            SET stage_id = COALESCE(stage_id, p_stage_id),
                updated_at = v_now
            WHERE id = v_part.id
              AND tenant_id = p_tenant_id;
        ELSE
            v_new_lottery_no := COALESCE(v_sp.lottery_number, v_part.lottery_number, LPAD(v_idx::text, 2, '0'));
        END IF;

        v_picked_q_ids := ARRAY[]::uuid[];
        v_picked_q_codes := ARRAY[]::text[];

        IF p_draw_mode IN ('maqra', 'both') THEN
            -- Pilih p_questions_per_participant soal aktif yang sesuai 3D (cabang + jenjang + babak),
            -- prioritaskan soal yang belum terpakai pada batch ini (sampling without replacement sebelum daur ulang)
            SELECT
                ARRAY_AGG(sub.id ORDER BY sub.ord),
                ARRAY_AGG((sub.code || ' - ' || sub.title) ORDER BY sub.ord)
            INTO v_picked_q_ids, v_picked_q_codes
            FROM (
                SELECT
                    q.id,
                    q.code,
                    q.title,
                    ROW_NUMBER() OVER (
                        ORDER BY
                            CASE WHEN q.id = ANY(v_used_q_ids) THEN 1 ELSE 0 END ASC,
                            public.lottery_sort_key(v_seed_hex, v_part.id::text, q.id::text) ASC,
                            q.id ASC
                    ) AS ord
                FROM public.questions q
                WHERE q.tenant_id = p_tenant_id
                  AND q.status = 'Aktif'
                  AND (q.stage_id IS NULL OR q.stage_id = p_stage_id)
                  AND (COALESCE(p_branch_id, v_stage.branch_id, v_part.branch_id) IS NULL OR q.branch_id IS NULL OR q.branch_id = COALESCE(p_branch_id, v_stage.branch_id, v_part.branch_id))
                  AND (COALESCE(p_level_id, v_part.level_id) IS NULL OR q.level_id IS NULL OR q.level_id = COALESCE(p_level_id, v_part.level_id))
                  AND (p_question_pool_ids IS NULL OR array_length(p_question_pool_ids, 1) IS NULL OR q.id = ANY(p_question_pool_ids))
                LIMIT p_questions_per_participant
            ) sub;

            IF v_picked_q_ids IS NULL OR COALESCE(array_length(v_picked_q_ids, 1), 0) < p_questions_per_participant THEN
                RAISE EXCEPTION 'INSUFFICIENT_QUESTION_POOL: Jumlah soal aktif yang sesuai cabang/jenjang/babak tidak mencukupi untuk peserta "%" (butuh %, tersedia %).',
                    v_part.name, p_questions_per_participant, COALESCE(array_length(v_picked_q_ids, 1), 0);
            END IF;

            DELETE FROM public.assigned_maqras
            WHERE stage_participation_id = v_sp.id
              AND tenant_id = p_tenant_id;

            FOREACH v_q_id IN ARRAY v_picked_q_ids
            LOOP
                INSERT INTO public.assigned_maqras (
                    id, tenant_id, stage_participation_id, question_id, assigned_at, assigned_by, method, notes
                ) VALUES (
                    gen_random_uuid(),
                    p_tenant_id,
                    v_sp.id,
                    v_q_id,
                    v_now,
                    v_actor_id,
                    'undian',
                    COALESCE(p_notes, 'Undian Server Terverifikasi (SHA-256: ' || LEFT(v_seed_sha256, 12) || ')')
                );
                v_used_q_ids := array_append(v_used_q_ids, v_q_id);
                IF NOT (v_q_id::text = ANY(v_all_q_ids)) THEN
                    v_all_q_ids := array_append(v_all_q_ids, v_q_id::text);
                END IF;
            END LOOP;

            SELECT * INTO v_first_q FROM public.questions WHERE id = v_picked_q_ids[1];

            UPDATE public.stage_participations
            SET status = 'Belum Dimulai',
                updated_at = v_now
            WHERE id = v_sp.id;

            UPDATE public.participants
            SET stage_id = COALESCE(stage_id, p_stage_id),
                updated_at = v_now
            WHERE id = v_part.id
              AND tenant_id = p_tenant_id;
        ELSE
            -- Jika hanya mengundi nomor tampil, pertahankan daftar maqra yang sudah ada untuk catatan log
            SELECT
                COALESCE(ARRAY_AGG(q.id), ARRAY[]::uuid[]),
                COALESCE(ARRAY_AGG(q.code || ' - ' || q.title), ARRAY[]::text[])
            INTO v_picked_q_ids, v_picked_q_codes
            FROM public.assigned_maqras am
            JOIN public.questions q ON q.id = am.question_id
            WHERE am.stage_participation_id = v_sp.id;
        END IF;

        v_draw_results := v_draw_results || jsonb_build_array(
            jsonb_build_object(
                'participantId', v_part.id,
                'participantCode', v_part.participant_code,
                'participantName', v_part.name,
                'lotteryNumber', v_new_lottery_no,
                'questionIds', to_jsonb(v_picked_q_ids),
                'assignedQuestionIds', to_jsonb(v_picked_q_ids),
                'questionTitles', to_jsonb(v_picked_q_codes),
                'assignedQuestionCodes', to_jsonb(v_picked_q_codes)
            )
        );
    END LOOP;

    IF v_target_count = 0 THEN
        RAISE EXCEPTION 'NO_ELIGIBLE_PARTICIPANTS: Tidak ada peserta berstatus Diverifikasi yang ditemukan untuk cakupan undian ini.';
    END IF;

    SELECT COALESCE(MAX(draw_version), 0) + 1 INTO v_draw_version
    FROM public.lottery_draw_logs
    WHERE tenant_id = p_tenant_id AND stage_id = p_stage_id;

    INSERT INTO public.lottery_draw_logs (
        id, tenant_id, stage_id, stage_name, branch_id, branch_name, level_id, level_name,
        actor_id, actor_name, questions_per_participant, participant_ids, question_pool_ids,
        draw_results, draw_version, notes, seed_hex, seed_sha256, draw_mode, created_at
    ) VALUES (
        v_draw_log_id, p_tenant_id, p_stage_id, v_stage.name,
        COALESCE(p_branch_id, v_stage.branch_id), COALESCE(v_branch_name, 'Semua Cabang'),
        p_level_id, COALESCE(v_level_name, 'Semua Jenjang'),
        v_actor_id, v_actor_name, p_questions_per_participant,
        v_all_p_ids, v_all_q_ids,
        v_draw_results, v_draw_version,
        COALESCE(p_notes, 'Undian Server (' || p_draw_mode || ') SHA-256: ' || LEFT(v_seed_sha256, 16)),
        v_seed_hex, v_seed_sha256, p_draw_mode, v_now
    );

    PERFORM set_config('mtq.rpc_audit_active', 'true', true);

    INSERT INTO public.audit_logs (
        tenant_id, actor_id, actor_name, action, target, summary, outcome, created_at
    ) VALUES (
        p_tenant_id, v_actor_id, v_actor_name,
        'LOTTERY_DRAW_COMMITTED',
        v_stage.name || ' - ' || COALESCE(v_branch_name, 'Semua Cabang'),
        'Undian Server (' || p_draw_mode || ') versi #' || v_draw_version || ': ' || v_target_count || ' peserta (SHA-256: ' || LEFT(v_seed_sha256, 12) || ').',
        'Success', v_now
    );

    RETURN jsonb_build_object(
        'success', true,
        'draw_log_id', v_draw_log_id,
        'draw_version', v_draw_version,
        'draw_mode', p_draw_mode,
        'seed_hex', v_seed_hex,
        'seed_sha256', v_seed_sha256,
        'participants_count', v_target_count,
        'results', v_draw_results
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.calculate_assessment_score_sql(
    p_tenant_id UUID,
    p_rubric_version_id UUID,
    p_error_counts JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_rubric RECORD;
    v_field RECORD;
    v_cat RECORD;
    v_cat_key TEXT;
    v_count_val TEXT;
    v_count NUMERIC;
    v_target_field_name TEXT;
    v_field_max_deduction NUMERIC;
    v_deduction NUMERIC;
    v_rule_deduction_points NUMERIC;
    v_rule_max_deduction NUMERIC;
    v_crit_id UUID;
    v_crit_max_deduction NUMERIC;
    v_unit_deduction NUMERIC;
    v_raw_deduction NUMERIC;
    v_crit_deductions JSONB := '{}'::jsonb;
    v_field_deductions JSONB := '{}'::jsonb;
    v_field_scores JSONB := '{}'::jsonb;
    v_deductions JSONB := '{}'::jsonb;
    v_total_deductions NUMERIC := 0.00;
    v_final_score NUMERIC := 0.00;
    v_cur_crit_ded NUMERIC;
    v_allowed_crit NUMERIC;
    v_field_score NUMERIC;
BEGIN
    SELECT * INTO v_rubric FROM public.rubric_versions WHERE id = p_rubric_version_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Rubrik penilaian tidak ditemukan di database.';
    END IF;

    FOR v_field IN
        SELECT * FROM public.rubric_fields
        WHERE rubric_version_id = p_rubric_version_id
          AND status = 'Aktif'
        ORDER BY field_order ASC
    LOOP
        v_field_deductions := jsonb_set(v_field_deductions, ARRAY[v_field.name], '0'::jsonb);
        v_field_scores := jsonb_set(v_field_scores, ARRAY[v_field.name], to_jsonb(v_field.max_score));
    END LOOP;

    IF p_error_counts IS NOT NULL AND jsonb_typeof(p_error_counts) = 'object' THEN
        FOR v_cat_key, v_count_val IN
            SELECT key, value #>> '{}' FROM jsonb_each(p_error_counts)
        LOOP
            IF v_count_val IS NULL OR TRIM(v_count_val) = '' THEN
                CONTINUE;
            END IF;

            IF NOT (v_count_val ~ '^[0-9]+$') THEN
                RAISE EXCEPTION 'Jumlah kejadian kesalahan kategori % wajib berupa bilangan bulat non-negatif.', v_cat_key;
            END IF;

            v_count := v_count_val::numeric;
            IF v_count <= 0 THEN
                CONTINUE;
            END IF;

            SELECT * INTO v_cat
            FROM public.error_categories
            WHERE tenant_id = p_tenant_id
              AND (id::text = v_cat_key OR code = v_cat_key)
              AND status = 'Aktif'
            LIMIT 1;

            IF NOT FOUND THEN
                RAISE EXCEPTION 'Kategori kesalahan % tidak ditemukan atau tidak berstatus aktif pada tenant ini.', v_cat_key;
            END IF;

            v_target_field_name := NULL;
            IF v_cat.rubric_field_id IS NOT NULL THEN
                SELECT name INTO v_target_field_name
                FROM public.rubric_fields
                WHERE id = v_cat.rubric_field_id
                  AND rubric_version_id = p_rubric_version_id
                  AND status = 'Aktif';
            END IF;

            IF v_target_field_name IS NULL AND v_cat.criterion_id IS NOT NULL THEN
                SELECT rf.name INTO v_target_field_name
                FROM public.rubric_criteria rc
                JOIN public.rubric_fields rf ON rf.id = rc.rubric_field_id
                WHERE rc.id = v_cat.criterion_id
                  AND rf.rubric_version_id = p_rubric_version_id
                  AND rf.status = 'Aktif';
            END IF;

            IF v_target_field_name IS NULL AND v_cat.deduction_rule_id IS NOT NULL THEN
                SELECT rf.name INTO v_target_field_name
                FROM public.deduction_rules dr
                JOIN public.rubric_criteria rc ON rc.id = dr.criterion_id
                JOIN public.rubric_fields rf ON rf.id = rc.rubric_field_id
                WHERE dr.id = v_cat.deduction_rule_id
                  AND rf.rubric_version_id = p_rubric_version_id
                  AND rf.status = 'Aktif';
            END IF;

            IF v_target_field_name IS NULL THEN
                SELECT name INTO v_target_field_name
                FROM public.rubric_fields
                WHERE rubric_version_id = p_rubric_version_id
                  AND status = 'Aktif'
                  AND (
                      LOWER(name) = LOWER(v_cat.name)
                      OR LOWER(code) = LOWER(v_cat.code)
                      OR (v_cat.scope IS NOT NULL AND LOWER(name) = LOWER(v_cat.scope))
                  )
                LIMIT 1;
            END IF;

            -- J6: tidak ada lagi tebakan bidang berdasarkan kemiripan nama (ILIKE); kategori wajib dipetakan eksplisit

            IF v_target_field_name IS NULL THEN
                RAISE EXCEPTION 'Kategori kesalahan "%" belum terpetakan ke bidang rubrik aktif pada rubrik "%". Dilarang fallback ke bidang lain.', v_cat.name, v_rubric.name;
            END IF;

            v_unit_deduction := v_cat.default_deduction;
            v_raw_deduction := ROUND(v_count * v_unit_deduction, 2);

            IF v_cat.deduction_rule_id IS NOT NULL THEN
                SELECT dr.deduction_points, dr.max_deduction
                INTO v_rule_deduction_points, v_rule_max_deduction
                FROM public.deduction_rules dr
                WHERE dr.id = v_cat.deduction_rule_id;

                IF FOUND THEN
                    IF v_rule_deduction_points IS NOT NULL THEN
                        v_unit_deduction := v_rule_deduction_points;
                        v_raw_deduction := ROUND(v_count * v_unit_deduction, 2);
                    END IF;
                    IF v_rule_max_deduction IS NOT NULL AND v_rule_max_deduction >= 0 THEN
                        v_raw_deduction := LEAST(v_raw_deduction, v_rule_max_deduction);
                    END IF;
                END IF;
            END IF;

            IF v_cat.max_deduction IS NOT NULL AND v_cat.max_deduction >= 0 THEN
                v_raw_deduction := LEAST(v_raw_deduction, v_cat.max_deduction);
            END IF;

            IF v_cat.criterion_id IS NOT NULL THEN
                SELECT rc.id, rc.max_deduction
                INTO v_crit_id, v_crit_max_deduction
                FROM public.rubric_criteria rc
                WHERE rc.id = v_cat.criterion_id;

                IF FOUND AND v_crit_max_deduction IS NOT NULL AND v_crit_max_deduction >= 0 THEN
                    v_cur_crit_ded := COALESCE((v_crit_deductions ->> v_crit_id::text)::numeric, 0.00);
                    v_allowed_crit := GREATEST(0.00, v_crit_max_deduction - v_cur_crit_ded);
                    v_raw_deduction := LEAST(v_raw_deduction, v_allowed_crit);
                    v_crit_deductions := jsonb_set(
                        v_crit_deductions,
                        ARRAY[v_crit_id::text],
                        to_jsonb(ROUND(v_cur_crit_ded + v_raw_deduction, 2))
                    );
                END IF;
            END IF;

            v_deductions := jsonb_set(v_deductions, ARRAY[v_cat_key], to_jsonb(v_raw_deduction));

            v_deduction := COALESCE((v_field_deductions ->> v_target_field_name)::numeric, 0.00) + v_raw_deduction;
            v_field_deductions := jsonb_set(v_field_deductions, ARRAY[v_target_field_name], to_jsonb(ROUND(v_deduction, 2)));
        END LOOP;
    END IF;

    v_total_deductions := 0.00;
    v_final_score := 0.00;

    FOR v_field IN
        SELECT * FROM public.rubric_fields
        WHERE rubric_version_id = p_rubric_version_id
          AND status = 'Aktif'
        ORDER BY field_order ASC
    LOOP
        v_deduction := COALESCE((v_field_deductions ->> v_field.name)::numeric, 0.00);
        v_field_max_deduction := COALESCE(v_field.max_deduction, (v_field.max_score - v_field.min_score));
        v_deduction := LEAST(v_deduction, v_field_max_deduction);
        v_deduction := ROUND(v_deduction, 2);

        v_field_score := GREATEST(v_field.min_score, LEAST(v_field.max_score, v_field.max_score - v_deduction));
        v_field_score := ROUND(v_field_score, 2);

        v_field_scores := jsonb_set(v_field_scores, ARRAY[v_field.name], to_jsonb(v_field_score));
        v_field_deductions := jsonb_set(v_field_deductions, ARRAY[v_field.name], to_jsonb(v_deduction));

        v_total_deductions := v_total_deductions + v_deduction;
        v_final_score := v_final_score + ROUND(v_field_score * COALESCE(v_field.weight, 1), 2);
    END LOOP;

    v_total_deductions := ROUND(v_total_deductions, 2);
    -- S7: nilai akhir tidak boleh melebihi nilai maksimal rubrik (paritas dengan scoringEngine klien)
    v_final_score := ROUND(GREATEST(0, LEAST(COALESCE(v_rubric.starting_score, 100.00), v_final_score)), 2);

    RETURN jsonb_build_object(
        'final_score', v_final_score,
        'total_deductions', v_total_deductions,
        'field_scores', v_field_scores,
        'field_deductions', v_field_deductions,
        'deductions', v_deductions
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.compute_stage_rankings(p_stage_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_stage RECORD;
    v_rule RECORD;
    v_has_rule BOOLEAN := false;
    v_active_rules_count INT := 0;
    v_tie_break_fields TEXT[];
    v_rubric_version_id UUID := NULL;
    v_has_custom_weights BOOLEAN := false;
    v_required_judge_count INT := 0;
    v_rankings JSONB := '[]'::jsonb;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Sesi tidak terautentikasi.';
    END IF;

    SELECT * INTO v_stage FROM public.stages WHERE id = p_stage_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Babak musabaqah tidak ditemukan.';
    END IF;

    -- T8: peringkat sementara hanya untuk admin/superadmin (menjaga independensi dewan hakim sebelum pleno)
    IF NOT (public.is_superadmin() OR public.is_tenant_admin(v_stage.tenant_id)) THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Peringkat sementara hanya dapat dilihat Administrator penyelenggara.';
    END IF;

    SELECT COUNT(*) INTO v_active_rules_count
    FROM public.competition_rule_configs crc
    WHERE crc.tenant_id = v_stage.tenant_id
      AND crc.status = 'Aktif'
      AND (
          (v_stage.branch_id IS NOT NULL AND crc.branch_id = v_stage.branch_id)
          OR (v_stage.branch_id IS NULL AND crc.branch_id IS NULL)
      );

    IF v_active_rules_count > 1 THEN
        RAISE EXCEPTION 'Konflik konfigurasi aturan kompetisi: Ditemukan % aturan berstatus Aktif untuk cabang pada babak ini.', v_active_rules_count;
    END IF;

    SELECT * INTO v_rule
    FROM public.competition_rule_configs crc
    WHERE crc.tenant_id = v_stage.tenant_id
      AND crc.status = 'Aktif'
      AND (v_stage.branch_id IS NULL OR crc.branch_id = v_stage.branch_id OR crc.branch_id IS NULL)
    ORDER BY
        CASE WHEN v_stage.branch_id IS NOT NULL AND crc.branch_id = v_stage.branch_id THEN 0 ELSE 1 END ASC,
        crc.updated_at DESC,
        crc.created_at DESC
    LIMIT 1;

    v_has_rule := FOUND;

    IF v_has_rule AND v_rule.tie_break_order IS NOT NULL THEN
        SELECT COALESCE(
            ARRAY(
                SELECT TRIM(elem)
                FROM unnest(v_rule.tie_break_order) WITH ORDINALITY AS t(elem, ord)
                WHERE LOWER(TRIM(elem)) <> 'total' AND TRIM(elem) <> ''
                ORDER BY ord ASC
            ),
            ARRAY['Tajwid', 'Lagu', 'Fashahah', 'Suara']
        ) INTO v_tie_break_fields;
        v_rubric_version_id := v_rule.rubric_version_id;
    ELSE
        v_tie_break_fields := ARRAY['Tajwid', 'Lagu', 'Fashahah', 'Suara'];
    END IF;

    IF v_rubric_version_id IS NULL THEN
        SELECT jass.rubric_version_id INTO v_rubric_version_id
        FROM public.stage_participations sp
        JOIN public.judge_assessments jass ON jass.stage_participation_id = sp.id
        WHERE sp.stage_id = p_stage_id AND sp.tenant_id = v_stage.tenant_id
        LIMIT 1;
    END IF;

    IF v_rubric_version_id IS NULL THEN
        SELECT rv.id INTO v_rubric_version_id
        FROM public.rubric_versions rv
        WHERE rv.tenant_id = v_stage.tenant_id AND rv.status = 'Aktif'
        ORDER BY CASE WHEN v_stage.branch_id IS NOT NULL AND rv.branch_id = v_stage.branch_id THEN 0 ELSE 1 END ASC
        LIMIT 1;
    END IF;

    IF v_rubric_version_id IS NOT NULL THEN
        SELECT EXISTS (
            SELECT 1 FROM public.rubric_fields rf
            WHERE rf.rubric_version_id = v_rubric_version_id
              AND rf.status = 'Aktif'
              AND COALESCE(rf.weight, 1) <> 1
        ) INTO v_has_custom_weights;
    END IF;

    SELECT COUNT(DISTINCT ja.judge_profile_id) INTO v_required_judge_count
    FROM public.judge_assignments ja
    JOIN public.tenant_memberships tm
      ON tm.tenant_id = ja.tenant_id
     AND tm.profile_id = ja.judge_profile_id
     AND tm.status = 'Aktif'
    WHERE ja.tenant_id = v_stage.tenant_id
      AND ja.stage_id = p_stage_id
      AND ja.status = 'Aktif'
      AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id);

    WITH active_judges AS (
        SELECT DISTINCT ja.judge_profile_id
        FROM public.judge_assignments ja
        JOIN public.tenant_memberships tm
          ON tm.tenant_id = ja.tenant_id
         AND tm.profile_id = ja.judge_profile_id
         AND tm.status = 'Aktif'
        WHERE ja.tenant_id = v_stage.tenant_id
          AND ja.stage_id = p_stage_id
          AND ja.status = 'Aktif'
          AND (v_stage.branch_id IS NULL OR ja.branch_id IS NULL OR ja.branch_id = v_stage.branch_id)
    ),
    valid_assessments AS (
        SELECT jass.*
        FROM public.judge_assessments jass
        JOIN active_judges aj ON aj.judge_profile_id = jass.judge_profile_id
        -- K2: hanya lembar yang memakai maqra milik peserta itu sendiri
        JOIN public.assigned_maqras am_own
          ON am_own.id = jass.assigned_maqra_id
         AND am_own.stage_participation_id = jass.stage_participation_id
        WHERE jass.tenant_id = v_stage.tenant_id
          AND jass.status = 'finalized'
          AND jass.is_locked = true
    ),
    participant_agg AS (
        SELECT
            sp.id AS stage_participation_id,
            sp.participant_id,
            p.name AS participant_name,
            sp.lottery_number,
            COALESCE(k.name, '-') AS kafilah_name,
            COALESCE(v_stage.branch_id, p.branch_id) AS branch_id,
            COALESCE(b.name, 'Semua Cabang') AS branch_name,
            (
                SELECT COUNT(*) FROM public.assigned_maqras am
                WHERE am.stage_participation_id = sp.id
            )::int AS maqra_count,
            (
                SELECT COUNT(*)
                FROM public.assigned_maqras am
                JOIN valid_assessments va
                  ON va.stage_participation_id = sp.id
                 AND va.assigned_maqra_id = am.id
                WHERE am.stage_participation_id = sp.id
            )::int AS finalized_units_count,
            (
                SELECT COUNT(DISTINCT va.judge_profile_id)
                FROM valid_assessments va
                WHERE va.stage_participation_id = sp.id
            )::int AS finalized_judge_count,
            (
                SELECT CASE
                    WHEN COUNT(va.id) = 0 THEN NULL
                    WHEN v_has_custom_weights AND v_rubric_version_id IS NOT NULL THEN
                        COALESCE(
                            (
                                SELECT ROUND(LEAST(
                                    COALESCE((SELECT rv.starting_score FROM public.rubric_versions rv WHERE rv.id = v_rubric_version_id), 100.00),
                                    SUM(field_avg * COALESCE(rf.weight, 1))
                                ), 2)
                                FROM public.rubric_fields rf
                                CROSS JOIN LATERAL (
                                    SELECT AVG(public.get_field_score(va2.field_scores, rf.name)) AS field_avg
                                    FROM valid_assessments va2
                                    WHERE va2.stage_participation_id = sp.id
                                ) fa
                                WHERE rf.rubric_version_id = v_rubric_version_id
                                  AND rf.status = 'Aktif'
                                  AND fa.field_avg IS NOT NULL
                            ),
                            ROUND(AVG(va.final_score)::numeric, 2)
                        )
                    ELSE
                        ROUND(AVG(va.final_score)::numeric, 2)
                END
                FROM valid_assessments va
                WHERE va.stage_participation_id = sp.id
            ) AS computed_score,
            (
                SELECT COALESCE(
                    jsonb_object_agg(fname, fval) FILTER (WHERE fval IS NOT NULL),
                    '{}'::jsonb
                )
                FROM (
                    SELECT DISTINCT fname
                    FROM (
                        SELECT rf.name AS fname
                        FROM public.rubric_fields rf
                        WHERE rf.rubric_version_id = v_rubric_version_id
                          AND rf.status = 'Aktif'
                        UNION
                        SELECT unnest(v_tie_break_fields) AS fname
                    ) fn
                    WHERE fname IS NOT NULL AND TRIM(fname) <> ''
                ) all_fields
                CROSS JOIN LATERAL (
                    SELECT ROUND(AVG(public.get_field_score(va.field_scores, all_fields.fname)), 2) AS fval
                    FROM valid_assessments va
                    WHERE va.stage_participation_id = sp.id
                ) calc
            ) AS field_scores
        FROM public.stage_participations sp
        JOIN public.participants p ON p.id = sp.participant_id
        LEFT JOIN public.kafilahs k ON k.id = p.kafilah_id
        LEFT JOIN public.branches b ON b.id = COALESCE(v_stage.branch_id, p.branch_id)
        WHERE sp.stage_id = p_stage_id
          AND sp.tenant_id = v_stage.tenant_id
    ),
    participant_vectors AS (
        SELECT
            pa.*,
            (
                pa.maqra_count >= 1
                AND v_required_judge_count >= 1
                AND pa.finalized_units_count = (pa.maqra_count * v_required_judge_count)
            ) AS is_complete,
            CASE
                WHEN pa.computed_score IS NULL THEN NULL::numeric[]
                ELSE ARRAY[pa.computed_score] || COALESCE(
                    ARRAY(
                        SELECT (
                            SELECT ROUND(AVG(public.get_field_score(va.field_scores, crit_name)), 2)
                            FROM valid_assessments va
                            WHERE va.stage_participation_id = pa.stage_participation_id
                        )
                        FROM unnest(v_tie_break_fields) WITH ORDINALITY AS t(crit_name, ord)
                        ORDER BY ord ASC
                    ),
                    ARRAY[]::numeric[]
                )
            END AS tie_vector
        FROM participant_agg pa
    ),
    ranked_participants AS (
        SELECT
            pv.*,
            CASE
                WHEN pv.computed_score IS NULL THEN NULL::int
                ELSE (
                    1 + (
                        SELECT COUNT(*)
                        FROM participant_vectors other
                        WHERE other.computed_score IS NOT NULL
                          AND other.participant_id <> pv.participant_id
                          AND public.compare_tie_vectors(other.tie_vector, pv.tie_vector) < 0
                    )
                )::int
            END AS true_rank,
            CASE
                WHEN pv.computed_score IS NULL THEN false
                ELSE EXISTS (
                    SELECT 1
                    FROM participant_vectors other
                    WHERE other.computed_score IS NOT NULL
                      AND other.participant_id <> pv.participant_id
                      AND public.compare_tie_vectors(pv.tie_vector, other.tie_vector) = 0
                )
            END AS is_tied,
            CASE
                WHEN pv.computed_score IS NULL THEN false
                ELSE EXISTS (
                    SELECT 1
                    FROM participant_vectors other
                    WHERE other.computed_score IS NOT NULL
                      AND other.participant_id <> pv.participant_id
                      AND other.computed_score = pv.computed_score
                )
            END AS has_same_total_score
        FROM participant_vectors pv
    ),
    ordered_participants AS (
        SELECT
            rp.*,
            ROW_NUMBER() OVER (
                ORDER BY
                    CASE WHEN rp.computed_score IS NULL THEN 1 ELSE 0 END ASC,
                    rp.true_rank ASC NULLS LAST,
                    rp.lottery_number ASC NULLS LAST,
                    rp.participant_id ASC
            )::int AS display_order
        FROM ranked_participants rp
    )
    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'stage_participation_id', op.stage_participation_id,
                'participant_id', op.participant_id,
                'participant_name', op.participant_name,
                'lottery_number', op.lottery_number,
                'kafilah_name', op.kafilah_name,
                'branch_id', op.branch_id,
                'branch_name', op.branch_name,
                'computed_score', op.computed_score,
                'final_score', op.computed_score,
                'field_scores', op.field_scores,
                'tie_vector', to_jsonb(op.tie_vector),
                'rank', op.true_rank,
                'display_order', op.display_order,
                'is_tied', op.is_tied,
                'has_same_total_score', op.has_same_total_score,
                'is_complete', op.is_complete,
                'finalized_judge_count', op.finalized_judge_count,
                'required_judge_count', v_required_judge_count,
                'tie_break_note', CASE
                    WHEN op.is_tied THEN 'Nilai seri identik pada seluruh kriteria bidang (Perlu Keputusan Sidang Pleno / Resolusi Seri)'
                    WHEN op.has_same_total_score THEN 'Diselesaikan melalui urutan tie-break resmi (' || array_to_string(v_tie_break_fields, ' > ') || ')'
                    ELSE NULL
                END
            )
            ORDER BY op.display_order ASC
        ),
        '[]'::jsonb
    ) INTO v_rankings
    FROM ordered_participants op;

    RETURN jsonb_build_object(
        'stage_id', v_stage.id,
        'tenant_id', v_stage.tenant_id,
        'branch_id', v_stage.branch_id,
        'qualification_quota', v_stage.qualification_quota,
        'champion_count', COALESCE(v_stage.champion_count, 3),
        'rubric_version_id', v_rubric_version_id,
        'tie_break_order', CASE
            WHEN v_has_rule AND v_rule.tie_break_order IS NOT NULL THEN to_jsonb(v_rule.tie_break_order)
            ELSE to_jsonb(ARRAY['total'] || v_tie_break_fields)
        END,
        'required_judge_count', v_required_judge_count,
        'all_finalized', (
            v_required_judge_count >= 1
            AND jsonb_array_length(v_rankings) > 0
            AND NOT EXISTS (
                SELECT 1
                FROM jsonb_array_elements(v_rankings) elem
                WHERE COALESCE((elem ->> 'is_complete')::boolean, false) = false
            )
        ),
        'can_finalize', (
            v_required_judge_count >= 1
            AND jsonb_array_length(v_rankings) > 0
            AND NOT EXISTS (
                SELECT 1
                FROM jsonb_array_elements(v_rankings) elem
                WHERE COALESCE((elem ->> 'is_complete')::boolean, false) = false
            )
        ),
        'rankings', v_rankings
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.is_assigned_judge(
    p_tenant_id UUID,
    p_stage_participation_id UUID,
    p_judge_id UUID
)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    SELECT (
        auth.uid() IS NOT NULL
        AND (p_judge_id = auth.uid() OR is_tenant_admin(p_tenant_id))
        AND EXISTS (
            SELECT 1
            FROM stage_participations sp
            JOIN stages s ON s.id = sp.stage_id
            JOIN participants p ON p.id = sp.participant_id
            JOIN judge_assignments ja ON ja.stage_id = sp.stage_id
                 AND ja.tenant_id = sp.tenant_id
                 AND (ja.branch_id IS NULL OR ja.branch_id = p.branch_id OR ja.branch_id = s.branch_id)
            WHERE sp.id = p_stage_participation_id
              AND sp.tenant_id = p_tenant_id
              AND ja.judge_profile_id = p_judge_id
              AND ja.status = 'Aktif'
              -- S3: hakim wajib masih berstatus anggota aktif tenant (sama dengan syarat compute_stage_rankings)
              AND EXISTS (
                  SELECT 1 FROM tenant_memberships tm
                  WHERE tm.tenant_id = sp.tenant_id
                    AND tm.profile_id = p_judge_id
                    AND tm.status = 'Aktif'
              )
        )
    );
$$;


REVOKE EXECUTE ON FUNCTION public.resolve_stage_rubric_version(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.resolve_stage_rubric_version(UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.delete_participant_safe(UUID, UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_participant_safe(UUID, UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.delete_tenant_safe(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_tenant_safe(UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.is_assigned_judge(UUID, UUID, UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_assigned_judge(UUID, UUID, UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.calculate_assessment_score_sql(UUID, UUID, JSONB) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.calculate_assessment_score_sql(UUID, UUID, JSONB) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.compute_stage_rankings(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.compute_stage_rankings(UUID) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.advance_stage_qualifiers(UUID, UUID, UUID[], JSONB, JSONB, JSONB) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.advance_stage_qualifiers(UUID, UUID, UUID[], JSONB, JSONB, JSONB) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.draw_lottery_server(UUID, UUID, UUID, UUID, INT, VARCHAR, TEXT, UUID[], UUID[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.draw_lottery_server(UUID, UUID, UUID, UUID, INT, VARCHAR, TEXT, UUID[], UUID[]) TO authenticated;

-- =============================================================================
-- MIGRASI 20261118: PENGATURAN SITUS & SEO (site_settings) DAN FONDASI HEALTH
-- =============================================================================
CREATE TABLE IF NOT EXISTS public.site_settings (
    id TEXT PRIMARY KEY DEFAULT 'global' CHECK (id = 'global'),
    site_name TEXT NOT NULL DEFAULT 'Manajemen MTQ',
    title_template TEXT NOT NULL DEFAULT '%s — Manajemen MTQ',
    default_title TEXT NOT NULL DEFAULT 'Manajemen MTQ — Musabaqah Digital' CHECK (char_length(default_title) <= 70),
    meta_description TEXT NOT NULL DEFAULT 'Platform manajemen MTQ multi-tenant dengan penilaian digital dewan hakim, mushaf kanvas, dan rekapitulasi nilai real-time.' CHECK (char_length(meta_description) <= 200),
    meta_keywords TEXT NOT NULL DEFAULT 'MTQ, STQ, LPTQ, Musabaqah Tilawatil Quran, E-Scoring MTQ',
    canonical_url TEXT NOT NULL DEFAULT 'https://mtq.id' CHECK (canonical_url ~ '^https://'),
    robots TEXT NOT NULL DEFAULT 'index,follow' CHECK (robots IN ('index,follow', 'noindex,nofollow')),
    favicon_url TEXT NOT NULL DEFAULT '/icon.svg',
    og_title TEXT NOT NULL DEFAULT 'Manajemen MTQ — Musabaqah Digital',
    og_description TEXT NOT NULL DEFAULT 'Platform manajemen MTQ multi-tenant dengan penilaian digital dewan hakim, mushaf kanvas, dan rekapitulasi nilai real-time.',
    og_image_url TEXT NOT NULL DEFAULT 'https://mtq.id/icons/icon-512x512.png' CHECK (og_image_url ~ '^https://'),
    og_image_alt TEXT NOT NULL DEFAULT 'Logo dan Antarmuka Manajemen MTQ Digital',
    og_type TEXT NOT NULL DEFAULT 'website',
    og_locale TEXT NOT NULL DEFAULT 'id_ID',
    twitter_card TEXT NOT NULL DEFAULT 'summary_large_image' CHECK (twitter_card IN ('summary_large_image', 'summary')),
    twitter_site TEXT NOT NULL DEFAULT '@lptq_id',
    theme_color TEXT NOT NULL DEFAULT '#065f46',
    google_site_verification TEXT NOT NULL DEFAULT '',
    manual_checks JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO public.site_settings (id)
VALUES ('global')
ON CONFLICT (id) DO NOTHING;

ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS site_settings_select_policy ON public.site_settings;
CREATE POLICY site_settings_select_policy ON public.site_settings
    FOR SELECT
    TO anon, authenticated
    USING (true);

DROP POLICY IF EXISTS site_settings_insert_policy ON public.site_settings;
CREATE POLICY site_settings_insert_policy ON public.site_settings
    FOR INSERT
    TO authenticated
    WITH CHECK (public.is_superadmin());

DROP POLICY IF EXISTS site_settings_update_policy ON public.site_settings;
CREATE POLICY site_settings_update_policy ON public.site_settings
    FOR UPDATE
    TO authenticated
    USING (public.is_superadmin())
    WITH CHECK (public.is_superadmin());

DROP POLICY IF EXISTS site_settings_delete_policy ON public.site_settings;
CREATE POLICY site_settings_delete_policy ON public.site_settings
    FOR DELETE
    TO authenticated
    USING (public.is_superadmin());

GRANT SELECT ON public.site_settings TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.site_settings TO authenticated;

CREATE OR REPLACE FUNCTION public.touch_site_settings_metadata()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
    NEW.updated_at := now();
    IF auth.uid() IS NOT NULL THEN
        NEW.updated_by := auth.uid();
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_touch_site_settings_metadata ON public.site_settings;
CREATE TRIGGER trg_touch_site_settings_metadata
    BEFORE UPDATE ON public.site_settings
    FOR EACH ROW EXECUTE FUNCTION public.touch_site_settings_metadata();

CREATE OR REPLACE FUNCTION public.audit_site_settings_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor RECORD;
    v_target_tenant_id UUID;
    v_changed_cols TEXT[];
    v_changed_list TEXT;
BEGIN
    SELECT array_agg(n.key ORDER BY n.key)
    INTO v_changed_cols
    FROM jsonb_each(to_jsonb(NEW)) n
    LEFT JOIN jsonb_each(to_jsonb(OLD)) o ON o.key = n.key
    WHERE n.key NOT IN ('updated_at', 'updated_by')
      AND n.value IS DISTINCT FROM o.value;

    IF v_changed_cols IS NULL OR array_length(v_changed_cols, 1) IS NULL THEN
        v_changed_cols := ARRAY['updated_at'];
    END IF;
    v_changed_list := array_to_string(v_changed_cols, ', ');

    SELECT name, role INTO v_actor FROM public.profiles WHERE id = auth.uid();

    SELECT t.id INTO v_target_tenant_id
    FROM public.tenants t
    WHERE t.id <> '00000000-0000-0000-0000-000000000000'::uuid
      AND t.status = 'Aktif'
    ORDER BY t.created_at ASC
    LIMIT 1;

    IF v_target_tenant_id IS NULL THEN
        SELECT t.id INTO v_target_tenant_id
        FROM public.tenants t
        ORDER BY t.created_at ASC
        LIMIT 1;
    END IF;

    IF v_target_tenant_id IS NOT NULL THEN
        PERFORM set_config('mtq.rpc_audit_active', 'true', true);
        INSERT INTO public.audit_logs (
            tenant_id,
            actor_id,
            actor_name,
            action,
            target,
            summary,
            outcome,
            metadata
        ) VALUES (
            v_target_tenant_id,
            auth.uid(),
            COALESCE(v_actor.name, 'Superadmin') || ' (' || COALESCE(v_actor.role, 'superadmin') || ')',
            'SITE_SETTINGS_UPDATED',
            'Pengaturan Situs & SEO (' || NEW.id || ')',
            'Memperbarui pengaturan SEO & meta situs. Kolom berubah: ' || v_changed_list,
            'Success',
            jsonb_build_object('changed_columns', to_jsonb(v_changed_cols))
        );
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_audit_site_settings_change ON public.site_settings;
CREATE TRIGGER trg_audit_site_settings_change
    AFTER UPDATE ON public.site_settings
    FOR EACH ROW EXECUTE FUNCTION public.audit_site_settings_change();

-- =============================================================================
-- FASE 5: TABEL VERSI SKEMA & RPC get_platform_health()
-- =============================================================================

CREATE TABLE IF NOT EXISTS public.app_schema_versions (
    version TEXT PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO public.app_schema_versions (version)
VALUES
    ('20261114'),
    ('20261115'),
    ('20261116'),
    ('20261117'),
    ('20261118')
ON CONFLICT (version) DO NOTHING;

ALTER TABLE public.app_schema_versions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS app_schema_versions_select_policy ON public.app_schema_versions;
CREATE POLICY app_schema_versions_select_policy ON public.app_schema_versions
    FOR SELECT
    TO authenticated
    USING (public.is_superadmin());

DROP POLICY IF EXISTS app_schema_versions_manage_policy ON public.app_schema_versions;
CREATE POLICY app_schema_versions_manage_policy ON public.app_schema_versions
    FOR ALL
    TO authenticated
    USING (public.is_superadmin())
    WITH CHECK (public.is_superadmin());

GRANT SELECT, INSERT, UPDATE, DELETE ON public.app_schema_versions TO authenticated;

CREATE OR REPLACE FUNCTION public.get_platform_health()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_latest_version TEXT;
    v_schema_detail JSONB;

    v_unmapped_count INT;
    v_unmapped_detail JSONB;

    v_borrowed_count INT;
    v_borrowed_detail JSONB;

    v_unverified_rubrics_count INT;
    v_unverified_rubrics_detail JSONB;

    v_orphan_tenants_count INT;
    v_orphan_tenants_detail JSONB;

    v_stages_no_judges_count INT;
    v_stages_no_judges_detail JSONB;

    v_pending_verif_count INT;
    v_pending_verif_detail JSONB;

    v_stalled_count INT;
    v_stalled_detail JSONB;

    v_site_missing_count INT;
    v_site_missing_detail JSONB;
BEGIN
    IF NOT public.is_superadmin() THEN
        RAISE EXCEPTION 'Otorisasi ditolak: Hanya Superadmin yang dapat menjalankan pemeriksaan kesehatan platform.';
    END IF;

    -- 1. schema_version
    SELECT MAX(version) INTO v_latest_version FROM public.app_schema_versions;
    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'version', v.version,
                'applied_at', v.applied_at
            )
            ORDER BY v.version DESC
        ),
        '[]'::jsonb
    ) INTO v_schema_detail
    FROM (
        SELECT version, applied_at
        FROM public.app_schema_versions
        ORDER BY version DESC
        LIMIT 20
    ) v;

    -- 2. unmapped_error_categories
    SELECT COUNT(*)::int INTO v_unmapped_count
    FROM public.error_categories ec
    WHERE ec.status = 'Aktif'
      AND ec.rubric_field_id IS NULL
      AND ec.criterion_id IS NULL
      AND ec.deduction_rule_id IS NULL;

    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'id', u.id,
                'code', u.code,
                'name', u.name,
                'tenant_id', u.tenant_id,
                'tenant_name', u.tenant_name
            )
        ),
        '[]'::jsonb
    ) INTO v_unmapped_detail
    FROM (
        SELECT ec.id, ec.code, ec.name, ec.tenant_id, t.name AS tenant_name
        FROM public.error_categories ec
        JOIN public.tenants t ON t.id = ec.tenant_id
        WHERE ec.status = 'Aktif'
          AND ec.rubric_field_id IS NULL
          AND ec.criterion_id IS NULL
          AND ec.deduction_rule_id IS NULL
        ORDER BY t.name ASC, ec.code ASC
        LIMIT 20
    ) u;

    -- 3. borrowed_maqra_sheets
    SELECT COUNT(*)::int INTO v_borrowed_count
    FROM public.judge_assessments ja
    JOIN public.assigned_maqras am ON am.id = ja.assigned_maqra_id
    WHERE am.stage_participation_id <> ja.stage_participation_id;

    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'assessment_id', b.id,
                'stage_participation_id', b.stage_participation_id,
                'maqra_stage_participation_id', b.maqra_sp_id,
                'tenant_id', b.tenant_id,
                'tenant_name', b.tenant_name
            )
        ),
        '[]'::jsonb
    ) INTO v_borrowed_detail
    FROM (
        SELECT
            ja.id,
            ja.stage_participation_id,
            am.stage_participation_id AS maqra_sp_id,
            ja.tenant_id,
            t.name AS tenant_name
        FROM public.judge_assessments ja
        JOIN public.assigned_maqras am ON am.id = ja.assigned_maqra_id
        JOIN public.tenants t ON t.id = ja.tenant_id
        WHERE am.stage_participation_id <> ja.stage_participation_id
        ORDER BY ja.created_at DESC
        LIMIT 20
    ) b;

    -- 4. rubrics_without_official_source
    WITH unverified_items AS (
        SELECT
            'rubrik'::text AS jenis,
            rv.code AS identifier,
            rv.name AS item_name,
            COALESCE(NULLIF(TRIM(rv.official_source), ''), 'Belum diisi') AS official_source,
            rv.tenant_id,
            t.name AS tenant_name
        FROM public.rubric_versions rv
        JOIN public.tenants t ON t.id = rv.tenant_id
        WHERE COALESCE(TRIM(rv.official_source), '') = ''
        UNION ALL
        SELECT
            'aturan'::text AS jenis,
            COALESCE(crc.branch_name, 'Cabang') AS identifier,
            'Aturan Kompetisi ' || COALESCE(crc.branch_name, '') AS item_name,
            COALESCE(NULLIF(TRIM(crc.official_source), ''), 'Belum terverifikasi resmi') AS official_source,
            crc.tenant_id,
            t.name AS tenant_name
        FROM public.competition_rule_configs crc
        JOIN public.tenants t ON t.id = crc.tenant_id
        WHERE COALESCE(TRIM(crc.official_source), '') = ''
           OR crc.is_verified_official = false
    )
    SELECT
        COUNT(*)::int,
        COALESCE(
            (
                SELECT jsonb_agg(
                    jsonb_build_object(
                        'jenis', ui.jenis,
                        'identifier', ui.identifier,
                        'name', ui.item_name,
                        'official_source', ui.official_source,
                        'tenant_id', ui.tenant_id,
                        'tenant_name', ui.tenant_name
                    )
                )
                FROM (SELECT * FROM unverified_items LIMIT 20) ui
            ),
            '[]'::jsonb
        )
    INTO v_unverified_rubrics_count, v_unverified_rubrics_detail
    FROM unverified_items;

    -- 5. tenants_without_active_admin
    SELECT COUNT(*)::int INTO v_orphan_tenants_count
    FROM public.tenants t
    WHERE t.status = 'Aktif'
      AND t.id <> '00000000-0000-0000-0000-000000000000'::uuid
      AND NOT EXISTS (
          SELECT 1 FROM public.tenant_memberships tm
          WHERE tm.tenant_id = t.id
            AND tm.role = 'admin'
            AND tm.status = 'Aktif'
      );

    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'tenant_id', ot.id,
                'code', ot.code,
                'name', ot.name,
                'event_name', ot.event_name
            )
        ),
        '[]'::jsonb
    ) INTO v_orphan_tenants_detail
    FROM (
        SELECT t.id, t.code, t.name, t.event_name
        FROM public.tenants t
        WHERE t.status = 'Aktif'
          AND t.id <> '00000000-0000-0000-0000-000000000000'::uuid
          AND NOT EXISTS (
              SELECT 1 FROM public.tenant_memberships tm
              WHERE tm.tenant_id = t.id
                AND tm.role = 'admin'
                AND tm.status = 'Aktif'
          )
        ORDER BY t.created_at DESC
        LIMIT 20
    ) ot;

    -- 6. stages_without_judges
    SELECT COUNT(*)::int INTO v_stages_no_judges_count
    FROM public.stages s
    WHERE s.is_finalized = false
      AND EXISTS (
          SELECT 1 FROM public.stage_participations sp
          WHERE sp.stage_id = s.id
      )
      AND NOT EXISTS (
          SELECT 1 FROM public.judge_assignments ja
          WHERE ja.stage_id = s.id
            AND ja.status = 'Aktif'
      );

    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'stage_id', sj.id,
                'stage_name', sj.name,
                'tenant_id', sj.tenant_id,
                'tenant_name', sj.tenant_name
            )
        ),
        '[]'::jsonb
    ) INTO v_stages_no_judges_detail
    FROM (
        SELECT s.id, s.name, s.tenant_id, t.name AS tenant_name
        FROM public.stages s
        JOIN public.tenants t ON t.id = s.tenant_id
        WHERE s.is_finalized = false
          AND EXISTS (
              SELECT 1 FROM public.stage_participations sp
              WHERE sp.stage_id = s.id
          )
          AND NOT EXISTS (
              SELECT 1 FROM public.judge_assignments ja
              WHERE ja.stage_id = s.id
                AND ja.status = 'Aktif'
          )
        ORDER BY t.name ASC, s.stage_order ASC
        LIMIT 20
    ) sj;

    -- 7. pending_verifications
    SELECT COUNT(*)::int INTO v_pending_verif_count
    FROM public.participants p
    WHERE p.verification_status = 'Diajukan';

    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'tenant_id', pv.tenant_id,
                'tenant_name', pv.tenant_name,
                'pending_count', pv.pending_count
            )
        ),
        '[]'::jsonb
    ) INTO v_pending_verif_detail
    FROM (
        SELECT
            t.id AS tenant_id,
            t.name AS tenant_name,
            COUNT(p.id)::int AS pending_count
        FROM public.participants p
        JOIN public.tenants t ON t.id = p.tenant_id
        WHERE p.verification_status = 'Diajukan'
        GROUP BY t.id, t.name
        ORDER BY COUNT(p.id) DESC
        LIMIT 20
    ) pv;

    -- 8. stalled_assessments
    SELECT COUNT(*)::int INTO v_stalled_count
    FROM public.judge_assessments ja
    WHERE ja.status = 'in_progress'
      AND ja.updated_at < (now() - interval '24 hours');

    SELECT COALESCE(
        jsonb_agg(
            jsonb_build_object(
                'assessment_id', sa.id,
                'judge_name', sa.judge_name,
                'updated_at', sa.updated_at,
                'tenant_id', sa.tenant_id,
                'tenant_name', sa.tenant_name
            )
        ),
        '[]'::jsonb
    ) INTO v_stalled_detail
    FROM (
        SELECT
            ja.id,
            COALESCE(pr.name, 'Dewan Hakim') AS judge_name,
            ja.updated_at,
            ja.tenant_id,
            t.name AS tenant_name
        FROM public.judge_assessments ja
        JOIN public.tenants t ON t.id = ja.tenant_id
        LEFT JOIN public.profiles pr ON pr.id = ja.judge_profile_id
        WHERE ja.status = 'in_progress'
          AND ja.updated_at < (now() - interval '24 hours')
        ORDER BY ja.updated_at ASC
        LIMIT 20
    ) sa;

    -- 9. site_settings_missing
    SELECT COUNT(*)::int INTO v_site_missing_count
    FROM (
        SELECT 1
        WHERE NOT EXISTS (SELECT 1 FROM public.site_settings WHERE id = 'global')
           OR EXISTS (
               SELECT 1 FROM public.site_settings
               WHERE id = 'global'
                 AND (
                     COALESCE(TRIM(site_name), '') = ''
                     OR COALESCE(TRIM(default_title), '') = ''
                     OR COALESCE(TRIM(og_image_url), '') = ''
                 )
           )
    ) sm;

    IF v_site_missing_count > 0 THEN
        v_site_missing_detail := jsonb_build_array(
            jsonb_build_object(
                'id', 'global',
                'issue', 'Baris site_settings belum lengkap atau og_image_url kosong'
            )
        );
    ELSE
        v_site_missing_detail := '[]'::jsonb;
    END IF;

    RETURN jsonb_build_array(
        jsonb_build_object(
            'key', 'schema_version',
            'label', 'Versi Migrasi Skema Database',
            'status', CASE WHEN COALESCE(v_latest_version, '') = '20261118' THEN 'ok' ELSE 'critical' END,
            'count', CASE WHEN COALESCE(v_latest_version, '') = '20261118' THEN 0 ELSE 1 END,
            'detail', v_schema_detail,
            'how_to_fix', 'Pastikan seluruh migrasi hingga 20261118_site_settings_and_health.sql telah dijalankan secara berurutan sesuai panduan di README.md.'
        ),
        jsonb_build_object(
            'key', 'unmapped_error_categories',
            'label', 'Kategori Kesalahan Aktif Tanpa Pemetaan Bidang Rubrik',
            'status', CASE WHEN v_unmapped_count > 0 THEN 'critical' ELSE 'ok' END,
            'count', v_unmapped_count,
            'detail', v_unmapped_detail,
            'how_to_fix', 'Buka menu Master Data & Rubrik pada penyelenggara terkait, lalu petakan setiap kategori kesalahan aktif ke bidang rubrik (rubric_field_id), kriteria, atau aturan potongan.'
        ),
        jsonb_build_object(
            'key', 'borrowed_maqra_sheets',
            'label', 'Lembar Penilaian dengan Maqra Milik Peserta Lain',
            'status', CASE WHEN v_borrowed_count > 0 THEN 'critical' ELSE 'ok' END,
            'count', v_borrowed_count,
            'detail', v_borrowed_detail,
            'how_to_fix', 'Periksa integritas lembar penilaian terkait dan pastikan assigned_maqra_id merujuk pada maqra milik stage_participation_id peserta yang sama.'
        ),
        jsonb_build_object(
            'key', 'rubrics_without_official_source',
            'label', 'Rubrik & Aturan Kompetisi Tanpa Rujukan Resmi',
            'status', CASE WHEN v_unverified_rubrics_count > 0 THEN 'warning' ELSE 'ok' END,
            'count', v_unverified_rubrics_count,
            'detail', v_unverified_rubrics_detail,
            'how_to_fix', 'Buka Master Data & Rubrik, isi nomor SK/Juknis resmi LPTQ pada kolom official_source, dan tandai is_verified_official = true setelah diverifikasi.'
        ),
        jsonb_build_object(
            'key', 'tenants_without_active_admin',
            'label', 'Penyelenggara Aktif Tanpa Keanggotaan Admin Aktif',
            'status', CASE WHEN v_orphan_tenants_count > 0 THEN 'warning' ELSE 'ok' END,
            'count', v_orphan_tenants_count,
            'detail', v_orphan_tenants_detail,
            'how_to_fix', 'Buka menu Manajemen Akun di Superadmin, lalu tambahkan atau aktifkan minimal satu akun Admin MTQ untuk penyelenggara tersebut.'
        ),
        jsonb_build_object(
            'key', 'stages_without_judges',
            'label', 'Babak Belum Disahkan Berpeserta Tanpa Penugasan Hakim Aktif',
            'status', CASE WHEN v_stages_no_judges_count > 0 THEN 'warning' ELSE 'ok' END,
            'count', v_stages_no_judges_count,
            'detail', v_stages_no_judges_detail,
            'how_to_fix', 'Buka menu Manajemen Babak pada penyelenggara terkait dan tugaskan dewan hakim aktif pada babak yang memiliki peserta.'
        ),
        jsonb_build_object(
            'key', 'pending_verifications',
            'label', 'Peserta Berstatus Diajukan (Menunggu Verifikasi Berkas)',
            'status', CASE WHEN v_pending_verif_count > 0 THEN 'warning' ELSE 'ok' END,
            'count', v_pending_verif_count,
            'detail', v_pending_verif_detail,
            'how_to_fix', 'Buka menu Grup & Peserta MTQ pada penyelenggara terkait untuk memverifikasi atau menolak berkas peserta sebelum undian dimulai.'
        ),
        jsonb_build_object(
            'key', 'stalled_assessments',
            'label', 'Lembar Penilaian In-Progress Lebih dari 24 Jam',
            'status', CASE WHEN v_stalled_count > 0 THEN 'warning' ELSE 'ok' END,
            'count', v_stalled_count,
            'detail', v_stalled_detail,
            'how_to_fix', 'Buka menu Monitoring Penilaian Dewan Hakim untuk meninjau lembar penilaian yang tertahan lebih dari 24 jam.'
        ),
        jsonb_build_object(
            'key', 'site_settings_missing',
            'label', 'Kelengkapan Pengaturan SEO & Gambar Open Graph Situs',
            'status', CASE WHEN v_site_missing_count > 0 THEN 'warning' ELSE 'ok' END,
            'count', v_site_missing_count,
            'detail', v_site_missing_detail,
            'how_to_fix', 'Buka menu Pengaturan di Superadmin dan pastikan Nama Situs, Judul Bawaan, serta URL Gambar Open Graph (https://) telah terisi.'
        )
    );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.get_platform_health() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_platform_health() TO authenticated;
