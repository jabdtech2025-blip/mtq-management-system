import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import {
  Tenant,
  User,
  Kafilah,
  Participant,
  StageParticipation,
  Question,
  ErrorCategory,
  JudgeAssessment,
  ActivityLogItem,
  CanvasStroke,
  CompetitionStage,
  JudgeAssignment,
  AuditLogItem,
  ParticipantProgressStatus,
  GenericMasterItem,
  AssignedMaqraItem,
  StageResultSnapshot,
  RubricVersion,
  CompetitionRuleConfig,
  LotteryDrawLogItem,
  LotteryDrawResultItem,
  SiteSettings,
  DEFAULT_SITE_SETTINGS
} from '../types/mtq';
import {
  INITIAL_TENANTS,
  INITIAL_USERS,
  INITIAL_KAFILAHS,
  INITIAL_QUESTIONS,
  INITIAL_ERROR_CATEGORIES,
  INITIAL_PARTICIPANTS,
  INITIAL_STAGE_PARTICIPATIONS,
  INITIAL_ASSESSMENTS,
  INITIAL_ACTIVITY_LOGS,
  INITIAL_STAGES,
  INITIAL_JUDGE_ASSIGNMENTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_JENJANG,
  INITIAL_CABANG,
  calculateScore
} from '../data/mockData';
import {
  calculateAssessmentScore,
  getActiveRubricFields,
  validateMaqraAssignmentForParticipant
} from '../services/scoringEngine';
import { RankingService } from '../services/rankingService';
import { getParticipantStageCompletion, resolveRequiredJudgeIdsForStage } from '../services/completion';
import { supabaseDataService, AuthenticatedSupabaseProfile } from '../services/supabaseDataService';
import {
  SupabaseConnectionInfo,
  AccessGateReason,
  evaluateWorkspaceAccessGate,
  supabase
} from '../lib/supabaseClient';
import { generateUuid, toDeterministicUuid, isValidUuid } from '../utils/uuid';
import {
  OFFICIAL_SENI_BACA_RUBRIC,
  INITIAL_RUBRIC_VERSIONS,
  DEFAULT_COMPETITION_RULES,
  getBranchRuleConfig,
  resolveActiveRubricForBranch
} from '../services/competitionRules';
import { outboxSyncService, OutboxSummary } from '../services/outboxSyncService';
import {
  fisherYatesShuffle,
  ParsedParticipantImportRow,
  ParsedQuestionImportRow
} from '../utils/excelHelper';

export type ViewType =
  // Admin MTQ
  | 'dashboard'
  | 'kafilah'
  | 'bank_soal'
  | 'master_data'
  | 'user_management'
  | 'penilaian_hakim'
  | 'rekap_nilai'
  | 'stage_management'
  | 'hasil_kelulusan'
  | 'penilaian_dual_panel'
  | 'log_aktivitas'
  // Superadmin
  | 'superadmin_dashboard'
  | 'superadmin_tenants'
  | 'superadmin_users'
  | 'superadmin_health'
  | 'superadmin_audit'
  | 'superadmin_settings';

export interface LocalNotification {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
  timestamp: string;
  isRead: boolean;
  module?: string;
}

interface MtqContextType {
  notifications: LocalNotification[];
  addNotification: (notif: { title: string; message: string; type: 'success' | 'error' | 'warning' | 'info'; module?: string }) => void;
  markAllNotificationsAsRead: () => void;
  clearNotifications: () => void;
  tenants: Tenant[];
  currentTenant: Tenant;
  setTenantId: (id: string) => void;
  addTenant: (tenant: Omit<Tenant, 'id'>) => Promise<{ success: boolean; message: string }>;
  updateTenant: (id: string, updated: Partial<Tenant>) => Promise<{ success: boolean; message: string }>;
  toggleTenantStatus: (id: string) => Promise<{ success: boolean; message: string }>;
  deleteTenant: (id: string) => Promise<{ success: boolean; message: string }>;

  users: User[];
  currentUser: User;
  setCurrentUserId: (id: string) => void;
  addUser: (user: Omit<User, 'id'> & { initialPassword?: string }) => Promise<{ success: boolean; message: string }>;
  updateUser: (id: string, updated: Partial<User>) => Promise<{ success: boolean; message: string }>;
  retryUserProvisioning: (id: string) => Promise<{ success: boolean; message: string }>;
  toggleUserStatus: (id: string) => Promise<{ success: boolean; message: string }>;
  deleteUser: (id: string) => Promise<{ success: boolean; message: string }>;

  kafilahs: Kafilah[];
  participants: Participant[];
  stageParticipations: StageParticipation[];
  questions: Question[];
  errorCategories: ErrorCategory[];
  assessments: JudgeAssessment[];
  activityLogs: ActivityLogItem[];
  auditLogs: AuditLogItem[];
  stages: CompetitionStage[];
  judgeAssignments: JudgeAssignment[];

  // Master Data: Jenjang & Cabang (Persisted)
  jenjangList: GenericMasterItem[];
  cabangList: GenericMasterItem[];
  addJenjang: (item: Omit<GenericMasterItem, 'id' | 'tenantId'>) => void;
  updateJenjang: (id: string, updated: Partial<GenericMasterItem>) => void;
  deleteJenjang: (id: string) => { success: boolean; message: string; activeCount?: number };
  addCabang: (item: Omit<GenericMasterItem, 'id' | 'tenantId'>) => void;
  updateCabang: (id: string, updated: Partial<GenericMasterItem>) => void;
  deleteCabang: (id: string) => { success: boolean; message: string; activeCount?: number };

  // Dynamic Competition Rules & Rubric Versions (P0)
  rubricVersions: RubricVersion[];
  competitionRules: CompetitionRuleConfig[];
  addRubricVersion: (rubric: Omit<RubricVersion, 'id' | 'tenantId' | 'createdAt'>) => void;
  updateRubricVersion: (id: string, updated: Partial<RubricVersion>) => { success: boolean; message: string };
  activateRubricVersion: (id: string) => { success: boolean; message: string };
  archiveRubricVersion: (id: string) => void;
  deleteRubricVersion: (id: string) => { success: boolean; message: string };
  deleteRubricField: (rubricVersionId: string, fieldId: string) => Promise<{ success: boolean; message: string }>;
  addCompetitionRule: (rule: Omit<CompetitionRuleConfig, 'id' | 'tenantId'>) => void;
  updateCompetitionRule: (id: string, updated: Partial<CompetitionRuleConfig>) => void;
  deleteCompetitionRule: (id: string) => { success: boolean; message: string };
  getActiveRubricForBranch: (branchName: string, branchId?: string, levelId?: string, levelName?: string) => RubricVersion | null;
  getBranchRuleConfigByBranch: (branchName: string, branchId?: string) => CompetitionRuleConfig;

  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  isSidebarOpen: boolean;
  setIsSidebarOpen: (open: boolean) => void;
  toggleSidebar: () => void;
  selectedParticipantId: string;
  setSelectedParticipantId: (id: string) => void;
  selectedStageName: string;
  setSelectedStageName: (name: string) => void;

  // Active Monitoring Judge ID (when admin inspects a judge's assessment)
  monitoringJudgeId: string;
  setMonitoringJudgeId: (judgeId: string) => void;

  syncStatus: string;
  lastSyncTime: string;

  // Assessments & Annotations
  initializeAssessment: (
    participantId: string,
    judgeId: string,
    stageName?: string,
    questionId?: string
  ) => { success: boolean; message: string; assessmentId?: string; assessment?: JudgeAssessment };
  updateErrorCount: (
    participantId: string,
    judgeId: string,
    categoryId: string,
    delta: number,
    stageName?: string,
    questionId?: string
  ) => void;
  saveAnnotations: (
    participantId: string,
    judgeId: string,
    annotations: CanvasStroke[],
    stageName?: string,
    questionId?: string
  ) => void;
  finalizeAssessment: (
    participantId: string,
    judgeId: string,
    stageName?: string,
    questionId?: string,
    options?: { confirmFlawless?: boolean }
  ) => Promise<{ success: boolean; message: string }>;
  reopenAssessment: (
    participantId: string,
    judgeId: string,
    reason: string,
    stageName?: string,
    questionId?: string
  ) => Promise<{ success: boolean; message: string }>;
  stageSnapshots: StageResultSnapshot[];
  lotteryDrawLogs: LotteryDrawLogItem[];
  outboxSummary: OutboxSummary;
  flushOutboxQueue: () => Promise<{ processed: number; succeeded: number; failed: number }>;
  getJudgeAssessment: (
    participantId: string,
    judgeId: string,
    stageName?: string,
    questionId?: string
  ) => JudgeAssessment | undefined;
  getParticipantProgress: (
    participantId: string,
    stageName?: string
  ) => ParticipantProgressStatus;
  getStageParticipation: (
    participantId: string,
    stageName?: string
  ) => StageParticipation | undefined;
  getParticipantStageQuestions: (
    participantId: string,
    stageName?: string
  ) => AssignedMaqraItem[];

  // Master Data & Config (Tenant Scoped)
  addKafilah: (kafilah: Omit<Kafilah, 'id' | 'tenantId'>) => void;
  updateKafilah: (id: string, updated: Partial<Kafilah>) => void;
  deleteKafilah: (id: string) => { success: boolean; message: string };
  addParticipant: (part: Omit<Participant, 'id' | 'tenantId'>) => { success: boolean; message: string };
  updateParticipant: (id: string, updated: Partial<Participant>) => { success: boolean; message: string };
  deleteParticipant: (id: string) => { success: boolean; message: string };
  verifyParticipant: (
    participantId: string,
    status: 'Diajukan' | 'Diverifikasi' | 'Ditolak',
    note?: string
  ) => Promise<{ success: boolean; message: string }>;
  importParticipantsBatch: (
    rows: ParsedParticipantImportRow[]
  ) => Promise<{ total: number; succeeded: number; failed: number; errors: string[] }>;
  addQuestion: (q: Omit<Question, 'id' | 'tenantId'>) => void;
  updateQuestion: (id: string, updated: Partial<Question>) => void;
  deleteQuestion: (id: string) => { success: boolean; message: string };
  importQuestionsBatch: (
    rows: ParsedQuestionImportRow[]
  ) => Promise<{ total: number; succeeded: number; failed: number; errors: string[] }>;
  assignMaqraToParticipant: (
    participantId: string,
    questionId: string,
    stageName?: string
  ) => void;
  addQuestionToParticipant: (
    participantId: string,
    questionId: string,
    stageName?: string
  ) => { success: boolean; message: string };
  removeQuestionFromParticipant: (
    participantId: string,
    questionId: string,
    stageName?: string
  ) => void;
  conductLotteryDraw: (options: {
    stageName: string;
    branchName?: string;
    levelName?: string;
    participantIds: string[];
    questionPoolIds?: string[];
    questionsPerParticipant: number;
    notes?: string;
    predefinedResults?: {
      participantId: string;
      participantName: string;
      questionIds: string[];
      questionTitles: string[];
    }[];
  }) => {
    success: boolean;
    message: string;
    results?: {
      participantId: string;
      participantName: string;
      questionIds: string[];
      questionTitles: string[];
    }[];
    drawLog?: LotteryDrawLogItem;
  };
  drawLotteryServer: (options: {
    stageName: string;
    branchName?: string;
    levelName?: string;
    participantIds: string[];
    questionPoolIds?: string[];
    questionsPerParticipant: number;
    drawMode?: 'lottery_number' | 'maqra' | 'both';
    notes?: string;
  }) => Promise<{
    success: boolean;
    message: string;
    results?: {
      participantId: string;
      participantName: string;
      lotteryNumber?: string;
      questionIds: string[];
      questionTitles: string[];
    }[];
    drawLog?: LotteryDrawLogItem;
  }>;
  commitLotteryDrawResults: (
    results: {
      participantId: string;
      participantName: string;
      questionIds: string[];
      questionTitles: string[];
    }[],
    stageName: string,
    metadata?: {
      branchName?: string;
      levelName?: string;
      questionPoolIds?: string[];
      questionsPerParticipant?: number;
      notes?: string;
    }
  ) => { success: boolean; message: string; drawLog?: LotteryDrawLogItem };
  updateCategoryDeduction: (categoryId: string, deduction: number) => void;
  addErrorCategory: (cat: Omit<ErrorCategory, 'id' | 'tenantId'>) => void;
  updateErrorCategory: (id: string, updated: Partial<ErrorCategory>) => void;
  deleteErrorCategory: (id: string) => { success: boolean; message: string };

  // Stages & Progressions
  addStage: (stage: Omit<CompetitionStage, 'id' | 'tenantId'>) => void;
  updateStage: (id: string, updated: Partial<CompetitionStage>) => void;
  deleteStage: (id: string) => { success: boolean; message: string };
  advanceQualifiers: (
    currentStageNameOrParams:
      | string
      | {
          currentStageId?: string;
          currentStageName: string;
          nextStageId?: string;
          nextStageName?: string;
          branchId?: string;
          branchName?: string;
          qualifiedParticipantIds: string[];
          overrideReasons?: Record<string, string>;
          manualOverrides?: Record<string, boolean>;
          tieResolution?: Record<string, number>;
        },
    nextStageName?: string,
    qualifiedParticipantIds?: string[],
    overrideReasons?: Record<string, string>
  ) => Promise<{ success: boolean; message: string }>;

  // Judge Assignments
  addJudgeAssignment: (asg: Omit<JudgeAssignment, 'id' | 'tenantId'>) => void;
  removeJudgeAssignment: (id: string) => void;

  // Superadmin Workspace Delegation Mode
  isSuperadminWorkspaceMode: boolean;
  enterTenantWorkspace: (tenantId: string) => void;
  exitTenantWorkspace: () => void;

  // Demo Account Modal & Prototype Storage Reset
  isDemoAccountModalOpen: boolean;
  setIsDemoAccountModalOpen: (open: boolean) => void;
  resetPrototypeData: () => void;

  // Real Supabase Connection & Auth Integration
  connectionInfo: SupabaseConnectionInfo;
  authenticatedProfile: AuthenticatedSupabaseProfile | null;
  dataSourceMode: 'demo_local' | 'supabase_live' | 'supabase_error';
  workspaceError: string | null;
  isOfflineDemoSimulation: boolean;
  isLiveSupabaseMode: boolean;
  isLiveAccessAuthorized: boolean;
  accessGateReason: AccessGateReason;
  isPasswordRecoveryMode: boolean;
  setIsPasswordRecoveryMode: (active: boolean) => void;
  enterOfflineDemoSimulation: () => void;
  exitOfflineDemoSimulation: () => Promise<void>;
  refreshSupabaseConnection: () => Promise<SupabaseConnectionInfo>;
  signInWithSupabase: (email: string, password: string) => Promise<{ success: boolean; message: string }>;
  signUpWithSupabase: (params: {
    name: string;
    username: string;
    email: string;
    password: string;
  }) => Promise<{ success: boolean; requiresEmailConfirmation?: boolean; message: string }>;
  signOutSupabase: () => Promise<void>;
  requestPasswordReset: (email: string) => Promise<{ success: boolean; message: string }>;
  completePasswordReset: (newPassword: string) => Promise<{ success: boolean; message: string }>;
  bootstrapFirstSuperadmin: (targetEmail: string) => Promise<{ success: boolean; message: string }>;
  siteSettings: SiteSettings;
  updateSiteSettings: (updates: Partial<SiteSettings>) => Promise<{ success: boolean; message: string }>;
}

const MtqContext = createContext<MtqContextType | undefined>(undefined);

// Storage Prefix V3 with clean isolation and schema versioning
const STORAGE_PREFIX = 'mtq_platform_data_v3_';

let logIdSequence = 0;
const generateUniqueLogId = (prefix: string = 'act') => {
  logIdSequence = (logIdSequence + 1) % 1000000;
  return `${prefix}-${Date.now()}-${logIdSequence}-${Math.random().toString(36).substring(2, 8)}`;
};

export const MtqProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tenants, setTenants] = useState<Tenant[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'tenants');
      return saved ? JSON.parse(saved) : INITIAL_TENANTS;
    } catch {
      return INITIAL_TENANTS;
    }
  });

  const [currentTenantId, setCurrentTenantId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'tenant_id');
      if (saved) return saved;
      return 'platform';
    } catch {
      return 'platform';
    }
  });

  const [users, setUsers] = useState<User[]>(() => {
    try {
      const isDemoMode = localStorage.getItem('mtq_offline_demo_simulation_v4') === 'true';
      if (!isDemoMode) {
        return [];
      }
      const saved = localStorage.getItem(STORAGE_PREFIX + 'users');
      return saved ? JSON.parse(saved) : INITIAL_USERS;
    } catch {
      return [];
    }
  });

  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    try {
      return localStorage.getItem(STORAGE_PREFIX + 'user_id') || 'user-admin-rh';
    } catch {
      return 'user-admin-rh';
    }
  });

  const [kafilahs, setKafilahs] = useState<Kafilah[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'kafilahs');
      return saved ? JSON.parse(saved) : INITIAL_KAFILAHS;
    } catch {
      return INITIAL_KAFILAHS;
    }
  });

  const [participants, setParticipants] = useState<Participant[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'participants');
      const loaded: Participant[] = saved ? JSON.parse(saved) : INITIAL_PARTICIPANTS;
      return loaded.map((p) => {
        if (!p.assignedQuestions || p.assignedQuestions.length === 0) {
          return {
            ...p,
            assignedQuestions: p.questionId ? [{
              questionId: p.questionId,
              title: p.assignedMaqra || 'Maqra Perlombaan',
              pageNumber: p.pageNumber || 305,
              stageName: p.stageName
            }] : [],
            questionIds: p.questionId ? [p.questionId] : []
          };
        }
        return p;
      });
    } catch {
      return INITIAL_PARTICIPANTS;
    }
  });

  const [stageParticipations, setStageParticipations] = useState<StageParticipation[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'stage_participations');
      const loaded: StageParticipation[] = saved ? JSON.parse(saved) : INITIAL_STAGE_PARTICIPATIONS;
      return loaded.map((sp) => {
        if (!sp.assignedQuestions || sp.assignedQuestions.length === 0) {
          if (sp.questionId && sp.questionId.trim() !== '') {
            return {
              ...sp,
              assignedQuestions: [
                {
                  questionId: sp.questionId,
                  title: sp.assignedMaqra || 'Maqra Tilawah',
                  pageNumber: sp.pageNumber || 305,
                  stageName: sp.stageName
                }
              ]
            };
          }
        }
        return sp;
      });
    } catch {
      return INITIAL_STAGE_PARTICIPATIONS;
    }
  });

  const [questions, setQuestions] = useState<Question[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'questions');
      return saved ? JSON.parse(saved) : INITIAL_QUESTIONS;
    } catch {
      return INITIAL_QUESTIONS;
    }
  });

  const [errorCategories, setErrorCategories] = useState<ErrorCategory[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'categories');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [assessments, setAssessments] = useState<JudgeAssessment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'assessments');
      const loaded: JudgeAssessment[] = saved ? JSON.parse(saved) : INITIAL_ASSESSMENTS;
      // Conservative, idempotent migration:
      // Ensure all assessments have tenantId, stageName, and questionId if unambiguously resolvable
      return loaded.map((a) => {
        let stage = a.stageName;
        let qId = a.questionId;

        if (!stage) {
          if (a.stageParticipationId) {
            const spMatch = INITIAL_STAGE_PARTICIPATIONS.find((s) => s.id === a.stageParticipationId);
            stage = spMatch?.stageName || 'Penyisihan';
          } else {
            stage = 'Penyisihan';
          }
        }

        if (!qId) {
          if (a.stageParticipationId) {
            const spMatch = INITIAL_STAGE_PARTICIPATIONS.find((s) => s.id === a.stageParticipationId);
            if (spMatch?.questionId) {
              qId = spMatch.questionId;
            }
          }
          if (!qId && a.participantId) {
            const partMatch = INITIAL_PARTICIPANTS.find((p) => p.id === a.participantId);
            if (partMatch?.questionId && (!partMatch.stageName || partMatch.stageName === stage)) {
              qId = partMatch.questionId;
            }
          }
        }

        return {
          ...a,
          tenantId: a.tenantId || 'tenant-jabar',
          stageName: stage,
          questionId: qId
        };
      });
    } catch {
      return INITIAL_ASSESSMENTS;
    }
  });

  const [activityLogs, setActivityLogs] = useState<ActivityLogItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'logs');
      const rawLogs: ActivityLogItem[] = saved ? JSON.parse(saved) : INITIAL_ACTIVITY_LOGS;
      const seenIds = new Set<string>();
      const sanitized: ActivityLogItem[] = [];

      rawLogs.forEach((item, idx) => {
        let uniqueId = item.id;
        if (!uniqueId || seenIds.has(uniqueId)) {
          uniqueId = `act-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 7)}`;
        }
        seenIds.add(uniqueId);
        sanitized.push({ ...item, id: uniqueId });
      });

      return sanitized;
    } catch {
      return INITIAL_ACTIVITY_LOGS;
    }
  });

  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'audit_logs');
      const rawLogs: AuditLogItem[] = saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
      const seenIds = new Set<string>();
      const sanitized: AuditLogItem[] = [];

      rawLogs.forEach((item, idx) => {
        let uniqueId = item.id;
        if (!uniqueId || seenIds.has(uniqueId)) {
          uniqueId = `aud-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 7)}`;
        }
        seenIds.add(uniqueId);
        sanitized.push({ ...item, id: uniqueId });
      });

      return sanitized;
    } catch {
      return INITIAL_AUDIT_LOGS;
    }
  });

  // Local ephemeral in-memory notifications (cleared on refresh as requested)
  const [notifications, setNotifications] = useState<LocalNotification[]>([]);

  const addNotification = useCallback(
    (notif: { title: string; message: string; type: 'success' | 'error' | 'warning' | 'info'; module?: string }) => {
      const newNotif: LocalNotification = {
        id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        title: notif.title,
        message: notif.message,
        type: notif.type,
        module: notif.module || 'Sistem',
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        isRead: false
      };
      setNotifications((prev) => [newNotif, ...prev.slice(0, 49)]);
    },
    []
  );

  const markAllNotificationsAsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  }, []);

  const clearNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  const [stages, setStages] = useState<CompetitionStage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'stages');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [judgeAssignments, setJudgeAssignments] = useState<JudgeAssignment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'judge_assignments');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Master Data: Jenjang & Cabang (Persisted)
  const [jenjangList, setJenjangList] = useState<GenericMasterItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'jenjang_list');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [cabangList, setCabangList] = useState<GenericMasterItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'cabang_list');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Dynamic Competition Rules & Rubric Versions (P0)
  const [rubricVersions, setRubricVersions] = useState<RubricVersion[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'rubric_versions');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [competitionRules, setCompetitionRules] = useState<CompetitionRuleConfig[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'competition_rules');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const VIEW_TO_PATH: Record<ViewType, string> = {
    dashboard: '/dashboard',
    kafilah: '/grup-peserta',
    bank_soal: '/bank-soal',
    master_data: '/master-data',
    penilaian_hakim: '/penilaian-hakim',
    penilaian_dual_panel: '/lembar-penilaian',
    rekap_nilai: '/rekap-nilai',
    hasil_kelulusan: '/hasil-kelulusan',
    stage_management: '/manajemen-babak',
    user_management: '/pengguna-hakim',
    log_aktivitas: '/log-aktivitas',
    superadmin_dashboard: '/platform/dashboard',
    superadmin_tenants: '/platform/tenants',
    superadmin_users: '/platform/users',
    superadmin_health: '/platform/health',
    superadmin_audit: '/platform/audit',
    superadmin_settings: '/platform/settings'
  };

  const PATH_TO_VIEW: Record<string, ViewType> = Object.entries(VIEW_TO_PATH).reduce(
    (acc, [view, path]) => {
      acc[path] = view as ViewType;
      return acc;
    },
    {} as Record<string, ViewType>
  );

  const [currentView, setCurrentViewState] = useState<ViewType>(() => {
    try {
      if (typeof window !== 'undefined' && window.location?.pathname) {
        const cleanPath = window.location.pathname.replace(/\/+$/, '') || '/';
        if (PATH_TO_VIEW[cleanPath]) {
          return PATH_TO_VIEW[cleanPath];
        }
      }
    } catch {}
    return 'dashboard';
  });

  const setCurrentView = useCallback((nextView: ViewType | ((prev: ViewType) => ViewType)) => {
    setCurrentViewState((prev) => {
      const resolved = typeof nextView === 'function' ? nextView(prev) : nextView;
      try {
        if (typeof window !== 'undefined' && window.history?.pushState) {
          const targetPath = VIEW_TO_PATH[resolved] || '/dashboard';
          const currentClean = window.location.pathname.replace(/\/+$/, '') || '/';
          if (currentClean !== targetPath) {
            window.history.pushState({ view: resolved }, '', targetPath + window.location.search + window.location.hash);
          }
        }
      } catch {}
      return resolved;
    });
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    // Sync initial URL if at root '/'
    try {
      const currentClean = window.location.pathname.replace(/\/+$/, '') || '/';
      // "/" (tautan email) dan "/app" (tombol Masuk di landing page) diarahkan ke tampilan awal aplikasi
      if ((currentClean === '/' || currentClean === '/app') && window.history?.replaceState) {
        const initialPath = VIEW_TO_PATH[currentView] || '/dashboard';
        window.history.replaceState({ view: currentView }, '', initialPath + window.location.search + window.location.hash);
      }
    } catch {}

    const handlePopState = () => {
      try {
        const cleanPath = window.location.pathname.replace(/\/+$/, '') || '/';
        const matched = PATH_TO_VIEW[cleanPath];
        if (matched) {
          setCurrentViewState(matched);
        }
      } catch {}
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const toggleSidebar = () => setIsSidebarOpen((prev) => !prev);
  const [selectedParticipantId, setSelectedParticipantId] = useState<string>('part-04');
  const [selectedStageName, setSelectedStageName] = useState<string>('Penyisihan');
  const [monitoringJudgeId, setMonitoringJudgeId] = useState<string>('judge-1');
  const [connectionInfo, setConnectionInfo] = useState<SupabaseConnectionInfo>(() =>
    supabaseDataService.getConnectionStatus()
  );
  const [authenticatedProfile, setAuthenticatedProfile] = useState<AuthenticatedSupabaseProfile | null>(null);
  const [isOfflineDemoSimulation, setIsOfflineDemoSimulation] = useState<boolean>(() => {
    try {
      return localStorage.getItem('mtq_offline_demo_simulation_v4') === 'true';
    } catch {
      return false;
    }
  });
  const [dataSourceMode, setDataSourceMode] = useState<'demo_local' | 'supabase_live' | 'supabase_error'>(() =>
    supabaseDataService.isLive() && localStorage.getItem('mtq_offline_demo_simulation_v4') !== 'true'
      ? 'supabase_live'
      : 'demo_local'
  );
  const [workspaceError, setWorkspaceError] = useState<string | null>(null);
  const [syncStatus, setSyncStatus] = useState<string>(() =>
    supabaseDataService.isLive()
      ? supabaseDataService.getConnectionStatus().statusLabel
      : 'Mode Lokal (Tersimpan di Browser)'
  );
  const [lastSyncTime, setLastSyncTime] = useState<string>('13:14:18 WIB');
  const [isDemoAccountModalOpen, setIsDemoAccountModalOpen] = useState<boolean>(false);
  const [isPasswordRecoveryMode, setIsPasswordRecoveryMode] = useState<boolean>(() => {
    try {
      if (typeof window !== 'undefined' && window.location?.hash) {
        return window.location.hash.includes('type=recovery');
      }
      return false;
    } catch {
      return false;
    }
  });

  // Fail-closed default: produksi maupun pengembangan wajib mode live kecuali simulasi demo lokal diaktifkan eksplisit
  const isLiveSupabaseMode = !isOfflineDemoSimulation;
  const isLiveDbActive =
    isLiveSupabaseMode && connectionInfo.isDatabaseReady && connectionInfo.isAuthenticated;

  // Sync to localStorage ONLY when in demo_local / offline simulation mode (Isolasi Cache dari Live Mode)
  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'tenants', JSON.stringify(tenants));
    } catch (e) {
      console.warn('Storage error: tenants', e);
    }
  }, [tenants, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'tenant_id', currentTenantId);
    } catch {}
  }, [currentTenantId, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'users', JSON.stringify(users));
    } catch {}
  }, [users, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'user_id', currentUserId);
    } catch {}
  }, [currentUserId, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'kafilahs', JSON.stringify(kafilahs));
    } catch {}
  }, [kafilahs, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'participants', JSON.stringify(participants));
    } catch {}
  }, [participants, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'stage_participations', JSON.stringify(stageParticipations));
    } catch {}
  }, [stageParticipations, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'questions', JSON.stringify(questions));
    } catch {}
  }, [questions, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'categories', JSON.stringify(errorCategories));
    } catch {}
  }, [errorCategories, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'assessments', JSON.stringify(assessments));
    } catch {}
  }, [assessments, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'logs', JSON.stringify(activityLogs));
    } catch {}
  }, [activityLogs, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'audit_logs', JSON.stringify(auditLogs));
    } catch {}
  }, [auditLogs, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'stages', JSON.stringify(stages));
    } catch {}
  }, [stages, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'judge_assignments', JSON.stringify(judgeAssignments));
    } catch {}
  }, [judgeAssignments, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'jenjang_list', JSON.stringify(jenjangList));
    } catch {}
  }, [jenjangList, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'rubric_versions', JSON.stringify(rubricVersions));
    } catch {}
  }, [rubricVersions, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'competition_rules', JSON.stringify(competitionRules));
    } catch {}
  }, [competitionRules, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'cabang_list', JSON.stringify(cabangList));
    } catch {}
  }, [cabangList, isLiveSupabaseMode]);

  const [stageSnapshots, setStageSnapshots] = useState<StageResultSnapshot[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'stage_snapshots');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [lotteryDrawLogs, setLotteryDrawLogs] = useState<LotteryDrawLogItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'lottery_draw_logs');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [outboxSummary, setOutboxSummary] = useState<OutboxSummary>(() =>
    outboxSyncService.getSummary()
  );

  // Refs for synchronous access during back-to-back initializeAssessment -> finalizeAssessment calls
  // and race condition protection across auth/hydration requests
  const authRequestGenRef = useRef<number>(0);
  const assessmentsRef = useRef<JudgeAssessment[]>(assessments);
  assessmentsRef.current = assessments;
  const stageParticipationsRef = useRef<StageParticipation[]>(stageParticipations);
  stageParticipationsRef.current = stageParticipations;

  useEffect(() => {
    outboxSyncService.registerProcessor(async (op) => {
      try {
        if (op.operationType === 'UPSERT_ASSESSMENT_DRAFT') {
          const { assessment, assignedMaqraId, stageParticipation, participant } = op.payload || {};
          if (!assessment) {
            return { success: false, message: 'Payload draf penilaian tidak lengkap di antrean outbox.' };
          }
          const res = await supabaseDataService.syncAssessmentToRemote(
            assessment as JudgeAssessment,
            assignedMaqraId as string | undefined,
            {
              stageParticipation: stageParticipation as StageParticipation | undefined,
              participant: participant as Participant | undefined
            }
          );
          return { success: res.success, message: res.message };
        }
        if (op.operationType === 'UPSERT_PARTICIPANT') {
          const { participant, stageParticipation, levelId, autoCreateMissingMaster } = op.payload || {};
          if (!participant || !stageParticipation) {
            return { success: false, message: 'Payload peserta tidak lengkap di antrean outbox.' };
          }
          const res = await supabaseDataService.upsertParticipantWithStage({
            participant: participant as Participant,
            stageParticipation: stageParticipation as StageParticipation,
            levelId: (levelId as string | null) ?? null,
            autoCreateMissingMaster: Boolean(autoCreateMissingMaster)
          });
          return { success: res.success, message: res.message };
        }
        if (op.operationType === 'UPSERT_QUESTION') {
          const { question, branchId, stageId, levelId } = op.payload || {};
          if (!question) {
            return { success: false, message: 'Payload soal tidak lengkap di antrean outbox.' };
          }
          const res = await supabaseDataService.upsertQuestion(
            question as Question,
            branchId as string | undefined,
            stageId as string | undefined,
            levelId as string | undefined
          );
          return { success: res.success, message: res.message };
        }
        if (op.operationType === 'COMMIT_LOTTERY_DRAW') {
          const { drawLog } = op.payload || {};
          if (!drawLog) {
            return { success: false, message: 'Payload riwayat undian tidak lengkap di antrean outbox.' };
          }
          const res = await supabaseDataService.insertLotteryDrawLog(drawLog as LotteryDrawLogItem);
          return { success: res.success, message: res.message };
        }
        if (op.operationType === 'DELETE_PARTICIPANT') {
          const { participantId } = (op.payload as { participantId?: string }) || {};
          if (!participantId) {
            return { success: false, message: 'Payload ID peserta tidak lengkap di antrean outbox.' };
          }
          const res = await supabaseDataService.deleteParticipant(
            toDeterministicUuid(op.tenantId),
            toDeterministicUuid(participantId)
          );
          return { success: res.success, message: res.message };
        }
        if (op.operationType === 'DELETE_QUESTION') {
          const { questionId } = (op.payload as { questionId?: string }) || {};
          if (!questionId) {
            return { success: false, message: 'Payload ID soal tidak lengkap di antrean outbox.' };
          }
          const res = await supabaseDataService.deleteQuestion(
            toDeterministicUuid(op.tenantId),
            toDeterministicUuid(questionId)
          );
          return { success: res.success, message: res.message };
        }
        if (op.operationType === 'UPSERT_MASTER_DATA') {
          const { entityType, item } = (op.payload as { entityType?: string; item?: any }) || {};
          if (!entityType || !item) {
            return { success: false, message: 'Payload master data tidak lengkap di antrean outbox.' };
          }
          if (entityType === 'branch') {
            const res = await supabaseDataService.upsertBranch(toDeterministicUuid(op.tenantId), item);
            return { success: res.success, message: res.message };
          }
          if (entityType === 'level') {
            const res = await supabaseDataService.upsertLevel(toDeterministicUuid(op.tenantId), item);
            return { success: res.success, message: res.message };
          }
          if (entityType === 'stage') {
            const res = await supabaseDataService.upsertStage({
              ...(item as any),
              tenantId: toDeterministicUuid(op.tenantId)
            });
            return { success: res.success, message: res.message };
          }
          return { success: false, message: `Tipe master data tidak dikenal: ${entityType}` };
        }
        return {
          success: false,
          message: `Operasi antrean outbox "${op.operationType}" tidak dikenal atau tidak didukung untuk sinkronisasi otomatis.`
        };
      } catch (err) {
        return {
          success: false,
          message: err instanceof Error ? err.message : 'Gagal mengeksekusi operasi outbox'
        };
      }
    });

    const unsubscribe = outboxSyncService.subscribe((summary) => {
      setOutboxSummary(summary);
    });
    return unsubscribe;
  }, []);

  const flushOutboxQueue = async () => {
    return outboxSyncService.flushPendingQueue();
  };

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'stage_snapshots', JSON.stringify(stageSnapshots));
    } catch {}
  }, [stageSnapshots, isLiveSupabaseMode]);

  useEffect(() => {
    if (isLiveSupabaseMode) return;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'lottery_draw_logs', JSON.stringify(lotteryDrawLogs));
    } catch {}
  }, [lotteryDrawLogs, isLiveSupabaseMode]);

  const accessGateDecision = evaluateWorkspaceAccessGate({
    isOfflineDemoSimulation,
    connectionInfo,
    authenticatedProfile,
    dataSourceMode,
    workspaceError
  });

  const accessGateReason: AccessGateReason = accessGateDecision.reason;
  const isLiveAccessAuthorized: boolean = accessGateDecision.isAuthorized;

  const currentTenant = tenants.find((t) => t.id === currentTenantId) || tenants[0];

  // Dalam mode live Supabase, currentUser wajib berasal dari profil terautentikasi & membership aktif,
  // tidak pernah dari persona demo localStorage.
  const currentUser: User = (() => {
    if (isLiveSupabaseMode) {
      if (authenticatedProfile && isLiveAccessAuthorized) {
        const matchedMembership =
          authenticatedProfile.memberships.find((m) => m.tenantId === currentTenantId) ||
          authenticatedProfile.memberships[0];
        const verifiedRole =
          authenticatedProfile.globalRole === 'superadmin'
            ? 'superadmin'
            : matchedMembership?.role || authenticatedProfile.globalRole;
        return {
          id: authenticatedProfile.authUserId,
          tenantId:
            matchedMembership?.tenantId ||
            (verifiedRole === 'superadmin' ? 'platform' : currentTenantId),
          username: authenticatedProfile.username,
          email: authenticatedProfile.email,
          name: authenticatedProfile.name,
          role: verifiedRole,
          status: 'Aktif',
          provisioningStatus: 'Aktif',
          judgeCategory: matchedMembership?.judgeCategory,
          judgeField: matchedMembership?.judgeField
        };
      }
      return {
        id: authenticatedProfile?.authUserId || 'unauthenticated-session',
        tenantId: currentTenantId,
        username: authenticatedProfile?.username || 'unauthenticated',
        email: authenticatedProfile?.email || '',
        name: authenticatedProfile?.name || 'Sesi Belum Terautentikasi',
        role: 'judge',
        status: 'Nonaktif',
        provisioningStatus: 'Nonaktif'
      };
    }
    return users.find((u) => u.id === currentUserId) || users[0];
  })();

  const setSafeCurrentUserId = (id: string) => {
    // Blokir pergantian persona palsu saat mode live Supabase aktif
    if (isLiveSupabaseMode) {
      console.warn('Pergantian akun simulasi dinonaktifkan pada mode produksi Supabase.');
      return;
    }
    setCurrentUserId(id);
  };

  const enterOfflineDemoSimulation = () => {
    try {
      localStorage.setItem('mtq_offline_demo_simulation_v4', 'true');
    } catch {}
    setIsOfflineDemoSimulation(true);
    setDataSourceMode('demo_local');
    setWorkspaceError(null);
    setTenants(INITIAL_TENANTS);
    setUsers(INITIAL_USERS);
    setCurrentTenantId('tenant-jabar');
    setCurrentUserId('user-admin-rh');
    setCabangList(INITIAL_CABANG);
    setJenjangList(INITIAL_JENJANG);
    setKafilahs(INITIAL_KAFILAHS);
    setStages(INITIAL_STAGES);
    setQuestions(INITIAL_QUESTIONS);
    setParticipants(INITIAL_PARTICIPANTS);
    setStageParticipations(INITIAL_STAGE_PARTICIPATIONS);
    setErrorCategories(INITIAL_ERROR_CATEGORIES);
    setRubricVersions(INITIAL_RUBRIC_VERSIONS);
    setCompetitionRules(
      Object.values(DEFAULT_COMPETITION_RULES).map((r) => ({
        ...r,
        tenantId: 'tenant-jabar',
        status: 'Aktif' as const
      }))
    );
    setJudgeAssignments(INITIAL_JUDGE_ASSIGNMENTS);
    setAssessments(INITIAL_ASSESSMENTS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setSyncStatus('Mode Simulasi Demo Lokal (Terisolasi dari Database Produksi)');
  };

  const exitOfflineDemoSimulation = async (): Promise<void> => {
    try {
      localStorage.removeItem('mtq_offline_demo_simulation_v4');
    } catch {}
    setIsOfflineDemoSimulation(false);
    setDataSourceMode(supabaseDataService.isLive() ? 'supabase_live' : 'supabase_error');
    await refreshSupabaseConnection();
  };

  const getWibTime = () =>
    new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' WIB';

  // Superadmin Workspace Mode Flag
  const isSuperadminWorkspaceMode =
    currentUser.role === 'superadmin' && currentTenantId !== 'platform';

  const enterTenantWorkspace = (tenantId: string) => {
    setCurrentTenantId(tenantId);
    setCurrentView('dashboard');
  };

  const exitTenantWorkspace = () => {
    setCurrentTenantId('platform');
    setCurrentView('superadmin_dashboard');
  };

  // Reset prototype storage helper
  const resetPrototypeData = () => {
    try {
      Object.keys(localStorage).forEach((key) => {
        if (key.startsWith('mtq_platform_data_') || key.startsWith('mtq_offline_demo_')) {
          localStorage.removeItem(key);
        }
      });
      window.location.reload();
    } catch (e) {
      console.warn('Reset error', e);
    }
  };

  /**
   * Pemeriksaan koneksi nyata ke Supabase, sinkronisasi profil Auth, dan hidrasi data workspace.
   * Dilindungi oleh `authRequestGenRef` agar respons lama (stale) tidak pernah menimpa sesi login/logout baru.
   */
  const refreshSupabaseConnection = async (): Promise<SupabaseConnectionInfo> => {
    const reqGen = ++authRequestGenRef.current;
    const info = await supabaseDataService.verifyDatabaseConnection();
    if (reqGen !== authRequestGenRef.current) return info;

    setConnectionInfo(info);
    setSyncStatus(info.statusLabel);

    if (info.isDatabaseReady) {
      const profile = await supabaseDataService.fetchAuthenticatedUserProfile();
      if (reqGen !== authRequestGenRef.current) return info;
      setAuthenticatedProfile(profile);

      if (!profile) {
        // Sesi belum login di mode live: bersihkan state operasional agar data demo tidak bocor
        setDataSourceMode('supabase_live');
        setWorkspaceError(null);
        setUsers([]);
        setKafilahs([]);
        setStages([]);
        setQuestions([]);
        setParticipants([]);
        setStageParticipations([]);
        setJudgeAssignments([]);
        setAssessments([]);
        setStageSnapshots([]);
        setAuditLogs([]);
        setLotteryDrawLogs([]);
        return info;
      }

      let targetTenantId = currentTenantId;
      const primaryMembership = profile.memberships[0];
      const effectiveRole =
        profile.globalRole === 'superadmin'
          ? 'superadmin'
          : primaryMembership?.role || profile.globalRole;
      const effectiveTenantId =
        primaryMembership?.tenantId ||
        (effectiveRole === 'superadmin' ? 'platform' : currentTenantId);

      if (
        primaryMembership?.tenantId &&
        (!isValidUuid(currentTenantId) || !profile.memberships.some((m) => m.tenantId === currentTenantId)) &&
        !(effectiveRole === 'superadmin' && currentTenantId === 'platform')
      ) {
        targetTenantId = primaryMembership.tenantId;
        setCurrentTenantId(primaryMembership.tenantId);
      } else if (primaryMembership?.tenantId && isValidUuid(currentTenantId)) {
        targetTenantId = currentTenantId;
      } else if (effectiveRole === 'superadmin' && !isValidUuid(currentTenantId)) {
        targetTenantId = 'platform';
        if (currentTenantId !== 'platform') {
          setCurrentTenantId('platform');
        }
      }

      const mappedUser: User = {
        id: profile.authUserId,
        tenantId: effectiveTenantId,
        username: profile.username,
        email: profile.email,
        name: profile.name,
        role: effectiveRole,
        status: 'Aktif',
        provisioningStatus: 'Aktif',
        judgeCategory: primaryMembership?.judgeCategory,
        judgeField: primaryMembership?.judgeField
      };

      setCurrentUserId(profile.authUserId);

      // Pastikan tampilan awal sesuai dengan peran yang terautentikasi tanpa menimpa URL spesifik yang sedang dibuka
      const currentCleanPath =
        typeof window !== 'undefined' ? window.location.pathname.replace(/\/+$/, '') || '/' : '/';
      const explicitUrlView = PATH_TO_VIEW[currentCleanPath];

      if (effectiveRole === 'superadmin' && targetTenantId === 'platform') {
        setCurrentView((prev) =>
          explicitUrlView && explicitUrlView.startsWith('superadmin_')
            ? explicitUrlView
            : prev === 'dashboard' || !prev.startsWith('superadmin_')
            ? 'superadmin_dashboard'
            : prev
        );
      } else if (effectiveRole === 'judge') {
        const judgeAllowedViews: ViewType[] = ['penilaian_hakim', 'penilaian_dual_panel'];
        setCurrentView((prev) =>
          explicitUrlView && judgeAllowedViews.includes(explicitUrlView)
            ? explicitUrlView
            : prev === 'dashboard' || prev.startsWith('superadmin_')
            ? 'penilaian_hakim'
            : prev
        );
      } else if (effectiveRole === 'admin') {
        setCurrentView((prev) =>
          explicitUrlView && !explicitUrlView.startsWith('superadmin_')
            ? explicitUrlView
            : prev.startsWith('superadmin_')
            ? 'dashboard'
            : prev
        );
      }

      if (!profile.hasProfileRow || (profile.memberships.length === 0 && profile.globalRole !== 'superadmin')) {
        // Profil atau membership tidak memenuhi syarat: bersihkan workspace operasional
        setUsers([mappedUser]);
        setKafilahs([]);
        setStages([]);
        setQuestions([]);
        setParticipants([]);
        setStageParticipations([]);
        setJudgeAssignments([]);
        setAssessments([]);
        setStageSnapshots([]);
        setAuditLogs([]);
        setLotteryDrawLogs([]);
        return info;
      }

      const hydration = await supabaseDataService.fetchTenantWorkspaceResult(targetTenantId);
      if (reqGen !== authRequestGenRef.current) return info;

      if (hydration.success && hydration.payload) {
        const hydrated = hydration.payload;
        setDataSourceMode('supabase_live');
        setWorkspaceError(null);

        if (hydrated.tenants && hydrated.tenants.length > 0) {
          setTenants(hydrated.tenants);
        }
        const dbUsers = hydrated.users || [];
        const hasCurrentAuthUser = dbUsers.some((u) => u.id === profile.authUserId);
        const combinedUsers = hasCurrentAuthUser ? dbUsers : [mappedUser, ...dbUsers];
        const uniqueUsers = Array.from(new Map(combinedUsers.map((u) => [u.id, u])).values());
        setUsers(uniqueUsers);

        setCabangList(hydrated.cabangList || []);
        setJenjangList(hydrated.jenjangList || []);
        setKafilahs(hydrated.kafilahs || []);
        setStages(hydrated.stages || []);
        setQuestions(hydrated.questions || []);
        const rawParticipants = hydrated.participants || [];
        const uniqueHydratedParticipants = Array.from(new Map(rawParticipants.map((p) => [p.id, p])).values());
        setParticipants(uniqueHydratedParticipants);
        setStageParticipations(hydrated.stageParticipations || []);
        stageParticipationsRef.current = hydrated.stageParticipations || [];
        setErrorCategories(hydrated.errorCategories || []);
        setCompetitionRules(hydrated.competitionRules || []);
        setJudgeAssignments(hydrated.judgeAssignments || []);
        setAssessments(hydrated.assessments || []);
        assessmentsRef.current = hydrated.assessments || [];
        setStageSnapshots(hydrated.stageSnapshots || []);
        setAuditLogs(hydrated.auditLogs || []);
        setLotteryDrawLogs(hydrated.lotteryDrawLogs || []);
        const hydratedRubrics = hydrated.rubricVersions || [];
        const deletedIds = (() => {
          try {
            return new Set(JSON.parse(localStorage.getItem(STORAGE_PREFIX + 'deleted_rubrics') || '[]'));
          } catch {
            return new Set<string>();
          }
        })();
        const filteredRubrics = hydratedRubrics.filter(
          (r) => !deletedIds.has(r.id) && !deletedIds.has(toDeterministicUuid(r.id))
        );
        setRubricVersions(filteredRubrics);
      } else {
        setDataSourceMode('supabase_error');
        setWorkspaceError(hydration.error || 'Gagal memuat workspace database.');
        setSyncStatus('Gagal Memuat Workspace Database');
        setUsers([mappedUser]);
        setKafilahs([]);
        setCabangList([]);
        setJenjangList([]);
        setStages([]);
        setQuestions([]);
        setParticipants([]);
        setStageParticipations([]);
        setErrorCategories([]);
        setRubricVersions([]);
        setCompetitionRules([]);
        setJudgeAssignments([]);
        setAssessments([]);
        setStageSnapshots([]);
        setLotteryDrawLogs([]);
      }
    } else {
      setAuthenticatedProfile(null);
      if (!isOfflineDemoSimulation) {
        setDataSourceMode('supabase_error');
        setWorkspaceError(info.lastError || info.statusLabel);
        setUsers([]);
        setKafilahs([]);
        setCabangList([]);
        setJenjangList([]);
        setStages([]);
        setQuestions([]);
        setParticipants([]);
        setStageParticipations([]);
        setErrorCategories([]);
        setRubricVersions([]);
        setCompetitionRules([]);
        setJudgeAssignments([]);
        setAssessments([]);
        setStageSnapshots([]);
        setLotteryDrawLogs([]);
      } else {
        setDataSourceMode('demo_local');
        setWorkspaceError(null);
      }
    }

    return info;
  };

  const signInWithSupabase = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; message: string }> => {
    try {
      localStorage.removeItem('mtq_offline_demo_simulation_v4');
    } catch {}
    setIsOfflineDemoSimulation(false);
    setWorkspaceError(null);
    const res = await supabaseDataService.signInWithPassword(email, password);
    if (!res.success) {
      return { success: false, message: res.message };
    }
    setDataSourceMode('supabase_live');
    await refreshSupabaseConnection();
    return { success: res.success, message: res.message };
  };

  const signUpWithSupabase = async (params: {
    name: string;
    username: string;
    email: string;
    password: string;
  }): Promise<{ success: boolean; requiresEmailConfirmation?: boolean; message: string }> => {
    try {
      localStorage.removeItem('mtq_offline_demo_simulation_v4');
    } catch {}
    setIsOfflineDemoSimulation(false);
    const res = await supabaseDataService.signUpNewUser(params);
    if (res.success && !res.requiresEmailConfirmation) {
      await refreshSupabaseConnection();
    }
    return {
      success: res.success,
      requiresEmailConfirmation: res.requiresEmailConfirmation,
      message: res.message
    };
  };

  const signOutSupabase = async (): Promise<void> => {
    // Invalidate any in-flight hydration requests immediately
    authRequestGenRef.current += 1;
    await supabaseDataService.signOut();
    setAuthenticatedProfile(null);
    setIsPasswordRecoveryMode(false);
    setWorkspaceError(null);
    setUsers([]);
    setKafilahs([]);
    setStages([]);
    setQuestions([]);
    setParticipants([]);
    setStageParticipations([]);
    stageParticipationsRef.current = [];
    setJudgeAssignments([]);
    setAssessments([]);
    assessmentsRef.current = [];
    setStageSnapshots([]);
    setAuditLogs([]);
    setLotteryDrawLogs([]);
    await refreshSupabaseConnection();
  };

  const requestPasswordReset = async (
    email: string
  ): Promise<{ success: boolean; message: string }> => {
    const res = await supabaseDataService.requestPasswordReset(email);
    return { success: res.success, message: res.message };
  };

  const completePasswordReset = async (
    newPassword: string
  ): Promise<{ success: boolean; message: string }> => {
    const res = await supabaseDataService.updatePasswordWithRecoverySession(newPassword);
    if (res.success) {
      setIsPasswordRecoveryMode(false);
      if (typeof window !== 'undefined' && window.history?.replaceState) {
        window.history.replaceState(null, '', window.location.pathname + window.location.search);
      }
      await refreshSupabaseConnection();
    }
    return { success: res.success, message: res.message };
  };

  const bootstrapFirstSuperadmin = async (
    targetEmail: string
  ): Promise<{ success: boolean; message: string }> => {
    const res = await supabaseDataService.bootstrapFirstSuperadmin({
      targetEmail,
      initialTenantId: isValidUuid(currentTenantId) ? currentTenantId : undefined
    });
    if (res.success) {
      await refreshSupabaseConnection();
    }
    return { success: res.success, message: res.message };
  };

  useEffect(() => {
    if (!isOfflineDemoSimulation) {
      void refreshSupabaseConnection();
    }
    if (supabase && !isOfflineDemoSimulation) {
      const { data: sub } = supabase.auth.onAuthStateChange((event) => {
        if (event === 'PASSWORD_RECOVERY') {
          setIsPasswordRecoveryMode(true);
        }
        // Gunakan setTimeout(..., 0) agar tidak terjadi race condition / deadlock di dalam lock internal Supabase Auth
        setTimeout(() => {
          void refreshSupabaseConnection();
        }, 0);
      });
      return () => {
        sub.subscription.unsubscribe();
      };
    }
  }, [currentTenantId, isOfflineDemoSimulation]);

  const notifyCrossTabSync = useCallback((reason: string) => {
    try {
      if (typeof BroadcastChannel !== 'undefined') {
        const bc = new BroadcastChannel('mtq_realtime_sync_channel');
        bc.postMessage({ type: 'MTQ_DATA_UPDATED', reason, timestamp: Date.now() });
        bc.close();
      }
    } catch {}
  }, []);

  // Supabase Realtime Subscription + Cross-Tab BroadcastChannel (judge_assessments, stage_participations, stages)
  useEffect(() => {
    let refreshTimer: ReturnType<typeof setTimeout> | null = null;
    const triggerRefresh = (label: string) => {
      setSyncStatus(label);
      if (refreshTimer) clearTimeout(refreshTimer);
      refreshTimer = setTimeout(() => {
        void refreshSupabaseConnection();
      }, 250);
    };

    let bc: BroadcastChannel | null = null;
    try {
      if (typeof BroadcastChannel !== 'undefined') {
        bc = new BroadcastChannel('mtq_realtime_sync_channel');
        bc.onmessage = (ev) => {
          if (ev.data?.type === 'MTQ_DATA_UPDATED') {
            triggerRefresh(`Sinkronisasi Antar-Tab (${ev.data.reason || 'Penilaian'})...`);
          }
        };
      }
    } catch {}

    let unsubscribeSupabase = () => {};
    if (isLiveDbActive && isLiveAccessAuthorized && isValidUuid(currentTenantId)) {
      unsubscribeSupabase = supabaseDataService.subscribeToTenantRealtime(
        currentTenantId,
        ({ table, eventType }) => {
          triggerRefresh(`Sinkronisasi Realtime (${table} • ${eventType})...`);
        }
      );
    }

    return () => {
      if (refreshTimer) clearTimeout(refreshTimer);
      unsubscribeSupabase();
      try {
        if (bc) bc.close();
      } catch {}
    };
  }, [isLiveDbActive, isLiveAccessAuthorized, currentTenantId]);

  /**
   * Helper to retrieve all questions assigned to a participant on a specific stage.
   * Primary source of truth is StageParticipation for targetStage.
   * STRICT: Never leaks questions from other stages!
   */
  const getParticipantStageQuestions = (
    participantId: string,
    stageName?: string
  ): AssignedMaqraItem[] => {
    const part = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    if (!part) return [];
    const targetStage = stageName || part.stageName || selectedStageName;

    // 1. Check all StageParticipations for targetStage and merge assignedQuestions across duplicate rows
    const matchingSps = stageParticipations.filter(
      (item) =>
        item.tenantId === currentTenantId &&
        item.participantId === participantId &&
        item.stageName === targetStage
    );

    const mergedAssignedQuestions: AssignedMaqraItem[] = [];
    for (const item of matchingSps) {
      if (item.assignedQuestions && item.assignedQuestions.length > 0) {
        for (const aq of item.assignedQuestions) {
          if (!aq.stageName || aq.stageName === targetStage) {
            if (!mergedAssignedQuestions.some((existing) => existing.questionId === aq.questionId)) {
              mergedAssignedQuestions.push(aq);
            }
          }
        }
      }
    }
    if (mergedAssignedQuestions.length > 0) {
      return mergedAssignedQuestions;
    }

    const sp =
      matchingSps.find((item) => item.assignedQuestions && item.assignedQuestions.length > 0) ||
      matchingSps.find((item) => item.questionId && item.questionId.trim() !== '') ||
      matchingSps[0];

    // 2. Check Participant assignedQuestions strictly matching targetStage
    if (part.assignedQuestions && part.assignedQuestions.length > 0) {
      const stageSpecific = part.assignedQuestions.filter(
        (aq) => !aq.stageName || aq.stageName === targetStage
      );
      if (stageSpecific.length > 0) return stageSpecific;
    }

    // 3. Fallback for legacy single-question data ONLY IF stage matches
    if (sp?.questionId && sp.questionId.trim() !== '') {
      const qObj = questions.find((q) => q.id === sp.questionId);
      return [
        {
          questionId: sp.questionId,
          code: qObj?.code || 'MQ-01',
          title: sp.assignedMaqra || qObj?.title || 'Maqra Tilawah',
          surahName: qObj?.surahName,
          surahNumber: qObj?.surahNumber,
          startAyah: qObj?.startAyah,
          endAyah: qObj?.endAyah,
          pageNumber: sp.pageNumber || qObj?.pageNumber || 305,
          pageStart: qObj?.pageStart || sp.pageNumber || 305,
          pageEnd: qObj?.pageEnd || sp.pageNumber || 305,
          stageName: targetStage
        }
      ];
    }

    if (part.questionId && part.questionId.trim() !== '' && part.stageName === targetStage) {
      const qObj = questions.find((q) => q.id === part.questionId);
      return [
        {
          questionId: part.questionId,
          code: qObj?.code || 'MQ-01',
          title: part.assignedMaqra || qObj?.title || 'Maqra Tilawah',
          surahName: qObj?.surahName,
          surahNumber: qObj?.surahNumber,
          startAyah: qObj?.startAyah,
          endAyah: qObj?.endAyah,
          pageNumber: part.pageNumber || qObj?.pageNumber || 305,
          pageStart: qObj?.pageStart || part.pageNumber || 305,
          pageEnd: qObj?.pageEnd || part.pageNumber || 305,
          stageName: targetStage
        }
      ];
    }

    // P0-04: Dilarang menurunkan penetapan maqra dari lembar penilaian yatim bila StageParticipation & Participant belum memiliki maqra resmi.
    return [];
  };

  /**
   * Helper to retrieve stage participation for a participant and stage
   */
  const getStageParticipation = (
    participantId: string,
    stageName?: string
  ): StageParticipation | undefined => {
    const part = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    const targetStage = stageName || part?.stageName || selectedStageName;
    const matchingSps = stageParticipations.filter(
      (sp) =>
        sp.tenantId === currentTenantId &&
        sp.participantId === participantId &&
        sp.stageName === targetStage
    );
    return (
      matchingSps.find((item) =>
        assessments.some((a) => a.tenantId === currentTenantId && a.stageParticipationId === item.id)
      ) ||
      matchingSps.find((item) => item.assignedQuestions && item.assignedQuestions.length > 0) ||
      matchingSps.find((item) => item.questionId && item.questionId.trim() !== '') ||
      matchingSps[0]
    );
  };

  /**
   * Helper to retrieve assessment matching participant, judge, stageParticipationId/stage, and questionId strictly (P0-04).
   * Identity: tenantId + participantId + judgeId + stageParticipationId + questionId
   */
  const getJudgeAssessment = (
    participantId: string,
    judgeId: string,
    stageName?: string,
    questionId?: string
  ): JudgeAssessment | undefined => {
    const part = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    const targetStage = stageName || part?.stageName || selectedStageName;
    const sp = getStageParticipation(participantId, targetStage);
    const stageQuestions = getParticipantStageQuestions(participantId, targetStage);
    const effectiveQuestionId = questionId || stageQuestions[0]?.questionId;
    const matchedStageQ = effectiveQuestionId
      ? stageQuestions.find((sq) => sq.questionId === effectiveQuestionId)
      : undefined;

    const matchesQuestion = (a: JudgeAssessment): boolean => {
      if (!effectiveQuestionId) return false;
      if (a.questionId === effectiveQuestionId) return true;
      if (matchedStageQ?.id && a.assignedMaqraId === matchedStageQ.id) return true;
      if (stageQuestions.length === 1 && Boolean(a.assignedMaqraId)) return true;
      return false;
    };

    const strictMatch = assessments.find((a) => {
      if (a.tenantId !== currentTenantId) return false;
      if (a.participantId !== participantId) return false;
      if (a.judgeId !== judgeId) return false;
      if (sp?.id && a.stageParticipationId && a.stageParticipationId !== sp.id) {
        return false;
      }
      if (a.stageName !== targetStage) return false;
      return matchesQuestion(a);
    });
    if (strictMatch) return strictMatch;

    // Fallback when duplicate stageParticipation rows exist for the same participant & stageName
    return assessments.find((a) => {
      if (a.tenantId !== currentTenantId) return false;
      if (a.participantId !== participantId) return false;
      if (a.judgeId !== judgeId) return false;
      if (a.stageName !== targetStage) return false;
      return matchesQuestion(a);
    });
  };

  /**
   * Derive overall participant status for a stage based on ALL required judge assignments AND ALL assigned maqras.
   * P0: Status "Lengkap" ONLY when ALL required judges have finalized ALL assigned questions for that stage.
   * If no maqras assigned on this stage, returns "Maqra Belum Ditetapkan".
   */
  const getParticipantProgress = (
    participantId: string,
    stageName?: string
  ): ParticipantProgressStatus => {
    const part = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    if (!part) return 'Belum Dimulai';
    const targetStage = stageName || part.stageName || selectedStageName;
    const sp = getStageParticipation(participantId, targetStage);
    const stageQuestions = getParticipantStageQuestions(participantId, targetStage);
    const requiredJudgeIds = resolveRequiredJudgeIdsForStage({
      tenantId: currentTenantId,
      stageId: sp?.stageId,
      stageName: targetStage,
      branchId: part.branchId,
      branchName: part.branchName,
      judgeAssignments
    });

    const completion = getParticipantStageCompletion({
      tenantId: currentTenantId,
      participant: part,
      participation: sp,
      stageId: sp?.stageId,
      stageName: targetStage,
      assignedMaqras: stageQuestions,
      requiredJudgeIds,
      assessments
    });

    return completion.progressStatus;
  };

  // Dynamic Rubric & Competition Rule Resolvers (P0 Dynamic Architecture)
  const getBranchRuleConfigByBranch = (branchName: string, branchId?: string): CompetitionRuleConfig => {
    return getBranchRuleConfig(branchName, currentTenantId, competitionRules, branchId);
  };

  const getActiveRubricForBranch = (
    branchName: string,
    branchId?: string,
    levelId?: string,
    levelName?: string
  ): RubricVersion | null => {
    const res = resolveActiveRubricForBranch({
      branchName,
      branchId,
      levelId,
      levelName,
      tenantId: currentTenantId,
      competitionRules,
      rubricVersions
    });
    if (res.rubric) return res.rubric;

    // Fallback: jika rubrik cabang masih berstatus Draft atau nama cabang sedikit berbeda, gunakan rubrik yang memiliki bidang
    const tenantRubrics = rubricVersions.filter(
      (r) => (r.tenantId === currentTenantId || r.tenantId === 'system') && r.fields && r.fields.length > 0
    );
    const branchClean = (branchName || '').toLowerCase().trim();
    const byBranchMatch = tenantRubrics.find((r) => {
      const rBr = (r.branchName || '').toLowerCase().trim();
      return (
        (branchId && r.branchId === branchId) ||
        (branchClean && rBr && (rBr.includes(branchClean) || branchClean.includes(rBr)))
      );
    });
    if (byBranchMatch) return byBranchMatch;

    return tenantRubrics.find((r) => r.status === 'Aktif') || tenantRubrics[0] || null;
  };

  /**
   * P1-07: Hitung ulang lembar penilaian pada cabang terkait ketika Admin mengaktifkan versi rubrik baru
   * atau mengubah konfigurasi aturan cabang (hanya pada babak yang belum difinalisasi).
   */
  const recalculateAssessmentsForRubricOrRuleChange = (params: {
    targetRubric: RubricVersion;
    branchName?: string;
    branchId?: string;
  }) => {
    const { targetRubric, branchName, branchId } = params;
    const finalizedStageIds = new Set(
      stages.filter((s) => s.tenantId === currentTenantId && s.isFinalized).map((s) => s.id)
    );
    const finalizedStageNames = new Set(
      stages
        .filter((s) => s.tenantId === currentTenantId && s.isFinalized && !s.branchId && !s.branchName)
        .map((s) => s.name)
    );

    setAssessments((prev) => {
      const updatedList = prev.map((a) => {
        if (a.tenantId !== currentTenantId) return a;
        if (a.stageId && finalizedStageIds.has(a.stageId)) return a;
        if (!a.stageId && finalizedStageNames.has(a.stageName)) return a;

        const part = participants.find((p) => p.id === a.participantId && p.tenantId === currentTenantId);
        if (!part) return a;

        const matchesBranch = branchId
          ? part.branchId === branchId
          : branchName
          ? part.branchName.toLowerCase() === branchName.toLowerCase() ||
            part.branchName.toLowerCase().includes(branchName.toLowerCase())
          : targetRubric.branchCode
          ? part.branchName.toLowerCase().includes(targetRubric.branchCode.toLowerCase()) ||
            (targetRubric.branchCode === 'SENI-BACA' && part.branchName.toLowerCase().includes('tilawah')) ||
            (targetRubric.branchCode === 'TAHFIZH' && part.branchName.toLowerCase().includes('tahfizh'))
          : false;

        if (!matchesBranch) return a;

        const calc = calculateAssessmentScore(
          a.errorCounts || {},
          errorCategories,
          targetRubric,
          targetRubric.startingScore
        );

        return {
          ...a,
          deductions: calc.deductions,
          fieldScores: calc.fieldScores,
          fieldDeductions: calc.fieldDeductions,
          totalDeductions: calc.totalDeductions,
          finalScore: calc.finalScore,
          rubricVersion: targetRubric.code,
          rubricVersionId: targetRubric.id,
          lastUpdated: getWibTime()
        };
      });
      assessmentsRef.current = updatedList;
      return updatedList;
    });
  };

  const addRubricVersion = (rubricData: Omit<RubricVersion, 'id' | 'tenantId' | 'createdAt'>) => {
    const newRubric: RubricVersion = {
      ...rubricData,
      id: generateUuid(),
      tenantId: currentTenantId,
      createdAt: new Date().toISOString()
    };
    setRubricVersions((prev) => [...prev, newRubric]);
    if (isLiveDbActive) {
      setSyncStatus('Menyimpan versi rubrik ke database...');
      void supabaseDataService
        .upsertRubricVersionWithFields(toDeterministicUuid(currentTenantId), {
          ...newRubric,
          id: toDeterministicUuid(newRubric.id),
          tenantId: toDeterministicUuid(currentTenantId),
          branchId: newRubric.branchId ? toDeterministicUuid(newRubric.branchId) : undefined,
          levelId: newRubric.levelId ? toDeterministicUuid(newRubric.levelId) : undefined
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal menyimpan rubrik: ${res.message}`);
            setRubricVersions((prev) => prev.filter((r) => r.id !== newRubric.id));
          } else {
            setSyncStatus('Rubrik Tersimpan di Database');
          }
        });
    }
  };

  const updateRubricVersion = (
    id: string,
    updated: Partial<RubricVersion>
  ): { success: boolean; message: string } => {
    const target = rubricVersions.find((r) => r.id === id);
    if (!target) {
      return { success: false, message: 'Versi rubrik tidak ditemukan.' };
    }

    // Historical Immutability Protection:
    // If this rubric version is already used in any finalized stage snapshot,
    // block in-place structural mutations (fields, startingScore, branchCode).
    const isUsedInSnapshots = stageSnapshots.some((s) => s.rubricVersionId === id);

    const isMutatingStructure =
      updated.fields !== undefined ||
      updated.startingScore !== undefined ||
      updated.branchCode !== undefined;

    if (isUsedInSnapshots && isMutatingStructure) {
      return {
        success: false,
        message: `Perubahan struktur rubrik "${target.name}" (${target.version}) ditolak karena versi ini telah digunakan pada snapshot babak yang sudah disahkan. Buat versi rubrik baru agar rekaman historis tetap utuh.`
      };
    }

    const mergedRubric: RubricVersion = { ...target, ...updated };
    setRubricVersions((prev) =>
      prev.map((r) => (r.id === id ? mergedRubric : r))
    );

    if (isMutatingStructure && mergedRubric.status === 'Aktif') {
      recalculateAssessmentsForRubricOrRuleChange({ targetRubric: mergedRubric });
    }

    if (isLiveDbActive) {
      setSyncStatus('Memperbarui rubrik di database...');
      void supabaseDataService
        .upsertRubricVersionWithFields(toDeterministicUuid(currentTenantId), {
          ...mergedRubric,
          id: toDeterministicUuid(mergedRubric.id),
          branchId: mergedRubric.branchId ? toDeterministicUuid(mergedRubric.branchId) : undefined,
          levelId: mergedRubric.levelId ? toDeterministicUuid(mergedRubric.levelId) : undefined,
          tenantId: toDeterministicUuid(
            mergedRubric.tenantId === 'system'
              ? '00000000-0000-0000-0000-000000000000'
              : mergedRubric.tenantId || currentTenantId
          )
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal memperbarui rubrik: ${res.message}`);
            setRubricVersions((prev) => prev.map((r) => (r.id === id ? target : r)));
          } else {
            setSyncStatus('Rubrik Diperbarui di Database');
          }
        });
    }

    return {
      success: true,
      message: `Versi rubrik "${target.name}" berhasil diperbarui.`
    };
  };

  const activateRubricVersion = (id: string): { success: boolean; message: string } => {
    const target = rubricVersions.find((r) => r.id === id);
    if (!target) return { success: false, message: 'Rubrik tidak ditemukan.' };

    const activeFields = getActiveRubricFields(target);
    const totalMax = activeFields.reduce((sum, f) => sum + Number(f.maxScore || 0), 0);
    if (activeFields.length === 0 || totalMax <= 0) {
      return { success: false, message: 'Rubrik harus memiliki minimal 1 bidang aktif dengan batas skor valid.' };
    }
    if (Math.abs(totalMax - Number(target.startingScore || 100)) > 0.001) {
      return {
        success: false,
        message: `Total maxScore bidang aktif (${totalMax}) harus sama dengan skor awal rubrik (${target.startingScore}).`
      };
    }

    const activatedRubric: RubricVersion = { ...target, status: 'Aktif' };
    const prevRubrics = rubricVersions;

    // P1-07: Isolasi pengarsipan versi lama secara ketat pada tenant yang sama (currentTenantId / target.tenantId)
    setRubricVersions((prev) =>
      prev.map((r) => {
        if (r.id === id) {
          return activatedRubric;
        }
        const sameTenantScope =
          r.tenantId === target.tenantId ||
          (r.tenantId === currentTenantId && (target.tenantId === currentTenantId || target.tenantId === 'system'));
        if (sameTenantScope && r.branchCode === target.branchCode && r.status === 'Aktif') {
          return { ...r, status: 'Arsip' as const };
        }
        return r;
      })
    );

    // Perbarui pula competitionRules di tenant aktif yang memiliki branchCode sepadan dan hitung ulang penilaian aktif (P1-07)
    recalculateAssessmentsForRubricOrRuleChange({ targetRubric: activatedRubric });

    if (isLiveDbActive) {
      const targetTenantUuid = toDeterministicUuid(
        target.tenantId === 'system'
          ? '00000000-0000-0000-0000-000000000000'
          : target.tenantId || currentTenantId
      );
      void supabaseDataService
        .updateRubricVersionStatus(targetTenantUuid, toDeterministicUuid(id), 'Aktif')
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal mengaktifkan rubrik: ${res.message}`);
            setRubricVersions(prevRubrics);
          } else {
            setSyncStatus('Status Rubrik Aktif Tersimpan di Database');
          }
        });
    }

    return {
      success: true,
      message: `Versi rubrik "${target.name}" (${target.version}) berhasil diaktifkan dan lembar penilaian cabang terkait telah disinkronkan.`
    };
  };

  const archiveRubricVersion = (id: string) => {
    const target = rubricVersions.find((r) => r.id === id);
    setRubricVersions((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: 'Arsip' as const } : r))
    );
    if (isLiveDbActive && target) {
      const targetTenantUuid = toDeterministicUuid(
        target.tenantId === 'system'
          ? '00000000-0000-0000-0000-000000000000'
          : target.tenantId || currentTenantId
      );
      void supabaseDataService
        .updateRubricVersionStatus(targetTenantUuid, toDeterministicUuid(id), 'Arsip')
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal mengarsipkan rubrik: ${res.message}`);
            setRubricVersions((prev) => prev.map((r) => (r.id === id ? target : r)));
          }
        });
    }
  };

  const deleteRubricVersion = (id: string): { success: boolean; message: string } => {
    const target = rubricVersions.find((r) => r.id === id);
    if (!target) {
      return { success: false, message: 'Versi rubrik tidak ditemukan.' };
    }

    const isUsedInFinalizedAssessments = assessments.some(
      (a) =>
        a.status === 'finalized' &&
        (a.rubricVersionId === id || a.rubricVersion === target.code)
    );
    const isUsedInSnapshots = stageSnapshots.some((s) => s.rubricVersionId === id);

    if (isUsedInFinalizedAssessments || isUsedInSnapshots) {
      return {
        success: false,
        message: `Versi rubrik "${target.name}" (${target.version}) tidak dapat dihapus karena telah digunakan pada lembar penilaian final atau snapshot babak. Gunakan fitur Arsip.`
      };
    }

    const updatedRubrics = rubricVersions.filter((r) => r.id !== id);
    setRubricVersions(updatedRubrics);

    try {
      const existingDeleted = JSON.parse(localStorage.getItem(STORAGE_PREFIX + 'deleted_rubrics') || '[]');
      const newDeleted = Array.from(new Set([...existingDeleted, id, toDeterministicUuid(id)]));
      localStorage.setItem(STORAGE_PREFIX + 'deleted_rubrics', JSON.stringify(newDeleted));
      localStorage.setItem(STORAGE_PREFIX + 'rubric_versions', JSON.stringify(updatedRubrics));
    } catch {}

    if (isLiveDbActive) {
      const targetTenantUuid = toDeterministicUuid(
        target.tenantId === 'system'
          ? '00000000-0000-0000-0000-000000000000'
          : target.tenantId || currentTenantId
      );
      void supabaseDataService
        .deleteRubricVersion(targetTenantUuid, toDeterministicUuid(id))
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal menghapus rubrik: ${res.message}`);
            setRubricVersions((prev) => [...prev, target]);
          } else {
            setSyncStatus('Versi Rubrik Dihapus dari Database');
          }
        });
    }

    return {
      success: true,
      message: `Versi rubrik "${target.name}" (${target.version}) berhasil dihapus.`
    };
  };

  const deleteRubricField = async (
    rubricVersionId: string,
    fieldId: string
  ): Promise<{ success: boolean; message: string }> => {
    const targetRubric = rubricVersions.find((r) => r.id === rubricVersionId);
    if (!targetRubric) {
      return { success: false, message: 'Versi rubrik tidak ditemukan.' };
    }

    const targetField = targetRubric.fields.find((f) => f.id === fieldId);
    if (!targetField) {
      return { success: false, message: 'Bidang penilaian tidak ditemukan pada rubrik ini.' };
    }

    const isUsedInSnapshots = stageSnapshots.some((s) => s.rubricVersionId === rubricVersionId);
    if (isUsedInSnapshots) {
      return {
        success: false,
        message: `Bidang "${targetField.name}" tidak dapat dihapus karena versi rubrik ini telah digunakan pada babak yang sudah disahkan.`
      };
    }

    const updatedFields = targetRubric.fields.filter((f) => f.id !== fieldId);
    const updatedRubric: RubricVersion = { ...targetRubric, fields: updatedFields };

    setRubricVersions((prev) =>
      prev.map((r) => (r.id === rubricVersionId ? updatedRubric : r))
    );

    // Detach or cleanup categories referencing this field
    setErrorCategories((prev) =>
      prev.map((c) => (c.fieldId === fieldId ? { ...c, fieldId: undefined } : c))
    );

    if (isLiveDbActive) {
      setSyncStatus(`Menghapus bidang "${targetField.name}" dari database...`);
      const res = await supabaseDataService.deleteRubricField(
        toDeterministicUuid(rubricVersionId),
        toDeterministicUuid(fieldId)
      );

      if (!res.success) {
        setRubricVersions((prev) =>
          prev.map((r) => (r.id === rubricVersionId ? targetRubric : r))
        );
        setSyncStatus(`Gagal menghapus bidang: ${res.message}`);
        return { success: false, message: `Gagal menghapus bidang dari database: ${res.message}` };
      } else {
        setSyncStatus('Bidang Rubrik Berhasil Dihapus Permanen dari Database');
      }
    }

    return { success: true, message: `Bidang "${targetField.name}" berhasil dihapus secara permanen.` };
  };

  /**
   * P1-04: Sinkronisasi terpusat kuota kelulusan babak antara CompetitionStage dan CompetitionRuleConfig
   */
  const syncStageQuotasFromRuleConfig = (branchName: string, branchId: string | undefined, quotaPerStage?: Record<string, number>) => {
    if (!quotaPerStage) return;
    setStages((prev) =>
      prev.map((s) => {
        if (s.tenantId !== currentTenantId || s.isFinalized) return s;
        const matchesBranch =
          (branchId && s.branchId === branchId) ||
          (s.branchName && s.branchName.toLowerCase() === branchName.toLowerCase());
        if (matchesBranch && typeof quotaPerStage[s.name] === 'number' && quotaPerStage[s.name] > 0) {
          return { ...s, qualificationQuota: quotaPerStage[s.name] };
        }
        return s;
      })
    );
  };

  const addCompetitionRule = (ruleData: Omit<CompetitionRuleConfig, 'id' | 'tenantId'>) => {
    const matchedBranch = cabangList.find(
      (c) =>
        (c.tenantId === currentTenantId || !c.tenantId) &&
        ruleData.branchName &&
        (c.name === ruleData.branchName || ruleData.branchName.includes(c.name) || c.name.includes(ruleData.branchName))
    );
    const resolvedBranchId = ruleData.branchId || matchedBranch?.id;

    // P1-04: Ambil kuota resmi dari Manajemen Babak (CompetitionStage) bila tersedia
    const branchStages = stages.filter(
      (s) =>
        s.tenantId === currentTenantId &&
        ((resolvedBranchId && s.branchId === resolvedBranchId) ||
          (s.branchName && s.branchName.toLowerCase() === ruleData.branchName.toLowerCase()))
    );
    const syncedQuotaPerStage: Record<string, number> = { ...(ruleData.quotaPerStage || {}) };
    branchStages.forEach((bs) => {
      if (bs.qualificationQuota > 0) {
        syncedQuotaPerStage[bs.name] = bs.qualificationQuota;
      }
    });

    const newRule: CompetitionRuleConfig = {
      ...ruleData,
      id: generateUuid(),
      tenantId: currentTenantId,
      quotaPerStage: syncedQuotaPerStage,
      ...(resolvedBranchId ? { branchId: resolvedBranchId } : {})
    };
    setCompetitionRules((prev) => [...prev, newRule]);

    if (newRule.rubricVersionId) {
      const targetRubric = rubricVersions.find((r) => r.id === newRule.rubricVersionId);
      if (targetRubric) {
        recalculateAssessmentsForRubricOrRuleChange({
          targetRubric,
          branchName: newRule.branchName,
          branchId: resolvedBranchId
        });
      }
    }

    if (isLiveDbActive && newRule.rubricVersionId) {
      void supabaseDataService
        .upsertCompetitionRuleConfig({
          ...newRule,
          id: toDeterministicUuid(newRule.id),
          tenantId: toDeterministicUuid(currentTenantId),
          branchId: newRule.branchId ? toDeterministicUuid(newRule.branchId) : undefined,
          rubricVersionId: toDeterministicUuid(newRule.rubricVersionId)
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal menyimpan aturan kompetisi: ${res.message}`);
            setCompetitionRules((prev) => prev.filter((r) => r.id !== newRule.id));
          } else {
            setSyncStatus('Aturan Kompetisi Tersimpan di Database');
          }
        });
    }
  };

  const updateCompetitionRule = (id: string, updated: Partial<CompetitionRuleConfig>) => {
    const existing = competitionRules.find((r) => r.id === id);
    const mergedRule: CompetitionRuleConfig | undefined = existing ? { ...existing, ...updated } : undefined;
    setCompetitionRules((prev) =>
      prev.map((r) => (r.id === id ? { ...r, ...updated } : r))
    );

    if (mergedRule) {
      const matchedBranch = cabangList.find(
        (c) =>
          (c.tenantId === currentTenantId || !c.tenantId) &&
          mergedRule.branchName &&
          (c.name === mergedRule.branchName || mergedRule.branchName.includes(c.name) || c.name.includes(mergedRule.branchName))
      );
      const effectiveBranchId = mergedRule.branchId || matchedBranch?.id;

      // P1-04: Sinkronkan kuota ke CompetitionStage milik cabang ini bila diedit
      if (updated.quotaPerStage) {
        syncStageQuotasFromRuleConfig(mergedRule.branchName, effectiveBranchId, updated.quotaPerStage);
      }

      // P1-07: Hitung ulang penilaian aktif apabila rubrik cabang berubah
      if (updated.rubricVersionId) {
        const targetRubric = rubricVersions.find((r) => r.id === updated.rubricVersionId);
        if (targetRubric) {
          recalculateAssessmentsForRubricOrRuleChange({
            targetRubric,
            branchName: mergedRule.branchName,
            branchId: effectiveBranchId
          });
        }
      }
    }

    if (isLiveDbActive && existing && mergedRule) {
      const matchedBranch = cabangList.find(
        (c) =>
          (c.tenantId === currentTenantId || !c.tenantId) &&
          mergedRule.branchName &&
          (c.name === mergedRule.branchName || mergedRule.branchName.includes(c.name) || c.name.includes(mergedRule.branchName))
      );
      const effectiveBranchId = mergedRule.branchId || matchedBranch?.id;
      if (mergedRule.rubricVersionId) {
        void supabaseDataService
          .upsertCompetitionRuleConfig({
            ...mergedRule,
            id: toDeterministicUuid(mergedRule.id),
            tenantId: toDeterministicUuid(currentTenantId),
            branchId: effectiveBranchId ? toDeterministicUuid(effectiveBranchId) : undefined,
            rubricVersionId: toDeterministicUuid(mergedRule.rubricVersionId)
          })
          .then((res) => {
            if (!res.success) {
              setSyncStatus(`Gagal memperbarui aturan kompetisi: ${res.message}`);
              setCompetitionRules((prev) => prev.map((r) => (r.id === id ? existing : r)));
            } else {
              setSyncStatus('Aturan Kompetisi Diperbarui di Database');
            }
          });
      }
    }
  };

  const deleteCompetitionRule = (id: string): { success: boolean; message: string } => {
    const existing = competitionRules.find((r) => r.id === id);
    if (!existing) {
      return { success: false, message: 'Konfigurasi aturan cabang tidak ditemukan.' };
    }

    setCompetitionRules((prev) => prev.filter((r) => r.id !== id));

    if (isLiveDbActive) {
      const targetTenantUuid = toDeterministicUuid(
        existing.tenantId === 'system'
          ? '00000000-0000-0000-0000-000000000000'
          : existing.tenantId || currentTenantId
      );
      void supabaseDataService
        .deleteCompetitionRuleConfig(targetTenantUuid, toDeterministicUuid(id))
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal menghapus aturan kompetisi: ${res.message}`);
            setCompetitionRules((prev) => [...prev, existing]);
          } else {
            setSyncStatus('Aturan Kompetisi Dihapus dari Database');
          }
        });
    }

    return {
      success: true,
      message: `Konfigurasi aturan untuk "${existing.branchName}" berhasil dihapus.`
    };
  };

  /**
   * Helper internal untuk memvalidasi apakah hakim memiliki penugasan resmi (judge_assignments)
   * pada babak dan cabang peserta terkait.
   */
  const getStageBranchJudgeAssignments = (
    targetStage: string,
    stageId: string | undefined,
    part: Participant
  ): JudgeAssignment[] => {
    const matchesBranch = (branchName?: string, branchId?: string): boolean => {
      if (!branchName || branchName === 'Semua Cabang') return true;
      if (part.branchId && branchId && part.branchId === branchId) return true;
      const jaBr = branchName.toLowerCase().trim();
      const pBr = (part.branchName || '').toLowerCase().trim();
      if (!pBr) return true;
      return jaBr === pBr || pBr.includes(jaBr) || jaBr.includes(pBr);
    };

    const explicitAssignments = judgeAssignments.filter((ja) => {
      if (ja.tenantId !== currentTenantId) return false;
      const matchesStage =
        (stageId && ja.stageId && ja.stageId === stageId) ||
        ja.stageName === targetStage ||
        !ja.stageName;
      if (!matchesStage) return false;
      return matchesBranch(ja.branchName, ja.branchId);
    });

    // Sertakan juga hakim dari manajemen pengguna (users) yang ditugaskan ke cabang ini namun belum memiliki baris di judgeAssignments
    const assignedJudgeIds = new Set(explicitAssignments.map((ja) => ja.judgeId));
    const fallbackFromUsers: JudgeAssignment[] = users
      .filter(
        (u) =>
          u.role === 'judge' &&
          u.status !== 'Nonaktif' &&
          !assignedJudgeIds.has(u.id) &&
          matchesBranch(u.assignedBranch, undefined)
      )
      .map((u) => ({
        id: `ja-profile-${u.id}-${stageId || targetStage}`,
        tenantId: currentTenantId,
        judgeId: u.id,
        judgeName: u.name,
        stageId: stageId || 'stage-penyisihan',
        stageName: targetStage,
        branchId: part.branchId,
        branchName: u.assignedBranch || part.branchName || 'Semua Cabang',
        judgeField: u.judgeField || 'Dewan Hakim'
      }));

    return [...explicitAssignments, ...fallbackFromUsers];
  };

  /**
   * Menginisialisasi / mengonfirmasi lembar penilaian (termasuk penampilan sempurna 0 kesalahan)
   * secara eksplisit sebelum difinalisasi oleh hakim yang ditugaskan.
   */
  const initializeAssessment = (
    participantId: string,
    judgeId: string,
    stageName?: string,
    questionId?: string
  ): { success: boolean; message: string; assessmentId?: string; assessment?: JudgeAssessment } => {
    if (currentUser.role !== 'judge' || currentUser.id !== judgeId) {
      return {
        success: false,
        message: 'Otorisasi ditolak: Hanya dewan hakim yang sedang bertugas yang dapat menginisialisasi lembar nilai.'
      };
    }

    const part = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    if (!part) {
      return { success: false, message: 'Peserta tidak ditemukan pada tenant aktif.' };
    }

    const targetStage = stageName || part.stageName || selectedStageName;
    const stageQuestions = getParticipantStageQuestions(participantId, targetStage);
    const targetQuestionId = questionId || stageQuestions[0]?.questionId;

    if (!targetQuestionId || !stageQuestions.some((q) => q.questionId === targetQuestionId)) {
      return {
        success: false,
        message: 'Inisialisasi ditolak: Peserta belum memiliki penetapan maqra yang sah pada babak ini.'
      };
    }

    const targetStageObj = stages.find(
      (s) =>
        s.tenantId === currentTenantId &&
        s.name === targetStage &&
        (!part.branchId || !s.branchId || s.branchId === part.branchId) &&
        (!part.branchName || !s.branchName || s.branchName === part.branchName)
    );
    const stageId = targetStageObj?.id || 'stage-penyisihan';

    const stageBranchAssignments = getStageBranchJudgeAssignments(targetStage, targetStageObj?.id, part);
    if (
      stageBranchAssignments.length === 0 ||
      !stageBranchAssignments.some((ja) => ja.judgeId === judgeId)
    ) {
      return {
        success: false,
        message: 'Otorisasi ditolak: Anda tidak terdaftar secara resmi pada penugasan majelis hakim (judge_assignments) untuk cabang dan babak ini.'
      };
    }

    const activeRubric = getActiveRubricForBranch(part.branchName, part.branchId);
    if (!activeRubric) {
      return {
        success: false,
        message: `Inisialisasi ditolak: Cabang "${part.branchName}" belum memiliki rubrik aktif.`
      };
    }

    let sp = stageParticipationsRef.current.find(
      (item) =>
        item.tenantId === currentTenantId &&
        item.participantId === participantId &&
        (targetStageObj?.id && item.stageId ? item.stageId === targetStageObj.id : item.stageName === targetStage)
    );

    if (!sp) {
      sp = {
        id: `sp-${participantId}-${stageId}-${Date.now()}`,
        tenantId: currentTenantId,
        participantId,
        stageId,
        stageName: targetStage,
        branchId: part.branchId,
        branchName: part.branchName,
        lotteryNumber: part.lotteryNumber,
        questionId: targetQuestionId,
        assignedMaqra: part.assignedMaqra,
        pageNumber: part.pageNumber,
        status: 'Berlangsung'
      };
      const nextSps = [...stageParticipationsRef.current, sp];
      stageParticipationsRef.current = nextSps;
      setStageParticipations(nextSps);
    }

    const existing = assessmentsRef.current.find(
      (a) =>
        a.tenantId === currentTenantId &&
        a.judgeId === judgeId &&
        a.participantId === participantId &&
        (sp?.id && a.stageParticipationId ? a.stageParticipationId === sp.id : a.stageName === targetStage) &&
        a.questionId === targetQuestionId
    );

    if (existing?.status === 'finalized') {
      return {
        success: false,
        message: 'Lembar penilaian ini sudah berstatus final.'
      };
    }

    const nowTime = getWibTime();
    const targetJudge = users.find((u) => u.id === judgeId) || currentUser;
    const currentCounts = existing ? { ...existing.errorCounts } : {};
    const scoreResult = calculateAssessmentScore(
      currentCounts,
      errorCategories,
      activeRubric,
      activeRubric.startingScore
    );

    if (scoreResult.validationErrors.length > 0) {
      return {
        success: false,
        message: `Validasi rubrik gagal: ${scoreResult.validationErrors.join('; ')}`
      };
    }

    const initializedAsm: JudgeAssessment = existing
      ? {
          ...existing,
          stageParticipationId: sp.id,
          stageId,
          stageName: targetStage,
          status: 'in_progress',
          deductions: scoreResult.deductions,
          fieldScores: scoreResult.fieldScores,
          fieldDeductions: scoreResult.fieldDeductions,
          totalDeductions: scoreResult.totalDeductions,
          finalScore: scoreResult.finalScore,
          rubricVersion: activeRubric.code,
          rubricVersionId: activeRubric.id,
          lastUpdated: nowTime
        }
      : {
          id: toDeterministicUuid(`asm-${participantId}-${judgeId}-${stageId}-${targetQuestionId}`),
          tenantId: currentTenantId,
          stageParticipationId: sp.id,
          stageId,
          stageName: targetStage,
          participantId,
          judgeId,
          judgeName: targetJudge.name,
          judgeField: targetJudge.judgeField || 'Dewan Hakim',
          questionId: targetQuestionId,
          status: 'in_progress',
          errorCounts: {},
          deductions: scoreResult.deductions,
          fieldScores: scoreResult.fieldScores,
          fieldDeductions: scoreResult.fieldDeductions,
          totalDeductions: scoreResult.totalDeductions,
          finalScore: scoreResult.finalScore,
          rubricVersion: activeRubric.code,
          rubricVersionId: activeRubric.id,
          annotations: [],
          lastUpdated: nowTime
        };

    const prevAssessmentsSnapshot = assessmentsRef.current;
    const prevSpSnapshot = stageParticipationsRef.current;

    const nextAssessments = [
      ...assessmentsRef.current.filter((a) => a.id !== initializedAsm.id),
      initializedAsm
    ];
    assessmentsRef.current = nextAssessments;
    setAssessments(nextAssessments);

    const nextStageParticipations = stageParticipationsRef.current.map((item) =>
      item.id === sp!.id && item.status === 'Belum Dimulai'
        ? { ...item, status: 'Berlangsung' as ParticipantProgressStatus }
        : item
    );
    stageParticipationsRef.current = nextStageParticipations;
    setStageParticipations(nextStageParticipations);

    if (connectionInfo.isDatabaseReady && connectionInfo.isAuthenticated) {
      setSyncStatus('Menyimpan ke database...');
      const matchedMaqraItem = stageQuestions.find((q) => q.questionId === targetQuestionId);
      const remoteAsmPayload = {
        ...initializedAsm,
        id: toDeterministicUuid(initializedAsm.id),
        tenantId: toDeterministicUuid(currentTenantId),
        stageParticipationId: toDeterministicUuid(sp.id),
        judgeId: toDeterministicUuid(judgeId),
        rubricVersionId: toDeterministicUuid(activeRubric.id),
        questionId: toDeterministicUuid(targetQuestionId),
        assignedMaqraId: matchedMaqraItem?.id
      };
      void supabaseDataService
        .syncAssessmentToRemote(
          remoteAsmPayload,
          matchedMaqraItem?.id,
          { stageParticipation: sp, participant: part }
        )
        .then((res) => {
          if (res.success) {
            setSyncStatus('Lembar Penilaian Tersimpan di Database');
            setLastSyncTime(getWibTime());
            void outboxSyncService.markSynced(`assessment-draft-${initializedAsm.id}`);
            if (res.data?.assignedMaqraId) {
              setAssessments((prev) => {
                const updated = prev.map((a) =>
                  a.id === initializedAsm.id ? { ...a, assignedMaqraId: res.data!.assignedMaqraId } : a
                );
                assessmentsRef.current = updated;
                return updated;
              });
            }
          } else {
            setSyncStatus(`Gagal Menyimpan Lembar Nilai: ${res.message}`);
            void outboxSyncService.enqueueOperation({
              idempotencyKey: `assessment-draft-${initializedAsm.id}`,
              tenantId: currentTenantId,
              operationType: 'UPSERT_ASSESSMENT_DRAFT',
              entityLabel: `Draf Nilai ${part.name}`,
              payload: {
                assessment: remoteAsmPayload,
                assignedMaqraId: matchedMaqraItem?.id,
                stageParticipation: sp,
                participant: part
              },
              errorMessage: res.message
            });
            assessmentsRef.current = prevAssessmentsSnapshot;
            setAssessments(prevAssessmentsSnapshot);
            stageParticipationsRef.current = prevSpSnapshot;
            setStageParticipations(prevSpSnapshot);
          }
        })
        .catch((err) => {
          const msg = err instanceof Error ? err.message : 'Kesalahan jaringan';
          setSyncStatus(`Gagal Menyimpan Lembar Nilai: ${msg}`);
          void outboxSyncService.enqueueOperation({
            idempotencyKey: `assessment-draft-${initializedAsm.id}`,
            tenantId: currentTenantId,
            operationType: 'UPSERT_ASSESSMENT_DRAFT',
            entityLabel: `Draf Nilai ${part.name}`,
            payload: {
              assessment: remoteAsmPayload,
              assignedMaqraId: matchedMaqraItem?.id,
              stageParticipation: sp,
              participant: part
            },
            errorMessage: msg
          });
          assessmentsRef.current = prevAssessmentsSnapshot;
          setAssessments(prevAssessmentsSnapshot);
          stageParticipationsRef.current = prevSpSnapshot;
          setStageParticipations(prevSpSnapshot);
        });
    } else {
      setSyncStatus('Mode Simulasi Lokal (Tersimpan di Browser)');
      setLastSyncTime(nowTime);
    }

    return {
      success: true,
      message: 'Lembar penilaian siap dan terkonfirmasi.',
      assessmentId: initializedAsm.id,
      assessment: initializedAsm
    };
  };

  /**
   * Update error count with centralized calculation helper and strict read-only lock for finalized
   * Identity: participantId + judgeId + targetStage + targetQuestionId
   */
  const updateErrorCount = (
    participantId: string,
    judgeId: string,
    categoryId: string,
    delta: number,
    stageName?: string,
    questionId?: string
  ) => {
    // Role & Identity check: Only the logged-in judge can modify their own error counts
    if (currentUser.role !== 'judge' || currentUser.id !== judgeId) {
      console.warn('Perubahan nilai ditolak: Hanya hakim pemilik lembar nilai yang berwenang mengubah skor.');
      return;
    }

    const part = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    if (!part) return;
    const targetStage = stageName || part.stageName || selectedStageName;
    const stageQuestions = getParticipantStageQuestions(participantId, targetStage);
    const targetQuestionId = questionId || stageQuestions[0]?.questionId;

    if (!targetQuestionId || !stageQuestions.some((q) => q.questionId === targetQuestionId)) {
      console.warn('Penilaian ditolak: Peserta belum memiliki maqra yang ditetapkan pada babak ini.');
      return;
    }

    const targetStageObj = stages.find(
      (s) =>
        s.tenantId === currentTenantId &&
        s.name === targetStage &&
        (!part.branchId || !s.branchId || s.branchId === part.branchId) &&
        (!part.branchName || !s.branchName || s.branchName === part.branchName)
    );
    const stageId = targetStageObj?.id || 'stage-penyisihan';

    // Mandatory official judge assignment check (with profile fallback)
    const stageBranchAssignments = getStageBranchJudgeAssignments(targetStage, targetStageObj?.id, part);
    const targetJudge = users.find((u) => u.id === judgeId) || currentUser;
    const judgeAssignment =
      stageBranchAssignments.find((ja) => ja.judgeId === judgeId) ||
      (targetJudge.role === 'judge'
        ? {
            id: `ja-fallback-${judgeId}`,
            tenantId: currentTenantId,
            judgeId,
            judgeName: targetJudge.name,
            stageId,
            stageName: targetStage,
            branchName: targetJudge.assignedBranch || part.branchName,
            judgeField: targetJudge.judgeField || 'Dewan Hakim'
          }
        : undefined);

    if (!judgeAssignment) {
      console.warn('Penilaian ditolak: Hakim tidak memiliki penugasan resmi pada babak dan cabang ini.');
      return;
    }

    // Resolusi rubrik aktif dinamis sesuai cabang lomba peserta (P0)
    const activeRubric = getActiveRubricForBranch(part.branchName, part.branchId, part.levelId, part.levelName);
    if (!activeRubric) {
      console.warn(`Pembaruan nilai dibatalkan: Cabang "${part.branchName}" belum memiliki rubrik aktif yang valid.`);
      return;
    }

    // Field-level access restriction: Judge may only score categories within their assigned field
    if (judgeAssignment.judgeField || judgeAssignment.judgeFieldId) {
      const cat = errorCategories.find((c) => c.id === categoryId);
      if (cat) {
        const assignedFieldClean = (judgeAssignment.judgeField || '')
          .toLowerCase()
          .replace(/^bidang\s+/i, '')
          .trim();
        const matchedRubricField = activeRubric.fields.find((f) => {
          if (judgeAssignment.judgeFieldId && f.id === judgeAssignment.judgeFieldId) return true;
          const fClean = f.name.toLowerCase().replace(/^bidang\s+/i, '').trim();
          return (
            assignedFieldClean &&
            (fClean === assignedFieldClean ||
              fClean.includes(assignedFieldClean) ||
              assignedFieldClean.includes(fClean))
          );
        });

        if (cat.fieldId && matchedRubricField) {
          if (cat.fieldId !== matchedRubricField.id) {
            const catScopeClean = (cat.scope || '').toLowerCase().replace(/^bidang\s+/i, '').trim();
            const fClean = matchedRubricField.name.toLowerCase().replace(/^bidang\s+/i, '').trim();
            if (!catScopeClean.includes(fClean) && !fClean.includes(catScopeClean)) {
              console.warn(`Perubahan nilai ditolak: Kategori "${cat.name}" bukan bagian dari bidang penugasan hakim.`);
              return;
            }
          }
        }
      }
    }

    // Get or create stage participation
    let sp = stageParticipations.find(
      (item) =>
        item.tenantId === currentTenantId &&
        item.participantId === participantId &&
        (targetStageObj?.id && item.stageId ? item.stageId === targetStageObj.id : item.stageName === targetStage)
    );

    if (!sp) {
      sp = {
        id: `sp-${participantId}-${stageId}-${Date.now()}`,
        tenantId: currentTenantId,
        participantId,
        stageId,
        stageName: targetStage,
        branchId: part.branchId,
        branchName: part.branchName,
        lotteryNumber: part.lotteryNumber,
        questionId: targetQuestionId,
        assignedMaqra: part.assignedMaqra,
        pageNumber: part.pageNumber,
        status: 'Berlangsung'
      };
      setStageParticipations((prev) => [...prev, sp!]);
    }

    const existing = assessments.find(
      (a) =>
        a.tenantId === currentTenantId &&
        a.judgeId === judgeId &&
        a.participantId === participantId &&
        (sp?.id && a.stageParticipationId ? a.stageParticipationId === sp.id : a.stageName === targetStage) &&
        a.questionId === targetQuestionId
    );

    if (existing?.status === 'finalized' || existing?.isLocked) {
      console.warn('Penilaian yang sudah final bersifat read-only dan tidak dapat diubah.');
      return;
    }

    const nowTime = getWibTime();

    const currentCounts = existing ? { ...existing.errorCounts } : {};
    const oldCount = currentCounts[categoryId] || 0;
    const newCount = Math.max(0, oldCount + delta);
    currentCounts[categoryId] = newCount;

    const scoreResult = calculateAssessmentScore(
      currentCounts,
      errorCategories,
      activeRubric,
      activeRubric.startingScore
    );

    const updatedAssessment: JudgeAssessment = existing
      ? {
          ...existing,
          stageParticipationId: sp.id,
          stageId,
          stageName: targetStage,
          questionId: targetQuestionId,
          errorCounts: currentCounts,
          deductions: scoreResult.deductions,
          fieldScores: scoreResult.fieldScores,
          fieldDeductions: scoreResult.fieldDeductions,
          totalDeductions: scoreResult.totalDeductions,
          finalScore: scoreResult.finalScore,
          rubricVersion: activeRubric.code,
          rubricVersionId: activeRubric.id,
          status: 'in_progress',
          lastUpdated: nowTime
        }
      : {
          id: toDeterministicUuid(`asm-${participantId}-${judgeId}-${stageId}-${targetQuestionId}`),
          tenantId: currentTenantId,
          stageParticipationId: sp.id,
          stageId,
          stageName: targetStage,
          participantId,
          judgeId,
          judgeName: targetJudge.name,
          judgeField: judgeAssignment.judgeField || targetJudge.judgeField || 'Dewan Hakim',
          questionId: targetQuestionId,
          status: 'in_progress',
          errorCounts: currentCounts,
          deductions: scoreResult.deductions,
          fieldScores: scoreResult.fieldScores,
          fieldDeductions: scoreResult.fieldDeductions,
          totalDeductions: scoreResult.totalDeductions,
          finalScore: scoreResult.finalScore,
          rubricVersion: activeRubric.code,
          rubricVersionId: activeRubric.id,
          annotations: [],
          lastUpdated: nowTime
        };

    setAssessments((prev) => {
      const others = prev.filter((a) => a.id !== updatedAssessment.id);
      const next = [...others, updatedAssessment];
      assessmentsRef.current = next;
      return next;
    });

    // Update stage participation status to Berlangsung
    setStageParticipations((prev) =>
      prev.map((item) =>
        item.id === sp!.id && item.status === 'Belum Dimulai'
          ? { ...item, status: 'Berlangsung' }
          : item
      )
    );

    // Update participant status to Berlangsung
    setParticipants((prev) =>
      prev.map((p) =>
        p.id === participantId && p.tenantId === currentTenantId && p.status === 'Menunggu'
          ? { ...p, status: 'Berlangsung' }
          : p
      )
    );

    // Activity log entry
    const cat = errorCategories.find((c) => c.id === categoryId);
    if (cat && delta !== 0) {
      const sign = delta > 0 ? `+${delta}` : `${delta}`;
      const newLog: ActivityLogItem = {
        id: generateUniqueLogId('act'),
        tenantId: currentTenantId,
        type: 'autosave',
        title: 'Koreksi Nilai',
        description: `Koreksi kesalahan ${cat.name} (${sign}) peserta ${part.participantId} ${part.name} oleh ${targetJudge.name}.`,
        timestamp: nowTime,
        actorName: targetJudge.name
      };
      setActivityLogs((prev) => [newLog, ...prev.filter((l) => l.id !== newLog.id).slice(0, 20)]);
      addNotification({
        title: 'Koreksi Nilai Dicatat',
        message: `${cat.name} (${sign}) pada peserta ${part.name} oleh ${targetJudge.name}.`,
        type: 'info',
        module: 'Penilaian'
      });
    }

    notifyCrossTabSync(`Koreksi Nilai ${part.name}`);

    if (connectionInfo.isDatabaseReady && connectionInfo.isAuthenticated) {
      setSyncStatus('Menyimpan ke database...');
      const matchedMaqraItem = stageQuestions.find((q) => q.questionId === targetQuestionId);
      const remoteAsmPayload = {
        ...updatedAssessment,
        id: toDeterministicUuid(updatedAssessment.id),
        tenantId: toDeterministicUuid(currentTenantId),
        stageParticipationId: toDeterministicUuid(sp.id),
        judgeId: toDeterministicUuid(judgeId),
        rubricVersionId: toDeterministicUuid(activeRubric.id),
        questionId: toDeterministicUuid(targetQuestionId),
        assignedMaqraId: matchedMaqraItem?.id
      };
      void supabaseDataService
        .syncAssessmentToRemote(
          remoteAsmPayload,
          matchedMaqraItem?.id,
          { stageParticipation: sp, participant: part }
        )
        .then((res) => {
          if (res.success) {
            setSyncStatus('Tersimpan di Database');
            setLastSyncTime(getWibTime());
            void outboxSyncService.markSynced(`assessment-draft-${updatedAssessment.id}`);
            notifyCrossTabSync(`Simpan Nilai ${part.name}`);
            if (res.data?.assignedMaqraId) {
              setAssessments((prev) =>
                prev.map((a) =>
                  a.id === updatedAssessment.id ? { ...a, assignedMaqraId: res.data!.assignedMaqraId } : a
                )
              );
            }
          } else {
            setSyncStatus(`Menunggu Sinkronisasi Ulang: ${res.message}`);
            void outboxSyncService.enqueueOperation({
              idempotencyKey: `assessment-draft-${updatedAssessment.id}`,
              tenantId: currentTenantId,
              operationType: 'UPSERT_ASSESSMENT_DRAFT',
              entityLabel: `Koreksi Nilai ${part.name}`,
              payload: {
                assessment: remoteAsmPayload,
                assignedMaqraId: matchedMaqraItem?.id,
                stageParticipation: sp,
                participant: part
              },
              errorMessage: res.message
            });
          }
        })
        .catch((err) => {
          const msg = err instanceof Error ? err.message : 'Kesalahan jaringan';
          setSyncStatus(`Menunggu Sinkronisasi Ulang: ${msg}`);
          void outboxSyncService.enqueueOperation({
            idempotencyKey: `assessment-draft-${updatedAssessment.id}`,
            tenantId: currentTenantId,
            operationType: 'UPSERT_ASSESSMENT_DRAFT',
            entityLabel: `Koreksi Nilai ${part.name}`,
            payload: {
              assessment: remoteAsmPayload,
              assignedMaqraId: matchedMaqraItem?.id,
              stageParticipation: sp,
              participant: part
            },
            errorMessage: msg
          });
        });
    } else {
      setSyncStatus('Mode Simulasi Lokal (Tersimpan di Browser)');
      setLastSyncTime(nowTime);
    }
  };

  /**
   * Save annotations independently without needing error counts first
   * Strictly scoped by participantId, judgeId, targetStage, and targetQuestionId
   */
  const saveAnnotations = (
    participantId: string,
    judgeId: string,
    annotations: CanvasStroke[],
    stageName?: string,
    questionId?: string
  ) => {
    // Role check: Admin cannot mutate annotations
    if (currentUser.role !== 'judge' || currentUser.id !== judgeId) {
      return;
    }

    const part = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    if (!part) return;
    const targetStage = stageName || part.stageName || selectedStageName;
    const stageQuestions = getParticipantStageQuestions(participantId, targetStage);
    const targetQuestionId = questionId || stageQuestions[0]?.questionId;
    if (!targetQuestionId) return;

    const targetStageObj = stages.find(
      (s) =>
        s.tenantId === currentTenantId &&
        s.name === targetStage &&
        (!part.branchId || !s.branchId || s.branchId === part.branchId) &&
        (!part.branchName || !s.branchName || s.branchName === part.branchName)
    );
    const stageId = targetStageObj?.id || 'stage-penyisihan';

    const stageBranchAssignments = getStageBranchJudgeAssignments(targetStage, targetStageObj?.id, part);
    if (
      stageBranchAssignments.length === 0 ||
      !stageBranchAssignments.some((ja) => ja.judgeId === judgeId)
    ) {
      return;
    }

    const prevAssessmentsSnapshot = assessments;
    const prevSpSnapshot = stageParticipations;

    let sp = stageParticipations.find(
      (item) =>
        item.tenantId === currentTenantId &&
        item.participantId === participantId &&
        (targetStageObj?.id && item.stageId ? item.stageId === targetStageObj.id : item.stageName === targetStage)
    );

    if (!sp) {
      sp = {
        id: `sp-${participantId}-${stageId}-${Date.now()}`,
        tenantId: currentTenantId,
        participantId,
        stageId,
        stageName: targetStage,
        branchId: part.branchId,
        branchName: part.branchName,
        lotteryNumber: part.lotteryNumber,
        questionId: targetQuestionId,
        assignedMaqra: part.assignedMaqra,
        pageNumber: part.pageNumber,
        status: 'Berlangsung'
      };
      setStageParticipations((prev) => [...prev, sp!]);
    }

    const existing = assessments.find(
      (a) =>
        a.tenantId === currentTenantId &&
        a.judgeId === judgeId &&
        a.participantId === participantId &&
        (sp?.id && a.stageParticipationId ? a.stageParticipationId === sp.id : a.stageName === targetStage) &&
        a.questionId === targetQuestionId
    );

    if (existing?.status === 'finalized' || existing?.isLocked) {
      return;
    }

    const nowTime = getWibTime();
    setSyncStatus('Menyimpan anotasi mushaf...');
    const targetJudge = users.find((u) => u.id === judgeId) || currentUser;
    const activeRubric = getActiveRubricForBranch(part.branchName, part.branchId);

    const updatedSheet: JudgeAssessment = existing
      ? {
          ...existing,
          stageParticipationId: sp.id,
          stageId,
          stageName: targetStage,
          questionId: targetQuestionId,
          annotations,
          lastUpdated: nowTime
        }
      : {
          id: toDeterministicUuid(`asm-${participantId}-${judgeId}-${stageId}-${targetQuestionId}`),
          tenantId: currentTenantId,
          stageParticipationId: sp.id,
          stageId,
          stageName: targetStage,
          participantId,
          judgeId,
          judgeName: targetJudge.name,
          judgeField: targetJudge.judgeField || 'Dewan Hakim',
          questionId: targetQuestionId,
          rubricVersion: activeRubric?.code || 'RUBRIC-SENI-BACA-2025',
          rubricVersionId: activeRubric?.id,
          status: 'in_progress',
          errorCounts: {},
          deductions: {},
          totalDeductions: 0,
          finalScore: activeRubric?.startingScore || 100.0,
          annotations,
          lastUpdated: nowTime
        };

    setAssessments((prev) => {
      const others = prev.filter((a) => a.id !== updatedSheet.id);
      return [...others, updatedSheet];
    });

    if (connectionInfo.isDatabaseReady && connectionInfo.isAuthenticated && activeRubric) {
      const matchedMaqraItem = stageQuestions.find((q) => q.questionId === targetQuestionId);
      void supabaseDataService
        .syncAssessmentToRemote(
          {
            ...updatedSheet,
            id: toDeterministicUuid(updatedSheet.id),
            tenantId: toDeterministicUuid(currentTenantId),
            stageParticipationId: toDeterministicUuid(sp.id),
            judgeId: toDeterministicUuid(judgeId),
            rubricVersionId: toDeterministicUuid(activeRubric.id),
            questionId: toDeterministicUuid(targetQuestionId),
            assignedMaqraId: matchedMaqraItem?.id || updatedSheet.assignedMaqraId
          },
          matchedMaqraItem?.id || updatedSheet.assignedMaqraId,
          { stageParticipation: sp, participant: part }
        )
        .then((res) => {
          if (res.success) {
            setSyncStatus('Anotasi & Nilai Tersimpan di Database');
            setLastSyncTime(getWibTime());
            if (res.data?.assignedMaqraId) {
              setAssessments((prev) =>
                prev.map((a) =>
                  a.id === updatedSheet.id ? { ...a, assignedMaqraId: res.data!.assignedMaqraId } : a
                )
              );
            }
          } else {
            setSyncStatus(`Gagal Menyimpan Anotasi: ${res.message}`);
            setAssessments(prevAssessmentsSnapshot);
            setStageParticipations(prevSpSnapshot);
          }
        })
        .catch((err) => {
          const msg = err instanceof Error ? err.message : 'Kesalahan jaringan';
          setSyncStatus(`Gagal Menyimpan Anotasi: ${msg}`);
          setAssessments(prevAssessmentsSnapshot);
          setStageParticipations(prevSpSnapshot);
        });
    } else {
      setSyncStatus('Mode Simulasi Lokal (Tersimpan di Browser)');
      setLastSyncTime(nowTime);
    }
  };

  /**
   * Finalize individual judge assessment scoped strictly to question, stage, and official judge assignment.
   * Rejects unassigned judges and rejects empty/uninitialized assessment sheets.
   * When connected to live database, waits for sync + RPC finalization before mutating local state to finalized.
   */
  const finalizeAssessment = async (
    participantId: string,
    judgeId: string,
    stageName?: string,
    questionId?: string,
    options?: { confirmFlawless?: boolean }
  ): Promise<{ success: boolean; message: string }> => {
    // 0. Block finalization if browser is explicitly offline
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return {
        success: false,
        message: 'Finalisasi ditolak saat perangkat sedang Offline. Hubungkan kembali jaringan untuk mengunci lembar penilaian resmi di server.'
      };
    }

    // 1. Role check: Admin cannot finalize on behalf of judge
    if (currentUser.role !== 'judge') {
      return {
        success: false,
        message: 'Otorisasi ditolak: Hanya dewan hakim yang berwenang memfinalisasi lembar penilaian.'
      };
    }

    // 2. Judge identity check
    if (currentUser.id !== judgeId) {
      return {
        success: false,
        message: 'Otorisasi ditolak: Identitas hakim tidak sesuai dengan pengguna yang sedang login.'
      };
    }

    // 3. Participant check
    const part = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    if (!part) {
      return {
        success: false,
        message: 'Peserta tidak ditemukan pada tenant aktif.'
      };
    }

    const targetStage = stageName || part.stageName || selectedStageName;
    const stageQuestions = getParticipantStageQuestions(participantId, targetStage);
    const targetQuestionId = questionId || stageQuestions[0]?.questionId;

    // 4. Maqra check: Must exist and belong to this participant's stage questions
    if (!targetQuestionId || !stageQuestions.some((q) => q.questionId === targetQuestionId)) {
      return {
        success: false,
        message: 'Finalisasi ditolak: Peserta belum memiliki penetapan maqra yang sah pada babak ini.'
      };
    }

    const targetStageObj = stages.find(
      (s) =>
        s.tenantId === currentTenantId &&
        s.name === targetStage &&
        (!part.branchId || !s.branchId || s.branchId === part.branchId) &&
        (!part.branchName || !s.branchName || s.branchName === part.branchName)
    );
    const stageId = targetStageObj?.id || 'stage-penyisihan';

    // 5. Mandatory Official Judge Assignment check
    const stageBranchAssignments = getStageBranchJudgeAssignments(targetStage, targetStageObj?.id, part);
    if (stageBranchAssignments.length === 0) {
      return {
        success: false,
        message: 'Finalisasi ditolak: Belum ada penugasan majelis hakim resmi (judge_assignments) untuk babak dan cabang ini.'
      };
    }

    const isJudgeAssigned = stageBranchAssignments.some((ja) => ja.judgeId === judgeId);
    if (!isJudgeAssigned) {
      return {
        success: false,
        message: 'Finalisasi ditolak: Anda tidak terdaftar secara resmi sebagai hakim penilai untuk cabang dan babak ini.'
      };
    }

    // 6. Active Rubric check
    const activeRubric = getActiveRubricForBranch(part.branchName, part.branchId);
    if (!activeRubric || activeRubric.status !== 'Aktif') {
      return {
        success: false,
        message: `Finalisasi ditolak: Aturan/rubrik penilaian belum terkonfigurasi atau tidak berstatus Aktif untuk cabang "${part.branchName}".`
      };
    }

    // If confirmFlawless is requested and assessment isn't initialized yet, initialize deterministically
    let sp = stageParticipationsRef.current.find(
      (item) =>
        item.tenantId === currentTenantId &&
        item.participantId === participantId &&
        (targetStageObj?.id && item.stageId ? item.stageId === targetStageObj.id : item.stageName === targetStage)
    );

    let existing = assessmentsRef.current.find(
      (a) =>
        a.tenantId === currentTenantId &&
        a.judgeId === judgeId &&
        a.participantId === participantId &&
        (sp?.id && a.stageParticipationId ? a.stageParticipationId === sp.id : a.stageName === targetStage) &&
        a.questionId === targetQuestionId
    );

    if ((!existing || existing.status === 'not_started') && options?.confirmFlawless) {
      const initRes = initializeAssessment(participantId, judgeId, targetStage, targetQuestionId);
      if (!initRes.success || !initRes.assessment) {
        return {
          success: false,
          message: initRes.message
        };
      }
      existing = initRes.assessment;
      sp = stageParticipationsRef.current.find(
        (item) =>
          item.tenantId === currentTenantId &&
          item.participantId === participantId &&
          (targetStageObj?.id && item.stageId ? item.stageId === targetStageObj.id : item.stageName === targetStage)
      );
    }

    if (!sp) {
      return {
        success: false,
        message: 'Finalisasi ditolak: Data partisipasi babak (StageParticipation) peserta tidak ditemukan.'
      };
    }

    // 7. Reject Empty / Non-Existent Assessment Bypass!
    if (!existing || existing.status === 'not_started') {
      return {
        success: false,
        message: 'Finalisasi ditolak: Lembar penilaian belum diinisialisasi atau belum pernah diisi. Silakan mulai lembar penilaian atau konfirmasi penampilan tanpa kesalahan terlebih dahulu.'
      };
    }

    // 8. Reject re-finalization of already finalized assessment
    if (existing.status === 'finalized' || existing.isLocked) {
      return {
        success: false,
        message: 'Lembar penilaian ini sudah dalam status terfinalisasi.'
      };
    }

    // 9. Calculate score and validate rubric fields using activeRubric.startingScore
    const currentCounts = existing.errorCounts || {};
    const scoreResult = calculateAssessmentScore(
      currentCounts,
      errorCategories,
      activeRubric,
      activeRubric.startingScore
    );

    if (scoreResult.validationErrors.length > 0) {
      return {
        success: false,
        message: `Finalisasi diblokir karena validasi rubrik gagal: ${scoreResult.validationErrors.join('; ')}`
      };
    }

    const matchedMaqraItem = stageQuestions.find((q) => q.questionId === targetQuestionId);
    let resolvedAssignedMaqraId = existing.assignedMaqraId || matchedMaqraItem?.id;
    let persistedAssessmentId = existing.id;

    // 10. Database Transaction First when in live database mode!
    if (supabaseDataService.isLive() && connectionInfo.isDatabaseReady && connectionInfo.isAuthenticated) {
      setSyncStatus('Memproses finalisasi di server...');
      const asmUuid = toDeterministicUuid(existing.id);

      const syncRes = await supabaseDataService.syncAssessmentToRemote(
        {
          ...existing,
          id: asmUuid,
          tenantId: toDeterministicUuid(currentTenantId),
          stageParticipationId: toDeterministicUuid(sp.id),
          judgeId: toDeterministicUuid(judgeId),
          rubricVersionId: toDeterministicUuid(activeRubric.id),
          questionId: toDeterministicUuid(targetQuestionId),
          assignedMaqraId: resolvedAssignedMaqraId,
          status: 'in_progress',
          isLocked: false,
          deductions: scoreResult.deductions,
          fieldScores: scoreResult.fieldScores,
          totalDeductions: scoreResult.totalDeductions,
          finalScore: scoreResult.finalScore
        },
        resolvedAssignedMaqraId,
        { stageParticipation: sp, participant: part }
      );

      if (!syncRes.success) {
        setSyncStatus('Gagal Menyimpan Draf ke Database');
        return {
          success: false,
          message: `Gagal menyimpan draf penilaian ke database sebelum finalisasi: ${syncRes.message}`
        };
      }

      persistedAssessmentId = syncRes.data?.assessmentId || asmUuid;
      resolvedAssignedMaqraId = syncRes.data?.assignedMaqraId || resolvedAssignedMaqraId;

      const rpcRes = await supabaseDataService.finalizeJudgeAssessmentRpc(persistedAssessmentId);
      if (!rpcRes.success) {
        setSyncStatus('Gagal Memfinalisasi di Database');
        addNotification({
          title: 'Finalisasi Penilaian Ditolak',
          message: `Finalisasi database ditolak: ${rpcRes.message}`,
          type: 'error',
          module: 'Penilaian'
        });
        return {
          success: false,
          message: `Finalisasi database ditolak: ${rpcRes.message}`
        };
      }
      void outboxSyncService.markSynced(`assessment-draft-${existing.id}`);
    }

    const nowTime = getWibTime();
    const targetJudge = users.find((u) => u.id === judgeId) || currentUser;
    const finalizedScore = scoreResult.finalScore;

    addNotification({
      title: 'Penilaian Berhasil Difinalisasi',
      message: `Nilai peserta ${part.name} difinalisasi oleh ${targetJudge.name} (Skor: ${finalizedScore.toFixed(2)})`,
      type: 'success',
      module: 'Penilaian'
    });

    const currentAssessmentsList = assessmentsRef.current.some((a) => a.id === existing!.id)
      ? assessmentsRef.current
      : [...assessmentsRef.current, existing];

    const updatedAssessments: JudgeAssessment[] = currentAssessmentsList.map((a) =>
      a.id === existing!.id
        ? {
            ...a,
            id: persistedAssessmentId || a.id,
            stageParticipationId: sp!.id,
            stageId,
            stageName: targetStage,
            assignedMaqraId: resolvedAssignedMaqraId,
            status: 'finalized',
            isLocked: true,
            deductions: scoreResult.deductions,
            fieldScores: scoreResult.fieldScores,
            fieldDeductions: scoreResult.fieldDeductions,
            totalDeductions: scoreResult.totalDeductions,
            finalScore: scoreResult.finalScore,
            rubricVersion: activeRubric.code,
            rubricVersionId: activeRubric.id,
            finalizedAt: nowTime,
            lastUpdated: nowTime
          }
        : a
    );
    assessmentsRef.current = updatedAssessments;
    setAssessments(updatedAssessments);

    // 11. Check required judges strictly from official assignments (NO fallback to all tenant judges)
    const requiredJudgeIds = Array.from(new Set(stageBranchAssignments.map((ja) => ja.judgeId)));
    const totalRequiredUnits = requiredJudgeIds.length * stageQuestions.length;
    let finalizedUnits = 0;

    for (const q of stageQuestions) {
      for (const jId of requiredJudgeIds) {
        const isCurrent = jId === judgeId && q.questionId === targetQuestionId;
        const asm = updatedAssessments.find(
          (a) =>
            a.tenantId === currentTenantId &&
            a.judgeId === jId &&
            a.participantId === participantId &&
            (a.stageParticipationId ? a.stageParticipationId === sp.id : a.stageName === targetStage) &&
            a.questionId === q.questionId
        );
        if (isCurrent || asm?.status === 'finalized') {
          finalizedUnits++;
        }
      }
    }

    const allFinalized = finalizedUnits === totalRequiredUnits && totalRequiredUnits > 0;
    const updatedStatus: ParticipantProgressStatus = allFinalized
      ? 'Lengkap'
      : finalizedUnits > 0
      ? 'Menunggu Hakim Lain'
      : 'Berlangsung';

    setStageParticipations((prev) =>
      prev.map((item) =>
        item.id === sp.id
          ? {
              ...item,
              status: updatedStatus,
              finalizedAt: allFinalized ? nowTime : item.finalizedAt
            }
          : item
      )
    );

    if (part.status === 'Menunggu') {
      setParticipants((prev) =>
        prev.map((p) =>
          p.id === participantId && p.tenantId === currentTenantId
            ? { ...p, status: 'Berlangsung' }
            : p
        )
      );
    }

    const currentQObj = stageQuestions.find((q) => q.questionId === targetQuestionId);
    const qLabel = currentQObj?.code || 'Maqra';
    const auditFinalized: AuditLogItem = {
      id: generateUniqueLogId('aud'),
      timestamp: nowTime,
      actor: `${currentUser.name} (${currentUser.role})`,
      action: 'ASSESSMENT_FINALIZED',
      target: `Peserta ${part.participantId} (${part.name}) - ${targetJudge.name}`,
      tenantName: currentTenant.name,
      summary: `Finalisasi lembar nilai ${targetJudge.judgeField || 'Dewan Hakim'} untuk ${qLabel} pada Babak ${targetStage} dengan nilai ${finalizedScore.toFixed(2)}.`,
      outcome: 'Success'
    };
    setAuditLogs((prev) => [auditFinalized, ...prev]);

    const newLog: ActivityLogItem = {
      id: generateUniqueLogId('act'),
      tenantId: currentTenantId,
      type: 'finalized',
      title: 'Penilaian Hakim Terkunci',
      description: `Penilaian ${qLabel} peserta ${part.participantId} ${part.name} berhasil dikunci oleh ${targetJudge.name} (Skor: ${finalizedScore.toFixed(2)}).`,
      timestamp: nowTime,
      actorName: targetJudge.name
    };
    setActivityLogs((prev) => [newLog, ...prev.filter((l) => l.id !== newLog.id).slice(0, 20)]);

    setSyncStatus(
      supabaseDataService.isLive()
        ? supabaseDataService.getConnectionStatus().statusLabel
        : 'Mode Lokal (Tersimpan di Browser)'
    );
    setLastSyncTime(nowTime);

    return {
      success: true,
      message: `Penilaian ${qLabel} untuk peserta ${part.name} (Skor: ${finalizedScore.toFixed(2)}) berhasil dikunci dan difinalisasi.`
    };
  };

  /**
   * Pembukaan kembali lembar penilaian final (Correction & Reopen Policy)
   * Hanya dapat dilakukan oleh Administrator / Superadmin dengan mencantumkan alasan wajib.
   * Menunggu transaksi RPC server sebelum membuka kunci di state lokal.
   */
  const reopenAssessment = async (
    participantId: string,
    judgeId: string,
    reason: string,
    stageName?: string,
    questionId?: string
  ): Promise<{ success: boolean; message: string }> => {
    if (currentUser.role === 'judge') {
      return {
        success: false,
        message: 'Otorisasi ditolak: Hanya Administrator yang berwenang membuka kembali penilaian yang sudah final.'
      };
    }

    if (!reason || reason.trim().length < 5) {
      return {
        success: false,
        message: 'Alasan pembukaan kembali lembar nilai wajib diisi minimal 5 karakter untuk rekaman audit trail.'
      };
    }

    const part = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    if (!part) {
      return { success: false, message: 'Peserta tidak ditemukan pada tenant ini.' };
    }

    const targetStage = stageName || part.stageName || selectedStageName;
    const stageQuestions = getParticipantStageQuestions(participantId, targetStage);
    const targetQuestionId = questionId || stageQuestions[0]?.questionId;

    const existing = assessments.find(
      (a) =>
        a.tenantId === currentTenantId &&
        a.judgeId === judgeId &&
        a.participantId === participantId &&
        a.stageName === targetStage &&
        (!targetQuestionId || a.questionId === targetQuestionId)
    );

    if (!existing) {
      return { success: false, message: 'Lembar penilaian tidak ditemukan.' };
    }

    if (existing.status !== 'finalized') {
      return { success: false, message: 'Lembar penilaian belum berstatus final.' };
    }

    // Execute server RPC FIRST when connected to live database
    if (supabaseDataService.isLive() && connectionInfo.isDatabaseReady && connectionInfo.isAuthenticated) {
      setSyncStatus('Membuka kunci penilaian di server...');
      const rpcRes = await supabaseDataService.reopenJudgeAssessmentRpc(
        toDeterministicUuid(existing.id),
        reason
      );
      if (!rpcRes.success) {
        setSyncStatus('Gagal Membuka Kunci di Database');
        return {
          success: false,
          message: `Pembukaan kembali penilaian di database ditolak: ${rpcRes.message}`
        };
      }
    }

    const nowTime = getWibTime();
    const targetJudge = users.find((u) => u.id === judgeId);

    // Buka kunci lembar penilaian kembali ke status in_progress
    setAssessments((prev) =>
      prev.map((a) =>
        a.id === existing.id
          ? {
              ...a,
              status: 'in_progress',
              isLocked: false,
              reopenedAt: nowTime,
              reopenedBy: `${currentUser.name} (${currentUser.role})`,
              reopenReason: reason,
              lastUpdated: nowTime
            }
          : a
      )
    );

    // Kembalikan status kemajuan babak peserta
    setStageParticipations((prev) =>
      prev.map((sp) =>
        sp.tenantId === currentTenantId &&
        sp.participantId === participantId &&
        sp.stageName === targetStage &&
        sp.status === 'Lengkap'
          ? { ...sp, status: 'Berlangsung' }
          : sp
      )
    );

    // Kembalikan status peserta jika sebelumnya 'Final'
    setParticipants((prev) =>
      prev.map((p) =>
        p.id === participantId && p.tenantId === currentTenantId && p.status === 'Final'
          ? { ...p, status: 'Berlangsung' }
          : p
      )
    );

    // Catat Audit Log Permanen
    const reopenAudit: AuditLogItem = {
      id: generateUniqueLogId('aud'),
      timestamp: nowTime,
      actor: `${currentUser.name} (${currentUser.role})`,
      action: 'ASSESSMENT_REOPENED',
      target: `Peserta ${part.participantId} (${part.name}) - Hakim ${targetJudge?.name || judgeId}`,
      tenantName: currentTenant.name,
      summary: `Pembukaan kembali lembar penilaian final (Skor sebelum koreksi: ${existing.finalScore.toFixed(2)}) pada Babak ${targetStage}.`,
      reason,
      outcome: 'Success'
    };
    setAuditLogs((prev) => [reopenAudit, ...prev]);

    const reopenActivity: ActivityLogItem = {
      id: generateUniqueLogId('act'),
      tenantId: currentTenantId,
      type: 'config',
      title: 'Penilaian Dibuka Kembali',
      description: `Lembar penilaian ${part.name} oleh ${targetJudge?.name || 'Hakim'} dibuka kembali oleh ${currentUser.name}. Alasan: ${reason}`,
      timestamp: nowTime,
      actorName: currentUser.name
    };
    setActivityLogs((prev) => [reopenActivity, ...prev.filter((l) => l.id !== reopenActivity.id).slice(0, 20)]);

    setSyncStatus(
      supabaseDataService.isLive()
        ? supabaseDataService.getConnectionStatus().statusLabel
        : 'Mode Lokal (Tersimpan di Browser)'
    );
    setLastSyncTime(nowTime);

    return {
      success: true,
      message: `Lembar penilaian berhasil dibuka kembali untuk koreksi. Hakim terkait sekarang dapat mengedit nilai.`
    };
  };

  // Kafilah Actions (Tenant Scoped)
  const addKafilah = (data: Omit<Kafilah, 'id' | 'tenantId'>) => {
    const newKafilah: Kafilah = {
      ...data,
      id: generateUuid(),
      tenantId: currentTenantId
    };
    setKafilahs((prev) => [...prev, newKafilah]);
    if (isLiveDbActive) {
      setSyncStatus('Menyimpan kafilah ke database...');
      void supabaseDataService
        .upsertKafilah({
          ...newKafilah,
          tenantId: toDeterministicUuid(currentTenantId)
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menyimpan Kafilah: ${res.message}`);
            setKafilahs((prev) => prev.filter((k) => k.id !== newKafilah.id));
          } else {
            setSyncStatus('Kafilah Tersimpan di Database');
            setLastSyncTime(getWibTime());
          }
        });
    }
  };

  const updateKafilah = (id: string, updated: Partial<Kafilah>) => {
    const existing = kafilahs.find((k) => k.id === id && k.tenantId === currentTenantId);
    if (!existing) return;
    const merged: Kafilah = { ...existing, ...updated };

    setKafilahs((prev) =>
      prev.map((k) => (k.id === id && k.tenantId === currentTenantId ? merged : k))
    );
    if (updated.name) {
      setParticipants((prev) =>
        prev.map((p) =>
          p.kafilahId === id && p.tenantId === currentTenantId
            ? { ...p, kafilahName: updated.name! }
            : p
        )
      );
    }

    if (isLiveDbActive) {
      setSyncStatus('Memperbarui kafilah di database...');
      void supabaseDataService
        .upsertKafilah({
          ...merged,
          id: toDeterministicUuid(merged.id),
          tenantId: toDeterministicUuid(currentTenantId)
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Memperbarui Kafilah: ${res.message}`);
            setKafilahs((prev) =>
              prev.map((k) => (k.id === id && k.tenantId === currentTenantId ? existing : k))
            );
          } else {
            setSyncStatus('Kafilah Diperbarui di Database');
            setLastSyncTime(getWibTime());
          }
        });
    }
  };

  const deleteKafilah = (id: string): { success: boolean; message: string } => {
    const existing = kafilahs.find((k) => k.id === id && k.tenantId === currentTenantId);
    if (!existing) {
      return { success: false, message: 'Grup/Kafilah tidak ditemukan.' };
    }
    const activeMembers = participants.filter(
      (p) => p.tenantId === currentTenantId && p.kafilahId === id
    ).length;
    if (activeMembers > 0) {
      return {
        success: false,
        message: `Grup "${existing.name}" masih memiliki ${activeMembers} peserta terdaftar. Hapus atau pindahkan peserta terlebih dahulu sebelum menghapus grup.`
      };
    }

    setKafilahs((prev) => prev.filter((k) => !(k.id === id && k.tenantId === currentTenantId)));

    if (isLiveDbActive) {
      setSyncStatus('Menghapus kafilah dari database...');
      void supabaseDataService
        .deleteKafilah(toDeterministicUuid(currentTenantId), toDeterministicUuid(id))
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menghapus Kafilah: ${res.message}`);
            setKafilahs((prev) => [...prev, existing]);
          } else {
            setSyncStatus('Kafilah Dihapus dari Database');
            setLastSyncTime(getWibTime());
          }
        });
    }

    return {
      success: true,
      message: `Grup "${existing.name}" berhasil dihapus.`
    };
  };

  // Participant Actions (Tenant Scoped)
  const addParticipant = (data: Omit<Participant, 'id' | 'tenantId'>): { success: boolean; message: string } => {
    const idTrimmed = (data.participantId || '').trim();
    if (idTrimmed) {
      const existingId = participants.find(
        (p) => p.tenantId === currentTenantId && p.participantId.trim().toLowerCase() === idTrimmed.toLowerCase()
      );
      if (existingId) {
        return {
          success: false,
          message: `ID Peserta "${data.participantId}" sudah terdaftar atas nama ${existingId.name}.`
        };
      }
    }

    const lotteryTrimmed = (data.lotteryNumber || '').trim();
    if (lotteryTrimmed) {
      const existingLottery = participants.find(
        (p) =>
          p.tenantId === currentTenantId &&
          p.branchName === data.branchName &&
          p.lotteryNumber.trim().toLowerCase() === lotteryTrimmed.toLowerCase()
      );
      if (existingLottery) {
        return {
          success: false,
          message: `Nomor undian "${data.lotteryNumber}" sudah digunakan oleh peserta ${existingLottery.name} pada cabang ${data.branchName}.`
        };
      }
    }

    const newPartId = generateUuid();
    const targetStage = data.stageName || 'Penyisihan';
    const targetStageObj = stages.find(
      (s) => s.tenantId === currentTenantId && s.name === targetStage
    );
    const stageId = targetStageObj?.id || toDeterministicUuid('stage-penyisihan');
    const matchedBranch = cabangList.find(
      (c) => c.name === data.branchName || data.branchName.includes(c.name)
    );
    const branchId = data.branchId || matchedBranch?.id || toDeterministicUuid(data.branchName);

    const hasQuestion = Boolean(data.questionId && data.questionId.trim() !== '');

    const newPart: Participant = {
      ...data,
      id: newPartId,
      tenantId: currentTenantId,
      branchId,
      verificationStatus: data.verificationStatus || 'Diajukan',
      questionId: hasQuestion ? data.questionId : '',
      assignedMaqra: hasQuestion ? data.assignedMaqra : 'Belum Ditetapkan',
      pageNumber: hasQuestion ? data.pageNumber : 1,
      assignedQuestions: data.assignedQuestions || [],
      questionIds: data.questionIds || (hasQuestion ? [data.questionId] : []),
      stageHistory: [
        {
          stageId,
          stageName: targetStage,
          status: 'Menunggu'
        }
      ]
    };

    const newParticipation: StageParticipation = {
      id: generateUuid(),
      tenantId: currentTenantId,
      participantId: newPartId,
      stageId,
      stageName: targetStage,
      branchId,
      branchName: data.branchName,
      lotteryNumber: data.lotteryNumber,
      questionId: hasQuestion ? data.questionId : '',
      assignedMaqra: hasQuestion ? data.assignedMaqra : 'Belum Ditetapkan',
      pageNumber: hasQuestion ? data.pageNumber : 1,
      assignedQuestions: data.assignedQuestions || [],
      status: hasQuestion ? 'Belum Dimulai' : 'Maqra Belum Ditetapkan'
    };

    setParticipants((prev) => [...prev, newPart]);
    setStageParticipations((prev) => [...prev, newParticipation]);

    if (isLiveDbActive) {
      setSyncStatus('Menyimpan peserta ke database...');
      const matchedLevel = jenjangList.find((j) => j.name === data.levelName);
      void supabaseDataService
        .upsertParticipantWithStage({
          participant: {
            ...newPart,
            tenantId: toDeterministicUuid(currentTenantId),
            kafilahId: toDeterministicUuid(newPart.kafilahId),
            branchId: toDeterministicUuid(branchId)
          },
          stageParticipation: {
            ...newParticipation,
            tenantId: toDeterministicUuid(currentTenantId),
            stageId: toDeterministicUuid(stageId)
          },
          levelId: matchedLevel?.id ? toDeterministicUuid(matchedLevel.id) : null,
          autoCreateMissingMaster: true
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menyimpan Peserta: ${res.message}`);
            setParticipants((prev) => prev.filter((p) => p.id !== newPartId));
            setStageParticipations((prev) => prev.filter((sp) => sp.id !== newParticipation.id));
          } else {
            setSyncStatus('Peserta Tersimpan di Database');
            setLastSyncTime(getWibTime());
          }
        });
    }

    setKafilahs((prev) =>
      prev.map((k) =>
        k.id === data.kafilahId && k.tenantId === currentTenantId
          ? { ...k, participantCount: k.participantCount + 1 }
          : k
      )
    );

    const newLog: ActivityLogItem = {
      id: generateUniqueLogId('act'),
      tenantId: currentTenantId,
      type: 'config',
      title: 'Pendaftaran Peserta',
      description: `Pendaftaran peserta ${newPart.participantId} (${newPart.name}) pada cabang ${newPart.branchName}.`,
      timestamp: getWibTime(),
      actorName: currentUser.name
    };
    setActivityLogs((prev) => [newLog, ...prev.filter((l) => l.id !== newLog.id).slice(0, 20)]);

    return {
      success: true,
      message: `Peserta "${newPart.name}" (${newPart.participantId}) berhasil didaftarkan.`
    };
  };

  const updateParticipant = (
    id: string,
    updated: Partial<Participant>
  ): { success: boolean; message: string } => {
    const existing = participants.find((p) => p.id === id && p.tenantId === currentTenantId);
    if (!existing) {
      return { success: false, message: 'Peserta tidak ditemukan.' };
    }

    const nextParticipantId = (updated.participantId ?? existing.participantId).trim();
    const nextBranchName = (updated.branchName ?? existing.branchName).trim();
    const nextLotteryNumber = (updated.lotteryNumber ?? existing.lotteryNumber).trim();
    const nextStageName = (updated.stageName ?? existing.stageName).trim();

    // P1-01: Prevent duplicate participant code (participantId) across tenant
    const duplicateCode = participants.find(
      (p) =>
        p.tenantId === currentTenantId &&
        p.id !== id &&
        p.participantId.trim().toLowerCase() === nextParticipantId.toLowerCase()
    );
    if (duplicateCode) {
      return {
        success: false,
        message: `Nomor peserta "${nextParticipantId}" sudah terdaftar atas nama ${duplicateCode.name} (${duplicateCode.branchName}).`
      };
    }

    // P1-01: Prevent duplicate lottery number within the same branch
    const duplicateLottery = participants.find(
      (p) =>
        p.tenantId === currentTenantId &&
        p.id !== id &&
        p.branchName === nextBranchName &&
        p.lotteryNumber.trim().toLowerCase() === nextLotteryNumber.toLowerCase()
    );
    if (duplicateLottery) {
      return {
        success: false,
        message: `Nomor undian "${nextLotteryNumber}" sudah digunakan oleh ${duplicateLottery.name} pada cabang ${nextBranchName}.`
      };
    }

    const matchedBranch = cabangList.find(
      (c) =>
        (updated.branchId && c.id === updated.branchId) ||
        c.name === nextBranchName ||
        nextBranchName.includes(c.name)
    );
    const resolvedBranchId =
      updated.branchId ||
      (updated.branchName && updated.branchName !== existing.branchName
        ? matchedBranch?.id || toDeterministicUuid(`branch-${currentTenantId}-${nextBranchName}`)
        : existing.branchId || matchedBranch?.id || toDeterministicUuid(`branch-${currentTenantId}-${nextBranchName}`));

    const matchedStage =
      stages.find(
        (s) =>
          s.tenantId === currentTenantId &&
          (updated.stageId ? s.id === updated.stageId : s.name === nextStageName) &&
          (s.branchId === resolvedBranchId || s.branchName === nextBranchName)
      ) ||
      stages.find(
        (s) =>
          s.tenantId === currentTenantId &&
          (updated.stageId ? s.id === updated.stageId : s.name === nextStageName) &&
          (!s.branchName || s.branchName === 'Semua Cabang')
      ) ||
      stages.find((s) => s.tenantId === currentTenantId && s.name === nextStageName);

    const resolvedStageId =
      updated.stageId ||
      (updated.stageName && updated.stageName !== existing.stageName
        ? matchedStage?.id || toDeterministicUuid(`stage-${currentTenantId}-${resolvedBranchId}-${nextStageName}`)
        : existing.stageId || matchedStage?.id || toDeterministicUuid(`stage-${currentTenantId}-${resolvedBranchId}-${nextStageName}`));

    const merged: Participant = {
      ...existing,
      ...updated,
      participantId: nextParticipantId,
      branchId: resolvedBranchId,
      branchName: nextBranchName,
      stageId: resolvedStageId,
      stageName: nextStageName,
      lotteryNumber: nextLotteryNumber
    };

    setParticipants((prev) =>
      prev.map((p) => (p.id === id && p.tenantId === currentTenantId ? merged : p))
    );

    // P1-01: Sync all relational attributes (stageId, stageName, branchId, branchName, lotteryNumber, assignedMaqra, pageNumber) to stage participation
    setStageParticipations((prev) =>
      prev.map((sp) => {
        if (
          sp.participantId === id &&
          sp.tenantId === currentTenantId &&
          (sp.stageId === existing.stageId || sp.stageName === existing.stageName)
        ) {
          return {
            ...sp,
            stageId: resolvedStageId,
            stageName: nextStageName,
            branchId: resolvedBranchId,
            branchName: nextBranchName,
            lotteryNumber: merged.lotteryNumber,
            assignedMaqra: updated.assignedMaqra !== undefined ? updated.assignedMaqra : sp.assignedMaqra,
            pageNumber: updated.pageNumber !== undefined ? updated.pageNumber : sp.pageNumber
          };
        }
        return sp;
      })
    );

    if (isLiveDbActive) {
      setSyncStatus('Memperbarui peserta di database...');
      const matchedLevel = jenjangList.find((j) => j.name === merged.levelName);
      void supabaseDataService
        .updateParticipantRecord(
          {
            ...merged,
            id: toDeterministicUuid(merged.id),
            tenantId: toDeterministicUuid(currentTenantId),
            kafilahId: toDeterministicUuid(merged.kafilahId),
            branchId: toDeterministicUuid(resolvedBranchId)
          },
          toDeterministicUuid(resolvedBranchId),
          matchedLevel?.id ? toDeterministicUuid(matchedLevel.id) : undefined
        )
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Memperbarui Peserta: ${res.message}`);
            setParticipants((prev) =>
              prev.map((p) => (p.id === id && p.tenantId === currentTenantId ? existing : p))
            );
          } else {
            setSyncStatus('Data Peserta Diperbarui di Database');
            setLastSyncTime(getWibTime());
          }
        });
    }

    return {
      success: true,
      message: `Data peserta "${merged.name}" (${merged.participantId}) berhasil diperbarui.`
    };
  };

  const deleteParticipant = (id: string): { success: boolean; message: string } => {
    const existing = participants.find((p) => p.id === id && p.tenantId === currentTenantId);
    if (!existing) {
      return { success: false, message: 'Peserta tidak ditemukan.' };
    }

    const hasFinalizedAssessment = assessments.some(
      (a) => a.tenantId === currentTenantId && a.participantId === id && a.status === 'finalized'
    );
    if (hasFinalizedAssessment || existing.status === 'Final') {
      return {
        success: false,
        message: `Peserta "${existing.name}" (${existing.participantId}) sudah memiliki lembar penilaian final dan tidak dapat dihapus.`
      };
    }

    const existingSps = stageParticipations.filter(
      (sp) => sp.tenantId === currentTenantId && sp.participantId === id
    );
    const existingAss = assessments.filter(
      (a) => a.tenantId === currentTenantId && a.participantId === id
    );

    setParticipants((prev) => prev.filter((p) => !(p.id === id && p.tenantId === currentTenantId)));
    setStageParticipations((prev) =>
      prev.filter((sp) => !(sp.participantId === id && sp.tenantId === currentTenantId))
    );
    setAssessments((prev) =>
      prev.filter((a) => !(a.participantId === id && a.tenantId === currentTenantId))
    );
    setKafilahs((prev) =>
      prev.map((k) =>
        k.id === existing.kafilahId && k.tenantId === currentTenantId
          ? { ...k, participantCount: Math.max(0, k.participantCount - 1) }
          : k
      )
    );

    if (isLiveDbActive) {
      setSyncStatus('Menghapus peserta dari database...');
      void supabaseDataService
        .deleteParticipant(toDeterministicUuid(currentTenantId), toDeterministicUuid(id))
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menghapus Peserta: ${res.message}`);
            setParticipants((prev) => [...prev, existing]);
            setStageParticipations((prev) => [...prev, ...existingSps]);
            setAssessments((prev) => [...prev, ...existingAss]);
            setKafilahs((prev) =>
              prev.map((k) =>
                k.id === existing.kafilahId && k.tenantId === currentTenantId
                  ? { ...k, participantCount: k.participantCount + 1 }
                  : k
              )
            );
          } else {
            setSyncStatus('Peserta Dihapus dari Database');
            setLastSyncTime(getWibTime());
          }
        });
    }

    return {
      success: true,
      message: `Peserta "${existing.name}" (${existing.participantId}) berhasil dihapus.`
    };
  };

  const verifyParticipant = async (
    participantId: string,
    status: 'Diajukan' | 'Diverifikasi' | 'Ditolak',
    note?: string
  ): Promise<{ success: boolean; message: string }> => {
    const existing = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    if (!existing) {
      return { success: false, message: 'Peserta tidak ditemukan.' };
    }

    if (status === 'Ditolak' && (!note || note.trim().length < 5)) {
      return {
        success: false,
        message: 'Alasan penolakan berkas wajib diisi minimal 5 karakter.'
      };
    }

    const nowIso = new Date().toISOString();
    const updatedPart: Participant = {
      ...existing,
      verificationStatus: status,
      verificationNote: note?.trim() || undefined,
      verifiedBy: currentUser.id,
      verifiedAt: nowIso
    };

    setParticipants((prev) =>
      prev.map((p) => (p.id === participantId && p.tenantId === currentTenantId ? updatedPart : p))
    );

    if (isLiveDbActive) {
      setSyncStatus('Memperbarui status verifikasi berkas peserta...');
      const res = await supabaseDataService.verifyParticipantRpc({
        tenantId: toDeterministicUuid(currentTenantId),
        participantId: toDeterministicUuid(participantId),
        status,
        note: note?.trim() || null
      });
      if (!res.success) {
        setSyncStatus(`Gagal Verifikasi Peserta: ${res.message}`);
        setParticipants((prev) =>
          prev.map((p) => (p.id === participantId && p.tenantId === currentTenantId ? existing : p))
        );
        return { success: false, message: res.message || 'Gagal memverifikasi peserta di database.' };
      }
      setSyncStatus('Status Verifikasi Peserta Tersimpan di Database');
      setLastSyncTime(getWibTime());
    }

    const nowTime = getWibTime();
    const newLog: ActivityLogItem = {
      id: generateUniqueLogId('act'),
      tenantId: currentTenantId,
      type: 'config',
      title: `Verifikasi Berkas Peserta (${status})`,
      description: `Status verifikasi berkas peserta ${existing.participantId} (${existing.name}) diubah menjadi ${status}${note ? ` — Catatan: ${note}` : ''}.`,
      timestamp: nowTime,
      actorName: currentUser.name
    };
    setActivityLogs((prev) => [newLog, ...prev.filter((l) => l.id !== newLog.id).slice(0, 20)]);

    const auditEntry: AuditLogItem = {
      id: generateUniqueLogId('aud'),
      timestamp: nowTime,
      actor: `${currentUser.name} (${currentUser.role})`,
      action: 'PARTICIPANT_VERIFIED',
      target: `${existing.participantId} - ${existing.name}`,
      tenantName: currentTenant?.name || 'Tenant Aktif',
      summary: `Status verifikasi berkas peserta diubah dari ${existing.verificationStatus || 'Diajukan'} menjadi ${status}.`,
      reason: note?.trim() || undefined,
      outcome: 'Success'
    };
    setAuditLogs((prev) => [auditEntry, ...prev]);

    return {
      success: true,
      message: `Status verifikasi peserta "${existing.name}" berhasil diperbarui menjadi ${status}.`
    };
  };

  // Question & Maqra Actions (Tenant Scoped)
  const addQuestion = (data: Omit<Question, 'id' | 'tenantId'>) => {
    const matchedBranch = cabangList.find(
      (c) =>
        (data.branchId && c.id === data.branchId) ||
        (data.branchName && c.name === data.branchName) ||
        (data.branchAndLevel && (data.branchAndLevel.includes(c.name) || c.name.includes(data.branchAndLevel)))
    );
    const matchedLevel = jenjangList.find(
      (j) =>
        (data.levelId && j.id === data.levelId) ||
        (data.levelName && j.name === data.levelName) ||
        (data.branchAndLevel && data.branchAndLevel.toLowerCase().includes(j.name.toLowerCase()))
    );
    const targetStageName = data.stageName || data.stage || 'Penyisihan';
    const matchedStage =
      stages.find(
        (s) =>
          s.tenantId === currentTenantId &&
          s.name === targetStageName &&
          (s.branchId === (data.branchId || matchedBranch?.id) || s.branchName === (data.branchName || matchedBranch?.name))
      ) ||
      stages.find((s) => s.tenantId === currentTenantId && s.name === targetStageName);
    const resolvedBranchName = data.branchName || matchedBranch?.name || data.branchAndLevel || 'Tilawah Dewasa Putra';
    const resolvedLevelName = data.levelName || matchedLevel?.name || '';
    const computedBranchAndLevel =
      data.branchAndLevel ||
      (resolvedLevelName && !resolvedBranchName.includes(resolvedLevelName)
        ? `${resolvedBranchName} - ${resolvedLevelName}`
        : resolvedBranchName);

    const newQ: Question = {
      ...data,
      id: generateUuid(),
      tenantId: currentTenantId,
      branchId: data.branchId || matchedBranch?.id,
      branchName: resolvedBranchName,
      levelId: data.levelId || matchedLevel?.id,
      levelName: resolvedLevelName || undefined,
      stageId: data.stageId || matchedStage?.id,
      stage: targetStageName,
      stageName: targetStageName,
      branchAndLevel: computedBranchAndLevel
    };
    setQuestions((prev) => [...prev, newQ]);
    if (isLiveDbActive) {
      void supabaseDataService
        .upsertQuestion(
          {
            ...newQ,
            tenantId: toDeterministicUuid(currentTenantId)
          },
          newQ.branchId ? toDeterministicUuid(newQ.branchId) : undefined,
          newQ.stageId ? toDeterministicUuid(newQ.stageId) : undefined,
          newQ.levelId ? toDeterministicUuid(newQ.levelId) : undefined
        )
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menyimpan Soal: ${res.message}`);
            setQuestions((prev) => prev.filter((q) => q.id !== newQ.id));
          } else {
            setSyncStatus('Soal Maqra Tersimpan di Database');
            setLastSyncTime(getWibTime());
          }
        });
    }
  };

  const updateQuestion = (id: string, updated: Partial<Question>) => {
    const existing = questions.find((q) => q.id === id && q.tenantId === currentTenantId);
    if (!existing) return;
    const rawMerged: Question = { ...existing, ...updated };
    const matchedBranch = cabangList.find(
      (c) =>
        (rawMerged.branchId && c.id === rawMerged.branchId) ||
        (rawMerged.branchName && c.name === rawMerged.branchName) ||
        (rawMerged.branchAndLevel && (rawMerged.branchAndLevel.includes(c.name) || c.name.includes(rawMerged.branchAndLevel)))
    );
    const matchedLevel = jenjangList.find(
      (j) =>
        (rawMerged.levelId && j.id === rawMerged.levelId) ||
        (rawMerged.levelName && j.name === rawMerged.levelName)
    );
    const targetStageName = rawMerged.stageName || rawMerged.stage || 'Penyisihan';
    const matchedStage =
      stages.find(
        (s) =>
          s.tenantId === currentTenantId &&
          s.name === targetStageName &&
          (s.branchId === (rawMerged.branchId || matchedBranch?.id) || s.branchName === (rawMerged.branchName || matchedBranch?.name))
      ) ||
      stages.find((s) => s.tenantId === currentTenantId && s.name === targetStageName);
    const merged: Question = {
      ...rawMerged,
      branchId: rawMerged.branchId || matchedBranch?.id,
      branchName: rawMerged.branchName || matchedBranch?.name,
      levelId: rawMerged.levelId || matchedLevel?.id,
      levelName: rawMerged.levelName || matchedLevel?.name,
      stageId: rawMerged.stageId || matchedStage?.id,
      stage: targetStageName,
      stageName: targetStageName
    };
    setQuestions((prev) =>
      prev.map((q) => (q.id === id && q.tenantId === currentTenantId ? merged : q))
    );
    if (isLiveDbActive) {
      void supabaseDataService
        .upsertQuestion(
          {
            ...merged,
            id: toDeterministicUuid(merged.id),
            tenantId: toDeterministicUuid(currentTenantId)
          },
          merged.branchId ? toDeterministicUuid(merged.branchId) : undefined,
          merged.stageId ? toDeterministicUuid(merged.stageId) : undefined,
          merged.levelId ? toDeterministicUuid(merged.levelId) : undefined
        )
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Memperbarui Soal: ${res.message}`);
            setQuestions((prev) =>
              prev.map((q) => (q.id === id && q.tenantId === currentTenantId ? existing : q))
            );
          } else {
            setSyncStatus('Soal Maqra Diperbarui di Database');
            setLastSyncTime(getWibTime());
          }
        });
    }
  };

  const importParticipantsBatch = async (
    rows: ParsedParticipantImportRow[]
  ): Promise<{ total: number; succeeded: number; failed: number; errors: string[] }> => {
    let succeeded = 0;
    let failed = 0;
    const errors: string[] = [];
    const seenCodesInBatch = new Set<string>();
    const seenLotteryByBranchInBatch = new Set<string>();

    for (const row of rows) {
      const normalizedCode = row.participantId.trim().toUpperCase();
      const normalizedLotteryKey = `${row.branchName.trim().toLowerCase()}::${row.lotteryNumber.trim().toLowerCase()}`;

      if (seenCodesInBatch.has(normalizedCode)) {
        failed += 1;
        errors.push(`${row.participantId} (${row.name}): Nomor peserta duplikat di dalam file import yang sama.`);
        continue;
      }
      if (seenLotteryByBranchInBatch.has(normalizedLotteryKey)) {
        failed += 1;
        errors.push(`${row.participantId} (${row.name}): Nomor undian ${row.lotteryNumber} duplikat pada cabang ${row.branchName} di dalam file import.`);
        continue;
      }

      const existingByCode = participants.find(
        (p) =>
          p.tenantId === currentTenantId &&
          p.participantId.trim().toUpperCase() === normalizedCode
      );
      if (existingByCode) {
        const updRes = updateParticipant(existingByCode.id, {
          adminSequenceNumber: row.adminSequenceNumber,
          participantId: row.participantId,
          lotteryNumber: row.lotteryNumber,
          name: row.name,
          fatherName: row.fatherName,
          gender: row.gender,
          originCity: row.originCity,
          originRegion: row.originRegion,
          originInstitution: row.originInstitution,
          kafilahId: row.kafilahId,
          kafilahName: row.kafilahName,
          branchId: row.branchId,
          branchName: row.branchName,
          levelId: row.levelId,
          levelName: row.levelName,
          stageId: row.stageId,
          stageName: row.stageName,
          status: row.status
        });
        if (!updRes.success) {
          failed += 1;
          errors.push(`${row.participantId} (${row.name}): ${updRes.message}`);
          continue;
        }
        seenCodesInBatch.add(normalizedCode);
        seenLotteryByBranchInBatch.add(normalizedLotteryKey);
        succeeded += 1;
      } else {
        const res = addParticipant({
          adminSequenceNumber: row.adminSequenceNumber,
          participantId: row.participantId,
          lotteryNumber: row.lotteryNumber,
          name: row.name,
          fatherName: row.fatherName,
          gender: row.gender,
          originCity: row.originCity,
          originRegion: row.originRegion,
          originInstitution: row.originInstitution,
          kafilahId: row.kafilahId,
          kafilahName: row.kafilahName,
          branchId: row.branchId,
          branchName: row.branchName,
          levelId: row.levelId,
          levelName: row.levelName,
          stageId: row.stageId,
          stageName: row.stageName,
          questionId: '',
          assignedMaqra: 'Belum Ditetapkan',
          pageNumber: 1,
          status: row.status
        });
        if (res.success) {
          seenCodesInBatch.add(normalizedCode);
          seenLotteryByBranchInBatch.add(normalizedLotteryKey);
          succeeded += 1;
        } else {
          failed += 1;
          errors.push(`${row.participantId} (${row.name}): ${res.message}`);
        }
      }
    }

    return { total: rows.length, succeeded, failed, errors };
  };

  const importQuestionsBatch = async (
    rows: ParsedQuestionImportRow[]
  ): Promise<{ total: number; succeeded: number; failed: number; errors: string[] }> => {
    let succeeded = 0;
    let failed = 0;
    const errors: string[] = [];
    const seenQuestionCodes = new Set<string>();

    for (const row of rows) {
      const normalizedCode = row.code.trim().toUpperCase();
      if (seenQuestionCodes.has(normalizedCode)) {
        failed += 1;
        errors.push(`${row.code}: Kode soal duplikat di dalam file import yang sama.`);
        continue;
      }
      try {
        const existingByCode = questions.find(
          (q) =>
            q.tenantId === currentTenantId &&
            q.code.trim().toUpperCase() === normalizedCode
        );
        if (existingByCode) {
          updateQuestion(existingByCode.id, {
            code: row.code,
            title: row.title,
            surahName: row.surahName,
            surahNumber: row.surahNumber,
            startAyah: row.startAyah,
            endAyah: row.endAyah,
            pageNumber: row.pageNumber,
            pageStart: row.pageStart,
            pageEnd: row.pageEnd,
            branchId: row.branchId,
            branchName: row.branchName,
            levelId: row.levelId,
            levelName: row.levelName,
            stageId: row.stageId,
            stage: row.stage,
            stageName: row.stage,
            branchAndLevel: row.branchAndLevel,
            status: row.status,
            description: row.description
          });
        } else {
          addQuestion({
            code: row.code,
            title: row.title,
            surahName: row.surahName,
            surahNumber: row.surahNumber,
            startAyah: row.startAyah,
            endAyah: row.endAyah,
            pageNumber: row.pageNumber,
            pageStart: row.pageStart,
            pageEnd: row.pageEnd,
            branchId: row.branchId,
            branchName: row.branchName,
            levelId: row.levelId,
            levelName: row.levelName,
            stageId: row.stageId,
            stage: row.stage,
            stageName: row.stage,
            branchAndLevel: row.branchAndLevel,
            status: row.status,
            description: row.description
          });
        }
        seenQuestionCodes.add(normalizedCode);
        succeeded += 1;
      } catch (err) {
        failed += 1;
        errors.push(`${row.code}: ${err instanceof Error ? err.message : 'Gagal menyimpan soal'}`);
      }
    }

    return { total: rows.length, succeeded, failed, errors };
  };

  const deleteQuestion = (id: string): { success: boolean; message: string } => {
    const existing = questions.find((q) => q.id === id && q.tenantId === currentTenantId);
    if (!existing) {
      return { success: false, message: 'Paket soal / maqra tidak ditemukan.' };
    }

    const usedInFinalizedAssessment = assessments.some(
      (a) => a.tenantId === currentTenantId && a.questionId === id && a.status === 'finalized'
    );
    if (usedInFinalizedAssessment) {
      return {
        success: false,
        message: `Soal "${existing.code}" tidak dapat dihapus karena telah digunakan pada lembar penilaian yang sudah difinalisasi.`
      };
    }

    setQuestions((prev) => prev.filter((q) => !(q.id === id && q.tenantId === currentTenantId)));

    // Bersihkan penetapan maqra dari peserta jika belum difinalisasi
    setParticipants((prev) =>
      prev.map((p) => {
        if (p.tenantId !== currentTenantId) return p;
        const filteredAq = (p.assignedQuestions || []).filter((aq) => aq.questionId !== id);
        const filteredQIds = (p.questionIds || []).filter((qId) => qId !== id);
        if (p.questionId === id || filteredAq.length !== (p.assignedQuestions || []).length) {
          const nextPrimary = filteredAq[0];
          return {
            ...p,
            questionId: nextPrimary ? nextPrimary.questionId : '',
            assignedMaqra: nextPrimary ? nextPrimary.title : 'Belum Ditetapkan',
            pageNumber: nextPrimary ? nextPrimary.pageNumber : 1,
            assignedQuestions: filteredAq,
            questionIds: filteredQIds
          };
        }
        return p;
      })
    );

    setStageParticipations((prev) =>
      prev.map((sp) => {
        if (sp.tenantId !== currentTenantId) return sp;
        const filteredAq = (sp.assignedQuestions || []).filter((aq) => aq.questionId !== id);
        if (sp.questionId === id || filteredAq.length !== (sp.assignedQuestions || []).length) {
          const nextPrimary = filteredAq[0];
          return {
            ...sp,
            questionId: nextPrimary ? nextPrimary.questionId : '',
            assignedMaqra: nextPrimary ? nextPrimary.title : 'Belum Ditetapkan',
            pageNumber: nextPrimary ? nextPrimary.pageNumber : 1,
            assignedQuestions: filteredAq,
            status: nextPrimary ? sp.status : 'Maqra Belum Ditetapkan'
          };
        }
        return sp;
      })
    );

    if (isLiveDbActive) {
      setSyncStatus('Menghapus paket soal dari database...');
      void supabaseDataService
        .deleteQuestion(toDeterministicUuid(currentTenantId), toDeterministicUuid(id))
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menghapus Soal: ${res.message}`);
            setQuestions((prev) => [...prev, existing]);
          } else {
            setSyncStatus('Paket Soal Dihapus dari Database');
            setLastSyncTime(getWibTime());
          }
        });
    }

    return {
      success: true,
      message: `Paket soal "${existing.code} - ${existing.title}" berhasil dihapus.`
    };
  };

  const assignMaqraToParticipant = (
    participantId: string,
    questionId: string,
    stageName?: string
  ) => {
    addQuestionToParticipant(participantId, questionId, stageName);
  };

  const addQuestionToParticipant = (
    participantId: string,
    questionId: string,
    stageName?: string
  ): { success: boolean; message: string } => {
    const q = questions.find((item) => item.id === questionId && item.tenantId === currentTenantId);
    if (!q) {
      return { success: false, message: 'Soal tidak ditemukan pada tenant ini.' };
    }

    const part = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    if (!part) {
      return { success: false, message: 'Peserta tidak ditemukan pada tenant ini.' };
    }

    const targetStage = stageName || q.stageName || part.stageName || selectedStageName;
    const currentStageQs = getParticipantStageQuestions(participantId, targetStage);
    const validation = validateMaqraAssignmentForParticipant(
      part,
      q,
      targetStage,
      currentStageQs.map((item) => item.questionId)
    );
    if (!validation.valid) {
      return {
        success: false,
        message: validation.reason || 'Soal tidak memenuhi kriteria cabang, jenjang, atau babak peserta.'
      };
    }

    const pageLabel = q.pageStart && q.pageEnd && q.pageStart !== q.pageEnd
      ? `Hal. ${q.pageStart} - ${q.pageEnd}`
      : `Hal. ${q.pageNumber}`;
    const assignedLabel = `${q.title} (${pageLabel})`;

    const maqraRecordId = generateUuid();
    const newMaqraItem: AssignedMaqraItem = {
      id: maqraRecordId,
      questionId: q.id,
      code: q.code,
      title: q.title,
      surahName: q.surahName,
      surahNumber: q.surahNumber,
      startAyah: q.startAyah,
      endAyah: q.endAyah,
      pageNumber: q.pageNumber,
      pageStart: q.pageStart || q.pageNumber,
      pageEnd: q.pageEnd || q.pageNumber,
      pageNumbers: q.pageNumbers || [q.pageNumber],
      assignedAt: getWibTime(),
      stageName: targetStage
    };

    const targetStageObj = stages.find(
      (s) => s.tenantId === currentTenantId && s.name === targetStage
    );
    const existingSp = stageParticipations.find(
      (sp) =>
        sp.tenantId === currentTenantId &&
        sp.participantId === participantId &&
        sp.stageName === targetStage
    );
    const resolvedSp: StageParticipation = existingSp
      ? {
          ...existingSp,
          questionId: q.id,
          assignedMaqra:
            ((existingSp.assignedQuestions || []).filter((item) => item.questionId !== '').length + 1) === 1
              ? assignedLabel
              : `${(existingSp.assignedQuestions || []).filter((item) => item.questionId !== '').length + 1} Maqra Ditetapkan`,
          pageNumber: q.pageNumber,
          assignedQuestions: [
            ...(existingSp.assignedQuestions || []).filter((item) => item.questionId !== ''),
            newMaqraItem
          ],
          status: existingSp.status === 'Maqra Belum Ditetapkan' ? 'Belum Dimulai' : existingSp.status
        }
      : {
          id: generateUuid(),
          tenantId: currentTenantId,
          participantId,
          stageId: targetStageObj?.id || toDeterministicUuid('stage-penyisihan'),
          stageName: targetStage,
          branchId: part.branchId,
          branchName: part.branchName,
          lotteryNumber: part.lotteryNumber,
          questionId: q.id,
          assignedMaqra: assignedLabel,
          pageNumber: q.pageNumber,
          assignedQuestions: [newMaqraItem],
          status: 'Belum Dimulai'
        };

    // Update participant
    setParticipants((prev) =>
      prev.map((p) => {
        if (p.id === participantId && p.tenantId === currentTenantId) {
          const currentList = (p.assignedQuestions || []).filter(
            (item) => item.questionId !== ''
          );
          const updatedList = [...currentList, newMaqraItem];
          const updatedQIds = Array.from(new Set([...(p.questionIds || []), q.id]));

          return {
            ...p,
            questionId: q.id,
            assignedMaqra: updatedList.length === 1 ? assignedLabel : `${updatedList.length} Maqra Ditetapkan`,
            pageNumber: q.pageNumber,
            assignedQuestions: updatedList,
            questionIds: updatedQIds
          };
        }
        return p;
      })
    );

    // Update or create stage participation
    setStageParticipations((prev) => {
      if (existingSp) {
        return prev.map((sp) => (sp.id === existingSp.id ? resolvedSp : sp));
      }
      return [...prev, resolvedSp];
    });

    // Persist assigned_maqra in database and sync returned database row ID
    if (connectionInfo.isDatabaseReady && connectionInfo.isAuthenticated) {
      void supabaseDataService
        .assignMaqraRecord({
          id: maqraRecordId,
          tenantId: toDeterministicUuid(currentTenantId),
          stageParticipationId: toDeterministicUuid(resolvedSp.id),
          questionId: toDeterministicUuid(q.id),
          method: 'manual',
          stageParticipation: resolvedSp,
          participant: part
        })
        .then((res) => {
          const dbMaqraId = res.data?.assignedMaqraId;
          if (res.success && dbMaqraId) {
            setStageParticipations((prev) =>
              prev.map((sp) =>
                sp.id === resolvedSp.id
                  ? {
                      ...sp,
                      assignedQuestions: (sp.assignedQuestions || []).map((aq) =>
                        aq.questionId === q.id ? { ...aq, id: dbMaqraId } : aq
                      )
                    }
                  : sp
              )
            );
            setParticipants((prev) =>
              prev.map((p) =>
                p.id === participantId
                  ? {
                      ...p,
                      assignedQuestions: (p.assignedQuestions || []).map((aq) =>
                        aq.questionId === q.id && aq.stageName === targetStage
                          ? { ...aq, id: dbMaqraId }
                          : aq
                      )
                    }
                  : p
              )
            );
          }
        });
    }

    // Update question assignment tag
    setQuestions((prev) =>
      prev.map((item) => {
        if (item.tenantId !== currentTenantId) return item;
        if (item.id === questionId) {
          const existingIds = item.assignedToParticipantIds || (item.assignedToParticipantId ? [item.assignedToParticipantId] : []);
          return {
            ...item,
            assignedToParticipantId: participantId,
            assignedToParticipantIds: Array.from(new Set([...existingIds, participantId]))
          };
        }
        return item;
      })
    );

    const newLog: ActivityLogItem = {
      id: generateUniqueLogId('act'),
      tenantId: currentTenantId,
      type: 'config',
      title: 'Penetapan Maqra',
      description: `Penetapan ${q.title} untuk peserta ${part.participantId} ${part.name} pada Babak ${targetStage}.`,
      timestamp: getWibTime(),
      actorName: currentUser.name
    };
    setActivityLogs((prev) => [newLog, ...prev.filter((l) => l.id !== newLog.id).slice(0, 20)]);

    return {
      success: true,
      message: `Soal ${q.code} berhasil ditetapkan untuk peserta ${part.name} pada Babak ${targetStage}.`
    };
  };

  const removeQuestionFromParticipant = (
    participantId: string,
    questionId: string,
    stageName?: string
  ) => {
    const part = participants.find((p) => p.id === participantId && p.tenantId === currentTenantId);
    if (!part) return;
    const targetStage = stageName || part.stageName || selectedStageName;
    const targetSp = stageParticipations.find(
      (sp) =>
        sp.tenantId === currentTenantId &&
        sp.participantId === participantId &&
        sp.stageName === targetStage
    );

    setParticipants((prev) =>
      prev.map((p) => {
        if (p.id === participantId && p.tenantId === currentTenantId) {
          // Only remove question that matches questionId AND stageName (if specified)
          const remaining = (p.assignedQuestions || []).filter(
            (item) => !(item.questionId === questionId && (!item.stageName || item.stageName === targetStage))
          );
          const remainingIds = remaining.map((r) => r.questionId);
          const fallback = remaining[0];
          return {
            ...p,
            questionId: fallback ? fallback.questionId : '',
            assignedMaqra: fallback ? fallback.title : 'Belum Ditetapkan',
            pageNumber: fallback ? fallback.pageNumber : 305,
            assignedQuestions: remaining,
            questionIds: remainingIds
          };
        }
        return p;
      })
    );

    setStageParticipations((prev) =>
      prev.map((sp) => {
        if (sp.tenantId === currentTenantId && sp.participantId === participantId && sp.stageName === targetStage) {
          const remaining = (sp.assignedQuestions || []).filter((item) => item.questionId !== questionId);
          const fallback = remaining[0];
          return {
            ...sp,
            questionId: fallback ? fallback.questionId : '',
            assignedMaqra: fallback ? fallback.title : 'Belum Ditetapkan',
            pageNumber: fallback ? fallback.pageNumber : 305,
            assignedQuestions: remaining,
            status: remaining.length === 0 ? ('Maqra Belum Ditetapkan' as ParticipantProgressStatus) : sp.status
          };
        }
        return sp;
      })
    );

    setQuestions((prev) =>
      prev.map((item) => {
        if (item.tenantId !== currentTenantId) return item;
        if (item.id === questionId) {
          const updatedIds = (item.assignedToParticipantIds || []).filter((pid) => pid !== participantId);
          return {
            ...item,
            assignedToParticipantId: updatedIds[0] || undefined,
            assignedToParticipantIds: updatedIds
          };
        }
        return item;
      })
    );

    if (isLiveDbActive && targetSp) {
      setSyncStatus('Melepas penetapan maqra di database...');
      void supabaseDataService
        .unassignMaqraRecord({
          tenantId: toDeterministicUuid(currentTenantId),
          stageParticipationId: toDeterministicUuid(targetSp.id),
          questionId: toDeterministicUuid(questionId)
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Melepas Maqra: ${res.message}`);
            void refreshSupabaseConnection();
          } else {
            setSyncStatus('Penetapan Maqra Dilepas di Database');
            setLastSyncTime(getWibTime());
          }
        });
    }
  };

  const commitLotteryDrawResults = (
    results: {
      participantId: string;
      participantName: string;
      questionIds: string[];
      questionTitles: string[];
    }[],
    stageName: string,
    metadata?: {
      branchName?: string;
      levelName?: string;
      questionPoolIds?: string[];
      questionsPerParticipant?: number;
      notes?: string;
    }
  ): { success: boolean; message: string; drawLog?: LotteryDrawLogItem } => {
    if (!results || results.length === 0) {
      return { success: false, message: 'Tidak ada hasil undian untuk ditetapkan.' };
    }

    // 1. P0-03 & Fase 3: Strict validation across entire batch (Verification status, Stage lock, Active status, Branch, Level)
    const targetIdsSet = new Set(results.map((r) => r.participantId));
    const hasStartedAssessments = assessments.some(
      (a) =>
        a.tenantId === currentTenantId &&
        a.stageName === stageName &&
        targetIdsSet.has(a.participantId)
    );
    if (hasStartedAssessments) {
      return {
        success: false,
        message: `STAGE_ASSESSMENTS_ALREADY_STARTED: Undian pada Babak ${stageName} telah dikunci karena penilaian dewan hakim sudah berjalan.`
      };
    }

    for (const r of results) {
      const part = participants.find((p) => p.id === r.participantId && p.tenantId === currentTenantId);
      if (!part) {
        return {
          success: false,
          message: `Transaksi dibatalkan: Peserta "${r.participantName}" tidak ditemukan di tenant aktif.`
        };
      }
      if (part.verificationStatus && part.verificationStatus !== 'Diverifikasi') {
        return {
          success: false,
          message: `PARTICIPANT_NOT_VERIFIED: Peserta "${part.name}" belum diverifikasi berkasnya (status: ${part.verificationStatus}).`
        };
      }
      const assignedInThisResult: string[] = [];
      for (const qId of r.questionIds) {
        const q = questions.find((item) => item.id === qId && item.tenantId === currentTenantId);
        if (!q) {
          return {
            success: false,
            message: `Transaksi dibatalkan: Soal dengan ID "${qId}" tidak ditemukan di tenant aktif.`
          };
        }
        const validation = validateMaqraAssignmentForParticipant(
          part,
          q,
          stageName,
          assignedInThisResult
        );
        if (!validation.valid) {
          return {
            success: false,
            message: `Transaksi dibatalkan untuk ${part.name}: ${validation.reason}`
          };
        }
        assignedInThisResult.push(q.id);
      }
    }

    const nowTime = getWibTime();
    const targetStageObj = stages.find((s) => s.tenantId === currentTenantId && s.name === stageName);
    const stageId = targetStageObj?.id || 'stage-penyisihan';

    // Map of participantId -> AssignedMaqraItem[] to add
    const itemsByParticipant: Record<string, AssignedMaqraItem[]> = {};
    const questionToParticipantsMap: Record<string, string[]> = {};
    const drawResultsAudit: LotteryDrawResultItem[] = [];

    results.forEach((r) => {
      itemsByParticipant[r.participantId] = [];
      const partObj = participants.find((p) => p.id === r.participantId && p.tenantId === currentTenantId)!;
      const assignedCodes: string[] = [];

      r.questionIds.forEach((qId) => {
        const q = questions.find((item) => item.id === qId && item.tenantId === currentTenantId)!;
        assignedCodes.push(q.code);
        const newMaqraItem: AssignedMaqraItem = {
          id: generateUuid(),
          questionId: q.id,
          code: q.code,
          title: q.title,
          surahName: q.surahName,
          surahNumber: q.surahNumber,
          startAyah: q.startAyah,
          endAyah: q.endAyah,
          pageNumber: q.pageNumber,
          pageStart: q.pageStart || q.pageNumber,
          pageEnd: q.pageEnd || q.pageNumber,
          pageNumbers: q.pageNumbers || [q.pageNumber],
          assignedAt: nowTime,
          stageName
        };
        itemsByParticipant[r.participantId].push(newMaqraItem);

        if (!questionToParticipantsMap[qId]) {
          questionToParticipantsMap[qId] = [];
        }
        questionToParticipantsMap[qId].push(r.participantId);
      });

      drawResultsAudit.push({
        participantId: partObj.id,
        participantCode: partObj.participantId,
        participantName: partObj.name,
        lotteryNumber: partObj.lotteryNumber,
        assignedQuestionIds: r.questionIds,
        assignedQuestionCodes: assignedCodes
      });
    });

    // 2. Atomic Participants Update (Replace stage questions cleanly on re-draw)
    setParticipants((prev) =>
      prev.map((p) => {
        if (p.tenantId === currentTenantId && itemsByParticipant[p.id]) {
          const newItems = itemsByParticipant[p.id];
          const otherStageItems = (p.assignedQuestions || []).filter(
            (item) => item.questionId !== '' && item.stageName && item.stageName !== stageName
          );
          const combined = [...otherStageItems, ...newItems];
          const combinedQIds = Array.from(new Set(combined.map((n) => n.questionId)));
          const lastItem = newItems[newItems.length - 1] || combined[combined.length - 1];
          return {
            ...p,
            questionId: lastItem ? lastItem.questionId : '',
            assignedMaqra: newItems.length === 1 ? newItems[0].title : `${newItems.length} Maqra Ditetapkan`,
            pageNumber: lastItem ? lastItem.pageNumber : 1,
            assignedQuestions: combined,
            questionIds: combinedQIds
          };
        }
        return p;
      })
    );

    // 3. Atomic StageParticipations Update
    const resolvedSpByParticipant: Record<string, StageParticipation> = {};
    setStageParticipations((prev) => {
      const updated = prev.map((sp) => {
        if (sp.tenantId === currentTenantId && sp.stageName === stageName && itemsByParticipant[sp.participantId]) {
          const newItems = itemsByParticipant[sp.participantId];
          const lastItem = newItems[newItems.length - 1];
          const updatedSp: StageParticipation = {
            ...sp,
            questionId: lastItem ? lastItem.questionId : '',
            assignedMaqra: newItems.length === 1 ? newItems[0].title : `${newItems.length} Maqra Ditetapkan`,
            pageNumber: lastItem ? lastItem.pageNumber : 1,
            assignedQuestions: newItems,
            status: sp.status === 'Maqra Belum Ditetapkan' ? ('Belum Dimulai' as ParticipantProgressStatus) : sp.status
          };
          resolvedSpByParticipant[sp.participantId] = updatedSp;
          return updatedSp;
        }
        return sp;
      });

      results.forEach((r) => {
        const hasSp = updated.some(
          (sp) => sp.tenantId === currentTenantId && sp.stageName === stageName && sp.participantId === r.participantId
        );
        if (!hasSp) {
          const part = participants.find((p) => p.id === r.participantId && p.tenantId === currentTenantId);
          if (part) {
            const newItems = itemsByParticipant[r.participantId] || [];
            const lastItem = newItems[newItems.length - 1];
            const createdSp: StageParticipation = {
              id: generateUuid(),
              tenantId: currentTenantId,
              participantId: r.participantId,
              stageId,
              stageName,
              branchId: part.branchId,
              branchName: part.branchName,
              lotteryNumber: part.lotteryNumber,
              questionId: lastItem ? lastItem.questionId : '',
              assignedMaqra: newItems.length === 1 ? newItems[0].title : `${newItems.length} Maqra Ditetapkan`,
              pageNumber: lastItem ? lastItem.pageNumber : 1,
              assignedQuestions: newItems,
              status: 'Belum Dimulai'
            };
            resolvedSpByParticipant[r.participantId] = createdSp;
            updated.push(createdSp);
          }
        }
      });

      stageParticipationsRef.current = updated;
      return updated;
    });

    // 4. Resolve branch and level metadata for atomic RPC and audit logging
    const firstPart = participants.find((p) => p.id === results[0]?.participantId && p.tenantId === currentTenantId);
    const resolvedBranchName = metadata?.branchName || firstPart?.branchName || 'Semua Cabang';
    const resolvedLevelName = metadata?.levelName || firstPart?.levelName || undefined;
    const matchedBranchObj = cabangList.find((c) => c.name === resolvedBranchName);
    const matchedLevelObj = resolvedLevelName ? jenjangList.find((j) => j.name === resolvedLevelName) : undefined;

    // Persist assigned_maqras atomically to live database if connected via commit_lottery_draw RPC (P0-04)
    if (connectionInfo.isDatabaseReady && connectionInfo.isAuthenticated) {
      void supabaseDataService
        .commitLotteryDrawRpc({
          tenantId: toDeterministicUuid(currentTenantId),
          stageId: toDeterministicUuid(stageId),
          stageName,
          branchId: matchedBranchObj ? toDeterministicUuid(matchedBranchObj.id) : null,
          branchName: resolvedBranchName !== 'Semua Cabang' ? resolvedBranchName : null,
          levelId: matchedLevelObj ? toDeterministicUuid(matchedLevelObj.id) : null,
          levelName: resolvedLevelName || null,
          actorId: authenticatedProfile?.authUserId || null,
          actorName: currentUser.name || 'Administrator MTQ',
          results: results.map((r) => ({
            participantId: toDeterministicUuid(r.participantId),
            questionIds: r.questionIds.map((qid) => toDeterministicUuid(qid))
          })),
          questionsPerParticipant: metadata?.questionsPerParticipant || results[0]?.questionIds.length || 1,
          notes: metadata?.notes || null
        })
        .then((res) => {
          if (!res.success) {
            console.warn('[commitLotteryDraw] commit_lottery_draw RPC fallback:', res.message);
            // Fallback per-record sync
            results.forEach((r) => {
              const part = participants.find((p) => p.id === r.participantId && p.tenantId === currentTenantId);
              const sp =
                resolvedSpByParticipant[r.participantId] ||
                stageParticipationsRef.current.find(
                  (item) =>
                    item.tenantId === currentTenantId &&
                    item.stageName === stageName &&
                    item.participantId === r.participantId
                );
              const newItems = itemsByParticipant[r.participantId] || [];
              if (part && sp) {
                newItems.forEach((maqraItem) => {
                  void supabaseDataService.assignMaqraRecord({
                    id: maqraItem.id || generateUuid(),
                    tenantId: toDeterministicUuid(currentTenantId),
                    stageParticipationId: toDeterministicUuid(sp.id),
                    questionId: toDeterministicUuid(maqraItem.questionId),
                    method: 'undian',
                    stageParticipation: sp,
                    participant: part
                  });
                });
              }
            });
          }
        });
    }

    // 4. Atomic Questions Update
    setQuestions((prev) =>
      prev.map((q) => {
        if (q.tenantId === currentTenantId && questionToParticipantsMap[q.id]) {
          const newPIds = questionToParticipantsMap[q.id];
          const existingIds = q.assignedToParticipantIds || (q.assignedToParticipantId ? [q.assignedToParticipantId] : []);
          const merged = Array.from(new Set([...existingIds, ...newPIds]));
          return {
            ...q,
            assignedToParticipantId: merged[0] || undefined,
            assignedToParticipantIds: merged
          };
        }
        return q;
      })
    );

    // 5. Record Lottery Draw Audit Log (Riwayat Undian Maqra)
    const prevDrawsCount = lotteryDrawLogs.filter(
      (l) => l.tenantId === currentTenantId && l.stageName === stageName && l.branchName === resolvedBranchName
    ).length;

    const drawLogEntry: LotteryDrawLogItem = {
      id: generateUuid(),
      tenantId: currentTenantId,
      stageId: targetStageObj?.id,
      stageName,
      branchId: matchedBranchObj?.id,
      branchName: resolvedBranchName,
      levelId: matchedLevelObj?.id,
      levelName: resolvedLevelName,
      actorId: currentUser.id,
      actorName: `${currentUser.name} (${currentUser.role})`,
      questionsPerParticipant: metadata?.questionsPerParticipant || results[0]?.questionIds.length || 1,
      participantIds: results.map((r) => r.participantId),
      questionPoolIds:
        metadata?.questionPoolIds ||
        Array.from(new Set(results.flatMap((r) => r.questionIds))),
      drawResults: drawResultsAudit,
      drawVersion: prevDrawsCount + 1,
      notes: metadata?.notes,
      createdAt: new Date().toISOString()
    };

    setLotteryDrawLogs((prev) => [drawLogEntry, ...prev]);

    if (isLiveDbActive) {
      const drawLogPayload = {
        ...drawLogEntry,
        tenantId: toDeterministicUuid(currentTenantId)
      };
      void supabaseDataService
        .insertLotteryDrawLog(drawLogPayload)
        .then((res) => {
          if (!res.success) {
            void outboxSyncService.enqueueOperation({
              idempotencyKey: `lottery-draw-${drawLogEntry.id}`,
              tenantId: currentTenantId,
              operationType: 'COMMIT_LOTTERY_DRAW',
              entityLabel: `Undian Maqra ${stageName} (${resolvedBranchName})`,
              payload: { drawLog: drawLogPayload },
              errorMessage: res.message
            });
          } else {
            void outboxSyncService.markSynced(`lottery-draw-${drawLogEntry.id}`);
          }
        })
        .catch((err) => {
          void outboxSyncService.enqueueOperation({
            idempotencyKey: `lottery-draw-${drawLogEntry.id}`,
            tenantId: currentTenantId,
            operationType: 'COMMIT_LOTTERY_DRAW',
            entityLabel: `Undian Maqra ${stageName} (${resolvedBranchName})`,
            payload: { drawLog: drawLogPayload },
            errorMessage: err instanceof Error ? err.message : 'Kesalahan jaringan'
          });
        });
    }

    // 6. Single Consolidated Activity Log & Audit Log
    const newLog: ActivityLogItem = {
      id: generateUniqueLogId('act'),
      tenantId: currentTenantId,
      type: 'config',
      title: `Penetapan Hasil Undian (Versi #${drawLogEntry.drawVersion})`,
      description: `Penetapan hasil undian maqra untuk ${results.length} peserta pada Babak ${stageName} (${resolvedBranchName}) berhasil disimpan secara permanen.`,
      timestamp: nowTime,
      actorName: currentUser.name
    };
    setActivityLogs((prev) => [newLog, ...prev.filter((l) => l.id !== newLog.id).slice(0, 20)]);

    const auditEntry: AuditLogItem = {
      id: generateUniqueLogId('aud'),
      timestamp: nowTime,
      actor: `${currentUser.name} (${currentUser.role})`,
      action: 'MAQRA_LOTTERY_COMMITTED',
      target: `Babak ${stageName} - ${resolvedBranchName} (Undian #${drawLogEntry.drawVersion})`,
      tenantName: currentTenant?.name || 'Tenant Aktif',
      summary: `Penetapan undian maqra untuk ${results.length} peserta (${drawLogEntry.questionsPerParticipant} soal/peserta) dari pool ${drawLogEntry.questionPoolIds.length} soal.`,
      outcome: 'Success'
    };
    setAuditLogs((prev) => [auditEntry, ...prev]);

    return {
      success: true,
      message: `Berhasil menetapkan maqra untuk ${results.length} peserta pada Babak ${stageName} (Undian #${drawLogEntry.drawVersion}).`,
      drawLog: drawLogEntry
    };
  };

  const conductLotteryDraw = (options: {
    stageName: string;
    branchName?: string;
    levelName?: string;
    participantIds: string[];
    questionPoolIds?: string[];
    questionsPerParticipant: number;
    notes?: string;
    predefinedResults?: {
      participantId: string;
      participantName: string;
      questionIds: string[];
      questionTitles: string[];
    }[];
  }) => {
    const {
      stageName,
      branchName,
      levelName,
      participantIds,
      questionPoolIds,
      questionsPerParticipant,
      notes,
      predefinedResults
    } = options;

    if (predefinedResults && predefinedResults.length > 0) {
      return commitLotteryDrawResults(predefinedResults, stageName, {
        branchName,
        levelName,
        questionPoolIds,
        questionsPerParticipant,
        notes
      });
    }

    const targetParticipants = participants.filter(
      (p) => participantIds.includes(p.id) && p.tenantId === currentTenantId
    );

    if (targetParticipants.length === 0) {
      return {
        success: false,
        message: 'Tidak ada peserta yang dipilih untuk diundi.'
      };
    }

    const explicitPoolSet =
      questionPoolIds && questionPoolIds.length > 0 ? new Set(questionPoolIds) : null;

    // P0-03: Validate per-participant eligibility using 3D relational check (Branch + Level + Stage)
    for (const part of targetParticipants) {
      const partEligibleQuestions = questions.filter((q) => {
        if (q.tenantId !== currentTenantId) return false;
        if (explicitPoolSet && !explicitPoolSet.has(q.id)) return false;
        return validateMaqraAssignmentForParticipant(part, q, stageName, []).valid;
      });

      if (partEligibleQuestions.length < questionsPerParticipant) {
        return {
          success: false,
          message: `Pool soal aktif yang dipilih tidak mencukupi untuk peserta ${part.name} (${part.branchName}${part.levelName ? ` - ${part.levelName}` : ''}). Dibutuhkan minimal ${questionsPerParticipant} soal unik yang sesuai cabang, jenjang, dan babak, namun hanya tersedia ${partEligibleQuestions.length} soal di dalam pool.`
        };
      }
    }

    const generatedResults: {
      participantId: string;
      participantName: string;
      questionIds: string[];
      questionTitles: string[];
    }[] = [];

    const batchUsedQuestionIds = new Set<string>();

    for (const part of targetParticipants) {
      const partEligibleQuestions = questions.filter((q) => {
        if (q.tenantId !== currentTenantId) return false;
        if (explicitPoolSet && !explicitPoolSet.has(q.id)) return false;
        return validateMaqraAssignmentForParticipant(part, q, stageName, []).valid;
      });

      const existingPartQIds = new Set(
        (part.assignedQuestions || [])
          .filter((aq) => !aq.stageName || aq.stageName === stageName)
          .map((aq) => aq.questionId)
      );

      let candidatePool = partEligibleQuestions.filter((q) => !existingPartQIds.has(q.id));
      if (candidatePool.length < questionsPerParticipant) {
        candidatePool = partEligibleQuestions;
      }

      const unusedInBatch = candidatePool.filter((q) => !batchUsedQuestionIds.has(q.id));
      const pool = unusedInBatch.length >= questionsPerParticipant ? unusedInBatch : candidatePool;

      // Unbiased Fisher-Yates Shuffle
      const shuffled = fisherYatesShuffle(pool);
      const picked = shuffled.slice(0, questionsPerParticipant);

      picked.forEach((q) => batchUsedQuestionIds.add(q.id));

      generatedResults.push({
        participantId: part.id,
        participantName: part.name,
        questionIds: picked.map((q) => q.id),
        questionTitles: picked.map((q) => q.title)
      });
    }

    const commitRes = commitLotteryDrawResults(generatedResults, stageName, {
      branchName,
      levelName,
      questionPoolIds:
        questionPoolIds && questionPoolIds.length > 0
          ? questionPoolIds
          : Array.from(new Set(generatedResults.flatMap((r) => r.questionIds))),
      questionsPerParticipant,
      notes
    });

    return {
      success: commitRes.success,
      message: commitRes.message,
      results: generatedResults,
      drawLog: commitRes.drawLog
    };
  };

  const drawLotteryServer = async (options: {
    stageName: string;
    branchName?: string;
    levelName?: string;
    participantIds: string[];
    questionPoolIds?: string[];
    questionsPerParticipant: number;
    drawMode?: 'lottery_number' | 'maqra' | 'both';
    notes?: string;
  }) => {
    const {
      stageName,
      branchName,
      levelName,
      participantIds,
      questionPoolIds,
      questionsPerParticipant,
      drawMode = 'both',
      notes
    } = options;

    const targetParticipants = participants.filter(
      (p) => participantIds.includes(p.id) && p.tenantId === currentTenantId
    );
    if (targetParticipants.length === 0) {
      return {
        success: false,
        message: 'Tidak ada peserta yang dipilih untuk diundi.'
      };
    }

    // Validasi status verifikasi berkas peserta
    const unverifiedPart = targetParticipants.find(
      (p) => p.verificationStatus && p.verificationStatus !== 'Diverifikasi'
    );
    if (unverifiedPart) {
      return {
        success: false,
        message: `PARTICIPANT_NOT_VERIFIED: Peserta "${unverifiedPart.name}" (${unverifiedPart.participantId}) belum diverifikasi berkasnya (status: ${unverifiedPart.verificationStatus}).`
      };
    }

    // Validasi penguncian undian jika penilaian sudah berjalan pada babak ini
    const targetIdsSet = new Set(targetParticipants.map((p) => p.id));
    const hasStartedAssessments = assessments.some(
      (a) =>
        a.tenantId === currentTenantId &&
        a.stageName === stageName &&
        targetIdsSet.has(a.participantId)
    );
    if (hasStartedAssessments) {
      return {
        success: false,
        message: `STAGE_ASSESSMENTS_ALREADY_STARTED: Undian pada Babak ${stageName} telah dikunci karena penilaian dewan hakim sudah berjalan.`
      };
    }

    const targetStageObj =
      stages.find(
        (s) =>
          s.tenantId === currentTenantId &&
          s.name === stageName &&
          (!branchName || branchName === 'Semua Cabang' || s.branchName === branchName)
      ) || stages.find((s) => s.tenantId === currentTenantId && s.name === stageName);
    const stageId = targetStageObj?.id || toDeterministicUuid('stage-penyisihan');
    const resolvedBranchName = branchName || targetParticipants[0]?.branchName || 'Semua Cabang';
    const matchedBranchObj = cabangList.find((c) => c.name === resolvedBranchName);
    const matchedLevelObj = levelName ? jenjangList.find((j) => j.name === levelName) : undefined;

    if (isLiveDbActive) {
      const rpcRes = await supabaseDataService.drawLotteryServerRpc({
        tenantId: toDeterministicUuid(currentTenantId),
        stageId: toDeterministicUuid(stageId),
        branchId: matchedBranchObj ? toDeterministicUuid(matchedBranchObj.id) : null,
        levelId: matchedLevelObj ? toDeterministicUuid(matchedLevelObj.id) : null,
        questionsPerParticipant,
        drawMode,
        notes: notes || null,
        participantIds: targetParticipants.map((p) => toDeterministicUuid(p.id)),
        questionPoolIds: questionPoolIds?.map((qid) => toDeterministicUuid(qid))
      });

      if (!rpcRes.success) {
        return {
          success: false,
          message: rpcRes.message || 'Gagal menjalankan undian server.'
        };
      }

      const rpcData = (rpcRes.data || {}) as {
        draw_log_id?: string;
        draw_version?: number;
        draw_mode?: 'lottery_number' | 'maqra' | 'both';
        seed_hex?: string;
        seed_sha256?: string;
        results?: LotteryDrawResultItem[];
      };

      const serverResults = Array.isArray(rpcData.results) ? rpcData.results : [];
      const nowTime = getWibTime();

      // Sinkronkan state lokal dari hasil server
      const resultMap = new Map<string, LotteryDrawResultItem>();
      serverResults.forEach((r) => {
        resultMap.set(String(r.participantId), r);
      });

      setParticipants((prev) =>
        prev.map((p) => {
          const r = resultMap.get(toDeterministicUuid(p.id)) || resultMap.get(p.id);
          if (p.tenantId !== currentTenantId || !r) return p;

          const nextLottery =
            (drawMode === 'lottery_number' || drawMode === 'both') && r.lotteryNumber
              ? r.lotteryNumber
              : p.lotteryNumber;

          if (drawMode === 'lottery_number') {
            return { ...p, lotteryNumber: nextLottery };
          }

          const newMaqraItems: AssignedMaqraItem[] = (r.assignedQuestionIds || [])
            .map((qid) => {
              const q = questions.find(
                (item) =>
                  item.tenantId === currentTenantId &&
                  (toDeterministicUuid(item.id) === qid || item.id === qid)
              );
              if (!q) return null;
              return {
                id: generateUuid(),
                questionId: q.id,
                code: q.code,
                title: q.title,
                surahName: q.surahName,
                surahNumber: q.surahNumber,
                startAyah: q.startAyah,
                endAyah: q.endAyah,
                pageNumber: q.pageNumber,
                pageStart: q.pageStart || q.pageNumber,
                pageEnd: q.pageEnd || q.pageNumber,
                pageNumbers: q.pageNumbers || [q.pageNumber],
                assignedAt: nowTime,
                stageName
              } as AssignedMaqraItem;
            })
            .filter(Boolean) as AssignedMaqraItem[];

          const otherStageItems = (p.assignedQuestions || []).filter(
            (item) => item.questionId !== '' && item.stageName && item.stageName !== stageName
          );
          const combined = [...otherStageItems, ...newMaqraItems];
          const combinedQIds = Array.from(new Set(combined.map((n) => n.questionId)));
          const lastItem = newMaqraItems[newMaqraItems.length - 1] || combined[combined.length - 1];

          return {
            ...p,
            lotteryNumber: nextLottery,
            questionId: lastItem ? lastItem.questionId : p.questionId,
            assignedMaqra:
              newMaqraItems.length === 1
                ? newMaqraItems[0].title
                : newMaqraItems.length > 1
                ? `${newMaqraItems.length} Maqra Ditetapkan`
                : p.assignedMaqra,
            pageNumber: lastItem ? lastItem.pageNumber : p.pageNumber,
            assignedQuestions: combined,
            questionIds: combinedQIds
          };
        })
      );

      setStageParticipations((prev) =>
        prev.map((sp) => {
          const r = resultMap.get(toDeterministicUuid(sp.participantId)) || resultMap.get(sp.participantId);
          if (sp.tenantId !== currentTenantId || sp.stageName !== stageName || !r) return sp;
          const nextLottery =
            (drawMode === 'lottery_number' || drawMode === 'both') && r.lotteryNumber
              ? r.lotteryNumber
              : sp.lotteryNumber;
          if (drawMode === 'lottery_number') {
            return { ...sp, lotteryNumber: nextLottery };
          }
          const newMaqraItems: AssignedMaqraItem[] = (r.assignedQuestionIds || [])
            .map((qid) => {
              const q = questions.find(
                (item) =>
                  item.tenantId === currentTenantId &&
                  (toDeterministicUuid(item.id) === qid || item.id === qid)
              );
              if (!q) return null;
              return {
                id: generateUuid(),
                questionId: q.id,
                code: q.code,
                title: q.title,
                surahName: q.surahName,
                surahNumber: q.surahNumber,
                startAyah: q.startAyah,
                endAyah: q.endAyah,
                pageNumber: q.pageNumber,
                pageStart: q.pageStart || q.pageNumber,
                pageEnd: q.pageEnd || q.pageNumber,
                pageNumbers: q.pageNumbers || [q.pageNumber],
                assignedAt: nowTime,
                stageName
              } as AssignedMaqraItem;
            })
            .filter(Boolean) as AssignedMaqraItem[];
          const lastItem = newMaqraItems[newMaqraItems.length - 1];
          return {
            ...sp,
            lotteryNumber: nextLottery,
            questionId: lastItem ? lastItem.questionId : sp.questionId,
            assignedMaqra:
              newMaqraItems.length === 1
                ? newMaqraItems[0].title
                : newMaqraItems.length > 1
                ? `${newMaqraItems.length} Maqra Ditetapkan`
                : sp.assignedMaqra,
            pageNumber: lastItem ? lastItem.pageNumber : sp.pageNumber,
            assignedQuestions: newMaqraItems.length > 0 ? newMaqraItems : sp.assignedQuestions,
            status:
              newMaqraItems.length > 0 && sp.status === 'Maqra Belum Ditetapkan'
                ? 'Belum Dimulai'
                : sp.status
          };
        })
      );

      const newDrawLog: LotteryDrawLogItem = {
        id: rpcData.draw_log_id || generateUuid(),
        tenantId: currentTenantId,
        stageId: targetStageObj?.id,
        stageName,
        branchId: matchedBranchObj?.id,
        branchName: resolvedBranchName,
        levelId: matchedLevelObj?.id,
        levelName,
        actorId: currentUser.id,
        actorName: `${currentUser.name} (${currentUser.role})`,
        questionsPerParticipant,
        participantIds: targetParticipants.map((p) => p.id),
        questionPoolIds: questionPoolIds || [],
        drawResults: serverResults,
        drawVersion: rpcData.draw_version || 1,
        seedHex: rpcData.seed_hex,
        seedSha256: rpcData.seed_sha256,
        drawMode: rpcData.draw_mode || drawMode,
        notes,
        createdAt: new Date().toISOString()
      };

      setLotteryDrawLogs((prev) => [newDrawLog, ...prev]);

      const formattedResults = serverResults.map((r) => {
        const qTitles = (r.assignedQuestionIds || []).map((qid) => {
          const q = questions.find(
            (item) =>
              item.tenantId === currentTenantId &&
              (toDeterministicUuid(item.id) === qid || item.id === qid)
          );
          return q ? `${q.code} - ${q.title}` : qid;
        });
        return {
          participantId: r.participantId,
          participantName: r.participantName,
          lotteryNumber: r.lotteryNumber,
          questionIds: r.assignedQuestionIds || [],
          questionTitles: qTitles
        };
      });

      return {
        success: true,
        message: rpcRes.message,
        results: formattedResults,
        drawLog: newDrawLog
      };
    }

    // Mode Simulasi Lokal: Bangkitkan CSPRNG seed & SHA-256
    const bytes = new Uint8Array(16);
    if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
      crypto.getRandomValues(bytes);
    } else {
      for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);
    }
    const seedHex = Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
    let seedSha256 = seedHex + seedHex;
    try {
      if (typeof crypto !== 'undefined' && crypto.subtle) {
        const digestBuf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(seedHex));
        seedSha256 = Array.from(new Uint8Array(digestBuf))
          .map((b) => b.toString(16).padStart(2, '0'))
          .join('');
      }
    } catch {
      // Fallback hash
    }

    // Jika mode lottery_number atau both, acak nomor urut tampil
    const lotteryMap = new Map<string, string>();
    if (drawMode === 'lottery_number' || drawMode === 'both') {
      const shuffledParts = fisherYatesShuffle(targetParticipants);
      shuffledParts.forEach((p, idx) => {
        const prefix = (p.branchName || 'MTQ').replace(/[^A-Za-z]/g, '').slice(0, 2).toUpperCase() || 'NP';
        lotteryMap.set(p.id, `${prefix}-${String(idx + 1).padStart(2, '0')}`);
      });

      setParticipants((prev) =>
        prev.map((p) =>
          p.tenantId === currentTenantId && lotteryMap.has(p.id)
            ? { ...p, lotteryNumber: lotteryMap.get(p.id)! }
            : p
        )
      );
      setStageParticipations((prev) =>
        prev.map((sp) =>
          sp.tenantId === currentTenantId && sp.stageName === stageName && lotteryMap.has(sp.participantId)
            ? { ...sp, lotteryNumber: lotteryMap.get(sp.participantId)! }
            : sp
        )
      );
    }

    if (drawMode === 'lottery_number') {
      const prevDrawsCount = lotteryDrawLogs.filter(
        (l) => l.tenantId === currentTenantId && l.stageName === stageName && l.branchName === resolvedBranchName
      ).length;
      const drawResultsAudit: LotteryDrawResultItem[] = targetParticipants.map((p) => ({
        participantId: p.id,
        participantCode: p.participantId,
        participantName: p.name,
        lotteryNumber: lotteryMap.get(p.id) || p.lotteryNumber,
        assignedQuestionIds: (p.assignedQuestions || []).map((q) => q.questionId),
        assignedQuestionCodes: (p.assignedQuestions || []).map((q) => q.code || '')
      }));
      const drawLogEntry: LotteryDrawLogItem = {
        id: generateUuid(),
        tenantId: currentTenantId,
        stageId: targetStageObj?.id,
        stageName,
        branchId: matchedBranchObj?.id,
        branchName: resolvedBranchName,
        levelId: matchedLevelObj?.id,
        levelName,
        actorId: currentUser.id,
        actorName: `${currentUser.name} (${currentUser.role})`,
        questionsPerParticipant: 0,
        participantIds: targetParticipants.map((p) => p.id),
        questionPoolIds: [],
        drawResults: drawResultsAudit,
        drawVersion: prevDrawsCount + 1,
        seedHex,
        seedSha256,
        drawMode: 'lottery_number',
        notes,
        createdAt: new Date().toISOString()
      };
      setLotteryDrawLogs((prev) => [drawLogEntry, ...prev]);

      return {
        success: true,
        message: `Undian nomor tampil berhasil ditetapkan untuk ${targetParticipants.length} peserta pada Babak ${stageName} (Undian #${drawLogEntry.drawVersion}).`,
        results: targetParticipants.map((p) => ({
          participantId: p.id,
          participantName: p.name,
          lotteryNumber: lotteryMap.get(p.id) || p.lotteryNumber,
          questionIds: [],
          questionTitles: []
        })),
        drawLog: drawLogEntry
      };
    }

    const drawRes = conductLotteryDraw({
      stageName,
      branchName,
      levelName,
      participantIds,
      questionPoolIds,
      questionsPerParticipant,
      notes
    });

    if (drawRes.success && drawRes.drawLog) {
      const enrichedLog: LotteryDrawLogItem = {
        ...drawRes.drawLog,
        seedHex,
        seedSha256,
        drawMode,
        drawResults: drawRes.drawLog.drawResults.map((dr) => ({
          ...dr,
          lotteryNumber: lotteryMap.get(dr.participantId) || dr.lotteryNumber
        }))
      };
      setLotteryDrawLogs((prev) =>
        prev.map((l) => (l.id === enrichedLog.id ? enrichedLog : l))
      );
      const rawResults: any[] = 'results' in drawRes && Array.isArray((drawRes as any).results)
        ? (drawRes as any).results
        : [];
      return {
        ...drawRes,
        results: rawResults.map((r: any) => ({
          ...r,
          lotteryNumber: lotteryMap.get(r.participantId)
        })),
        drawLog: enrichedLog
      };
    }

    return drawRes;
  };

  // Jenjang & Cabang Actions (Tenant Scoped)
  const addJenjang = (item: Omit<GenericMasterItem, 'id' | 'tenantId'>) => {
    const newItem: GenericMasterItem = {
      ...item,
      id: generateUuid(),
      tenantId: currentTenantId
    };
    setJenjangList((prev) => [...prev, newItem]);
    if (isLiveDbActive) {
      void supabaseDataService
        .upsertLevel(toDeterministicUuid(currentTenantId), {
          ...newItem,
          id: toDeterministicUuid(newItem.id)
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menyimpan Jenjang: ${res.message}`);
            setJenjangList((prev) => prev.filter((j) => j.id !== newItem.id));
          } else {
            setSyncStatus('Jenjang Tersimpan di Database');
          }
        });
    }
  };

  const updateJenjang = (id: string, updated: Partial<GenericMasterItem>) => {
    const existing = jenjangList.find((j) => j.id === id);
    if (!existing) return;
    const merged: GenericMasterItem = { ...existing, ...updated };
    setJenjangList((prev) =>
      prev.map((j) => (j.id === id ? merged : j))
    );
    if (isLiveDbActive) {
      void supabaseDataService
        .upsertLevel(toDeterministicUuid(currentTenantId), {
          ...merged,
          id: toDeterministicUuid(merged.id)
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Memperbarui Jenjang: ${res.message}`);
            setJenjangList((prev) => prev.map((j) => (j.id === id ? existing : j)));
          } else {
            setSyncStatus('Jenjang Diperbarui di Database');
          }
        });
    }
  };

  const deleteJenjang = (id: string): { success: boolean; message: string; activeCount?: number } => {
    const item = jenjangList.find((j) => j.id === id);
    if (!item) return { success: false, message: 'Jenjang tidak ditemukan.' };

    const usedByParticipants = participants.filter((p) =>
      p.tenantId === currentTenantId && (p.levelName === item.name || item.name.includes(p.levelName) || p.levelName.includes(item.code))
    ).length;

    const usedByQuestions = questions.filter((q) =>
      q.tenantId === currentTenantId && (q.branchAndLevel.includes(item.name) || q.branchAndLevel.includes(item.code))
    ).length;

    const totalActiveRefs = usedByParticipants + usedByQuestions;

    if (totalActiveRefs > 0) {
      return {
        success: false,
        activeCount: totalActiveRefs,
        message: `Jenjang "${item.name}" masih digunakan oleh ${usedByParticipants} peserta dan ${usedByQuestions} soal. Penghapusan langsung dicegah untuk melindungi integritas referensi data.`
      };
    }

    setJenjangList((prev) => prev.filter((j) => j.id !== id));
    if (isLiveDbActive) {
      void supabaseDataService
        .deleteLevel(toDeterministicUuid(currentTenantId), toDeterministicUuid(id))
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menghapus Jenjang: ${res.message}`);
            setJenjangList((prev) => [...prev, item]);
          } else {
            setSyncStatus('Jenjang Dihapus dari Database');
          }
        });
    }
    return { success: true, message: `Jenjang "${item.name}" berhasil dihapus.` };
  };

  const addCabang = (item: Omit<GenericMasterItem, 'id' | 'tenantId'>) => {
    const newItem: GenericMasterItem = {
      ...item,
      id: generateUuid(),
      tenantId: currentTenantId
    };
    setCabangList((prev) => [...prev, newItem]);
    if (isLiveDbActive) {
      void supabaseDataService
        .upsertBranch(toDeterministicUuid(currentTenantId), {
          ...newItem,
          id: toDeterministicUuid(newItem.id)
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menyimpan Cabang: ${res.message}`);
            setCabangList((prev) => prev.filter((c) => c.id !== newItem.id));
          } else {
            setSyncStatus('Cabang Lomba Tersimpan di Database');
          }
        });
    }
  };

  const updateCabang = (id: string, updated: Partial<GenericMasterItem>) => {
    const existing = cabangList.find((c) => c.id === id);
    if (!existing) return;
    const merged: GenericMasterItem = { ...existing, ...updated };
    setCabangList((prev) =>
      prev.map((c) => (c.id === id ? merged : c))
    );
    if (isLiveDbActive) {
      void supabaseDataService
        .upsertBranch(toDeterministicUuid(currentTenantId), {
          ...merged,
          id: toDeterministicUuid(merged.id)
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Memperbarui Cabang: ${res.message}`);
            setCabangList((prev) => prev.map((c) => (c.id === id ? existing : c)));
          } else {
            setSyncStatus('Cabang Lomba Diperbarui di Database');
          }
        });
    }
  };

  const deleteCabang = (id: string): { success: boolean; message: string; activeCount?: number } => {
    const item = cabangList.find((c) => c.id === id);
    if (!item) return { success: false, message: 'Cabang tidak ditemukan.' };

    const usedByParticipants = participants.filter((p) =>
      p.tenantId === currentTenantId && (p.branchName === item.name || item.name.includes(p.branchName))
    ).length;

    const usedByStages = stages.filter((s) =>
      s.tenantId === currentTenantId && (s.branchName === item.name || item.name.includes(s.branchName))
    ).length;

    const usedByQuestions = questions.filter((q) =>
      q.tenantId === currentTenantId && (q.branchAndLevel.includes(item.name) || q.branchAndLevel.includes(item.code))
    ).length;

    const totalActiveRefs = usedByParticipants + usedByStages + usedByQuestions;

    if (totalActiveRefs > 0) {
      return {
        success: false,
        activeCount: totalActiveRefs,
        message: `Cabang "${item.name}" masih digunakan oleh ${usedByParticipants} peserta, ${usedByStages} babak, dan ${usedByQuestions} soal. Penghapusan langsung dicegah untuk melindungi integritas referensi data.`
      };
    }

    setCabangList((prev) => prev.filter((c) => c.id !== id));
    if (isLiveDbActive) {
      void supabaseDataService
        .deleteBranch(toDeterministicUuid(currentTenantId), toDeterministicUuid(id))
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menghapus Cabang: ${res.message}`);
            setCabangList((prev) => [...prev, item]);
          } else {
            setSyncStatus('Cabang Lomba Dihapus dari Database');
          }
        });
    }
    return { success: true, message: `Cabang "${item.name}" berhasil dihapus.` };
  };

  // Error Category Actions
  const updateCategoryDeduction = (categoryId: string, deduction: number) => {
    const existing = errorCategories.find((c) => c.id === categoryId && c.tenantId === currentTenantId);
    if (!existing) return;
    const merged: ErrorCategory = { ...existing, defaultDeduction: deduction };
    setErrorCategories((prev) =>
      prev.map((c) =>
        c.id === categoryId && c.tenantId === currentTenantId ? merged : c
      )
    );
    if (isLiveDbActive) {
      void supabaseDataService
        .upsertErrorCategory({
          ...merged,
          id: toDeterministicUuid(merged.id),
          tenantId: toDeterministicUuid(currentTenantId),
          fieldId: merged.fieldId ? toDeterministicUuid(merged.fieldId) : undefined
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Memperbarui Potongan Nilai: ${res.message}`);
            setErrorCategories((prev) =>
              prev.map((c) => (c.id === categoryId && c.tenantId === currentTenantId ? existing : c))
            );
          }
        });
    }
  };

  const addErrorCategory = (cat: Omit<ErrorCategory, 'id' | 'tenantId'>) => {
    const newCat: ErrorCategory = {
      ...cat,
      id: generateUuid(),
      tenantId: currentTenantId
    };
    setErrorCategories((prev) => [...prev, newCat]);
    if (isLiveDbActive) {
      void supabaseDataService
        .upsertErrorCategory({
          ...newCat,
          id: toDeterministicUuid(newCat.id),
          tenantId: toDeterministicUuid(currentTenantId),
          fieldId: newCat.fieldId ? toDeterministicUuid(newCat.fieldId) : undefined
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menyimpan Kategori Kesalahan: ${res.message}`);
            setErrorCategories((prev) => prev.filter((c) => c.id !== newCat.id));
          } else {
            setSyncStatus('Kategori Kesalahan Tersimpan di Database');
          }
        });
    }
  };

  const updateErrorCategory = (id: string, updated: Partial<ErrorCategory>) => {
    const existing = errorCategories.find((c) => c.id === id && c.tenantId === currentTenantId);
    if (!existing) return;
    const merged: ErrorCategory = {
      ...existing,
      ...updated,
      fieldId: updated.fieldId || existing.fieldId
    };
    setErrorCategories((prev) =>
      prev.map((c) =>
        c.id === id && c.tenantId === currentTenantId ? merged : c
      )
    );
    if (isLiveDbActive) {
      void supabaseDataService
        .upsertErrorCategory({
          ...merged,
          id: toDeterministicUuid(merged.id),
          tenantId: toDeterministicUuid(currentTenantId),
          fieldId: merged.fieldId ? toDeterministicUuid(merged.fieldId) : undefined
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Memperbarui Kategori Kesalahan: ${res.message}`);
            setErrorCategories((prev) =>
              prev.map((c) => (c.id === id && c.tenantId === currentTenantId ? existing : c))
            );
          } else {
            setSyncStatus('Kategori Kesalahan Diperbarui di Database');
          }
        });
    }
  };

  const deleteErrorCategory = (id: string): { success: boolean; message: string } => {
    const existing = errorCategories.find((c) => c.id === id && c.tenantId === currentTenantId);
    if (!existing) {
      return { success: false, message: 'Kategori kesalahan tidak ditemukan.' };
    }

    const usedInFinalized = assessments.some(
      (a) =>
        a.tenantId === currentTenantId &&
        a.status === 'finalized' &&
        ((a.errorCounts?.[existing.code] || 0) > 0 || (a.errorCounts?.[id] || 0) > 0)
    );
    if (usedInFinalized) {
      return {
        success: false,
        message: `Kategori "${existing.name}" (${existing.code}) tidak dapat dihapus karena telah digunakan pada lembar penilaian yang sudah difinalisasi.`
      };
    }

    setErrorCategories((prev) =>
      prev.filter((c) => !(c.id === id && c.tenantId === currentTenantId))
    );

    if (isLiveDbActive) {
      void supabaseDataService
        .deleteErrorCategory(toDeterministicUuid(currentTenantId), toDeterministicUuid(id))
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menghapus Kategori Kesalahan: ${res.message}`);
            setErrorCategories((prev) => [...prev, existing]);
          } else {
            setSyncStatus('Kategori Kesalahan Dihapus dari Database');
          }
        });
    }

    return {
      success: true,
      message: `Kategori kesalahan "${existing.name}" (${existing.code}) berhasil dihapus.`
    };
  };

  // User & Judge Management
  const addUser = async (
    userData: Omit<User, 'id'> & { initialPassword?: string }
  ): Promise<{ success: boolean; message: string }> => {
    const { initialPassword, ...cleanUserData } = userData;
    const newUser: User = {
      ...cleanUserData,
      id: generateUuid(),
      provisioningStatus: isLiveDbActive ? 'Mengundang...' : 'Aktif'
    };
    setUsers((prev) => [...prev.filter((u) => u.id !== newUser.id), newUser]);

    if (isLiveDbActive) {
      const rawTargetTenant =
        newUser.tenantId && newUser.tenantId !== 'platform' && newUser.tenantId !== 'unassigned'
          ? newUser.tenantId
          : isValidUuid(currentTenantId)
          ? currentTenantId
          : tenants[0]?.id || 'platform';
      const targetTenantUuid =
        rawTargetTenant === 'platform' ? 'platform' : toDeterministicUuid(rawTargetTenant);

      setSyncStatus(
        initialPassword
          ? 'Mendaftarkan akun Auth dengan kata sandi & memetakan profil di Supabase...'
          : 'Memetakan profil & mengundang pengguna di Supabase...'
      );
      const res = await supabaseDataService.upsertUserAndMembership({
        tenantId: targetTenantUuid,
        user: newUser,
        initialPassword
      });

      if (!res.success) {
        setSyncStatus(`Perlu Tindakan Admin: ${res.message}`);
        setUsers((prev) =>
          prev.map((u) =>
            u.id === newUser.id
              ? {
                  ...u,
                  id: res.data?.profileId || u.id,
                  provisioningStatus: 'Gagal / Perlu Tindakan Admin',
                  provisioningMessage: res.message
                }
              : u
          )
        );
        return { success: false, message: res.message };
      }

      setSyncStatus(res.message || 'Keanggotaan Pengguna Tersimpan di Database');
      setLastSyncTime(getWibTime());
      setUsers((prev) =>
        prev.map((u) =>
          u.id === newUser.id
            ? {
                ...u,
                id: res.data?.profileId || u.id,
                provisioningStatus: res.data?.provisioningStatus || 'Aktif',
                provisioningMessage: res.message
              }
            : u
        )
      );
      return { success: true, message: res.message };
    }

    return {
      success: true,
      message: 'Pengguna berhasil ditambahkan pada mode simulasi lokal.'
    };
  };

  const updateUser = async (
    id: string,
    updated: Partial<User>
  ): Promise<{ success: boolean; message: string }> => {
    const existing = users.find((u) => u.id === id);
    if (!existing) {
      return { success: false, message: 'Pengguna tidak ditemukan.' };
    }
    const merged: User = {
      ...existing,
      ...updated,
      provisioningStatus: isLiveDbActive ? 'Mengundang...' : existing.provisioningStatus || 'Aktif'
    };
    setUsers((prev) => prev.map((u) => (u.id === id ? merged : u)));

    if (isLiveDbActive) {
      const targetTenantUuid = toDeterministicUuid(
        merged.tenantId && merged.tenantId !== 'platform' ? merged.tenantId : currentTenantId
      );
      setSyncStatus('Memperbarui keanggotaan pengguna di database...');
      const res = await supabaseDataService.upsertUserAndMembership({
        tenantId: targetTenantUuid,
        user: merged
      });

      if (!res.success) {
        setSyncStatus(`Gagal Memperbarui Pengguna: ${res.message}`);
        setUsers((prev) =>
          prev.map((u) =>
            u.id === id
              ? {
                  ...merged,
                  provisioningStatus: 'Gagal / Perlu Tindakan Admin',
                  provisioningMessage: res.message
                }
              : u
          )
        );
        return { success: false, message: res.message };
      }

      setSyncStatus('Profil & Keanggotaan Diperbarui di Database');
      setLastSyncTime(getWibTime());
      setUsers((prev) =>
        prev.map((u) =>
          u.id === id
            ? {
                ...merged,
                id: res.data?.profileId || merged.id,
                provisioningStatus: res.data?.provisioningStatus || 'Aktif',
                provisioningMessage: res.message
              }
            : u
        )
      );
      return { success: true, message: res.message };
    }

    return { success: true, message: 'Data pengguna diperbarui di mode simulasi lokal.' };
  };

  const retryUserProvisioning = async (
    id: string
  ): Promise<{ success: boolean; message: string }> => {
    const existing = users.find((u) => u.id === id);
    if (!existing) {
      return { success: false, message: 'Pengguna tidak ditemukan.' };
    }
    return updateUser(id, { status: existing.status });
  };

  const toggleUserStatus = async (
    id: string
  ): Promise<{ success: boolean; message: string }> => {
    const existing = users.find((u) => u.id === id);
    if (!existing) {
      return { success: false, message: 'Pengguna tidak ditemukan.' };
    }
    if (
      existing.status === 'Aktif' &&
      (currentUser.id === id || (authenticatedProfile && authenticatedProfile.authUserId === id))
    ) {
      return {
        success: false,
        message: 'Anda tidak dapat menonaktifkan akun yang sedang Anda gunakan sendiri.'
      };
    }
    const nextStatus = existing.status === 'Aktif' ? 'Nonaktif' : 'Aktif';
    const merged: User = { ...existing, status: nextStatus };

    setUsers((prev) =>
      prev.map((u) => (u.id === id ? merged : u))
    );

    if (isLiveDbActive) {
      const targetTenantUuid = toDeterministicUuid(
        existing.tenantId && existing.tenantId !== 'platform' ? existing.tenantId : currentTenantId
      );
      setSyncStatus('Memperbarui status akun di database...');
      const res = await supabaseDataService.upsertUserAndMembership({
        tenantId: targetTenantUuid,
        user: merged
      });
      if (!res.success) {
        setSyncStatus(`Gagal Mengubah Status Akun: ${res.message}`);
        setUsers((prev) => prev.map((u) => (u.id === id ? existing : u)));
        return { success: false, message: res.message };
      }
      setSyncStatus(`Status Akun (${nextStatus}) Tersimpan di Database`);
      const statusVerb = nextStatus === 'Nonaktif' ? 'berhasil dinonaktifkan' : 'berhasil diaktifkan';
      return { success: true, message: `Akun "${existing.name}" ${statusVerb}.` };
    }

    const statusVerb = nextStatus === 'Nonaktif' ? 'berhasil dinonaktifkan' : 'berhasil diaktifkan';
    return { success: true, message: `Akun "${existing.name}" ${statusVerb}.` };
  };

  const deleteUser = async (
    id: string
  ): Promise<{ success: boolean; message: string }> => {
    const existing = users.find((u) => u.id === id);
    if (!existing) {
      return { success: false, message: 'Pengguna tidak ditemukan.' };
    }

    // Protection: Cannot delete self
    if (currentUser.id === id || (authenticatedProfile && authenticatedProfile.authUserId === id)) {
      return {
        success: false,
        message: 'Anda tidak dapat menghapus akun yang sedang Anda gunakan saat ini.'
      };
    }

    setUsers((prev) => prev.filter((u) => u.id !== id));

    if (isLiveDbActive) {
      setSyncStatus('Menghapus akun pengguna dari database...');
      const res = await supabaseDataService.deleteUser(id);
      if (!res.success) {
        setSyncStatus(`Gagal Menghapus Pengguna: ${res.message}`);
        setUsers((prev) => [...prev, existing]);
        return { success: false, message: res.message };
      }
      setSyncStatus('Akun Pengguna Berhasil Dihapus');
      return { success: true, message: `Akun "${existing.name}" berhasil dihapus dari platform.` };
    }

    return { success: true, message: `Akun "${existing.name}" berhasil dihapus.` };
  };

  // Tenant Actions (Superadmin)
  const addTenant = async (
    tenantData: Omit<Tenant, 'id'>
  ): Promise<{ success: boolean; message: string }> => {
    const cleanCode = tenantData.code.trim().toUpperCase();
    const duplicateLocal = tenants.find(
      (t) => t.code.trim().toUpperCase() === cleanCode
    );
    if (duplicateLocal) {
      return {
        success: false,
        message: `Kode singkat "${cleanCode}" sudah digunakan oleh penyelenggara "${duplicateLocal.name}". Gunakan kode unik.`
      };
    }

    const newTenant: Tenant = {
      ...tenantData,
      code: cleanCode,
      name: tenantData.name.trim(),
      eventName: tenantData.eventName.trim(),
      region: tenantData.region.trim(),
      id: generateUuid()
    };

    setTenants((prev) => [...prev, newTenant]);

    if (isLiveDbActive) {
      setSyncStatus('Menyimpan penyelenggara baru ke database...');
      const res = await supabaseDataService.upsertTenant(newTenant);
      if (!res.success) {
        setSyncStatus(`Gagal Menyimpan Tenant: ${res.message}`);
        setTenants((prev) => prev.filter((t) => t.id !== newTenant.id));
        return {
          success: false,
          message: `Gagal menyimpan penyelenggara ke database: ${res.message}`
        };
      }
      setSyncStatus('Penyelenggara Baru Tersimpan di Database');
      return {
        success: true,
        message: `Penyelenggara "${newTenant.name}" (${newTenant.code}) berhasil ditambahkan dan disimpan di database.`
      };
    }

    return {
      success: true,
      message: `Penyelenggara "${newTenant.name}" (${newTenant.code}) berhasil ditambahkan.`
    };
  };

  const updateTenant = async (
    id: string,
    updated: Partial<Tenant>
  ): Promise<{ success: boolean; message: string }> => {
    const existing = tenants.find((t) => t.id === id);
    if (!existing) {
      return { success: false, message: 'Penyelenggara MTQ tidak ditemukan.' };
    }
    const cleanCode = (updated.code || existing.code).trim().toUpperCase();
    const duplicateLocal = tenants.find(
      (t) => t.id !== id && t.code.trim().toUpperCase() === cleanCode
    );
    if (duplicateLocal) {
      return {
        success: false,
        message: `Kode singkat "${cleanCode}" sudah digunakan oleh penyelenggara "${duplicateLocal.name}".`
      };
    }

    const merged: Tenant = {
      ...existing,
      ...updated,
      code: cleanCode
    };
    setTenants((prev) => prev.map((t) => (t.id === id ? merged : t)));

    if (isLiveDbActive) {
      setSyncStatus('Memperbarui penyelenggara di database...');
      const res = await supabaseDataService.upsertTenant({
        ...merged,
        id: toDeterministicUuid(merged.id)
      });
      if (!res.success) {
        setSyncStatus(`Gagal Memperbarui Tenant: ${res.message}`);
        setTenants((prev) => prev.map((t) => (t.id === id ? existing : t)));
        return {
          success: false,
          message: `Gagal memperbarui penyelenggara: ${res.message}`
        };
      }
      setSyncStatus('Penyelenggara Diperbarui di Database');
      return {
        success: true,
        message: `Data penyelenggara "${merged.name}" berhasil diperbarui.`
      };
    }

    return {
      success: true,
      message: `Data penyelenggara "${merged.name}" berhasil diperbarui.`
    };
  };

  const toggleTenantStatus = async (
    id: string
  ): Promise<{ success: boolean; message: string }> => {
    const existing = tenants.find((t) => t.id === id);
    if (!existing) {
      return { success: false, message: 'Penyelenggara MTQ tidak ditemukan.' };
    }
    const nextStatus: 'Aktif' | 'Nonaktif' = existing.status === 'Aktif' ? 'Nonaktif' : 'Aktif';
    const merged: Tenant = { ...existing, status: nextStatus };

    setTenants((prev) => prev.map((t) => (t.id === id ? merged : t)));

    if (isLiveDbActive) {
      setSyncStatus(`Memperbarui status MTQ (${nextStatus}) di database...`);
      const res = await supabaseDataService.upsertTenant({
        ...merged,
        id: toDeterministicUuid(merged.id)
      });
      if (!res.success) {
        setSyncStatus(`Gagal Mengubah Status MTQ: ${res.message}`);
        setTenants((prev) => prev.map((t) => (t.id === id ? existing : t)));
        return { success: false, message: res.message };
      }
      setSyncStatus(`Status MTQ (${nextStatus}) Tersimpan di Database`);
      return { success: true, message: `Status penyelenggara "${existing.name}" berhasil diubah menjadi ${nextStatus}.` };
    }

    return { success: true, message: `Status penyelenggara "${existing.name}" berhasil diubah menjadi ${nextStatus}.` };
  };

  const deleteTenant = async (
    id: string
  ): Promise<{ success: boolean; message: string }> => {
    const existing = tenants.find((t) => t.id === id);
    if (!existing) {
      return { success: false, message: 'Penyelenggara MTQ tidak ditemukan.' };
    }

    // Protection: Cannot delete system/platform tenant
    if (existing.id === 'platform' || existing.id === '00000000-0000-0000-0000-000000000000') {
      return { success: false, message: 'Penyelenggara MTQ platform/sistem utama tidak boleh dihapus.' };
    }

    if (currentTenantId === id) {
      setCurrentTenantId('platform');
      setCurrentView('superadmin_tenants');
    }

    setTenants((prev) => prev.filter((t) => t.id !== id));

    if (isLiveDbActive) {
      setSyncStatus('Menghapus penyelenggara MTQ dari database...');
      const res = await supabaseDataService.deleteTenant(toDeterministicUuid(id));
      if (!res.success) {
        setSyncStatus(`Gagal Menghapus MTQ: ${res.message}`);
        setTenants((prev) => [...prev, existing]);
        return { success: false, message: res.message };
      }
      setSyncStatus('Penyelenggara MTQ Berhasil Dihapus');
      return { success: true, message: `Penyelenggara MTQ "${existing.name}" berhasil dihapus dari sistem.` };
    }

    return { success: true, message: `Penyelenggara MTQ "${existing.name}" berhasil dihapus.` };
  };

  // Stage Management (Tenant Scoped)
  const addStage = (stageData: Omit<CompetitionStage, 'id' | 'tenantId'>) => {
    const matchedBranch = cabangList.find(
      (c) => stageData.branchName && (c.name === stageData.branchName || stageData.branchName.includes(c.name))
    );
    const newStage: CompetitionStage = {
      ...stageData,
      id: generateUuid(),
      tenantId: currentTenantId,
      branchId: stageData.branchId || matchedBranch?.id
    };
    setStages((prev) => [...prev, newStage]);
    // P1-04: Keep CompetitionRuleConfig.quotaPerStage synchronized with CompetitionStage.qualificationQuota
    if (typeof newStage.qualificationQuota === 'number') {
      setCompetitionRules((prev) =>
        prev.map((r) => {
          if (r.tenantId !== currentTenantId) return r;
          const matchesBranch =
            !newStage.branchName ||
            newStage.branchName === 'Semua Cabang' ||
            (newStage.branchId && r.branchId && newStage.branchId === r.branchId) ||
            r.branchName === newStage.branchName;
          if (!matchesBranch) return r;
          return {
            ...r,
            quotaPerStage: {
              ...r.quotaPerStage,
              [newStage.name]: newStage.qualificationQuota
            }
          };
        })
      );
    }
    if (isLiveDbActive) {
      setSyncStatus('Menyimpan babak baru ke database...');
      void supabaseDataService
        .upsertStage({
          ...newStage,
          id: toDeterministicUuid(newStage.id),
          tenantId: toDeterministicUuid(currentTenantId),
          branchId: newStage.branchId ? toDeterministicUuid(newStage.branchId) : undefined
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menyimpan Babak: ${res.message}`);
            setStages((prev) => prev.filter((s) => s.id !== newStage.id));
          } else {
            setSyncStatus('Babak Tersimpan di Database');
          }
        });
    }
  };

  const updateStage = (id: string, updated: Partial<CompetitionStage>) => {
    const existing = stages.find((s) => s.id === id && s.tenantId === currentTenantId);
    if (!existing) return;
    // Jangan izinkan perubahan status ke Selesai / isFinalized melalui updateStage biasa
    if (existing.isFinalized) {
      setSyncStatus('Babak yang sudah disahkan bersifat terkunci dan tidak dapat diubah.');
      return;
    }
    const safeUpdated: Partial<CompetitionStage> = {
      ...updated,
      isFinalized: existing.isFinalized,
      status: updated.status === 'Selesai' ? existing.status : updated.status || existing.status
    };
    const merged: CompetitionStage = { ...existing, ...safeUpdated };

    setStages((prev) =>
      prev.map((s) =>
        s.id === id && s.tenantId === currentTenantId ? merged : s
      )
    );
    // P1-04: Keep CompetitionRuleConfig.quotaPerStage synchronized with CompetitionStage.qualificationQuota
    if (typeof merged.qualificationQuota === 'number') {
      setCompetitionRules((prev) =>
        prev.map((r) => {
          if (r.tenantId !== currentTenantId) return r;
          const matchesBranch =
            !merged.branchName ||
            merged.branchName === 'Semua Cabang' ||
            (merged.branchId && r.branchId && merged.branchId === r.branchId) ||
            r.branchName === merged.branchName;
          if (!matchesBranch) return r;
          return {
            ...r,
            quotaPerStage: {
              ...r.quotaPerStage,
              [merged.name]: merged.qualificationQuota
            }
          };
        })
      );
    }
    if (isLiveDbActive) {
      setSyncStatus('Memperbarui konfigurasi babak di database...');
      void supabaseDataService
        .upsertStage({
          ...merged,
          id: toDeterministicUuid(merged.id),
          tenantId: toDeterministicUuid(currentTenantId),
          branchId: merged.branchId ? toDeterministicUuid(merged.branchId) : undefined
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Memperbarui Babak: ${res.message}`);
            setStages((prev) =>
              prev.map((s) => (s.id === id && s.tenantId === currentTenantId ? existing : s))
            );
          } else {
            setSyncStatus('Konfigurasi Babak Diperbarui di Database');
          }
        });
    }
  };

  const deleteStage = (id: string): { success: boolean; message: string } => {
    const existing = stages.find((s) => s.id === id && s.tenantId === currentTenantId);
    if (!existing) {
      return { success: false, message: 'Babak musabaqah tidak ditemukan.' };
    }
    if (existing.isFinalized || existing.status === 'Selesai') {
      return {
        success: false,
        message: `Babak "${existing.name}" sudah disahkan/selesai dan tidak dapat dihapus demi menjaga integritas riwayat nilai.`
      };
    }

    // Cek berapa banyak babak dengan nama & cabang yang sama (untuk mendeteksi babak duplikat/tidak terpakai)
    const siblingStagesWithSameName = stages.filter(
      (s) =>
        s.tenantId === currentTenantId &&
        s.name === existing.name &&
        (!existing.branchName || !s.branchName || s.branchName === existing.branchName)
    );
    const hasDuplicateSiblingStages = siblingStagesWithSameName.length > 1;

    // Jika ada babak duplikat (misal 3 Babak Penyisihan), periksa secara spesifik berdasarkan stageId terlebih dahulu
    const usedInFinalizedAssessments = assessments.some((a) => {
      if (a.tenantId !== currentTenantId || a.status !== 'finalized') return false;
      if (a.stageId) {
        return a.stageId === id || a.stageId === toDeterministicUuid(id);
      }
      if (hasDuplicateSiblingStages) {
        return false;
      }
      return a.stageName === existing.name;
    });

    if (usedInFinalizedAssessments) {
      return {
        success: false,
        message: `Babak "${existing.name}" memiliki lembar penilaian yang sudah difinalisasi dan tidak dapat dihapus.`
      };
    }

    const usedInDirectStageParticipations = stageParticipations.some(
      (sp) =>
        sp.tenantId === currentTenantId &&
        (sp.stageId === id || sp.stageId === toDeterministicUuid(id))
    );
    if (usedInDirectStageParticipations) {
      return {
        success: false,
        message: `Babak "${existing.name}" (${existing.branchName || 'Semua Cabang'}) sedang digunakan oleh peserta terdaftar dan tidak dapat dihapus.`
      };
    }

    setStages((prev) => prev.filter((s) => !(s.id === id && s.tenantId === currentTenantId)));
    setJudgeAssignments((prev) =>
      prev.filter((ja) => !(ja.tenantId === currentTenantId && ja.stageId === id))
    );

    if (isLiveDbActive) {
      setSyncStatus('Menghapus babak musabaqah dari database...');
      void supabaseDataService
        .deleteStage(toDeterministicUuid(currentTenantId), toDeterministicUuid(id))
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menghapus Babak: ${res.message}`);
            setStages((prev) => [...prev, existing]);
          } else {
            setSyncStatus('Babak Musabaqah Dihapus dari Database');
          }
        });
    }

    return {
      success: true,
      message: `Babak "${existing.name}" (${existing.branchName || 'Semua Cabang'}) berhasil dihapus.`
    };
  };

  /**
   * P0: advanceQualifiers() with strict validation:
   * - Verifies all required assessments are complete and finalized
   * - Prevents duplicate stage participation
   * - Scoped strictly to currentTenantId
   * - Documents tie-break override reasons
   * - Supports final stage championship finalization (when nextStageName is empty)
   * - Records complete historical snapshots (score, rank, finalizedAt)
   */
  const advanceQualifiers = async (
    currentStageNameOrParams:
      | string
      | {
          currentStageId?: string;
          currentStageName: string;
          nextStageId?: string;
          nextStageName?: string;
          branchId?: string;
          branchName?: string;
          qualifiedParticipantIds: string[];
          overrideReasons?: Record<string, string>;
          manualOverrides?: Record<string, boolean>;
          tieResolution?: Record<string, number>;
        },
    nextStageNameArg?: string,
    qualifiedParticipantIdsArg?: string[],
    overrideReasonsArg?: Record<string, string>
  ): Promise<{ success: boolean; message: string }> => {
    let currentStageName: string;
    let nextStageName: string = '';
    let qualifiedParticipantIds: string[] = [];
    let overrideReasons: Record<string, string> | undefined = undefined;
    let manualOverridesParam: Record<string, boolean> | undefined = undefined;
    let tieResolutionParam: Record<string, number> | undefined = undefined;
    let branchIdParam: string | undefined = undefined;
    let branchNameParam: string | undefined = undefined;
    let stageIdParam: string | undefined = undefined;

    let nextStageIdParam: string | undefined = undefined;

    if (typeof currentStageNameOrParams === 'object' && currentStageNameOrParams !== null) {
      currentStageName = currentStageNameOrParams.currentStageName;
      nextStageName = currentStageNameOrParams.nextStageName || '';
      nextStageIdParam = currentStageNameOrParams.nextStageId;
      qualifiedParticipantIds = currentStageNameOrParams.qualifiedParticipantIds || [];
      overrideReasons = currentStageNameOrParams.overrideReasons;
      manualOverridesParam = currentStageNameOrParams.manualOverrides;
      tieResolutionParam = currentStageNameOrParams.tieResolution;
      branchIdParam = currentStageNameOrParams.branchId;
      branchNameParam = currentStageNameOrParams.branchName;
      stageIdParam = currentStageNameOrParams.currentStageId;
    } else {
      currentStageName = currentStageNameOrParams;
      nextStageName = nextStageNameArg || '';
      qualifiedParticipantIds = qualifiedParticipantIdsArg || [];
      overrideReasons = overrideReasonsArg;
    }

    // 1. Role check: Only admin/superadmin can finalize stage and advance qualifiers
    if (currentUser.role === 'judge') {
      return {
        success: false,
        message: 'Otorisasi ditolak: Hanya Administrator yang berwenang mengesahkan hasil babak dan meloloskan peserta.'
      };
    }

    // 2. Strict ID-first resolution for currentStg (NO OR-widening when stageIdParam is provided!)
    const currentStg = stages.find((s) => {
      if (s.tenantId !== currentTenantId) return false;
      if (stageIdParam) {
        return s.id === stageIdParam;
      }
      if (s.name !== currentStageName) return false;
      if (branchIdParam && s.branchId) return s.branchId === branchIdParam;
      if (branchNameParam && s.branchName) return s.branchName === branchNameParam;
      return true;
    });

    if (!currentStg) {
      return {
        success: false,
        message: `Babak "${currentStageName}" tidak ditemukan pada tenant ini.`
      };
    }
    if (currentStg.isFinalized) {
      return {
        success: false,
        message: `Babak "${currentStageName}" sudah pernah difinalisasi sebelumnya.`
      };
    }

    const effectiveBranchId = branchIdParam || currentStg.branchId;
    const rawBranchName = branchNameParam || currentStg.branchName;
    const effectiveBranchName =
      rawBranchName && rawBranchName !== 'Semua Cabang' ? rawBranchName : undefined;

    const isFinalChampionship =
      (!nextStageName || nextStageName.trim() === '') && !nextStageIdParam;

    const nextStg = isFinalChampionship
      ? null
      : stages.find((s) => {
          if (s.tenantId !== currentTenantId) return false;
          if (nextStageIdParam) return s.id === nextStageIdParam;
          if (s.name !== nextStageName) return false;
          if (effectiveBranchId && s.branchId) return s.branchId === effectiveBranchId;
          if (effectiveBranchName && s.branchName && s.branchName !== 'Semua Cabang') {
            return s.branchName === effectiveBranchName;
          }
          return true;
        });

    if (!isFinalChampionship && !nextStg) {
      return {
        success: false,
        message: `Babak lanjutan "${nextStageName}" tidak ditemukan pada cabang/tenant ini.`
      };
    }

    if (
      nextStg &&
      effectiveBranchId &&
      nextStg.branchId &&
      nextStg.branchId !== effectiveBranchId
    ) {
      return {
        success: false,
        message: `Ketidaksesuaian cabang: Babak lanjutan "${nextStg.name}" berada pada cabang lomba berbeda.`
      };
    }

    // 3. Find participations for currentStg strictly by stageId (when present) and branch
    const filterStageParts = (matchByIdStrictly: boolean) =>
      stageParticipations.filter((sp) => {
        if (sp.tenantId !== currentTenantId) return false;
        const matchesStage =
          matchByIdStrictly && currentStg.id && sp.stageId
            ? sp.stageId === currentStg.id
            : sp.stageName === currentStageName;
        if (!matchesStage) return false;
        const partObj = participants.find((p) => p.id === sp.participantId && p.tenantId === currentTenantId);
        const spBranchId = sp.branchId || partObj?.branchId;
        const spBranchName =
          (sp.branchName && sp.branchName !== 'Semua Cabang' ? sp.branchName : partObj?.branchName) ||
          sp.branchName;
        if (effectiveBranchId && spBranchId) return spBranchId === effectiveBranchId;
        if (effectiveBranchName && spBranchName && spBranchName !== 'Semua Cabang') {
          return spBranchName === effectiveBranchName;
        }
        return true;
      });

    let stageParts = filterStageParts(true);
    if (stageParts.length === 0) {
      stageParts = filterStageParts(false);
    }

    if (stageParts.length === 0) {
      return {
        success: false,
        message: `Tidak ada peserta aktif di Babak ${currentStageName}.`
      };
    }

    // 4. Validate that every participant in qualifiedParticipantIds belongs to this stage & branch
    const stageParticipantIdSet = new Set(stageParts.map((sp) => sp.participantId));
    for (const qPid of qualifiedParticipantIds) {
      if (!stageParticipantIdSet.has(qPid)) {
        return {
          success: false,
          message: `Finalisasi ditolak: Peserta dengan ID "${qPid}" tidak terdaftar pada Babak ${currentStageName} di cabang ini.`
        };
      }
    }

    const effectiveEvalStageId =
      stageIdParam && stageParts.some((sp) => sp.stageId === currentStg.id)
        ? currentStg.id
        : undefined;

    // 5. P1-05: First evaluate automatic rankings (without overrides) so we only mark actual deviations or explicit manualOverrides as overridden
    const baseEvalResult = RankingService.evaluateStageParticipants({
      tenantId: currentTenantId,
      stageId: effectiveEvalStageId,
      stageName: currentStageName,
      branchId: effectiveBranchId,
      branchName: effectiveBranchName,
      participations: stageParts,
      participants,
      assessments,
      judgeAssignments,
      stageQuestionsGetter: getParticipantStageQuestions,
      quota: currentStg.qualificationQuota || 3,
      manualOverrides: {},
      overrideReasons: {},
      customRuleConfigs: competitionRules,
      customRubricVersions: rubricVersions
    });

    const autoQualifiedIdsSet = new Set(
      baseEvalResult.evaluatedParticipants.filter((p) => p.isQualified).map((p) => p.participant.id)
    );
    const manualOverridesMap: Record<string, boolean> = manualOverridesParam
      ? { ...manualOverridesParam }
      : stageParts.reduce<Record<string, boolean>>((acc, sp) => {
          const isSelectedAsQualified = qualifiedParticipantIds.includes(sp.participantId);
          const wasAutoQualified = autoQualifiedIdsSet.has(sp.participantId);
          const hasExplicitReason = Boolean(overrideReasons?.[sp.participantId]?.trim());
          if (isSelectedAsQualified !== wasAutoQualified || hasExplicitReason) {
            acc[sp.participantId] = isSelectedAsQualified;
          }
          return acc;
        }, {});

    // 6. Evaluate stage participants via centralized RankingService (checks judgeAssignments, assessments, tie-break config, quota, overrides)
    const evalResult = RankingService.evaluateStageParticipants({
      tenantId: currentTenantId,
      stageId: effectiveEvalStageId,
      stageName: currentStageName,
      branchId: effectiveBranchId,
      branchName: effectiveBranchName,
      participations: stageParts,
      participants,
      assessments,
      judgeAssignments,
      stageQuestionsGetter: getParticipantStageQuestions,
      quota: currentStg.qualificationQuota,
      manualOverrides: manualOverridesMap,
      overrideReasons,
      customRuleConfigs: competitionRules,
      customRubricVersions: rubricVersions
    });

    if (!evalResult.canFinalize) {
      return {
        success: false,
        message: `Finalisasi Babak Ditolak: ${evalResult.blockingReason || 'Terdapat kondisi kompetisi yang belum memenuhi syarat pengesahan.'}`
      };
    }

    const finalQualifiedIds = evalResult.evaluatedParticipants
      .filter((item) => item.isQualified)
      .map((item) => item.participant.id);

    if (!isFinalChampionship) {
      const alreadyAdvanced = stageParticipations.some(
        (sp) =>
          sp.tenantId === currentTenantId &&
          (nextStg?.id && sp.stageId ? sp.stageId === nextStg.id : sp.stageName === nextStageName) &&
          finalQualifiedIds.includes(sp.participantId)
      );
      if (alreadyAdvanced) {
        return {
          success: false,
          message: `Sebagian peserta yang dipilih sudah terdaftar di Babak ${nextStageName}.`
        };
      }
    }

    const scoreMap: Record<string, { score: number; rank: number; tieBreakResolvedBy?: string; isQualified: boolean }> = {};
    evalResult.evaluatedParticipants.forEach((item) => {
      scoreMap[item.participant.id] = {
        score: item.displayScore || 0,
        rank: item.rank,
        tieBreakResolvedBy: item.tieBreakResolvedBy,
        isQualified: item.isQualified
      };
    });

    // Buat objek snapshot hasil babak (disimpan ke state HANYA setelah transaksi RPC berhasil)
    const maxChamp = currentStg.championCount || 3;
    const stageSnapshot = RankingService.createStageResultSnapshot({
      tenantId: currentTenantId,
      stageId: currentStg.id,
      stageName: currentStageName,
      branchId: effectiveBranchId,
      branchName: effectiveBranchName || 'Cabang Terpadu',
      quota: currentStg.qualificationQuota,
      championCount: maxChamp,
      isFinalChampionship,
      finalizedBy: `${currentUser.name} (${currentUser.role})`,
      evaluatedParticipants: evalResult.evaluatedParticipants,
      customRuleConfigs: competitionRules
    });

    // 7. Execute Server RPC Transaction FIRST (including final championship where nextStageId = null!)
    const isServerCommit =
      supabaseDataService.isLive() && connectionInfo.isDatabaseReady && connectionInfo.isAuthenticated;
    if (isServerCommit) {
      setSyncStatus('Mengesahkan hasil babak di server...');
      const rpcRankingsSnapshot = stageSnapshot.rankings.map((entry) => ({
        ...entry,
        participant_id: toDeterministicUuid(entry.participantId),
        final_score: entry.totalScore,
        rank: entry.rank,
        champion_rank: entry.championRank ?? null,
        champion_title: entry.championTitle ?? null,
        is_qualified: entry.isQualified
      }));

      const rpcRes = await supabaseDataService.advanceStageQualifiersRpc({
        stageId: toDeterministicUuid(currentStg.id),
        nextStageId: isFinalChampionship ? null : nextStg ? toDeterministicUuid(nextStg.id) : null,
        qualifiedParticipantIds: finalQualifiedIds.map((id) => toDeterministicUuid(id)),
        overrideReasons: Object.fromEntries(
          Object.entries(overrideReasons || {}).map(([k, v]) => [toDeterministicUuid(k), v])
        ),
        rankingsSnapshot: rpcRankingsSnapshot,
        tieResolution: Object.fromEntries(
          Object.entries(tieResolutionParam || {}).map(([k, v]) => [toDeterministicUuid(k), v])
        )
      });

      if (!rpcRes.success) {
        setSyncStatus('Gagal Mengesahkan Babak di Database');
        const isMigrationNeeded = rpcRes.message?.includes('v_next_stage') || rpcRes.message?.includes('v_rule');
        const errMsg = isMigrationNeeded
          ? `Pengesahan babak di database ditolak: ${rpcRes.message}. Silakan jalankan file migrasi terbaru (supabase/migrations/20261114_audit_fixes.sql) di SQL Editor Supabase Anda.`
          : `Pengesahan babak di database ditolak: ${rpcRes.message}`;
        addNotification({
          title: 'Pengesahan Babak Ditolak',
          message: errMsg,
          type: 'error',
          module: 'Babak'
        });
        return {
          success: false,
          message: errMsg
        };
      }
    }

    // 8. Commit local state AFTER server transaction succeeded.
    // Mode live: snapshot resmi dibuat server; muat ulang dari database (bukan snapshot hitungan browser).
    if (isServerCommit) {
      void refreshSupabaseConnection();
    } else {
      setStageSnapshots((prev) => [...prev.filter((s) => s.id !== stageSnapshot.id), stageSnapshot]);
    }

    const nowTime = getWibTime();
    const quota = currentStg.qualificationQuota;
    const stagePartIds = new Set(stageParts.map((sp) => sp.id));

    addNotification({
      title: `Babak ${currentStageName} Berhasil Disahkan`,
      message: `Hasil kualifikasi Babak ${currentStageName} (${currentStg.branchName || 'Semua Cabang'}) telah disahkan oleh ${currentUser.name}.`,
      type: 'success',
      module: 'Babak'
    });

    if (isFinalChampionship) {
      // FINAL STAGE CHAMPIONSHIP FINALIZATION FLOW
      setStages((prev) =>
        prev.map((s) => {
          if (s.id === currentStg.id && s.tenantId === currentTenantId) {
            return {
              ...s,
              isFinalized: true,
              status: 'Selesai',
              finalizedAt: nowTime,
              finalizedBy: currentUser.name
            };
          }
          return s;
        })
      );

      setStageParticipations((prev) =>
        prev.map((sp) => {
          if (stagePartIds.has(sp.id)) {
            const data = scoreMap[sp.participantId] || { score: 0, rank: 99, isQualified: false };
            const cRank = data.rank <= maxChamp ? data.rank : undefined;
            const cTitle = data.rank <= maxChamp ? `Juara ${data.rank}` : undefined;
            const reason =
              overrideReasons?.[sp.participantId] ||
              cTitle ||
              `Finalis (Peringkat ${data.rank})`;

            return {
              ...sp,
              finalScore: data.score,
              rank: data.rank,
              championRank: cRank,
              championTitle: cTitle,
              isQualified: false,
              qualificationReason: reason,
              finalizedAt: nowTime,
              status: 'Lengkap' as ParticipantProgressStatus
            };
          }
          return sp;
        })
      );

      setParticipants((prev) =>
        prev.map((p) => {
          if (p.tenantId === currentTenantId && stageParticipantIdSet.has(p.id) && scoreMap[p.id]) {
            const data = scoreMap[p.id];
            const cRank = data.rank <= maxChamp ? data.rank : undefined;
            const cTitle = data.rank <= maxChamp ? `Juara ${data.rank}` : undefined;
            const statusLabel = cTitle || `Finalis (Peringkat ${data.rank})`;
            const reason = overrideReasons?.[p.id] || statusLabel;

            const historyEntry = {
              stageId: currentStg.id,
              stageName: currentStageName,
              status: statusLabel,
              score: data.score,
              rank: data.rank,
              championRank: cRank,
              championTitle: cTitle,
              qualified: false,
              reason,
              finalizedAt: nowTime
            };

            return {
              ...p,
              status: 'Final' as const,
              stageHistory: [...(p.stageHistory || []), historyEntry]
            };
          }
          return p;
        })
      );

      const newAudit: AuditLogItem = {
        id: generateUniqueLogId('aud'),
        timestamp: nowTime,
        actor: `${currentUser.name} (${currentUser.role})`,
        action: 'CHAMPIONSHIP_FINALIZED',
        target: `Babak ${currentStageName} (Puncak Kejuaraan)`,
        tenantName: currentTenant.name,
        summary: `Pengesahan resmi pemenang dan kejuaraan Musabaqah Babak ${currentStageName}.`,
        reason:
          Object.keys(overrideReasons || {}).length > 0
            ? JSON.stringify(overrideReasons)
            : undefined,
        outcome: 'Success'
      };
      setAuditLogs((prev) => [newAudit, ...prev.filter((l) => l.id !== newAudit.id)]);

      const newLog: ActivityLogItem = {
        id: generateUniqueLogId('act'),
        tenantId: currentTenantId,
        type: 'stage',
        title: 'Musabaqah Selesai & Juara Disahkan',
        description: `Seluruh rangkaian penilaian Babak ${currentStageName} telah disahkan dan ditetapkan secara resmi.`,
        timestamp: nowTime,
        actorName: currentUser.name
      };
      setActivityLogs((prev) => [newLog, ...prev.filter((l) => l.id !== newLog.id).slice(0, 20)]);

      setSyncStatus(
        supabaseDataService.isLive()
          ? supabaseDataService.getConnectionStatus().statusLabel
          : 'Mode Lokal (Tersimpan di Browser)'
      );
      setLastSyncTime(nowTime);

      return {
        success: true,
        message: `Hasil kejuaraan Babak ${currentStageName} berhasil disahkan secara resmi dan musabaqah dinyatakan selesai.`
      };
    }

    // STANDARD ADVANCEMENT TO NEXT STAGE
    // 1. Mark current stage as finalized and activate next stage
    setStages((prev) =>
      prev.map((s) => {
        if (s.id === currentStg.id && s.tenantId === currentTenantId) {
          return {
            ...s,
            isFinalized: true,
            status: 'Selesai',
            finalizedAt: nowTime,
            finalizedBy: currentUser.name
          };
        }
        if (nextStg && s.id === nextStg.id && s.tenantId === currentTenantId) {
          return { ...s, status: 'Aktif' };
        }
        return s;
      })
    );

    // 2. Update existing stageParticipations strictly for stagePartIds and create new ones for nextStg
    const newParticipations: StageParticipation[] = [];

    setStageParticipations((prev) => {
      const updated = prev.map((sp) => {
        if (stagePartIds.has(sp.id)) {
          const data = scoreMap[sp.participantId] || { score: 0, rank: 99, isQualified: false };
          const isQual = data.isQualified;
          const reason =
            overrideReasons?.[sp.participantId] ||
            (isQual ? `Lolos kuota Top ${quota}` : 'Tidak memenuhi kuota kelulusan');
          return {
            ...sp,
            finalScore: data.score,
            rank: data.rank,
            isQualified: isQual,
            qualificationReason: reason,
            finalizedAt: nowTime
          };
        }
        return sp;
      });

      finalQualifiedIds.forEach((pId) => {
        const part = participants.find((p) => p.id === pId && p.tenantId === currentTenantId);
        if (part && nextStg) {
          newParticipations.push({
            id: generateUuid(),
            tenantId: currentTenantId,
            participantId: part.id,
            stageId: nextStg.id,
            stageName: nextStg.name,
            branchId: part.branchId || nextStg.branchId,
            branchName: part.branchName,
            lotteryNumber: part.lotteryNumber,
            questionId: '',
            assignedMaqra: 'Belum Ditetapkan',
            pageNumber: 1,
            assignedQuestions: [],
            status: 'Maqra Belum Ditetapkan'
          });
        }
      });

      return [...updated, ...newParticipations];
    });

    // 3. Update participants records strictly for stageParticipantIdSet
    setParticipants((prev) =>
      prev.map((p) => {
        if (p.tenantId === currentTenantId && stageParticipantIdSet.has(p.id)) {
          const data = scoreMap[p.id];
          if (finalQualifiedIds.includes(p.id)) {
            const historyEntry = {
              stageId: currentStg.id,
              stageName: currentStageName,
              status: 'Lolos ke ' + nextStageName,
              score: data?.score,
              rank: data?.rank,
              qualified: true,
              reason: overrideReasons?.[p.id] || `Lolos kuota Top ${quota}`,
              finalizedAt: nowTime
            };
            return {
              ...p,
              stageName: nextStageName,
              status: 'Menunggu',
              stageHistory: [...(p.stageHistory || []), historyEntry],
              questionId: '',
              assignedMaqra: 'Belum Ditetapkan',
              assignedQuestions: [],
              questionIds: []
            };
          } else {
            const historyEntry = {
              stageId: currentStg.id,
              stageName: currentStageName,
              status: 'Gugur di ' + currentStageName,
              score: data?.score,
              rank: data?.rank,
              qualified: false,
              reason: overrideReasons?.[p.id] || 'Tidak memenuhi kuota kelulusan',
              finalizedAt: nowTime
            };
            return {
              ...p,
              status: 'Gugur',
              stageHistory: [...(p.stageHistory || []), historyEntry]
            };
          }
        }
        return p;
      })
    );

    // 4. Audit Log Entry
    const newAudit: AuditLogItem = {
      id: generateUniqueLogId('aud'),
      timestamp: nowTime,
      actor: `${currentUser.name} (${currentUser.role})`,
      action: 'STAGE_QUALIFICATION_ADVANCE',
      target: `Babak ${currentStageName} ➔ ${nextStageName}`,
      tenantName: currentTenant.name,
      summary: `Finalisasi Babak ${currentStageName} dan pelolosan resmi ${finalQualifiedIds.length} peserta ke Babak ${nextStageName}.`,
      reason:
        Object.keys(overrideReasons || {}).length > 0
          ? JSON.stringify(overrideReasons)
          : undefined,
      outcome: 'Success'
    };
    setAuditLogs((prev) => [newAudit, ...prev.filter((l) => l.id !== newAudit.id)]);

    setSyncStatus(
      supabaseDataService.isLive()
        ? supabaseDataService.getConnectionStatus().statusLabel
        : 'Mode Lokal (Tersimpan di Browser)'
    );
    setLastSyncTime(nowTime);

    return {
      success: true,
      message: `Berhasil memfinalisasi Babak ${currentStageName} dan meloloskan ${finalQualifiedIds.length} peserta ke Babak ${nextStageName}.`
    };
  };

  // Judge Assignment Actions (Tenant Scoped)
  const addJudgeAssignment = (asg: Omit<JudgeAssignment, 'id' | 'tenantId'>) => {
    const matchedStage = stages.find(
      (s) => s.tenantId === currentTenantId && s.name === asg.stageName
    ) || stages.find((s) => s.tenantId === currentTenantId);

    const matchedBranch = cabangList.find(
      (c) =>
        (c.tenantId === currentTenantId || !c.tenantId) &&
        asg.branchName &&
        (c.name === asg.branchName || asg.branchName.includes(c.name) || c.name.includes(asg.branchName))
    );

    let resolvedRubricFieldId = asg.rubricFieldId || asg.judgeFieldId;
    if (!resolvedRubricFieldId && asg.judgeField) {
      for (const rv of rubricVersions) {
        const matchedFld = rv.fields.find(
          (f) =>
            asg.judgeField.toLowerCase().includes(f.name.toLowerCase()) ||
            f.name.toLowerCase().includes(asg.judgeField.toLowerCase())
        );
        if (matchedFld) {
          resolvedRubricFieldId = matchedFld.id;
          break;
        }
      }
    }

    const resolvedStageId = asg.stageId || matchedStage?.id || 'stage-penyisihan';
    const resolvedBranchId = asg.branchId || matchedBranch?.id;
    const resolvedLevelId = asg.levelId;

    const newAsg: JudgeAssignment = {
      ...asg,
      id: generateUuid(),
      tenantId: currentTenantId,
      stageId: resolvedStageId,
      ...(resolvedBranchId ? { branchId: resolvedBranchId } : {}),
      ...(resolvedLevelId ? { levelId: resolvedLevelId } : {}),
      ...(resolvedRubricFieldId ? { rubricFieldId: resolvedRubricFieldId, judgeFieldId: resolvedRubricFieldId } : {})
    };
    setJudgeAssignments((prev) => [...prev, newAsg]);
    if (isLiveDbActive) {
      setSyncStatus('Menyimpan penugasan hakim ke database...');
      void supabaseDataService
        .upsertJudgeAssignment({
          ...newAsg,
          tenantId: toDeterministicUuid(currentTenantId),
          stageId: toDeterministicUuid(resolvedStageId),
          branchId: resolvedBranchId ? toDeterministicUuid(resolvedBranchId) : undefined,
          levelId: resolvedLevelId ? toDeterministicUuid(resolvedLevelId) : undefined,
          rubricFieldId: resolvedRubricFieldId ? toDeterministicUuid(resolvedRubricFieldId) : undefined,
          judgeFieldId: resolvedRubricFieldId ? toDeterministicUuid(resolvedRubricFieldId) : undefined,
          judgeId: toDeterministicUuid(newAsg.judgeId)
        })
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menyimpan Penugasan Hakim: ${res.message}`);
            setJudgeAssignments((prev) => prev.filter((ja) => ja.id !== newAsg.id));
          } else {
            setSyncStatus('Penugasan Hakim Tersimpan di Database');
            setLastSyncTime(getWibTime());
          }
        });
    }
  };

  const removeJudgeAssignment = (id: string) => {
    const existing = judgeAssignments.find((ja) => ja.id === id && ja.tenantId === currentTenantId);
    setJudgeAssignments((prev) =>
      prev.filter((ja) => ja.id !== id || ja.tenantId !== currentTenantId)
    );
    if (isLiveDbActive && existing) {
      setSyncStatus('Menghapus penugasan hakim dari database...');
      void supabaseDataService
        .deleteJudgeAssignment(toDeterministicUuid(currentTenantId), toDeterministicUuid(id))
        .then((res) => {
          if (!res.success) {
            setSyncStatus(`Gagal Menghapus Penugasan Hakim: ${res.message}`);
            setJudgeAssignments((prev) => [...prev, existing]);
          } else {
            setSyncStatus('Penugasan Hakim Dihapus dari Database');
            setLastSyncTime(getWibTime());
          }
        });
    }
  };

  const [siteSettings, setSiteSettings] = useState<SiteSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PREFIX + 'site_settings');
      if (saved) {
        return { ...DEFAULT_SITE_SETTINGS, ...JSON.parse(saved), id: 'global' };
      }
    } catch {
      // Fallback to default
    }
    return { ...DEFAULT_SITE_SETTINGS };
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_PREFIX + 'site_settings', JSON.stringify(siteSettings));
    } catch {
      // Ignore storage quota errors
    }
  }, [siteSettings]);

  useEffect(() => {
    if (isLiveDbActive) {
      void supabaseDataService.fetchSiteSettings().then((res) => {
        if (res.success && res.data) {
          setSiteSettings(res.data);
        }
      });
    }
  }, [isLiveDbActive]);

  const updateSiteSettings = async (
    updates: Partial<SiteSettings>
  ): Promise<{ success: boolean; message: string }> => {
    if (currentUser.role !== 'superadmin') {
      return {
        success: false,
        message: 'Akses ditolak: Hanya Superadmin yang dapat memperbarui Pengaturan SEO & Meta.'
      };
    }

    const nextSettings: SiteSettings = {
      ...siteSettings,
      ...updates,
      id: 'global'
    };

    if (nextSettings.defaultTitle.trim().length > 70) {
      return {
        success: false,
        message: 'Judul Bawaan (Default Title) maksimal 70 karakter.'
      };
    }
    if (nextSettings.metaDescription.trim().length > 200) {
      return {
        success: false,
        message: 'Deskripsi Meta maksimal 200 karakter.'
      };
    }
    if (!/^https:\/\//.test(nextSettings.canonicalUrl.trim())) {
      return {
        success: false,
        message: 'Canonical URL wajib diawali dengan https://'
      };
    }
    if (!/^https:\/\//.test(nextSettings.ogImageUrl.trim())) {
      return {
        success: false,
        message: 'URL Gambar Open Graph wajib diawali dengan https://'
      };
    }

    const changedKeys = (Object.keys(updates) as (keyof SiteSettings)[]).filter(
      (k) => k !== 'updatedAt' && k !== 'updatedBy' && updates[k] !== siteSettings[k]
    );

    if (isLiveDbActive) {
      const res = await supabaseDataService.updateSiteSettings(updates);
      if (!res.success) {
        return { success: false, message: res.message };
      }
      if (res.data) {
        setSiteSettings(res.data);
      }
    } else {
      const nowWib = getWibTime();
      const updatedLocal: SiteSettings = {
        ...nextSettings,
        updatedBy: currentUser.id,
        updatedAt: `18 Nov 2026 ${nowWib}`
      };
      setSiteSettings(updatedLocal);
    }

    const changedColsSummary =
      changedKeys.length > 0 ? changedKeys.join(', ') : 'updated_at';

    setAuditLogs((prev) => [
      {
        id: generateUniqueLogId('aud'),
        timestamp: `18 Nov 2026 ${getWibTime()}`,
        actor: `${currentUser.name} (${currentUser.role})`,
        action: 'SITE_SETTINGS_UPDATED',
        target: 'Pengaturan Situs & SEO (global)',
        tenantName: 'Platform Global',
        summary: `Memperbarui pengaturan SEO & meta situs. Kolom berubah: ${changedColsSummary}`,
        outcome: 'Success'
      },
      ...prev
    ]);

    setSyncStatus('Pengaturan SEO & Meta Disimpan');
    setLastSyncTime(getWibTime());

    return {
      success: true,
      message: 'Pengaturan SEO & Meta situs berhasil diperbarui dan tercatat pada log audit.'
    };
  };

  return (
    <MtqContext.Provider
      value={{
        tenants,
        currentTenant,
        setTenantId: setCurrentTenantId,
        addTenant,
        updateTenant,
        toggleTenantStatus,
        deleteTenant,
        users,
        currentUser,
        setCurrentUserId: setSafeCurrentUserId,
        addUser,
        updateUser,
        retryUserProvisioning,
        toggleUserStatus,
        deleteUser,
        kafilahs: kafilahs.filter((k) => k.tenantId === currentTenantId),
        participants: participants.filter((p) => p.tenantId === currentTenantId),
        stageParticipations: stageParticipations.filter((sp) => sp.tenantId === currentTenantId),
        questions: questions.filter((q) => q.tenantId === currentTenantId),
        errorCategories: errorCategories.filter((c) => c.tenantId === currentTenantId),
        assessments: assessments.filter((a) => a.tenantId === currentTenantId),
        activityLogs: activityLogs.filter((l) => l.tenantId === currentTenantId),
        auditLogs,
        stages: stages.filter((s) => s.tenantId === currentTenantId),
        judgeAssignments: judgeAssignments.filter((ja) => ja.tenantId === currentTenantId),
        jenjangList: jenjangList.filter((j) => j.tenantId === currentTenantId || !j.tenantId),
        cabangList: cabangList.filter((c) => c.tenantId === currentTenantId || !c.tenantId),
        addJenjang,
        updateJenjang,
        deleteJenjang,
        addCabang,
        updateCabang,
        deleteCabang,
        rubricVersions: rubricVersions.filter((r) => r.tenantId === currentTenantId || r.tenantId === 'system'),
        competitionRules: competitionRules.filter((r) => r.tenantId === currentTenantId || r.tenantId === 'system'),
        addRubricVersion,
        updateRubricVersion,
        activateRubricVersion,
        archiveRubricVersion,
        deleteRubricVersion,
        deleteRubricField,
        addCompetitionRule,
        updateCompetitionRule,
        deleteCompetitionRule,
        getActiveRubricForBranch,
        getBranchRuleConfigByBranch,
        currentView,
        setCurrentView,
        isSidebarOpen,
        setIsSidebarOpen,
        toggleSidebar,
        selectedParticipantId,
        setSelectedParticipantId,
        selectedStageName,
        setSelectedStageName,
        monitoringJudgeId,
        setMonitoringJudgeId,
        syncStatus,
        lastSyncTime,
        initializeAssessment,
        updateErrorCount,
        saveAnnotations,
        finalizeAssessment,
        reopenAssessment,
        stageSnapshots,
        lotteryDrawLogs: lotteryDrawLogs.filter((l) => l.tenantId === currentTenantId),
        outboxSummary,
        flushOutboxQueue,
        getJudgeAssessment,
        getParticipantProgress,
        getStageParticipation,
        getParticipantStageQuestions,
        addKafilah,
        updateKafilah,
        deleteKafilah,
        addParticipant,
        updateParticipant,
        deleteParticipant,
        verifyParticipant,
        importParticipantsBatch,
        addQuestion,
        updateQuestion,
        deleteQuestion,
        importQuestionsBatch,
        assignMaqraToParticipant,
        addQuestionToParticipant,
        removeQuestionFromParticipant,
        conductLotteryDraw,
        drawLotteryServer,
        commitLotteryDrawResults,
        updateCategoryDeduction,
        addErrorCategory,
        updateErrorCategory,
        deleteErrorCategory,
        addStage,
        updateStage,
        deleteStage,
        advanceQualifiers,
        addJudgeAssignment,
        removeJudgeAssignment,
        isSuperadminWorkspaceMode,
        enterTenantWorkspace,
        exitTenantWorkspace,
        isDemoAccountModalOpen,
        setIsDemoAccountModalOpen,
        resetPrototypeData,
        connectionInfo,
        authenticatedProfile,
        dataSourceMode,
        workspaceError,
        isOfflineDemoSimulation,
        isLiveSupabaseMode,
        isLiveAccessAuthorized,
        accessGateReason,
        isPasswordRecoveryMode,
        setIsPasswordRecoveryMode,
        enterOfflineDemoSimulation,
        exitOfflineDemoSimulation,
        refreshSupabaseConnection,
        signInWithSupabase,
        signUpWithSupabase,
        signOutSupabase,
        requestPasswordReset,
        completePasswordReset,
        bootstrapFirstSuperadmin,
        siteSettings,
        updateSiteSettings,
        notifications,
        addNotification,
        markAllNotificationsAsRead,
        clearNotifications
      }}
    >
      {children}
    </MtqContext.Provider>
  );
};

export const useMtq = () => {
  const context = useContext(MtqContext);
  if (!context) {
    throw new Error('useMtq must be used within a MtqProvider');
  }
  return context;
};
